"""Pont utilisateur pour exécuter Protocol Vantage depuis Google Colab.

Le module n'expose pas de serveur Flask dans Colab gratuit. Il exécute directement
les points d'entrée de l'application et écrit chaque artefact sur Google Drive.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


def _json_default(value: Any):
    if hasattr(value, 'value'):
        return value.value
    if hasattr(value, '__dict__'):
        return value.__dict__
    return str(value)


def _stable_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, default=_json_default).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=_json_default), encoding='utf-8')


def _course_slug(date: str, reunion: int, numero_course: int, hippodrome: str = '') -> str:
    safe_hippo = ''.join(ch if ch.isalnum() else '_' for ch in (hippodrome or 'course')).strip('_') or 'course'
    return f'{date}_R{int(reunion)}_C{int(numero_course)}_{safe_hippo}'


def run_pre_course(
    drive_root: str | Path,
    date: str,
    reunion: int,
    numero_course: int,
    hippodrome: str = '',
    t_decision: Optional[str] = None,
    enable_live_sources: bool = True,
) -> Tuple[Path, Dict[str, Any]]:
    """Exécute le pré-course et sauvegarde tous les artefacts dans Drive."""
    import os
    os.environ['VANTAGE_PRIORITY_SOURCES_ENABLED'] = '1' if enable_live_sources else '0'

    from collectors.race_resolver import collecter_course_par_identifiants
    from app import _executer_analyse_collectee

    root = Path(drive_root)
    course_dir = root / 'courses' / _course_slug(date, reunion, numero_course, hippodrome)
    pre_dir = course_dir / 'pre_course'
    pre_dir.mkdir(parents=True, exist_ok=True)

    query = {'date': date, 'reunion': int(reunion), 'numero_course': int(numero_course)}
    if hippodrome:
        query['hippodrome'] = hippodrome
    collecte = collecter_course_par_identifiants(query)
    _write_json(pre_dir / '01_collecte_resolue.json', collecte)
    _write_json(pre_dir / '02_rapport_collecte.json', collecte.get('rapport_collecte', {}))
    _write_json(pre_dir / '03_evidence_ledger.json', collecte.get('evidence_ledger', {}))

    if collecte.get('statut') != 'OK':
        _write_json(pre_dir / '00_echec_collecte.json', {
            'saved_at': datetime.now(timezone.utc).isoformat(),
            'query': query,
            'status': collecte.get('statut'),
            'error': collecte.get('erreur_code') or collecte.get('erreur'),
        })
        raise RuntimeError(f"Collecte impossible : {collecte.get('erreur_code') or collecte.get('erreur') or collecte.get('statut')}")

    course, rapport, export_data = _executer_analyse_collectee(collecte, 'AUTO_CONTINUE')
    _write_json(pre_dir / '04_rapport_pre_course.json', rapport)
    _write_json(pre_dir / '05_export_pre_course.json', export_data)

    ticket = export_data.get('ticket_final') or export_data.get('ticket') or {}
    freeze = {
        'mode_test': 'WALK_FORWARD_STRICT',
        'mode_execution': 'AUTO_CONTINUE',
        't_decision': t_decision or datetime.now(timezone.utc).isoformat(),
        'course_identity': {
            'date': course.date,
            'reunion': int(reunion),
            'numero_course': int(numero_course),
            'hippodrome': course.hippodrome,
            'discipline': course.discipline.value if course.discipline else 'NC',
        },
        'policy': {
            'allow_post_race_data_before_freeze': False,
            'post_course_locked_until_explicit_call': True,
            'unproven_effect': 'NONE',
        },
        'ticket': ticket,
        'ticket_hash': _stable_hash(ticket),
        'input_snapshot_hash': _stable_hash({'query': query, 'partants': export_data.get('partants', []), 'collecte': collecte.get('rapport_collecte', {})}),
        'source_ledger_hash': _stable_hash(collecte.get('evidence_ledger', {})),
        'ruleset_hash': _stable_hash({'protocol': 'PROTOCOL_VANTAGE', 'version': 'v1.22.2-test', 'ruleset_gel': '22/07/2026'}),
        'pre_course_only_warning': 'Vérifier que les pages consultées étaient disponibles avant T_DECISION pour un replay historique strict.',
    }
    _write_json(pre_dir / '06_ticket_freeze.json', freeze)
    state = {
        'pre_course_dir': str(pre_dir),
        'course_dir': str(course_dir),
        'course': export_data.get('course', {}),
        'identifiants': collecte.get('resolution', {}).get('identifiants', {}),
        'ticket': ticket,
        'partants': export_data.get('partants', []),
        'json_export_path': str(pre_dir / '05_export_pre_course.json'),
        'freeze_path': str(pre_dir / '06_ticket_freeze.json'),
        'created_at': datetime.now(timezone.utc).isoformat(),
        'post_course_status': 'LOCKED',
    }
    _write_json(pre_dir / '07_pre_course_state.json', state)
    _write_json(course_dir / 'README.json', {
        'course': state['course'],
        'pre_course_dir': str(pre_dir),
        'post_course_status': 'LOCKED',
        'saved_at': datetime.now(timezone.utc).isoformat(),
    })
    return pre_dir, state


def run_post_course(pre_course_dir: str | Path, drive_root: str | Path | None = None) -> Tuple[Path, Dict[str, Any]]:
    """Déverrouille explicitement l'audit post-course sans modifier le pré-course."""
    from collectors.post_course_collector import collecter_resultat_officiel
    from engine.post_course_audit import auditer_post_course

    pre_dir = Path(pre_course_dir)
    state_path = pre_dir / '07_pre_course_state.json'
    if not state_path.exists():
        raise FileNotFoundError(f'Etat pré-course absent : {state_path}')
    state = json.loads(state_path.read_text(encoding='utf-8'))
    identity = state.get('identifiants', {})
    course_data = state.get('course', {})
    date = identity.get('date') or course_data.get('date')
    reunion = int(identity.get('reunion') or identity.get('R') or 0)
    numero_course = int(identity.get('numero_course') or identity.get('course') or course_data.get('numero') or 0)
    if not date or not reunion or not numero_course:
        raise ValueError('Identité insuffisante pour l’audit post-course')

    officiel = collecter_resultat_officiel(
        date, reunion, numero_course,
        discipline=course_data.get('discipline', ''),
        hippodrome=course_data.get('hippodrome', ''),
    )
    pre_course = {
        'course': {'date': date, 'reunion': reunion, 'numero_course': numero_course},
        'ticket': state.get('ticket', {}),
        'partants': state.get('partants', []),
    }
    audit = auditer_post_course(pre_course, officiel, officiel.get('sources_consultees', []))
    post_dir = pre_dir.parent / 'post_course'
    post_dir.mkdir(parents=True, exist_ok=True)
    _write_json(post_dir / '01_resultat_officiel.json', officiel)
    _write_json(post_dir / '02_audit_post_course.json', audit)
    report_path = pre_dir / '08_rapport_execution_integral.json'
    if report_path.exists():
        execution_report = json.loads(report_path.read_text(encoding='utf-8'))
        phases = [phase for phase in execution_report.get('phases', []) if phase.get('name') != 'AUDIT_POST_COURSE']
        phases.append({'sequence': 8, 'name': 'AUDIT_POST_COURSE', 'status': 'PASS' if audit.get('status') == 'AUDIT_COMPLET' else 'BLOCKED', 'data': audit, 'errors': [] if audit.get('status') == 'AUDIT_COMPLET' else [audit.get('warning', 'Consensus officiel insuffisant')]})
        execution_report['phases'] = phases
        execution_report['post_course_audit'] = audit
        _write_json(report_path, execution_report)
    export_path = pre_dir / '05_export_pre_course.json'
    enriched_export = json.loads(export_path.read_text(encoding='utf-8')) if export_path.exists() else {}
    enriched_export['audit_post_course'] = audit
    _write_json(post_dir / '04_export_integral_enrichi_post_course.json', enriched_export)
    _write_json(post_dir / '05_rapport_execution_integral_enrichi.json', execution_report if report_path.exists() else {})
    _write_json(post_dir / '03_post_course_manifest.json', {
        'audited_at': datetime.now(timezone.utc).isoformat(),
        'pre_course_dir': str(pre_dir),
        'pre_course_ticket_hash': json.loads((pre_dir / '06_ticket_freeze.json').read_text(encoding='utf-8')).get('ticket_hash'),
        'post_course_does_not_modify_pre_course': True,
    })
    state['post_course_status'] = 'COMPLETED'
    _write_json(post_dir / '04_pre_course_state_after_audit.json', state)
    return post_dir, audit
