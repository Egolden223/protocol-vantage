"""IIC universel V2 — données observées uniquement.

Le module ne fabrique ni cote, ni snapshot, ni RK. En TROT, l'absence de RK
active le mode IIC_TROT_MARKET_FORM mais ne renseigne jamais Partant.rk_brute.
"""
import math
from typing import Dict, Optional, Tuple

from engine.models import Course, Partant


def _numeric(value) -> Optional[float]:
    try:
        if value in (None, '', 'NC', 'UNPROVEN'):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _market_block(partant: Partant) -> Dict[str, object]:
    market = getattr(partant, 'market_data', {}) or {}
    if not market:
        market = (getattr(partant, 'raw_data', {}) or {}).get('market_data', {}) or {}
    snapshots = market.get('sov_snapshots', []) if isinstance(market, dict) else []
    valid_snapshots = [s for s in snapshots if isinstance(s, dict) and _numeric(s.get('value')) is not None]
    reference = _numeric(market.get('cote_reference')) if isinstance(market, dict) else None
    direct = _numeric(market.get('cote_avant_course')) if isinstance(market, dict) else None
    return {
        'reference': reference,
        'direct': direct,
        'snapshots': valid_snapshots,
        'two_snapshots': len(valid_snapshots) >= 2,
        'fluctuation': _numeric(market.get('fluctuation_relative')) if isinstance(market, dict) else None,
    }


def _form_value(partant: Partant) -> Optional[float]:
    raw = getattr(partant, 'raw_data', {}) or {}
    values = raw.get('rangs_6_dernieres', raw.get('rangs_4_dernieres', raw.get('rangs_3_dernieres')))
    if not isinstance(values, (list, tuple)):
        return None
    numeric = [_numeric(value) for value in values]
    numeric = [value for value in numeric if value is not None and value >= 0]
    return sum(numeric) / len(numeric) if len(numeric) >= 3 else None


def _source_disagreement(course: Course) -> Tuple[Optional[float], Dict[str, object]]:
    """Calcule le désaccord seulement sur des Top5 explicitement observés."""
    lists = []
    meta = getattr(course, 'collecte_meta', {}) or {}

    def visit(value):
        if isinstance(value, dict):
            for key, nested in value.items():
                key_text = str(key).lower()
                if ('top5' in key_text or 'press' in key_text) and isinstance(nested, list):
                    candidates = nested if nested and all(isinstance(item, (list, tuple, set)) for item in nested) else [nested]
                    for candidate in candidates:
                        numbers = []
                        for item in candidate:
                            raw_number = item.get('numero') if isinstance(item, dict) else item
                            number = _numeric(raw_number)
                            if number is not None:
                                numbers.append(int(number))
                        if numbers:
                            lists.append(set(numbers[:5]))
                visit(nested)
        elif isinstance(value, list):
            for nested in value:
                visit(nested)

    visit(meta)
    observed_lists = [item for item in lists if item]
    if len(observed_lists) < 2:
        return None, {
            'status': 'UNPROVEN',
            'sources_comparables': len(observed_lists),
            'reason': 'Moins de deux Top5 observés et comparables',
        }
    overlaps = []
    for index, current in enumerate(observed_lists):
        for other in observed_lists[index + 1:]:
            overlaps.append(len(current & other) / max(1, len(current | other)))
    overlap = sum(overlaps) / len(overlaps)
    return max(0.0, min(1.0, 1.0 - overlap)), {
        'status': 'OBSERVED',
        'sources_comparables': len(observed_lists),
        'pairwise_overlap_mean': overlap,
    }


def calculer_iic(course: Course) -> float:
    """Calcul IIC universel V2 pour toutes les disciplines.

    Composantes autorisées : dispersion des cotes, fluctuation du marché,
    dispersion de la forme récente et désaccord inter-sources. Toute composante
    absente est retirée du dénominateur et enregistrée dans la preuve.
    """
    partants = list(getattr(course, 'partants', []) or [])
    discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
    details = {
        'version': 'IIC_UNIVERSEL_V2',
        'discipline': discipline,
        'components': {},
        'components_observed': [],
        'components_missing': [],
        'coverage': {},
        'source_mode': 'OBSERVED_ONLY',
        'confidence': 'BLOCKED' if not partants else 'UNPROVEN',
        'formula': '10*weighted_mean(observed_components)',
        'no_silent_defaults': True,
        'rah29_policy': 'HISTORIC_STOP_PRESERVED',
    }
    course.derived_metrics = getattr(course, 'derived_metrics', {}) or {}
    if not partants:
        details['status'] = 'BLOCKED'
        course.derived_metrics['iic'] = details
        return 0.0

    minimum = max(2, int(math.ceil(len(partants) * 0.80)))
    market_blocks = [_market_block(partant) for partant in partants]

    references = [block['reference'] for block in market_blocks if block['reference'] is not None and block['reference'] > 0]
    details['coverage']['market_reference'] = len(references) / len(partants)
    if len(references) >= minimum:
        implied = [1.0 / (1.0 + quote) for quote in references]
        total = sum(implied)
        probabilities = [value / total for value in implied] if total > 0 else []
        if len(probabilities) > 1:
            entropy = -sum(probability * math.log(probability) for probability in probabilities if probability > 0)
            details['components']['market_dispersion'] = max(0.0, min(1.0, entropy / math.log(len(probabilities))))
            details['components_observed'].append('market_dispersion')

    fluctuations = [abs(block['fluctuation']) for block in market_blocks if block['fluctuation'] is not None]
    details['coverage']['market_fluctuation'] = len(fluctuations) / len(partants)
    if len(fluctuations) >= minimum:
        details['components']['market_fluctuation'] = max(0.0, min(1.0, (sum(fluctuations) / len(fluctuations)) / 0.50))
        details['components_observed'].append('market_fluctuation')

    form_values = [value for value in (_form_value(partant) for partant in partants) if value is not None]
    details['coverage']['form_recent'] = len(form_values) / len(partants)
    if len(form_values) >= minimum:
        field_size = max(2, len(partants))
        normalized = [max(0.0, min(1.0, value / field_size)) for value in form_values]
        mean = sum(normalized) / len(normalized)
        variance = sum((value - mean) ** 2 for value in normalized) / len(normalized)
        details['components']['form_dispersion'] = max(0.0, min(1.0, math.sqrt(variance) * 4.0))
        details['components_observed'].append('form_dispersion')
    else:
        details['components_missing'].append('form_recent')
        details.setdefault('missing_reasons', {})['form_recent'] = {
            'observed': len(form_values),
            'expected_minimum': minimum,
            'coverage': details['coverage']['form_recent'],
            'reason': 'FORM_RECENT_COVERAGE_BELOW_MINIMUM'
        }

    disagreement, disagreement_details = _source_disagreement(course)
    details['source_disagreement'] = disagreement_details
    if disagreement is not None:
        details['components']['source_disagreement'] = disagreement
        details['components_observed'].append('source_disagreement')
    else:
        details['components_missing'].append('source_disagreement')

    rk_values = [_numeric(getattr(partant, 'rk_brute', None)) for partant in partants]
    rk_values = [value for value in rk_values if value is not None]
    if discipline in {'TROT_ATTELE', 'TROT_MONTE'}:
        details['rk_status'] = 'OBSERVED' if len(rk_values) >= minimum else 'MISSING'
        details['trot_mode'] = 'RK_OBSERVED' if details['rk_status'] == 'OBSERVED' else 'IIC_TROT_MARKET_FORM'
        if details['rk_status'] == 'MISSING':
            details['components_missing'].append('rk_dispersion')
    else:
        details['rk_status'] = 'NOT_APPLICABLE'

    weights = {
        'market_dispersion': 0.35,
        'market_fluctuation': 0.20,
        'form_dispersion': 0.30,
        'source_disagreement': 0.15,
    }
    observed = [(name, value, weights[name]) for name, value in details['components'].items() if name in weights]
    if not observed:
        details['status'] = 'BLOCKED'
        course.derived_metrics['iic'] = details
        return 0.0

    denominator = sum(weight for _, _, weight in observed)
    details['iic'] = max(0.0, min(10.0, 10.0 * sum(value * weight for _, value, weight in observed) / denominator))
    market_full = details['coverage'].get('market_reference', 0.0) >= 0.80 and details['coverage'].get('market_fluctuation', 0.0) >= 0.80
    form_full = details['coverage'].get('form_recent', 0.0) >= 0.80
    if market_full and form_full and disagreement is not None:
        details['confidence'] = 'FULL'
    elif len(observed) >= 2 and (market_full or form_full):
        details['confidence'] = 'DEGRADED'
    else:
        details['confidence'] = 'UNPROVEN'
    details['status'] = details['confidence']
    details['coverage']['components'] = len(observed) / len(weights)
    course.derived_metrics['iic'] = details
    return details['iic']


def calculer_p_guerre(course: Course) -> float:
    """Calcule P(GUERRE) uniquement pour un IIC suffisamment documenté."""
    details = (getattr(course, 'derived_metrics', {}) or {}).get('iic', {}) or {}
    if details.get('confidence') not in {'FULL', 'DEGRADED'}:
        return 0.0
    iic = course.iic
    if iic >= 9.0:
        return 0.70
    if iic >= 8.5:
        return 0.60
    if iic >= 8.0:
        return 0.55
    if iic >= 7.0:
        return 0.35
    return 0.15
