"""Métadonnées d'audit normalisées pour modules et indices Vantage.

Ce registre ne remplace aucune formule métier. Il décrit l'exécuteur réel, les
entrées attendues et le chemin d'effet afin que l'export distingue calcul,
absence de preuve et contribution neutre.
"""
from __future__ import annotations

from typing import Any, Dict


def _meta(executor: str, formula: str, inputs: list[str], disciplines: list[str] | None = None, effect: str = 'PCH_FINAL.module_score') -> Dict[str, Any]:
    return {
        'executor': executor,
        'formula_reference': formula,
        'input_fields': inputs,
        'disciplines': disciplines or ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'effect_path': effect,
    }


MODULE_AUDIT_METADATA: Dict[str, Dict[str, Any]] = {
    'STAB': _meta('modules.normative.module_stab_normative', 'module_stab_normative(partant, course); details.components', ['derniers_resultats', 'dq_dans_3_dernieres', 'stab01_tranche_pct'], effect='PCH_FINAL.module_score + catalogue_status.STAB'),
    'H2H_GRAPH': _meta('modules.normative.module_h2h_normative', 'H2H_GRAPH: confrontation sourcée; neutre si preuve absente', ['h2h_records', 'opponents', 'shared_race_date'], effect='PCH_FINAL.module_score'),
    'MODULE_TERRAIN_DYN': _meta('modules.normative.module_terrain_normative', 'terrain_normative(course.terrain, performances_terrain)', ['terrain', 'terrain_history', 'surface'], effect='PCH_FINAL.module_score'),
    'MODULE_DIST_ADAPT': _meta('modules.normative.module_dist_normative', 'distance_normative(course.distance, performances_distance)', ['distance', 'distance_history'], effect='PCH_FINAL.module_score'),
    'MPA_CHAMP': _meta('modules.normative.module_mpa_normative', 'MPA_CHAMP: moyenne des places observées du champ', ['derniers_resultats', 'field_results', 'style_mpa', 'rythme_projete'], effect='PCH_FINAL.module_score'),
    'TANDEM_BONUS': _meta('modules.obligatoires.module_tandem_bonus', 'taux_top5 × coeff_nb × coeff_temps lorsque metric.status=CALCULATED', ['tandem_bonus', 'taux_top5', 'nb_courses_ensemble'], effect='PCH_FINAL.module_score'),
    'OVERBET_DETECTOR': _meta('modules.normative.module_overbet_normative', 'OVERBET conditionnel cote faible / signaux justificatifs', ['cote', 'signaux_actifs', 'icp_count'], effect='PCH_FINAL.module_score'),
    'IFF_v2': _meta('modules.normative.module_iff_normative', 'IFF_v2: fenêtre discipline + tendance; détails.components', ['date_derniere_course', 'discipline', 'delai_j', 'tendance'], effect='PCH_FINAL.module_score'),
    'NRC': _meta('modules.normative.module_nrc_normative', 'NRC: niveau de risque/contexte observé', ['derniers_resultats', 'discipline', 'incident_flags'], effect='PCH_FINAL.module_score'),
    'BSH_v3v4': _meta('modules.normative.module_bsh_normative', 'BSH_v3/v4: fenêtre hippodrome-distance sourcée', ['hippodrome', 'distance', 'bsh_history', 'window'], effect='PCH_FINAL.module_score'),
    'BSC_v3': _meta('modules.normative.module_bsc_normative', 'BSC_v3: fenêtre contexte et cohérence terrain', ['hippodrome', 'distance', 'bsc_history', 'window'], effect='PCH_FINAL.module_score'),
    'CRE_v2': _meta('modules.normative.module_cre_normative', 'CRE_v2: coefficient terrain × performances admissibles', ['terrain', 'terrain_coeff', 'cre_records', 'rk_brute'], effect='PCH_FINAL.module_score'),
    'FORME_LINEAIRE': _meta('modules.normative.module_forme_lineaire_normative', 'FORME_LINEAIRE: échantillon de forme observé sans moyenne fictive', ['derniers_resultats', 'form_recent'], effect='PCH_FINAL.module_score + IIC.form_recent'),
    'SRI_v2': _meta('modules.critical_normative.executer_sri_v2', 'SRI_v2: sortie discipline-spécifique, age_mult et clamp [0,120]', ['age', 'gains', 'nb_courses', 'niveau_max', 'valeur_pmu', 'discipline'], effect='PCH_FINAL.module_score'),
    'CSF': _meta('modules.critical_normative.executer_csf', 'CSF: synergie des familles SF observées, cap 50 et normalisation', ['signaux_sf', 'families', 'sf_sources'], effect='COMPOSITE.csF_component'),
    'PDQ': _meta('modules.critical_normative.executer_pdq', 'PDQ: qualité des données / chevauchement des sources', ['pdq_sources', 'sources_overlap_pct', 'tendance'], effect='details.pdq_contribution + tocard_score'),
    'P5P6': _meta('modules.p5p6.executer_p5p6', 'P5P6 = pondération C1-C5 avec C2 conditionnel RAH-150; score documentaire', ['C1', 'C2', 'C3', 'C4', 'C5_montee_categorie', 'cote', 'nb_signaux_strict'], effect='ticket.reserve_policy; no direct PCH'),
    'RAH-235': _meta('modules.obligatoires.executer_rah235', 'RAH-235: malus D récent / tempérament documenté', ['derniers_resultats', 'dq_dans_3_dernieres', 'commentaire_temperament_risque'], effect='PCH_FINAL.module_score'),
    'RAH-102': _meta('modules.obligatoires.executer_rah102', 'RAH-102: corde extrême renforcée PLAT/OBSTACLE', ['numero_corde', 'nb_stalles_disponibles', 'gru_bonus_corde_specifique', 'distance'], ['PLAT', 'OBSTACLE', 'HAIES'], effect='PCH_FINAL.module_score'),
    'RAH-242': _meta('modules.obligatoires.executer_rah242', 'RAH-242: secondaires autorisés <= primaires positifs', ['bonus_primaires_positifs', 'bonus_secondaires'], effect='PCH_FINAL.module_score'),
    'SSFO': _meta('modules.advanced_catalogues.executer_ssfo', 'SSFO: règles F1/F7/F10… × convergence multiplier', ['ssfo_rules', 'cote', 'market_data', 'press_sources'], effect='details.ssfo_bonus + catalogue_status.SSFO'),
    'GAMMA': _meta('modules.advanced_catalogues.executer_gamma', 'GAMMA: signaux RAH-179..209 avec cap et décroissance', ['gamma_rules', 'cote_matin', 'cote_avant_course', 'age_jours'], effect='details.gamma_score + catalogue_status.GAMMA'),
    'GHOST': _meta('modules.ghost.executer_ghost', 'GHOST: D01-D43 + EE_SCORE et convergence D41', ['ghost_rules', 'historique', 'cote', 'sources'], effect='details.tocard_score + tocard_score'),
    'RAH_PRIORITES': _meta('modules.rah_priority.executer_rah_priorites', 'RAH priorités: gains/plafond/discipline/victoire_60j', ['gains_totaux', 'plafond_elimination', 'discipline', 'victoire_60j'], effect='PCH_FINAL.module_score'),
    'MODULE_POIDS': _meta('modules.normative.module_poids_normative', 'MODULE_POIDS: poids/handicap avec plafonds RAH-46/104', ['poids', 'poids_moyen', 'est_handicap', 'distance'], ['PLAT'], effect='PCH_FINAL.module_score'),
    'MODULE_RECUL': _meta('modules.normative.module_recul_normative', 'MODULE_RECUL: recul et échelons TROT handicap', ['recul_m', 'echelons_multiples', 'distance'], ['TROT_ATTELE', 'TROT_MONTE'], effect='PCH_FINAL.module_score'),
    'TACT': _meta('modules.normative.module_tact_normative', 'TACT: contexte tactique TROT, fenêtres et départ', ['rk_brute', 'type_depart', 'numero_autostart', 'distance'], ['TROT_ATTELE', 'TROT_MONTE'], effect='PCH_FINAL.module_score'),
}
for code, prefix in [('PLAT', 'module_plat'), ('TROT', 'module_trot'), ('OBS', 'module_obs')]:
    max_index = 4 if code in {'PLAT', 'TROT'} else 5
    disciplines = ['PLAT'] if code == 'PLAT' else ['TROT_ATTELE', 'TROT_MONTE'] if code == 'TROT' else ['OBSTACLE', 'HAIES']
    for index in range(1, max_index + 1):
        module_id = f'{code}-{index:02d}'
        MODULE_AUDIT_METADATA[module_id] = _meta(
            f'modules.normative.{prefix}{index:02d}_normative',
            f'{module_id}: module disciplinaire normatif; détails C1..C5 et flags',
            ['discipline', 'distance', 'terrain', 'est_handicap', 'raw_data'],
            disciplines,
            effect='PCH_FINAL.module_score'
        )

INDEX_AUDIT_METADATA: Dict[str, Dict[str, Any]] = {
    'P_LOCK': {'formula': 'clamp(0.15, 0.85, base + impacts_meneurs + impact_ICP + dispersion + champ)', 'inputs': ['cotes', 'signaux_actifs', 'icp_count', 'nb_partants'], 'effect': 'signature_msp'},
    'P_GUERRE': {'formula': 'calcul_p_guerre_universal(IIC, coverage, confidence)', 'inputs': ['IIC', 'iic_confidence', 'components_observed'], 'effect': 'signature_msp'},
    'P_STANDARD': {'formula': 'sortie de détermination MSP lorsque ni LOCK ni CHAOS ne s’appliquent', 'inputs': ['P_LOCK', 'P_GUERRE', 'IIC', 'profil_ado'], 'effect': 'signature_msp'},
    'IIC': {'formula': 'IIC universel V2: marché + fluctuation + forme + désaccord inter-sources, pondéré par couverture', 'inputs': ['cote_reference', 'cote_avant_course', 'form_recent', 'source_disagreement'], 'effect': 'P_GUERRE + garde RAH'},
    'IFT': {'formula': 'IFT brut = base + pénalités RAH; IFT borné = clamp(0,100,IFT brut)', 'inputs': ['rah_statuses', 'coverage', 'certification'], 'effect': 'certification'},
    'PCH_BRUT': {'formula': 'Σ(signal.valeur × poids_famille) + ajustements normatifs observés', 'inputs': ['signaux_actifs', 'raw_data', 'pente_details'], 'effect': 'PCH_FINAL'},
    'PCH_FINAL': {'formula': 'clamp(0,220,PCH_BRUT + GRU + Σ modules actifs)', 'inputs': ['PCH_BRUT', 'GRU', 'module_scores'], 'effect': 'COMPOSITE'},
    'COMPOSITE': {'formula': 'w_PCH×PCH_NORM + w_tocard×tocard_score + w_CSF×CSF_norm + 0.10×H2H_norm, poids selon discipline/signature', 'inputs': ['PCH_FINAL', 'tocard_score', 'CSF', 'H2H', 'discipline', 'signature_msp'], 'effect': 'ORDRE_SCORE'},
    'PRODUIT_MULT': {'formula': 'produit des multiplicateurs borné [0.65,1.45]', 'inputs': ['market', 'form', 'catalogues', 'rah_adjustments'], 'effect': 'COMPOSITE'},
    'ORDRE_SCORE': {'formula': 'Borda/score final avec PCH_NORM, COMPOSITE, cote, ICP, tocard et contraintes', 'inputs': ['PCH_NORM', 'COMPOSITE', 'tocard_score', 'cote', 'ICP', 'constraints'], 'effect': 'GMO-V ticket'},
    'ICP': {'formula': 'nombre pondéré de sources presse citant le cheval', 'inputs': ['press_top5_by_source'], 'effect': 'P_LOCK + COMPOSITE + SUPRA'},
    'SOV_v2': {'formula': 'SOV marché sur au moins deux snapshots cote', 'inputs': ['cote_matin', 'cote_avant_course'], 'effect': 'PCH/ORDRE/SUPRA S1'},
    'P_SCORE': {'formula': 'score continu des positions historiques avec fallback explicitement signalé', 'inputs': ['positions_mi_course', 'historical_results'], 'effect': 'PCH/RAH-117'},
    'P5P6': {'formula': '0.40*C1 + 0.25*C2 + 0.20*C3 + 0.15*C4 + C5 conditionnel', 'inputs': ['C1', 'C2', 'C3', 'C4', 'C5'], 'effect': 'PCH/ticket reserves'},
    'GHOST': {'formula': 'D01-D43 weighted excuses + EE_SCORE + D41 convergence', 'inputs': ['ghost_rules', 'history', 'cote'], 'effect': 'tocard_score'},
    'SSFO': {'formula': 'F1/F7/F10… evidence × convergence multiplier', 'inputs': ['ssfo_rules', 'cote', 'market', 'press'], 'effect': 'catalogue/score'},
    'GAMMA': {'formula': 'gamma rules with cap, age decay and bounded effects', 'inputs': ['gamma_rules', 'market', 'age_jours'], 'effect': 'catalogue/score'},
    'LONGSHOTS': {'formula': 'LS_BASE=max(F1..F5,F7,F8); convergence ×1.10/×1.20; LS_FINAL=min(1,LS_BASE×bonus); F6 observation only', 'inputs': ['p_top5', 'families_F1_F5_F7_F8', 'cote'], 'effect': 'GMO-V eligibility via RAH-230/RAH-266 only'},
}


def _lookup_input(partant: Any, course: Any, key: str) -> Any:
    raw = getattr(partant, 'raw_data', {}) or {}
    market = getattr(partant, 'market_data', {}) or {}
    ext = getattr(partant, 'extended_metrics', {}) or {}
    if key in raw and raw[key] not in (None, '', 'NC', 'UNPROVEN'):
        return raw[key]
    if key in market and market[key] not in (None, '', 'NC', 'UNPROVEN'):
        return market[key]
    if key in ext and ext[key] not in (None, '', 'NC', 'UNPROVEN'):
        return ext[key]
    if hasattr(partant, key):
        value = getattr(partant, key)
        if value not in (None, '', 'NC', 'UNPROVEN'):
            return value
    if hasattr(course, key):
        value = getattr(course, key)
        if value not in (None, '', 'NC', 'UNPROVEN'):
            return getattr(value, 'value', value)
    return None


def enrich_module_audit_metadata(module: Any, partant: Any, course: Any) -> Any:
    module_id = getattr(module, 'nom', '')
    meta = MODULE_AUDIT_METADATA.get(module_id, _meta(f'unknown:{module_id}', f'{module_id}: exécuteur non enregistré', ['raw_data']))
    details = dict(getattr(module, 'details', {}) or {})
    details.setdefault('execution_status', 'EXECUTED')
    details.setdefault('status', 'CALCULATED' if getattr(module, 'actif', False) else 'NOT_APPLICABLE')
    details.setdefault('formula', details.get('formule') or meta['formula_reference'])
    details.setdefault('formula_reference', meta['formula_reference'])
    existing_inputs = details.get('inputs', details.get('entrees'))
    if not isinstance(existing_inputs, dict):
        existing_inputs = {key: _lookup_input(partant, course, key) for key in meta['input_fields']}
    details['inputs'] = existing_inputs
    details.setdefault('input_fields', meta['input_fields'])
    details.setdefault('observed_inputs', {key: value for key, value in existing_inputs.items() if value not in (None, '', 'NC', 'UNPROVEN')})
    details.setdefault('impact_pch', float(getattr(module, 'score', 0.0) or 0.0) if getattr(module, 'actif', False) else 0.0)
    details.setdefault('impact_path', meta['effect_path'])
    details['audit_metadata'] = meta
    module.details = details
    return module


def build_index_audit(course: Any, rapport: Dict[str, Any]) -> Dict[str, Any]:
    """Construit un registre uniforme des indices course et partant.

    Les indices partant ne sont pas réduits à une moyenne silencieuse : leurs
    valeurs individuelles sont conservées, avec couverture, bornes et statut.
    """
    derived = getattr(course, 'derived_metrics', {}) or {}
    partants = getattr(course, 'partants', []) or []
    course_values = {
        'P_LOCK': getattr(course, 'p_lock', None),
        'P_GUERRE': getattr(course, 'p_guerre', None),
        'P_STANDARD': getattr(course, 'p_standard', None),
        'IIC': getattr(course, 'iic', None),
        'IFT': rapport.get('ift_score', getattr(course, 'ift_score', None)),
    }
    partant_attrs = {
        'PCH_BRUT': 'pch_brut', 'PCH_FINAL': 'pch_final', 'COMPOSITE': 'composite',
        'PRODUIT_MULT': 'produit_mult_ecrete', 'ORDRE_SCORE': 'ordre_score',
        'TOCARD_SCORE': 'tocard_score', 'ICP': 'icp_count',
    }

    def valid(value: Any) -> bool:
        return value not in (None, '', 'NC', 'UNPROVEN')

    result: Dict[str, Any] = {}
    for key, meta in INDEX_AUDIT_METADATA.items():
        if key in course_values:
            value = course_values[key]
            row = {**meta, 'scope': 'COURSE', 'value': value, 'status': 'OBSERVED' if valid(value) else 'UNPROVEN'}
            if key == 'IFT':
                row['raw_value'] = rapport.get('ift_score_raw', value)
                row['bounded_value'] = value
            result[key] = row
            continue
        status_values = None
        if key in partant_attrs:
            attr = partant_attrs[key]
            values = [getattr(partant, attr, None) for partant in partants]
        elif key == 'SOV_v2':
            values = []
            for partant in partants:
                market = getattr(partant, 'market_data', {}) or {}
                raw = getattr(partant, 'raw_data', {}) or {}
                values.append(market['sov_v2'] if 'sov_v2' in market else raw.get('sov_v2'))
        elif key == 'P_SCORE':
            values = []
            for partant in partants:
                raw = getattr(partant, 'raw_data', {}) or {}
                values.append(raw.get('p_score_continu'))
        elif key == 'P5P6':
            values = []
            status_values = []
            for partant in partants:
                module = next((m for m in getattr(partant, 'modules_results', []) or [] if getattr(m, 'nom', '') == 'P5P6'), None)
                details = getattr(module, 'details', {}) or {} if module else {}
                values.append(details.get('p5p6_score') if isinstance(details, dict) else None)
                status_values.append(str(details.get('status', 'UNPROVEN')).upper() if isinstance(details, dict) else 'UNPROVEN')
        elif key == 'GHOST':
            values = []
            status_values = []
            for partant in partants:
                details = getattr(partant, 'ghost_details', {}) or {}
                values.append(details.get('tocard_score', getattr(partant, 'tocard_score', None)))
                status_values.append(str(details.get('status', 'UNPROVEN')).upper())
        elif key == 'SSFO':
            values = []
            status_values = []
            for partant in partants:
                details = getattr(partant, 'ssfo_details', {}) or {}
                values.append(details.get('bonus_ssfo_final', details.get('bonus_ssfo')))
                status_values.append(str(details.get('status', 'UNPROVEN')).upper())
        elif key == 'GAMMA':
            values = []
            status_values = []
            for partant in partants:
                details = getattr(partant, 'gamma_details', {}) or {}
                values.append(details.get('gamma_score', details.get('score')))
                status_values.append(str(details.get('status', 'UNPROVEN')).upper())
        elif key == 'LONGSHOTS':
            values = []
            status_values = []
            for partant in partants:
                details = getattr(partant, 'longshots_details', {}) or {}
                values.append(details.get('LS_FINAL'))
                status_values.append(str(details.get('status', 'UNPROVEN')).upper())
        else:
            value = derived.get(key.lower(), derived.get(key))
            result[key] = {**meta, 'scope': 'COURSE', 'value': value, 'status': 'OBSERVED' if valid(value) else 'UNPROVEN'}
            continue
        effective_statuses = status_values or [('OBSERVED' if valid(value) else 'UNPROVEN') for value in values]
        observed = [value for value, status in zip(values, effective_statuses) if valid(value) and isinstance(value, (int, float)) and status in {'OBSERVED', 'CALCULATED', 'APPLIED', 'ACTIVE'}]
        status_observed_count = sum(valid(value) and status in {'OBSERVED', 'CALCULATED', 'APPLIED', 'ACTIVE'} for value, status in zip(values, effective_statuses))
        row = {
            **meta,
            'scope': 'PARTANT',
            'value': None,
            'status': 'OBSERVED' if status_observed_count == len(partants) and partants else 'UNPROVEN',
            'observed_count': status_observed_count,
            'expected_count': len(partants),
            'coverage': len(observed) / len(partants) if partants else 0.0,
            'min': min(observed) if observed else None,
            'max': max(observed) if observed else None,
            'nonzero_count': sum(value != 0 for value in observed),
            'partant_values': [
                {'numero': getattr(partant, 'numero', None), 'value': value, 'status': effective_statuses[index]}
                for index, (partant, value) in enumerate(zip(partants, values))
            ],
        }
        result[key] = row
    return result
