"""Activation contrôlée de magnitudes GRU validées.

Par défaut, aucune surcharge n’est chargée. Un patch runtime doit être
explicitement activé et porter le statut APPROVED_HOLDOUT.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

_CACHE: Optional[Dict[str, Any]] = None


def reset_activation_cache() -> None:
    global _CACHE
    _CACHE = None


def _load() -> Dict[str, Any]:
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    if os.getenv('GRU_CALIBRATION_ACTIVATION', '0') != '1':
        _CACHE = {'status': 'DISABLED', 'rules': {}}
        return _CACHE
    path = os.getenv('GRU_CALIBRATION_PATCH_PATH', '').strip()
    if not path:
        _CACHE = {'status': 'BLOCKED', 'reason': 'GRU_CALIBRATION_PATCH_PATH absent', 'rules': {}}
        return _CACHE
    try:
        payload = json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception as exc:
        _CACHE = {'status': 'BLOCKED', 'reason': f'patch illisible: {type(exc).__name__}', 'rules': {}}
        return _CACHE
    if payload.get('schema') != 'VANTAGE_GRU_APPROVED_PATCH_V1' or payload.get('status') != 'APPROVED_HOLDOUT':
        _CACHE = {'status': 'BLOCKED', 'reason': 'schema ou statut d’approbation invalide', 'rules': {}}
        return _CACHE
    rules = payload.get('rules') if isinstance(payload.get('rules'), dict) else {}
    valid = {}
    rejected = []
    for code, entry in rules.items():
        if not isinstance(entry, dict) or entry.get('enabled') is not True:
            continue
        try:
            magnitude = float(entry['magnitude'])
        except (KeyError, TypeError, ValueError):
            continue
        evidence_id = str(entry.get('evidence_id') or '').strip()
        if not math.isfinite(magnitude) or abs(magnitude) > 12.0 or not evidence_id:
            rejected.append(str(code))
            continue
        valid[str(code)] = {'magnitude': magnitude, 'evidence_id': evidence_id, 'version': entry.get('version', 'V1')}
    _CACHE = {'status': 'APPROVED_HOLDOUT', 'rules': valid, 'rejected_codes': sorted(rejected), 'patch_id': payload.get('patch_id'), 'evidence_ids': sorted({item['evidence_id'] for item in valid.values()})}
    return _CACHE


def calibrated_contribution(code: str, default: float) -> Tuple[float, Dict[str, Any]]:
    state = _load()
    entry = state.get('rules', {}).get(str(code))
    if not entry:
        status = state.get('status', 'DISABLED')
        if status == 'APPROVED_HOLDOUT':
            status = 'APPROVED_HOLDOUT_NOT_APPLIED'
        return default, {'status': status, 'code': code, 'default_magnitude': default}
    return entry['magnitude'], {'status': 'APPLIED_APPROVED_HOLDOUT', 'code': code, 'default_magnitude': default, **entry}


def activation_state() -> Dict[str, Any]:
    state = _load()
    return {'status': state.get('status'), 'reason': state.get('reason'), 'patch_id': state.get('patch_id'), 'enabled_codes': sorted(state.get('rules', {}).keys())}
