"""Trace d'audit intégrale de l'exécution Vantage.

La trace est volontairement additive : elle n'invente aucune donnée et conserve
les absences sous forme NC/UNPROVEN avec raison. Elle rend explicites les
limites d'attribution lorsqu'un objet de calcul ne transporte pas sa formule ou
son impact.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List
import math


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
            return None
        return value
    if hasattr(value, 'value') and not isinstance(value, dict):
        try:
            return value.value
        except Exception:
            pass
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if hasattr(value, '__dict__'):
        return _jsonable(vars(value))
    return str(value)


def _status_for_field(value: Any, declared: Any = None) -> str:
    if isinstance(declared, str) and declared:
        return declared.upper()
    if value in (None, '', 'NC', 'UNPROVEN'):
        return 'NC'
    return 'OBSERVED'


def _field_evidence(partant: Any) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    market = getattr(partant, 'market_data', {}) or {}
    quality = getattr(partant, 'data_quality', {}) or {}
    source_by_field = raw.get('source_by_field', {}) if isinstance(raw, dict) else {}
    fields: Dict[str, Any] = {}
    names = ['numero', 'nom', 'cote', 'poids', 'driver_jockey', 'entraineur', 'age', 'sexe',
             'rk_brute', 'valeur_pmu', 'cote_matin', 'cote_avant_course', 'cote_15min',
             'deferrage', 'numero_corde', 'oeilleres', 'form_recent', 'press_top5',
             'press_sources', 'sov_v2']
    for name in names:
        value = getattr(partant, name, None)
        if name in market and value in (None, '', 'NC'):
            value = market.get(name)
        if name in raw and value in (None, '', 'NC'):
            value = raw.get(name)
        declared = quality.get(name) if isinstance(quality, dict) else None
        status = _status_for_field(value, declared)
        source = source_by_field.get(name) if isinstance(source_by_field, dict) else None
        if source is None:
            source = raw.get('source') or market.get('selected_source')
        reason = '' if status == 'OBSERVED' else ('Champ absent ou non collecté' if status == 'NC' else 'Preuve source insuffisante')
        fields[name] = {'status': status, 'value': _jsonable(value), 'sources': _jsonable(source or []), 'reason': reason}
    return fields


def _signal_traces(partant: Any) -> List[Dict[str, Any]]:
    result = []
    for signal in getattr(partant, 'signaux', []) or []:
        result.append({
            'code': getattr(signal, 'code', ''),
            'nom': getattr(signal, 'nom', ''),
            'active': bool(getattr(signal, 'actif', False)),
            'value': _jsonable(getattr(signal, 'valeur', None)),
            'family': getattr(signal, 'famille', ''),
            'fallback_level': getattr(signal, 'niveau_fallback', ''),
            'source': getattr(signal, 'source', ''),
            'missing': bool(getattr(signal, 'flag_manquant', False)),
            'reason': getattr(signal, 'raison_manquant', '') or '',
            'impact': _jsonable(getattr(signal, 'valeur', 0) if getattr(signal, 'actif', False) else 0),
        })
    return result


def _module_traces(partant: Any) -> List[Dict[str, Any]]:
    result = []
    for module in getattr(partant, 'modules_results', []) or []:
        details = getattr(module, 'details', {}) or {}
        formula = details.get('formula', details.get('formule')) if isinstance(details, dict) else None
        inputs = details.get('inputs', details.get('entrees', {})) if isinstance(details, dict) else {}
        impact = None
        if isinstance(details, dict):
            for key in ('impact_pch', 'pch_contribution', 'score_contribution', 'delta_pch', 'impact'):
                if key in details:
                    impact = details[key]
                    break
        result.append({
            'module_id': getattr(module, 'nom', ''),
            'status': 'ACTIVE' if getattr(module, 'actif', False) else 'INACTIVE',
            'inputs': _jsonable(inputs),
            'formula': _jsonable(formula),
            'score_raw': _jsonable(getattr(module, 'score', 0)),
            'flags': _jsonable(getattr(module, 'flags', []) or []),
            'impact_pch': _jsonable(impact),
            'details': _jsonable(details),
        })
    return result


def _catalogue_traces(partant: Any) -> Dict[str, Any]:
    return {
        'catalogue_status': _jsonable(getattr(partant, 'catalogue_status', {}) or {}),
        'GHOST': _jsonable(getattr(partant, 'ghost_details', {}) or {}),
        'SSFO': _jsonable(getattr(partant, 'ssfo_details', {}) or {}),
        'GAMMA': _jsonable(getattr(partant, 'gamma_details', {}) or {}),
        'LONGSHOTS': _jsonable(getattr(partant, 'longshots_details', {}) or {}),
        'HISTORICAL_CATALOGUES': _jsonable((getattr(partant, 'raw_data', {}) or {}).get('historical_catalogue_audit', {})),
    }


def build_partant_audit_trace(partant: Any, ticket: Any = None) -> Dict[str, Any]:
    modules = _module_traces(partant)
    signals = _signal_traces(partant)
    scores = {
        'pch_brut': _jsonable(getattr(partant, 'pch_brut', 0)),
        'pch_final': _jsonable(getattr(partant, 'pch_final', 0)),
        'composite': _jsonable(getattr(partant, 'composite', 0)),
        'produit_mult_brut': _jsonable(getattr(partant, 'produit_mult', 0)),
        'produit_mult_ecrete': _jsonable(getattr(partant, 'produit_mult_ecrete', 0)),
        'ordre_base': _jsonable(getattr(partant, 'ordre_base', 0)),
        'ordre_score': _jsonable(getattr(partant, 'ordre_score', 0)),
        'tocard_score': _jsonable(getattr(partant, 'tocard_score', 0)),
    }
    steps = [{'step': key, 'value': value} for key, value in scores.items()]
    module_impacts = [
        {'module_id': row['module_id'], 'score_raw': row['score_raw'], 'impact_pch': row['impact_pch']}
        for row in modules if row['score_raw'] not in (None, 0, 0.0) or row['impact_pch'] is not None
    ]
    signal_impacts = [
        {'code': row['code'], 'value': row['value'], 'impact': row['impact']}
        for row in signals if row['active'] and row['value'] not in (None, 0, 0.0)
    ]
    ticket_decision = ticket if isinstance(ticket, dict) else {
        'position': getattr(partant, 'position_ticket', None),
        'eligible': getattr(partant, 'position_ticket', None) is not None,
        'flags': _jsonable(getattr(partant, 'flags', []) or []),
    }
    formula_count = sum(bool(row['formula']) for row in modules)
    impact_count = sum(row['impact_pch'] is not None for row in modules)
    source_count = sum(bool(row.get('source')) for row in signals)
    return {
        'numero': getattr(partant, 'numero', None),
        'nom': getattr(partant, 'nom', ''),
        'field_evidence': _field_evidence(partant),
        'raw_observations': _jsonable(getattr(partant, 'raw_data', {}) or {}),
        'market_observations': _jsonable(getattr(partant, 'market_data', {}) or {}),
        'signals': signals,
        'modules': modules,
        'catalogues': _catalogue_traces(partant),
        'scores': scores,
        'score_impact_ledger': {
            'module_contributions': module_impacts,
            'signal_contributions': signal_impacts,
            'score_steps': steps,
        },
        'ticket_decision': _jsonable(ticket_decision),
        'attribution_completeness': {
            'module_count': len(modules),
            'module_formula_count': formula_count,
            'module_impact_count': impact_count,
            'signal_count': len(signals),
            'signal_source_count': source_count,
            'limits': [limit for limit in (
                'FORMULA_NOT_EXPOSED_FOR_MODULE' if formula_count < len(modules) else None,
                'MODULE_IMPACT_NOT_EXPOSED_FOR_MODULE' if impact_count < len(modules) else None,
                'SIGNAL_SOURCE_NOT_EXPOSED_FOR_SIGNAL' if source_count < len(signals) else None,
            ) if limit],
        },
        'data_quality': _jsonable(getattr(partant, 'data_quality', {}) or {}),
    }


def build_execution_audit_trace(course: Any, rapport: Dict[str, Any], ticket: Any = None) -> Dict[str, Any]:
    rows = []
    ticket_map = {}
    if isinstance(ticket, dict):
        for position, item in ticket.items():
            if isinstance(item, dict) and item.get('numero') is not None:
                ticket_map[str(item['numero'])] = {'position': position, **item}
    for partant in getattr(course, 'partants', []) or []:
        rows.append(build_partant_audit_trace(partant, ticket_map.get(str(getattr(partant, 'numero', '')))))
    modules = [module for row in rows for module in row['modules']]
    signals = [signal for row in rows for signal in row['signals']]
    limits = []
    if not any(row['attribution_completeness']['module_formula_count'] for row in rows):
        limits.append('NO_MODULE_FORMULAS_EXPOSED_BY_RUNTIME_OBJECTS')
    if not any(row['attribution_completeness']['module_impact_count'] for row in rows):
        limits.append('NO_MODULE_IMPACTS_EXPOSED_BY_RUNTIME_OBJECTS')
    return {
        'trace_version': '1.1',
        'status': 'COMPLETE_WITH_LIMITS' if limits else 'COMPLETE',
        'partants': rows,
        'phase_outputs': _jsonable(rapport.get('etapes', {}) or {}),
        'indices': _jsonable((getattr(course, 'derived_metrics', {}) or {}).get('index_audit', {})),
        'rah_trace': _jsonable(rapport.get('rah_audit', {}) or {}),
        'ticket_trace': _jsonable(ticket or rapport.get('ticket', {}) or {}),
        'attribution_completeness': {
            'partants': len(rows),
            'module_instances': len(modules),
            'signal_instances': len(signals),
            'module_formulas': sum(bool(m.get('formula')) for m in modules),
            'module_impacts': sum(m.get('impact_pch') is not None for m in modules),
            'limits': limits,
        },
        'post_course': _jsonable(getattr(course, 'post_course_audit', None)),
    }
