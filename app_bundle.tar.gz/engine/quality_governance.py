"""Gouvernance de qualité RAH-269 et RAH-270."""
from __future__ import annotations

from typing import Any, Dict, List

from engine.models import Course, Partant


FRONTIER_MIN_RANK = 5
FRONTIER_MAX_RANK = 12

# Champs dont l’absence réduit réellement la traçabilité pré-course. La liste est
# volontairement explicite : elle ne considère pas chaque clé optionnelle comme
# manquante et ne fabrique aucune valeur de remplacement.
QUALITY_FIELDS = (
    # RAH-269 pénalise les entrées qui conditionnent directement la traçabilité
    # du classement. Les catalogues ALL et les chronos sectionnels ont leurs
    # propres statuts RAH et ne doivent pas être pénalisés une seconde fois ici.
    'rk_brute', 'valeur_pmu', 'pente_score', 'sov_v2',
    'h2h_avg', 'gains_totaux_eur', 'nb_courses',
)


def _raw(partant: Partant, key: str, default=None):
    return (getattr(partant, 'raw_data', {}) or {}).get(key, default)


def _missing(partant: Partant) -> List[str]:
    """Retourne uniquement les champs réellement non prouvés.

    Les collecteurs peuvent stocker une même preuve dans l’attribut Partant,
    raw_data, market_data ou dans un conteneur PMU imbriqué. RAH-269 ne doit pas
    pénaliser deux fois une donnée observée simplement parce que sa clé n’est
    pas au niveau racine.
    """
    missing = []
    raw = getattr(partant, 'raw_data', {}) or {}
    market = getattr(partant, 'market_data', {}) or {}
    nested = [raw.get('api_pmu'), raw.get('turf_bzh')]

    def valid(value):
        return value not in (None, '', 'NC', 'UNPROVEN') and not (isinstance(value, (list, dict, tuple, set)) and len(value) == 0)

    for key in QUALITY_FIELDS:
        candidates = []
        if hasattr(partant, key):
            candidates.append(getattr(partant, key, None))
        candidates.extend([raw.get(key), market.get(key), raw.get('market_data', {}).get(key) if isinstance(raw.get('market_data'), dict) else None])
        for container in nested:
            if isinstance(container, dict):
                candidates.append(container.get(key))

        if key == 'sov_v2':
            snapshots = market.get('sov_snapshots') or raw.get('sov_snapshots') or (raw.get('market_data') or {}).get('sov_snapshots')
            if isinstance(snapshots, (list, tuple)) and len(snapshots) >= 2:
                candidates.append('OBSERVED_TWO_SNAPSHOTS')
            if str(market.get('sov_v2_input_status') or raw.get('sov_v2_input_status') or '').upper() == 'READY_TWO_POINTS':
                candidates.append('OBSERVED_TWO_POINTS')
        elif key == 'gains_totaux_eur':
            for container in [raw, *nested]:
                gains = container.get('gainsParticipant') if isinstance(container, dict) else None
                if isinstance(gains, dict):
                    candidates.append(gains.get('gainsCarriere'))
                candidates.append(container.get('gains') if isinstance(container, dict) else None)
        elif key == 'nb_courses':
            for container in [raw, *nested]:
                if isinstance(container, dict):
                    candidates.extend([container.get('nb_courses'), container.get('nb_courses_total'), container.get('nbCourses'), container.get('nombreCourses')])
        elif key == 'pente_score':
            pente = raw.get('pente_details')
            if isinstance(pente, dict):
                candidates.append(pente.get('pente_score'))
        elif key == 'h2h_avg':
            for module in getattr(partant, 'modules_results', []) or []:
                if getattr(module, 'nom', '') == 'H2H_GRAPH' and getattr(module, 'actif', False):
                    candidates.append('MODULE_H2H_EXECUTED')

        if not any(valid(value) for value in candidates):
            missing.append(key)
    return missing


def classify_frontier(course: Course) -> Dict[int, int]:
    ordered = sorted(course.partants, key=lambda p: (p.ordre_score is not None, p.ordre_score or 0.0), reverse=True)
    return {id(partant): rank for rank, partant in enumerate(ordered, start=1)}


def evaluer_rah269(course: Course) -> Dict[str, Any]:
    ranks = classify_frontier(course)
    rows = []
    total_penalty = 0
    for partant in course.partants:
        rank = ranks.get(id(partant))
        in_frontier = rank is not None and FRONTIER_MIN_RANK <= rank <= min(FRONTIER_MAX_RANK, len(course.partants))
        missing = _missing(partant)
        base_penalty = len(missing) * 2
        penalty = base_penalty * 2 if in_frontier else base_penalty
        total_penalty += penalty
        row = {
            'numero': partant.numero,
            'rang_ordre_score': rank,
            'zone_frontiere': in_frontier,
            'missing_fields': missing,
            'base_penalty_ift': base_penalty,
            'penalty_ift': penalty,
            'status': 'CALCULATED',
            'flag': 'RAH269_ZONE_FRONTIERE_DOUBLE' if in_frontier and missing else ('RAH269_DONNEES_MANQUANTES' if missing else ''),
        }
        rows.append(row)
        raw = getattr(partant, 'raw_data', {}) or {}
        raw['rah269'] = row
        partant.raw_data = raw
    return {
        'rule': 'RAH-269',
        'status': 'CALCULATED',
        'frontier_range': [FRONTIER_MIN_RANK, FRONTIER_MAX_RANK],
        'total_penalty_ift': total_penalty,
        'rows': rows,
    }


def evaluer_rah270(partant: Partant) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    commentaire = raw.get('commentaire_rythme') or raw.get('commentaire_qualitatif_rythme')
    chrono = raw.get('chrono_sectionnel')
    if commentaire not in (None, '', 'NC', 'UNPROVEN'):
        result = {
            'rule': 'RAH-270', 'status': 'CALCULATED', 'priority': 'COMMENTAIRE_QUALITATIF',
            'commentaire_rythme': commentaire, 'chrono_sectionnel': chrono,
            'flag': 'RAH270_COMMENTAIRE_PRIME_CHRONO_MANQUANT' if chrono in (None, '', 'NC', 'UNPROVEN') else 'RAH270_COMMENTAIRE_PRIORITAIRE',
        }
    elif chrono not in (None, '', 'NC', 'UNPROVEN'):
        result = {
            'rule': 'RAH-270', 'status': 'CALCULATED', 'priority': 'CHRONO_SECTIONNEL',
            'commentaire_rythme': None, 'chrono_sectionnel': chrono,
            'flag': 'RAH270_COMMENTAIRE_ABSENT',
        }
    else:
        result = {
            'rule': 'RAH-270', 'status': 'UNPROVEN', 'priority': 'NC',
            'commentaire_rythme': None, 'chrono_sectionnel': None,
            'flag': 'RAH270_DONNEES_RYTHME_ABSENTES',
        }
    raw['rah270'] = result
    partant.raw_data = raw
    return result


def appliquer_gouvernance_rah269_270(course: Course) -> Dict[str, Any]:
    rah269 = evaluer_rah269(course)
    rah270_rows = [evaluer_rah270(partant) | {'numero': partant.numero} for partant in course.partants]
    # EQUITY_NEUTRALITY_V1 : la pénalité historique RAH-269 était individuelle.
    # Elle pénalisait un cheval lorsque la source n'avait pas livré sa fiche,
    # même si cette absence était un défaut de collecte et non une observation
    # négative. On conserve le montant théorique uniquement pour l'audit.
    from engine.equity_policy import build_equity_report
    equity = build_equity_report(course)
    legacy_total = rah269['total_penalty_ift']
    for row in rah269.get('rows', []):
        row['legacy_penalty_ift'] = row.get('penalty_ift', 0)
        row['base_legacy_penalty_ift'] = row.get('base_penalty_ift', 0)
        row['base_penalty_ift'] = 0
        row['penalty_ift'] = 0
        row['equity_policy'] = 'NONE_FOR_COLLECTION_GAP'
    rah269['legacy_total_penalty_ift'] = legacy_total
    rah269['total_penalty_ift'] = 0
    rah269['equity_policy'] = equity
    return {
        'rah269': rah269,
        'rah270': {'rule': 'RAH-270', 'status': 'CALCULATED' if any(row['status'] == 'CALCULATED' for row in rah270_rows) else 'UNPROVEN', 'rows': rah270_rows},
        'ift_penalty_applied': 0,
        'legacy_ift_penalty_not_applied': legacy_total,
        'equity_policy': equity,
    }
