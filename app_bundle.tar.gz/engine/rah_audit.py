"""Audit structuré des 22 règles inviolables et de leur niveau de preuve."""
from __future__ import annotations

from typing import Any, Dict

from collectors.source_orchestrator import calculer_sources_effectives


def _entry(rule_id: str, status: str, summary: str, evidence: Any = None, reason: str = '') -> Dict[str, Any]:
    return {
        'rule_id': rule_id,
        'status': status,
        'summary': summary,
        'evidence': evidence,
        'reason': reason,
    }


def _active_modules(course: Any) -> set[str]:
    return {m.nom for p in course.partants for m in getattr(p, 'modules_results', []) if getattr(m, 'actif', False)}


def _p5p6_evidence(course: Any) -> Dict[str, Any]:
    rows = []
    for partant in getattr(course, 'partants', []) or []:
        for module in getattr(partant, 'modules_results', []) or []:
            if getattr(module, 'nom', '') == 'P5P6':
                details = getattr(module, 'details', {}) or {}
                rows.append({'numero': getattr(partant, 'numero', None), 'status': details.get('status'), 'details': details, 'flags': getattr(module, 'flags', []) or []})
    statuses = [str(row.get('status', '')).upper() for row in rows]
    flags = sorted({flag for row in rows for flag in row.get('flags', []) or []})
    calculated = bool(rows) and all(status in {'CALCULATED', 'OBSERVED', 'APPLIED'} for status in statuses)
    return {'rows': rows, 'count': len(rows), 'statuses': sorted(set(statuses)), 'flags': flags, 'calculated': calculated}


def _pre_course_result_control(course: Any) -> Dict[str, Any]:
    """Contrôle uniquement une éventuelle fuite de résultat officiel pré-course."""
    meta = getattr(course, 'collecte_meta', {}) or {}
    suspicious = []
    explicit_keys = {'official_result', 'post_course_audit', 'arrival_position_per_runner', 'resultat_officiel', 'official_order'}
    for key in explicit_keys:
        if meta.get(key):
            suspicious.append({'location': 'collecte_meta', 'key': key})
    for collection_key in ('source_attempts', 'sources_consultees'):
        for item in meta.get(collection_key, []) or []:
            if not isinstance(item, dict):
                continue
            role = str(item.get('role', item.get('source_role', ''))).upper()
            if any(marker in role for marker in ('RESULTAT_OFFICIEL', 'POST_COURSE')) and item.get('order_observee'):
                suspicious.append({'location': collection_key, 'source': item.get('source'), 'role': role})
            if item.get('phase') == 'POST_COURSE' and item.get('order_observee'):
                suspicious.append({'location': collection_key, 'source': item.get('source'), 'phase': item.get('phase')})
    return {'checked': True, 'suspicious_markers': suspicious, 'status': 'FAIL' if suspicious else 'PASS'}


def _supra_s1_evidence(course: Any) -> Dict[str, Any]:
    context = getattr(course, 'rah_context', {}) or {}
    supra = context.get('supra', {}) if isinstance(context, dict) else {}
    if not isinstance(supra, dict):
        return {'status': 'UNPROVEN', 'reason': 'Sortie SUPRA absente'}
    decisions = list(supra.get('modifications_appliquees', []) or []) + list(supra.get('modifications_bloquees', []) or [])
    evidence = supra.get('s1_marche_evidence') or {}
    if not decisions:
        return {'status': 'N_A', 'decisions': 0, 'reason': 'Aucune décision SUPRA à justifier'}
    attached = all(isinstance(decision, dict) and decision.get('s1_marche_evidence') for decision in decisions)
    return {'status': 'PASS' if attached else 'UNPROVEN', 'decisions': len(decisions), 'attached': attached, 'evidence': evidence}


def construire_rah_audit(course: Any, textual: Dict[str, str]) -> Dict[str, Any]:
    """Convertit les contrôles applicatifs en preuves structurées et prudentes."""
    modules = _active_modules(course)
    collecte_meta = getattr(course, 'collecte_meta', {}) or {}
    sources = calculer_sources_effectives(collecte_meta)
    entries = (getattr(course, 'evidence_ledger', {}) or {}).get('entries', []) or []
    result: Dict[str, Dict[str, Any]] = {}

    result['REGLE_01'] = _entry('REGLE_01', 'PASS' if all(len(p.signaux) > 0 for p in course.partants) else 'FAIL', textual.get('REGLE_01', ''), {'partants': len(course.partants), 'partants_avec_signaux': sum(bool(p.signaux) for p in course.partants)})
    result['REGLE_02'] = _entry('REGLE_02', 'PASS' if entries and not any(str(e.get('status', '')).upper() in {'UNPROVEN', 'NC'} for e in entries) else 'UNPROVEN', textual.get('REGLE_02', ''), {'evidence_entries': len(entries)}, 'La provenance par champ doit être complète pour PASS')
    result['REGLE_03'] = _entry('REGLE_03', 'PASS', textual.get('REGLE_03', ''), {'pipeline': '12 étapes + 10bis'})
    result['REGLE_04'] = _entry('REGLE_04', 'PASS' if len(sources) >= 3 else 'UNPROVEN', textual.get('REGLE_04', ''), {'sources': len(sources), 'sources_effectives': sources}, 'Moins de trois sources effectivement exploitables')
    result['REGLE_05'] = _entry('REGLE_05', 'PASS' if course.gru_actif else 'FAIL', textual.get('REGLE_05', ''), {'hippodrome': course.hippodrome, 'gru_actif': course.gru_actif})
    required_modules = {'STAB', 'H2H_GRAPH', 'MODULE_TERRAIN_DYN', 'MODULE_DIST_ADAPT', 'MPA_CHAMP', 'TANDEM_BONUS', 'OVERBET_DETECTOR'}
    result['REGLE_06'] = _entry('REGLE_06', 'PASS' if required_modules.issubset(modules) else 'FAIL', textual.get('REGLE_06', ''), {'modules_actifs': sorted(modules), 'required_modules': sorted(required_modules)})

    expected_rules = {f'REGLE_{index:02d}' for index in range(1, 23)}
    result['REGLE_07'] = _entry('REGLE_07', 'PASS', textual.get('REGLE_07', ''), {'expected_rule_count': 22, 'registry_complete': True}, 'Registre des 22 règles construit par le présent audit')

    validation = (getattr(course, 'rah_context', {}) or {}).get('export_validation')
    if isinstance(validation, dict) and validation.get('valid') is True:
        result['REGLE_08'] = _entry('REGLE_08', 'PASS', textual.get('REGLE_08', ''), validation)
    elif isinstance(validation, dict) and validation.get('valid') is False:
        result['REGLE_08'] = _entry('REGLE_08', 'FAIL', textual.get('REGLE_08', ''), validation, 'Validation de l’export échouée')
    else:
        result['REGLE_08'] = _entry('REGLE_08', 'UNPROVEN', textual.get('REGLE_08', ''), {'validation_pending': True}, 'Validation exécutée après construction de l’export')

    result['REGLE_09'] = _entry('REGLE_09', 'PASS' if sources else 'UNPROVEN', textual.get('REGLE_09', ''), {'sources_effectives': sources, 'sources_effectives_count': len(sources)})
    result['REGLE_10'] = _entry('REGLE_10', 'PASS' if course.derived_metrics else 'UNPROVEN', textual.get('REGLE_10', ''), {'derived_metrics': bool(course.derived_metrics)})

    plat_handicap = bool(course.discipline and str(course.discipline.value).startswith('PLAT') and course.est_handicap)
    poids_active = any(m.nom == 'MODULE_POIDS' and m.actif for p in course.partants for m in p.modules_results)
    result['REGLE_11'] = _entry('REGLE_11', 'PASS' if not plat_handicap else ('PASS' if poids_active else 'FAIL'), textual.get('REGLE_11', ''), {'applicable': plat_handicap, 'module_actif': poids_active})

    trot_handicap = bool(course.discipline and str(course.discipline.value).startswith('TROT') and course.est_handicap)
    recul_active = any(m.nom == 'MODULE_RECUL' and m.actif for p in course.partants for m in p.modules_results)
    result['REGLE_12'] = _entry('REGLE_12', 'PASS' if not trot_handicap else ('PASS' if recul_active else 'FAIL'), textual.get('REGLE_12', ''), {'applicable': trot_handicap, 'module_actif': recul_active})
    result['REGLE_13'] = _entry('REGLE_13', 'PASS' if len(entries) > 0 else 'UNPROVEN', textual.get('REGLE_13', ''), {'evidence_entries': len(entries)})
    result['REGLE_14'] = _entry('REGLE_14', 'PASS' if course.ticket else 'UNPROVEN', textual.get('REGLE_14', ''), {'ticket_positions': len(course.ticket)})
    result['REGLE_15'] = _entry('REGLE_15', result['REGLE_05']['status'], textual.get('REGLE_15', ''), result['REGLE_05']['evidence'])
    result['REGLE_16'] = _entry('REGLE_16', 'PASS' if course.phase_b else 'FAIL', textual.get('REGLE_16', ''), {'phase_b': getattr(course.phase_b, 'value', None)})
    result['REGLE_17'] = _entry('REGLE_17', _supra_s1_evidence(course).get('status', 'UNPROVEN'), textual.get('REGLE_17', ''), _supra_s1_evidence(course), 'Chaque décision SUPRA doit porter la preuve S1-MARCHÉ')
    result['REGLE_18'] = _entry('REGLE_18', 'PASS' if course.supra_modifications <= 3 else 'FAIL', textual.get('REGLE_18', ''), {'modifications': course.supra_modifications})

    p5p6 = _p5p6_evidence(course)
    result['REGLE_19'] = _entry('REGLE_19', 'PASS' if p5p6['calculated'] else 'UNPROVEN', textual.get('REGLE_19', ''), p5p6, 'C2 doit être relié au registre de paliers RAH-150')

    result_control = _pre_course_result_control(course)
    result['REGLE_20'] = _entry('REGLE_20', result_control['status'], textual.get('REGLE_20', ''), result_control, 'Contrôle technique séparé de toute arrivée post-course')
    result['REGLE_21'] = _entry('REGLE_21', 'PASS' if all(0.65 <= p.produit_mult_ecrete <= 1.45 for p in course.partants if p.produit_mult_ecrete > 0) else 'FAIL', textual.get('REGLE_21', ''), {'bounds': [0.65, 1.45]})
    result['REGLE_22'] = _entry('REGLE_22', 'PASS' if course.gru_tier_c_prudence else 'N_A', textual.get('REGLE_22', ''), {'gru_tier_c_prudence': course.gru_tier_c_prudence})

    # Garde de cohérence interne : les 22 entrées doivent toujours exister.
    missing = sorted(expected_rules - set(result))
    if missing:
        for rule_id in missing:
            result[rule_id] = _entry(rule_id, 'UNPROVEN', '', None, 'Entrée RAH manquante')
    return result
