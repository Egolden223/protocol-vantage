"""Évaluation traçable des catalogues du protocole."""
from __future__ import annotations

from typing import Any, Dict

from engine.rules_registry import charger_catalogue


def _status_signal(signal: Any) -> str:
    if getattr(signal, 'flag_manquant', False):
        return 'NC'
    if getattr(signal, 'actif', False):
        return 'ACTIVE'
    if getattr(signal, 'source', '') or getattr(signal, 'raison_manquant', ''):
        return 'INACTIVE'
    return 'UNPROVEN'


def evaluer_catalogues_partant(partant: Any) -> Dict[str, Any]:
    catalogue = charger_catalogue().get('catalogues', {})
    signal_by_code = {str(signal.code).upper(): signal for signal in getattr(partant, 'signaux', [])}
    module_by_name = {str(module.nom).upper(): module for module in getattr(partant, 'modules_results', [])}
    ghost_rules = getattr(partant, 'ghost_details', {}).get('rules', {}) or {}
    ssfo_rules = getattr(partant, 'ssfo_details', {}).get('rules', {}) or {}
    gamma_rules = getattr(partant, 'gamma_details', {}).get('rules', {}) or {}
    rah_rules = getattr(partant, 'rah_details', {}).get('scores', {}) or {}
    output: Dict[str, Any] = {}

    for group, codes in catalogue.items():
        if group == 'rah':
            continue
        group_result = {}
        for code in codes:
            signal = signal_by_code.get(code)
            advanced = ghost_rules.get(code) or ssfo_rules.get(code) or gamma_rules.get(code) or ({'status': 'ACTIVE', 'value': value} if (value := rah_rules.get(code)) is not None else None)
            if signal is not None:
                status = _status_signal(signal)
                evidence = {
                    'value': getattr(signal, 'valeur', None),
                    'source': getattr(signal, 'source', None),
                    'famille': getattr(signal, 'famille', None),
                }
            elif advanced is not None:
                raw_status = advanced.get('status', 'UNPROVEN')
                status = 'ACTIVE' if raw_status == 'ACTIVE' else 'INACTIVE' if raw_status == 'INACTIVE' else 'UNPROVEN'
                evidence = advanced
            else:
                status = 'UNPROVEN'
                evidence = None
            group_result[code] = {
                'code': code,
                'status': status,
                'evidence': evidence,
                'reason': 'Signal déclaré dans le catalogue mais aucun évaluateur dédié relié' if status == 'UNPROVEN' else '',
            }
        output[group] = group_result

    partant.catalogue_status = output
    return output


def evaluer_catalogues_course(course: Any) -> Dict[str, Any]:
    totals: Dict[str, Dict[str, int]] = {}
    for partant in course.partants:
        result = evaluer_catalogues_partant(partant)
        for group, entries in result.items():
            group_totals = totals.setdefault(group, {})
            for entry in entries.values():
                status = entry['status']
                group_totals[status] = group_totals.get(status, 0) + 1
    summary = {
        'totals_by_catalogue_and_status': totals,
        'partants_evalues': len(course.partants),
        'catalogues': sorted(totals),
    }
    course.catalogue_coverage = summary
    return summary
