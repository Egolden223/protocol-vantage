"""Imputation neutre contrôlée après collecte multisource exhaustive.

Les valeurs produites ici ne sont pas des observations. Elles sont stockées dans
un registre séparé et doivent uniquement neutraliser un module mathématique.
"""
from __future__ import annotations

from typing import Any, Dict, List


NEUTRAL_CONTRACTS: Dict[str, Dict[str, Any]] = {
    'sov_v2': {
        'value': 0.0,
        'unit': 'score',
        'formula': 'SOV_v2_NEUTRAL = 0.0',
        'reason': 'Aucun mouvement de marché prouvé après recherche multisource',
        'allowed_effect': 'ORDRE_MULTIPLIER_NEUTRAL_ONLY',
    },
    'iql_v2': {
        'value': 1.0,
        'unit': 'multiplicateur',
        'formula': 'IQL_v2_NEUTRAL = 1.0',
        'reason': 'Aucun couple montant/allocation admissible après recherche multisource',
        'allowed_effect': 'ORDRE_MULTIPLIER_NEUTRAL_ONLY',
    },
    'h2h_norm': {
        'value': 0.0,
        'unit': 'score_normalise',
        'formula': 'H2H_NORM_NEUTRAL = 0.0',
        'reason': 'Aucune confrontation sourcée admissible après recherche multisource',
        'allowed_effect': 'COMPOSITE_RELATIONAL_COMPONENT_NEUTRAL_ONLY',
    },
    'context_contribution': {
        'value': 0.0,
        'unit': 'points_PCH',
        'formula': 'CONTEXT_CONTRIBUTION_NEUTRAL = 0.0',
        'reason': 'Aucun historique terrain/distance admissible après recherche multisource',
        'allowed_effect': 'PCH_MODULE_NEUTRAL_ONLY',
    },
}

FORBIDDEN_FACT_IMPUTATIONS = {
    'cote_matin', 'cote_avant_course', 'cote_finale', 'rk_brute',
    'position_arrivee', 'position_attendue', 'deferrage', 'oeilleres',
    'numero_corde', 'poids_actuel_kg', 'incident', 'disqualification',
    'allocation', 'montant', 'press_top5', 'gamma_signals', 'ssfo_signals',
}


def _source_names(rapport_collecte: Dict[str, Any]) -> List[str]:
    names = []
    for key in ('source_attempts', 'sources_consultees'):
        for item in rapport_collecte.get(key, []) or []:
            source = item.get('source') if isinstance(item, dict) else item
            if source and str(source).upper() not in names:
                names.append(str(source).upper())
    return names


def _field_exhausted(field: str, tableau_row: Dict[str, Any], rapport_collecte: Dict[str, Any]) -> Dict[str, Any]:
    """Détermine si l’imputation neutre est autorisée.

    La preuve d’épuisement est volontairement stricte : la ligne doit être
    présente dans le tableau consolidé, le champ doit être réellement absent,
    au moins trois sources effectives doivent avoir été tentées et aucune valeur
    du champ ne doit exister dans les observations conservées.
    """
    cell = (tableau_row.get('fields') or {}).get(field, {}) if isinstance(tableau_row, dict) else {}
    value = cell.get('value') if isinstance(cell, dict) else None
    sources = _source_names(rapport_collecte)
    effective = rapport_collecte.get('sources_effectives', []) or []
    no_observed_value = value in (None, '', 'NC', 'UNPROVEN')
    exhausted = bool(no_observed_value and len(set(str(x).upper() for x in effective)) >= 3 and len(sources) >= 3)
    return {
        'field': field,
        'exhausted': exhausted,
        'sources_attempted_count': len(sources),
        'sources_effective_count': len(effective),
        'observed_value': value,
        'reason': 'MULTISOURCE_EXHAUSTED' if exhausted else 'MULTISOURCE_NOT_EXHAUSTED',
    }


def apply_neutral_imputations(partants: List[Dict[str, Any]], tableau: Dict[str, Any], rapport_collecte: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows = {str(row.get('numero')): row for row in (tableau or {}).get('rows', []) if row.get('numero') is not None}
    applied = []
    for partant in partants or []:
        if not isinstance(partant, dict):
            continue
        row = rows.get(str(partant.get('numero')))
        if not row:
            continue
        raw = dict(partant.get('raw_data', {}) or {})
        registry = dict(raw.get('neutral_imputations', {}) or {})
        for field, contract in NEUTRAL_CONTRACTS.items():
            check = _field_exhausted(field, row, rapport_collecte)
            if not check['exhausted']:
                continue
            registry[field] = {
                **contract,
                'status': 'IMPUTED_NEUTRAL',
                'observed': False,
                'source': None,
                'source_status': 'EXHAUSTED_WITHOUT_OBSERVATION',
                'evidence': check,
                'contribution_rule': 'MUST_BE_ZERO_DIFFERENTIAL',
            }
        raw['neutral_imputations'] = registry
        raw['imputation_policy'] = 'HYBRID_MULTISOURCE_NEUTRAL_V1'
        partant['raw_data'] = raw
        if registry:
            applied.append({'numero': partant.get('numero'), 'fields': sorted(registry)})
    return partants, {
        'policy_version': 'HYBRID_MULTISOURCE_NEUTRAL_V1',
        'applied_count': len(applied),
        'partants': applied,
        'forbidden_fact_imputations': sorted(FORBIDDEN_FACT_IMPUTATIONS),
        'rule': 'NO_OBSERVED_VALUE_IS_CREATED',
    }
