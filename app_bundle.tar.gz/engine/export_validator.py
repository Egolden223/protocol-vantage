"""Validation déterministe de l’export Vantage et de sa trace d’audit."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

SCHEMA_PATH = Path(__file__).with_name('vantage_export.schema.json')


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def valider_export_vantage(document: Any) -> Dict[str, Any]:
    errors: List[str] = []
    warnings: List[str] = []
    if isinstance(document, str):
        try:
            document = json.loads(document)
        except json.JSONDecodeError as exc:
            return {'valid': False, 'errors': [f'JSON invalide: {exc}'], 'warnings': [], 'schema': str(SCHEMA_PATH)}
    if not isinstance(document, dict):
        return {'valid': False, 'errors': ['Export attendu comme objet JSON'], 'warnings': [], 'schema': str(SCHEMA_PATH)}

    schema = json.loads(SCHEMA_PATH.read_text(encoding='utf-8'))
    for key in schema.get('required', []):
        if key not in document:
            errors.append(f'Champ obligatoire absent: {key}')
    if document.get('protocol') != 'PROTOCOL_VANTAGE':
        errors.append('protocol doit être PROTOCOL_VANTAGE')

    checkpoint = document.get('checkpoint_bloc_4', {})
    if not isinstance(checkpoint, dict):
        errors.append('checkpoint_bloc_4 doit être un objet')
    else:
        if checkpoint.get('validation_mode') != 'AUTO_CONTINUE':
            errors.append('checkpoint_bloc_4.validation_mode doit être AUTO_CONTINUE')
        if checkpoint.get('decision') not in {'CONTINUE_FULL', 'CONTINUE_DEGRADED', 'BLOCKED_TECHNICAL'}:
            errors.append('Décision Bloc 4 invalide')

    certification = document.get('certification', {})
    if not isinstance(certification, dict) or 'ticket_certifie' not in certification or 'raisons' not in certification:
        errors.append('Certification incomplète')

    raw_ift = document.get('ift_score_raw')
    bounded_ift = document.get('ift_score')
    if not _is_number(raw_ift) or not _is_number(bounded_ift):
        errors.append('ift_score_raw et ift_score doivent être numériques')
    elif bounded_ift != max(0, min(100, raw_ift)):
        errors.append('ift_score ne correspond pas au bornage de ift_score_raw')

    partants = document.get('partants', [])
    if not isinstance(partants, list):
        errors.append('partants doit être un tableau')
        partants = []
    else:
        for index, partant in enumerate(partants):
            if not isinstance(partant, dict):
                errors.append(f'partants[{index}] doit être un objet')
                continue
            for key in ('numero', 'nom', 'extended_metrics', 'catalogue_status', 'scores', 'modules', 'data_quality'):
                if key not in partant:
                    errors.append(f'partants[{index}].{key} absent')

    trace = document.get('audit_trace')
    if not isinstance(trace, dict):
        errors.append('audit_trace doit être un objet')
    else:
        for key in ('trace_version', 'status', 'partants', 'phase_outputs', 'rah_trace', 'ticket_trace', 'attribution_completeness'):
            if key not in trace:
                errors.append(f'audit_trace.{key} absent')
        trace_rows = trace.get('partants', [])
        if not isinstance(trace_rows, list):
            errors.append('audit_trace.partants doit être un tableau')
            trace_rows = []
        elif len(trace_rows) != len(partants):
            errors.append('audit_trace.partants doit couvrir exactement tous les partants')
        for index, row in enumerate(trace_rows):
            if not isinstance(row, dict):
                errors.append(f'audit_trace.partants[{index}] doit être un objet')
                continue
            for key in ('field_evidence', 'raw_observations', 'market_observations', 'signals', 'modules', 'catalogues', 'scores', 'score_impact_ledger', 'ticket_decision', 'attribution_completeness'):
                if key not in row:
                    errors.append(f'audit_trace.partants[{index}].{key} absent')
            attribution = row.get('attribution_completeness', {})
            if isinstance(attribution, dict) and attribution.get('limits'):
                warnings.append(f"Partant {row.get('numero')}: attribution limitée — {attribution.get('limits')}")
        global_attr = trace.get('attribution_completeness', {})
        if isinstance(global_attr, dict) and global_attr.get('limits'):
            warnings.append(f"Trace globale: limites d’attribution — {global_attr.get('limits')}")

    # Un export peut rester structurellement valide avec des preuves UNPROVEN,
    # mais celles-ci doivent être visibles dans les avertissements.
    rah_audit = document.get('rah_audit', {})
    if isinstance(rah_audit, dict):
        unproven = [key for key, value in rah_audit.items() if isinstance(value, dict) and value.get('status') == 'UNPROVEN']
        if unproven:
            warnings.append(f'Règles RAH UNPROVEN: {sorted(unproven)}')

    return {
        'valid': not errors,
        'errors': errors,
        'warnings': warnings,
        'schema': str(SCHEMA_PATH),
        'checks': {
            'required_root_keys': not any('Champ obligatoire absent' in error for error in errors),
            'ift_raw_bounded_coherent': not any('ift_score ne correspond' in error for error in errors),
            'audit_trace_complete': not any(error.startswith('audit_trace') for error in errors),
            'runner_trace_coverage': not any('audit_trace.partants doit couvrir' in error for error in errors),
        },
    }
