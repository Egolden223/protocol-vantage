"""Calibration contrôlée des magnitudes GRU.

Le module produit uniquement des candidats et des rapports. Il ne modifie jamais
les règles actives automatiquement. Les courses incomplètes, ambiguës ou
potentiellement contaminées par une information future sont exclues.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple


POLICY = {
    'schema': 'VANTAGE_GRU_CALIBRATION_POLICY_V2',
    'min_races_total': 100,
    'min_races_train': 70,
    'min_races_validation': 30,
    'min_triggered_train': 100,
    'min_triggered_validation': 30,
    'min_time_blocks': 3,
    'holdout_fraction': 0.30,
    'min_validation_recall_gain': 0.02,
    'max_validation_recall_loss': 0.00,
    'max_block_recall_loss': 0.03,
    'max_abs_magnitude': 12.0,
    'shrinkage_prior_triggered': 100.0,
    'shrinkage_rounding_step': 0.5,
    # Grille centrale fine : les points +/-1 et +/-2 détectent les effets
    # modestes ; les extrêmes restent possibles uniquement si la preuve le
    # justifie et si le holdout les confirme.
    'magnitude_grid_default': [-12.0, -10.0, -8.0, -6.0, -5.0, -4.0, -3.0, -2.0, -1.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 12.0],
    'magnitude_grid_local': [-6.0, -4.0, -3.0, -2.0, -1.0, 0.0, 1.0, 2.0, 3.0, 4.0, 6.0],
    'magnitude_grid_risk': [-10.0, -8.0, -6.0, -5.0, -4.0, -3.0, -2.0, -1.0, 0.0],
    'activation_requires_complete_starter_denominator': True,
    'activation_requires_no_future_leakage': True,
    'recommended_sample_plan': {
        'screening': {'complete_races': 120, 'train_races': 84, 'validation_races': 36, 'min_time_blocks': 3, 'purpose': 'selection_initiale_shadow_only'},
        'confirmation': {'complete_races': 300, 'train_races': 210, 'validation_races': 90, 'min_time_blocks': 3, 'purpose': 'confirmation_hors_echantillon'},
        'activation_review': {'complete_races': 500, 'train_races': 350, 'validation_races': 150, 'min_time_blocks': 5, 'purpose': 'revue_finale_stabilite'},
    },
}


def _day(value: Any) -> Optional[date]:
    try:
        return date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        return None


def _num(value: Any) -> Optional[float]:
    try:
        if value in (None, '', 'NC', 'UNPROVEN'):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _number_key(value: Any) -> Tuple[int, str]:
    try:
        return (0, str(int(float(value))))
    except (TypeError, ValueError):
        return (1, str(value or ''))


def _truth(value: Any) -> bool:
    return value is True or value == 1 or str(value).strip().lower() in {'true', '1', 'yes', 'oui'}


def _rule_family(rule_code: str) -> str:
    code = str(rule_code).upper()
    if any(token in code for token in ('AUTO', 'VOLTE', 'CORDE', 'POSITION', 'STALLE', 'DEPART')):
        return 'LOCAL_TRACK_START'
    if any(token in code for token in ('RISK', 'DISQUAL', 'GALOP', 'CHUTE', 'FRAGILE')):
        return 'RISK_PENALTY'
    if any(token in code for token in ('MARCHE', 'COTE', 'ODDS', 'MARKET')):
        return 'MARKET'
    if any(token in code for token in ('TERRAIN', 'PSF', 'BOUE', 'LOURD')):
        return 'LOCAL_TRACK_START'
    return 'STRUCTURAL'


def _magnitude_grid(rule_code: str) -> List[float]:
    family = _rule_family(rule_code)
    key = {
        'LOCAL_TRACK_START': 'magnitude_grid_local',
        'RISK_PENALTY': 'magnitude_grid_risk',
        'MARKET': 'magnitude_grid_local',
        'STRUCTURAL': 'magnitude_grid_default',
    }[family]
    return list(POLICY[key])


def _feature_dates(race: Dict[str, Any]) -> List[str]:
    values: List[str] = []
    for row in race.get('partants', []) or []:
        for key in ('feature_timestamps', 'candidate_feature_timestamps', 'source_timestamps'):
            current = row.get(key, {}) if isinstance(row, dict) else {}
            if isinstance(current, dict):
                values.extend(str(value) for value in current.values() if value not in (None, ''))
            elif isinstance(current, list):
                values.extend(str(value) for value in current if value not in (None, ''))
    return values


def _has_future_leakage(race: Dict[str, Any]) -> bool:
    decision = race.get('decision_timestamp') or race.get('timestamp_decision') or race.get('pre_race_timestamp')
    if not decision:
        return False
    try:
        decision_dt = datetime.fromisoformat(str(decision).replace('Z', '+00:00'))
    except ValueError:
        return True
    for value in _feature_dates(race):
        try:
            feature_dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError:
            return True
        if feature_dt > decision_dt:
            return True
    return False


def _complete_race(race: Dict[str, Any]) -> bool:
    partants = race.get('partants')
    if not isinstance(partants, list) or len(partants) < 8:
        return False
    if race.get('all_starters_complete') is not True:
        return False
    declared = race.get('declared_starters')
    if declared is not None and _num(declared) != len(partants):
        return False
    if _has_future_leakage(race):
        return False
    official = race.get('official_top5')
    identifiers = {_number_key(row.get('numero'))[1] for row in partants if isinstance(row, dict)}
    if not isinstance(official, list) or len(official) < 5:
        return False
    top5 = [_number_key(value)[1] for value in official[:5]]
    if len(set(top5)) != 5 or not set(top5).issubset(identifiers):
        return False
    for row in partants:
        if not isinstance(row, dict) or _num(row.get('base_score')) is None:
            return False
        if _num(row.get('official_rank')) is None:
            return False
    return True


def _race_key(race: Dict[str, Any]) -> Tuple[str, str]:
    return (str(race.get('date') or ''), str(race.get('race_id') or race.get('id') or ''))


def _time_blocks(races: List[Dict[str, Any]]) -> int:
    blocks = {str(race.get('time_block') or str(race.get('date', ''))[:4]) for race in races}
    return len({block for block in blocks if block and block != 'None'})


def _trigger(row: Dict[str, Any], rule_code: str) -> bool:
    features = row.get('candidate_features') or {}
    candidates = row.get('gru_candidates') or {}
    return _truth(features.get(rule_code, candidates.get(rule_code, False)))


def _ticket_recall(race: Dict[str, Any], magnitude: float, rule_code: str) -> Optional[float]:
    rows = []
    for row in race.get('partants', []):
        base = _num(row.get('base_score'))
        if base is None:
            return None
        number = _number_key(row.get('numero'))
        score = base + (magnitude if _trigger(row, rule_code) else 0.0)
        rows.append((score, number, str(row.get('numero'))))
    if len(rows) < 8:
        return None
    rows.sort(key=lambda item: (-item[0], item[1]))
    ticket = {number for _, _, number in rows[:8]}
    top5 = {_number_key(x)[1] for x in race.get('official_top5', [])[:5]}
    return len({_number_key(x)[1] for x in ticket} & top5) / 5.0


def _mean_recall(races: List[Dict[str, Any]], magnitude: float, rule_code: str, replay_fn: Optional[Callable[[Dict[str, Any], str, float], Optional[float]]] = None) -> Optional[float]:
    values = [replay_fn(race, rule_code, magnitude) if replay_fn else _ticket_recall(race, magnitude, rule_code) for race in races]
    values = [x for x in values if x is not None]
    return sum(values) / len(values) if values else None


def _block_recalls(races: List[Dict[str, Any]], magnitude: float, rule_code: str, replay_fn: Optional[Callable[[Dict[str, Any], str, float], Optional[float]]] = None) -> Dict[str, Optional[float]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for race in races:
        block = str(race.get('time_block') or str(race.get('date', ''))[:4])
        grouped[block].append(race)
    return {block: _mean_recall(rows, magnitude, rule_code, replay_fn) for block, rows in sorted(grouped.items())}


def _triggered_count(races: Iterable[Dict[str, Any]], rule_code: str) -> int:
    return sum(1 for race in races for row in race.get('partants', []) if _trigger(row, rule_code))


def _split_temporal(races: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    ordered = sorted(races, key=_race_key)
    cut = max(1, min(len(ordered) - 1, int(round(len(ordered) * (1 - POLICY['holdout_fraction'])))))
    return ordered[:cut], ordered[cut:]


def _shrink_magnitude(raw_magnitude: float, triggered_train: int) -> Tuple[float, float]:
    """Réduit l’amplitude vers zéro lorsque le nombre d’observations est limité."""
    if not raw_magnitude or triggered_train <= 0:
        return 0.0, 0.0
    prior = float(POLICY['shrinkage_prior_triggered'])
    factor = triggered_train / (triggered_train + prior)
    step = float(POLICY['shrinkage_rounding_step'])
    shrunk = round((raw_magnitude * factor) / step) * step
    shrunk = max(-POLICY['max_abs_magnitude'], min(POLICY['max_abs_magnitude'], shrunk))
    return float(shrunk), round(factor, 6)


def _best_magnitude(train: List[Dict[str, Any]], rule_code: str, baseline: float, replay_fn: Optional[Callable[[Dict[str, Any], str, float], Optional[float]]] = None) -> Tuple[float, Dict[str, Any]]:
    candidates = []
    grid = _magnitude_grid(rule_code)
    for magnitude in grid:
        recall = _mean_recall(train, magnitude, rule_code, replay_fn)
        if recall is not None:
            candidates.append((recall, magnitude))
    if not candidates:
        return 0.0, {'status': 'UNPROVEN', 'reason': 'Aucune course exploitable', 'magnitude_grid': grid}
    # Maximiser le rappel ; à égalité choisir la plus petite magnitude absolue,
    # puis la valeur négative/positive de façon déterministe.
    selected_recall, selected = sorted(candidates, key=lambda item: (-item[0], abs(item[1]), item[1]))[0]
    raw_triggered = _triggered_count(train, rule_code)
    shrunk, shrinkage_factor = _shrink_magnitude(selected, raw_triggered)
    shrunk_recall = _mean_recall(train, shrunk, rule_code, replay_fn)
    return shrunk, {
        'status': 'CALCULATED',
        'magnitude_family': _rule_family(rule_code),
        'baseline_recall': round(baseline, 6),
        'selected_train_recall': round(shrunk_recall if shrunk_recall is not None else selected_recall, 6),
        'raw_selected_train_recall': round(selected_recall, 6),
        'raw_selected_magnitude': selected,
        'recommended_magnitude_after_shrinkage': shrunk,
        'shrinkage_factor': shrinkage_factor,
        'triggered_train_for_shrinkage': raw_triggered,
        'candidate_grid': [{'magnitude': magnitude, 'recall': round(recall, 6)} for recall, magnitude in sorted(candidates, key=lambda x: x[1])],
    }


def calibrate_gru_candidates(records: Iterable[Dict[str, Any]], candidate_rules: Optional[Iterable[str]] = None, replay_fn: Optional[Callable[[Dict[str, Any], str, float], Optional[float]]] = None) -> Dict[str, Any]:
    """Calibre les règles candidates sans les activer."""
    source_records = [record for record in records if isinstance(record, dict)]
    complete = [record for record in source_records if _complete_race(record)]
    incomplete_count = len(source_records) - len(complete)
    leakage_count = sum(1 for record in source_records if _has_future_leakage(record))
    rules = set(candidate_rules or [])
    if not rules:
        for race in complete:
            for row in race.get('partants', []):
                rules.update((row.get('candidate_features') or {}).keys())
                rules.update((row.get('gru_candidates') or {}).keys())
    rules = sorted(str(rule) for rule in rules if rule)
    result_rules: Dict[str, Any] = {}
    for rule_code in rules:
        triggered = _triggered_count(complete, rule_code)
        eligible_base = len(complete) >= POLICY['min_races_total'] and _time_blocks(complete) >= POLICY['min_time_blocks']
        train, validation = _split_temporal(complete) if len(complete) >= 2 else ([], [])
        train_triggered = _triggered_count(train, rule_code)
        validation_triggered = _triggered_count(validation, rule_code)
        baseline_train = _mean_recall(train, 0.0, rule_code, replay_fn)
        baseline_validation = _mean_recall(validation, 0.0, rule_code, replay_fn)
        selected, train_detail = _best_magnitude(train, rule_code, baseline_train or 0.0, replay_fn) if train else (0.0, {'status': 'UNPROVEN', 'reason': 'Train vide', 'magnitude_grid': _magnitude_grid(rule_code)})
        selected_validation = _mean_recall(validation, selected, rule_code, replay_fn)
        train_gain = (train_detail.get('selected_train_recall') - train_detail.get('baseline_recall')) if train_detail.get('status') == 'CALCULATED' else None
        validation_gain = (selected_validation - baseline_validation) if selected_validation is not None and baseline_validation is not None else None
        baseline_blocks = _block_recalls(validation, 0.0, rule_code, replay_fn)
        selected_blocks = _block_recalls(validation, selected, rule_code, replay_fn)
        block_losses = {
            block: round((selected_blocks.get(block) or 0.0) - (baseline_blocks.get(block) or 0.0), 6)
            for block in selected_blocks
        }
        max_block_loss = min(block_losses.values()) if block_losses else None
        status = 'SHADOW_ONLY'
        reasons = []
        if incomplete_count:
            reasons.append('INCOMPLETE_RACES_EXCLUDED')
        if leakage_count:
            reasons.append('FUTURE_LEAKAGE_RACES_EXCLUDED')
        if not eligible_base:
            reasons.append('INSUFFICIENT_COMPLETE_RACES_OR_TIME_BLOCKS')
        if len(train) < POLICY['min_races_train']:
            reasons.append('INSUFFICIENT_TRAIN_RACES')
        if len(validation) < POLICY['min_races_validation']:
            reasons.append('INSUFFICIENT_VALIDATION_RACES')
        if train_triggered < POLICY['min_triggered_train']:
            reasons.append('INSUFFICIENT_TRAIN_TRIGGER_OBSERVATIONS')
        if validation_triggered < POLICY['min_triggered_validation']:
            reasons.append('INSUFFICIENT_VALIDATION_TRIGGER_OBSERVATIONS')
        if validation_gain is None or validation_gain < POLICY['min_validation_recall_gain']:
            reasons.append('VALIDATION_GAIN_BELOW_THRESHOLD')
        if validation_gain is not None and validation_gain < -POLICY['max_validation_recall_loss']:
            reasons.append('VALIDATION_RECALL_LOSS')
        if max_block_loss is not None and max_block_loss < -POLICY['max_block_recall_loss']:
            reasons.append('TEMPORAL_BLOCK_INSTABILITY')
        if selected and abs(selected) > POLICY['max_abs_magnitude']:
            reasons.append('MAGNITUDE_OUT_OF_BOUNDS')
        if replay_fn is None:
            reasons.append('FULL_PIPELINE_REPLAY_NOT_PROVIDED')
        if not reasons:
            status = 'ELIGIBLE_FOR_ACTIVATION_REVIEW'
        result_rules[rule_code] = {
            'status': status,
            'candidate_magnitude': selected,
            'magnitude_family': _rule_family(rule_code),
            'magnitude_grid': _magnitude_grid(rule_code),
            'source_races': len(source_records),
            'complete_races': len(complete),
            'time_blocks': _time_blocks(complete),
            'triggered_partants': triggered,
            'train': {'races': len(train), 'triggered_partants': train_triggered, 'baseline_recall': baseline_train, 'selected_recall': train_detail.get('selected_train_recall'), 'gain': train_gain},
            'validation': {'races': len(validation), 'triggered_partants': validation_triggered, 'baseline_recall': baseline_validation, 'selected_recall': selected_validation, 'gain': validation_gain, 'baseline_blocks': baseline_blocks, 'selected_blocks': selected_blocks, 'block_gains': block_losses, 'max_block_loss': max_block_loss},
            'selection_detail': train_detail,
            'activation_reasons': reasons,
            'activation_policy': 'REVIEW_REQUIRED_NO_AUTO_ACTIVATION',
        }
    return {
        'schema': 'VANTAGE_GRU_CALIBRATION_REPORT_V2',
        'status': 'CALIBRATION_CANDIDATES_ONLY',
        'policy': POLICY,
        'data_contract': {'complete_starter_denominator': True, 'pre_race_features_only': True, 'official_top5_required': True, 'minimum_partants': 8, 'timestamp_leakage_checked': True, 'evaluation_mode': 'FULL_PIPELINE_REPLAY' if replay_fn else 'BASE_SCORE_PROXY_SCREENING'},
        'source_records': len(source_records),
        'complete_records': len(complete),
        'excluded_incomplete_records': incomplete_count,
        'excluded_future_leakage_records': leakage_count,
        'rules': result_rules,
        'activation_patch': {'status': 'NOT_APPLIED', 'reason': 'Calibration never mutates runtime rules automatically', 'eligible_rules': [rule for rule, value in result_rules.items() if value['status'] == 'ELIGIBLE_FOR_ACTIVATION_REVIEW']},
    }
