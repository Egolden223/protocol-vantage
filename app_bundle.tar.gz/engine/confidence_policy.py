"""Politique de confiance de l'exécution Protocol Vantage.

La politique distingue le mode d'exécution technique AUTO_CONTINUE du mode de
fidélité des données. Elle ne fabrique aucune valeur de remplacement.
"""
from __future__ import annotations

from typing import Any, Dict, List


def _non_empty(value: Any) -> bool:
    return value not in (None, '', 0, 'NC', 'UNPROVEN')


def _quality_statuses(course) -> Dict[str, List[int]]:
    statuses: Dict[str, List[int]] = {}
    for partant in course.partants or []:
        for field, status in (partant.data_quality or {}).items():
            statuses.setdefault(str(status).upper(), []).append(partant.numero)
    return statuses


def evaluer_mode_fidelite(course, rapport_gmov: Dict[str, Any] | None = None) -> Dict[str, Any]:
    rapport_gmov = rapport_gmov or {}
    critical_missing: List[str] = []
    degraded_reasons: List[str] = []
    proxy_fields: List[str] = []

    if not _non_empty(course.date):
        critical_missing.append('course.date')
    if not _non_empty(course.hippodrome):
        critical_missing.append('course.hippodrome')
    if not course.numero_course:
        critical_missing.append('course.numero_course')
    if course.discipline is None:
        critical_missing.append('course.discipline')
    if not course.partants:
        critical_missing.append('course.partants')

    numbers = [p.numero for p in course.partants or []]
    if len(numbers) != len(set(numbers)):
        critical_missing.append('partants.numero_unique')
    if course.partants and any(not _non_empty(p.nom) for p in course.partants):
        critical_missing.append('partants.nom')
    if course.partants and any(p.cote is None or p.cote <= 0 for p in course.partants):
        degraded_reasons.append('cote_absente_ou_non_positive')

    quality = _quality_statuses(course)
    if quality.get('UNPROVEN'):
        degraded_reasons.append('champs_UNPROVEN')
    if quality.get('PARTIAL'):
        degraded_reasons.append('champs_PARTIAL')

    gmov_evidence = rapport_gmov.get('gmov_evidence', {}) if isinstance(rapport_gmov, dict) else {}
    if gmov_evidence.get('p_top5_proxy_used'):
        proxy_fields.append('GMO_V.P_TOP5')
    if gmov_evidence.get('coverage_formula_status') == 'HEURISTIC_PROXY':
        proxy_fields.append('GMO_V.COUVERTURE_JOINTE')
    if rapport_gmov.get('pool_elargi', {}).get('fallback_admission_numbers'):
        proxy_fields.append('GMO_V.POOL_ELARGI_FALLBACK')
    if proxy_fields:
        degraded_reasons.append('proxy_ou_fallback_GMO_V')

    harville_unproven = any(
        isinstance(value, dict) and value.get('status') == 'UNPROVEN'
        for value in (rapport_gmov.get('rah167', {}) or {}).values()
    )
    if harville_unproven:
        degraded_reasons.append('harville_UNPROVEN')

    phase_b = getattr(course.phase_b, 'value', course.phase_b)
    if phase_b in {'DEGRADEE', 'NEUTRALISEE'}:
        degraded_reasons.append(f'phase_b_{str(phase_b).lower()}')

    if critical_missing:
        mode = 'NON_CERTIFIABLE'
    elif proxy_fields or degraded_reasons:
        mode = 'DEGRADEE'
    else:
        mode = 'INTEGRALE'

    confidence = 1.0
    confidence -= min(0.45, 0.15 * len(critical_missing))
    confidence -= min(0.35, 0.07 * len(set(degraded_reasons)))
    confidence -= min(0.30, 0.10 * len(set(proxy_fields)))
    confidence = round(max(0.0, min(1.0, confidence)), 3)

    return {
        'mode_fidelite': mode,
        'confidence': confidence,
        'critical_missing': sorted(set(critical_missing)),
        'degraded_reasons': sorted(set(degraded_reasons)),
        'proxy_fields': sorted(set(proxy_fields)),
        'quality_statuses': {key: sorted(set(values)) for key, values in quality.items()},
        'ticket_effect_policy': 'UNPROVEN_NC_NO_DIRECT_EFFECT',
        'certification_policy': 'INTEGRALE_ONLY_WITHOUT_CRITICAL_MISSING_PROXY_OR_FALLBACK',
    }
