"""Calculateurs déterministes des formules explicites du protocole maître.

Chaque calcul renvoie valeur, statut, entrées et flags. Une formule dont les
entrées ou coefficients normatifs manquent reste NC/UNPROVEN : aucun nombre
n'est fabriqué pour obtenir artificiellement un score.
"""
from __future__ import annotations

from statistics import mean
from typing import Any, Dict, Iterable, Optional

from engine.gru_recalibration_segments import build_gru_recalibration_context


def clamp(lo: float, hi: float, value: float) -> float:
    return max(lo, min(hi, value))


def _result(metric: str, value: Any, status: str, inputs: Dict[str, Any], formula: str, flags=None, reason='') -> Dict[str, Any]:
    return {
        'metric': metric,
        'value': value,
        'status': status,
        'inputs': inputs,
        'formula': formula,
        'flags': flags or [],
        'reason': reason,
    }


def valeur_pmu_alternative(
    gains_totaux_eur: Optional[float],
    nb_courses: Optional[int],
    victoires_total: Optional[int],
    places_total: Optional[int],
    cote_matin: Optional[float],
) -> Dict[str, Any]:
    """Formule protocolaire 2.5bis, avec clamp [20,45]."""
    inputs = {
        'gains_totaux_eur': gains_totaux_eur,
        'nb_courses': nb_courses,
        'victoires_total': victoires_total,
        'places_total': places_total,
        'cote_matin': cote_matin,
    }
    if gains_totaux_eur is not None and nb_courses and nb_courses > 0 and victoires_total is not None and places_total is not None:
        taux_top5 = (victoires_total + places_total) / max(nb_courses, 1)
        brute = 15 + gains_totaux_eur / 10000 + victoires_total * 2 + taux_top5 * 10
        flags = ['VALEUR_PMU_CALCULEE']
    elif cote_matin is not None and cote_matin > 0:
        brute = 30 - (cote_matin - 5) / 2
        flags = ['VALEUR_PMU_CALCULEE']
    else:
        return _result('valeur_pmu_calculee', None, 'NC', inputs, 'clamp(20,45,valeur_brute)', reason='Entrées insuffisantes')
    value = clamp(20, 45, brute)
    if brute < 20 or brute > 45:
        flags.append('VALEUR_FORTEMENT_ESTIMEE')
    return _result('valeur_pmu_calculee', round(value, 4), 'CALCULATED', inputs, 'clamp(20,45,15+gains/10000+victoires*2+taux_top5*10) ou 30-(cote_matin-5)/2', flags)


def gain_par_course(gains_totaux_eur: Optional[float], nb_courses: Optional[int]) -> Dict[str, Any]:
    inputs = {'gains_totaux_eur': gains_totaux_eur, 'nb_courses': nb_courses}
    if gains_totaux_eur is None or nb_courses is None:
        return _result('gain_par_course', None, 'NC', inputs, 'gains_totaux_eur/max(nb_courses,1)', reason='Gains ou nombre de courses absent')
    return _result('gain_par_course', round(gains_totaux_eur / max(nb_courses, 1), 4), 'CALCULATED', inputs, 'gains_totaux_eur/max(nb_courses,1)')


def snapshots_cotes(cote_matin: Optional[float], cote_avant_course: Optional[float], nb_snapshots: int = 0) -> Dict[str, Any]:
    inputs = {'cote_matin': cote_matin, 'cote_avant_course': cote_avant_course, 'nb_snapshots': nb_snapshots}
    flags = []
    if cote_matin is None or cote_avant_course is None or cote_matin <= 0:
        flags.append('VAC_ABS_MANQUANT')
        return _result('delta_cote_pct', None, 'NC', inputs, '(cote_matin-cote_avant_course)/cote_matin*100', flags, 'Deux snapshots requis')
    delta = (cote_matin - cote_avant_course) / cote_matin * 100
    vac_abs = abs(cote_matin - cote_avant_course)
    return {
        'delta_cote_pct': _result('delta_cote_pct', round(delta, 4), 'CALCULATED', inputs, '(cote_matin-cote_avant_course)/cote_matin*100'),
        'vac_abs': _result('vac_abs', round(vac_abs, 4), 'CALCULATED', inputs, '|cote_matin-cote_avant_course|'),
        'direction': 'BAISSE' if delta > 0 else 'HAUSSE' if delta < 0 else 'STABLE',
        'flags': flags,
    }


def all_score(allocations_last3: Iterable[float], allocation_course_actuelle: Optional[float]) -> Dict[str, Any]:
    allocations = [float(x) for x in allocations_last3 if x is not None]
    inputs = {'allocations_last3': allocations, 'allocation_course_actuelle': allocation_course_actuelle}
    if not allocations or allocation_course_actuelle is None or allocation_course_actuelle <= 0:
        return _result('all_score', 1.0, 'NC', inputs, 'mean(allocations_last3)/allocation_course_actuelle', ['ALL_MANQUANT'], 'Formule neutre imposée par le protocole en cas d’absence')
    return _result('all_score', round(mean(allocations) / allocation_course_actuelle, 6), 'CALCULATED', inputs, 'mean(allocations_last3)/allocation_course_actuelle')


def h2h_norm(h2h_avg: Optional[float]) -> Dict[str, Any]:
    inputs = {'h2h_avg': h2h_avg}
    if h2h_avg is None:
        return _result('h2h_norm', None, 'NC', inputs, 'clamp(-1,1,h2h_avg/15)', reason='Historique H2H absent')
    return _result('h2h_norm', round(clamp(-1, 1, h2h_avg / 15), 6), 'CALCULATED', inputs, 'clamp(-1,1,h2h_avg/15)')


def tandem_bonus(taux_top5: Optional[float], coeff_nb: Optional[float], coeff_temps: Optional[float], nb_courses_ensemble: Optional[int]) -> Dict[str, Any]:
    inputs = {
        'taux_top5': taux_top5,
        'coeff_nb': coeff_nb,
        'coeff_temps': coeff_temps,
        'nb_courses_ensemble': nb_courses_ensemble,
    }
    if nb_courses_ensemble == 0:
        return _result('tandem_bonus', 0.0, 'CALCULATED', inputs, 'taux_top5*coeff_nb*coeff_temps', ['PREMIERE_ASSOCIATION'], 'Aucune course commune')
    if None in (taux_top5, coeff_nb, coeff_temps):
        return _result('tandem_bonus', None, 'NC', inputs, 'taux_top5*coeff_nb*coeff_temps', reason='Taux ou coefficients normatifs absents')
    return _result('tandem_bonus', round(taux_top5 * coeff_nb * coeff_temps, 6), 'CALCULATED', inputs, 'taux_top5*coeff_nb*coeff_temps')


def enrichir_partant(partant: Any) -> Dict[str, Any]:
    """Calcule les métriques explicites disponibles pour un partant."""
    raw = dict(getattr(partant, 'raw_data', {}) or {})
    metrics: Dict[str, Any] = {}

    def first(*keys):
        for key in keys:
            if raw.get(key) is not None:
                return raw.get(key)
        return None

    metrics['gain_par_course'] = gain_par_course(
        first('gains_totaux_eur', 'gains_total', 'gains'),
        first('nb_courses', 'nombreCourses'),
    )
    metrics['valeur_pmu_alternative'] = valeur_pmu_alternative(
        first('gains_totaux_eur', 'gains_total', 'gains'),
        first('nb_courses', 'nombreCourses'),
        first('victoires_total', 'nombreVictoires', 'victoires'),
        first('places_total', 'nombrePlaces', 'places'),
        first('cote_matin', 'coteMatin'),
    )
    metrics['snapshots_cotes'] = snapshots_cotes(
        first('cote_matin', 'coteMatin'),
        first('cote_avant_course', 'coteAvantCourse', 'cote'),
        int(first('nb_snapshots', 'nombreSnapshots') or 0),
    )
    metrics['all_score'] = all_score(
        first('allocations_last3', 'allocations_3_dernieres') or [],
        first('allocation_course_actuelle', 'allocation'),
    )
    metrics['h2h_norm'] = h2h_norm(first('h2h_avg', 'h2h_moyenne'))
    metrics['tandem_bonus'] = tandem_bonus(
        first('taux_top5_tandem', 'taux_top5'),
        first('coeff_nb_tandem', 'coeff_nb'),
        first('coeff_temps_tandem', 'coeff_temps'),
        first('nb_courses_ensemble', 'tandem_courses'),
    )

    # Les modules réellement branchés dans modules/normative.py sont signalés
    # comme délégués à leur exécuteur. Ils ne doivent pas apparaître à la fois
    # comme calculés et comme UNPROVEN dans le même export.
    delegated = ('IFF_v2', 'NRC', 'BSH_v4', 'BSC_v3', 'CRE_v2', 'FORME_LINEAIRE', 'GAMMA', 'SRI_v2', 'CSF', 'PDQ', 'P5P6')
    for module in delegated:
        metrics[module] = _result(
            module,
            None,
            'DEFERRED_TO_NORMATIVE_MODULE',
            {},
            f'{module}: calcul exécuté dans modules/normative.py ou advanced_catalogues.py',
            reason='Le statut détaillé et les entrées sont portés par modules_results',
        )

    # Ne jamais remplacer silencieusement des métriques déjà produites par un
    # module amont : les segments et les diagnostics doivent coexister avec les
    # formules déléguées et les preuves existantes.
    previous = dict(getattr(partant, 'extended_metrics', {}) or {})
    previous.update(metrics)
    partant.extended_metrics = previous
    return previous


def enrichir_course(course: Any) -> Dict[str, Any]:
    """Enrichit tous les partants et retourne une synthèse de couverture."""
    statuses = {}
    for partant in course.partants:
        metrics = enrichir_partant(partant)
        for metric, result in metrics.items():
            if isinstance(result, dict):
                statuses.setdefault(metric, {})[result.get('status', 'UNKNOWN')] = statuses.setdefault(metric, {}).get(result.get('status', 'UNKNOWN'), 0) + 1
    recalibration_context = build_gru_recalibration_context(course)
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        p_segment = {
            'numero': getattr(partant, 'numero', None),
            'style_mpa': raw.get('style_mpa'),
            'numero_autostart': raw.get('numero_autostart', raw.get('numero')),
            'numero_corde': raw.get('numero_corde', raw.get('stalle')),
            'status': 'OBSERVED' if raw else 'UNPROVEN',
            'policy': 'SEGMENT_ONLY_NO_SCORE_IMPACT',
        }
        partant.extended_metrics['gru_recalibration_segment'] = p_segment

    summary = dict(getattr(course, 'derived_metrics', {}) or {})
    summary.update({
        'metrics_by_status': statuses,
        'partants_enrichis': len(course.partants),
        'mode': 'EXPLICIT_FORMULAS_ONLY',
        'gru_recalibration_context': recalibration_context,
    })
    course.derived_metrics = summary
    return summary
