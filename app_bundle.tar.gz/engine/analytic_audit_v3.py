"""Audit analytique V3 des scores Vantage.

Ce module produit une analyse descriptive et contrefactuelle. Il ne modifie
jamais le ticket gelé, les scores pré-course ni les données historiques.
"""
from __future__ import annotations

from statistics import median
from typing import Any, Dict, List, Optional


def _number(value: Any) -> Optional[float]:
    if value in (None, '', 'NC', 'UNPROVEN'):
        return None
    if isinstance(value, str) and value.startswith(('NC:', 'UNPROVEN:')):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _module_entries(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    modules = row.get('modules') or {}
    if isinstance(modules, dict):
        iterator = modules.items()
    elif isinstance(modules, list):
        iterator = ((item.get('nom', item.get('module_id', f'MODULE_{i}')), item) for i, item in enumerate(modules) if isinstance(item, dict))
    else:
        iterator = []
    result = []
    for module_id, raw in iterator:
        if not isinstance(raw, dict):
            continue
        details = raw.get('details') if isinstance(raw.get('details'), dict) else {}
        score = _number(raw.get('score', details.get('score'))) or 0.0
        impact = _number(raw.get('impact_pch', details.get('impact_pch')))
        if impact is None and str(module_id) not in {'CSF', 'PDQ', 'P5P6', 'GHOST'}:
            impact = score
        status = raw.get('status') or raw.get('statut') or details.get('status') or details.get('execution_status') or 'UNPROVEN'
        result.append({
            'module_id': str(module_id),
            'score': round(score, 6),
            'impact_pch': round(impact, 6) if impact is not None else None,
            'status': str(status),
            'actif': bool(raw.get('actif', True)),
            'formula': raw.get('formula') or details.get('formula') or details.get('formule'),
            'flags': list(raw.get('flags') or details.get('flags') or []),
            'path': details.get('impact_path') or details.get('effect_path'),
        })
    return result


def _ticket_numbers(ticket: Any) -> List[int]:
    values = ticket.values() if isinstance(ticket, dict) else ticket if isinstance(ticket, list) else []
    result = []
    for value in values:
        if isinstance(value, dict):
            value = value.get('numero', value.get('numPmu', value.get('number')))
        try:
            n = int(value)
        except (TypeError, ValueError):
            continue
        if n not in result:
            result.append(n)
    return result


def _row_score(row: Dict[str, Any], key: str) -> Optional[float]:
    return _number((row.get('scores') or {}).get(key))


def _ordre_multiplier(factors: Dict[str, Any]) -> Optional[float]:
    values = []
    for key, default in (('sov_v2', 0.0), ('iql', 1.0), ('tact_mult', 1.0), ('stab_mult', 1.0), ('all_mult', 1.0), ('harville_mult', 1.0), ('gru_enghien_mult', 1.0)):
        value = _number(factors.get(key))
        values.append(default if value is None else (1.0 + value if key == 'sov_v2' else value))
    return values[0] * values[1] * values[2] * values[3] * values[4] * values[5] * values[6]


def _rank_map(rows: List[Dict[str, Any]]) -> Dict[int, int]:
    ordered = sorted(rows, key=lambda row: (_row_score(row, 'ordre_score') if _row_score(row, 'ordre_score') is not None else float('-inf')), reverse=True)
    return {int(row.get('numero')): index for index, row in enumerate(ordered, 1) if str(row.get('numero', '')).isdigit()}


def _counterfactual(row: Dict[str, Any], module_id: str, contribution: float, current: Dict[str, Optional[float]], components: Dict[str, Any], factors: Dict[str, Any]) -> Dict[str, Any]:
    pch_final = current.get('pch_final')
    composite = current.get('composite')
    ordre = current.get('ordre_score')
    if pch_final is None:
        return {'status': 'UNPROVEN', 'reason': 'PCH_FINAL absent'}
    pch_without = _clamp(pch_final - contribution, 0.0, 220.0)
    w_pch = _number(components.get('w_PCH')) or 0.0
    pch_norm_without = pch_without / 220.0
    tocard = _number(row.get('tocard_score')) or 0.0
    w_tocard = _number(components.get('w_tocard')) or 0.0
    csf = _number(components.get('csf_norm')) or 0.0
    h2h = _number(components.get('h2h_norm')) or 0.0
    w_csf = _number(components.get('w_CSF')) or 0.0
    w_h2h = _number(components.get('w_H2H')) or 0.10
    composite_without = _clamp(w_pch * pch_norm_without + w_tocard * _clamp(tocard, 0.0, 1.0) + w_csf * _clamp(csf, 0.0, 1.0) + w_h2h * _clamp(h2h, -1.0, 1.0), 0.0, 1.0)
    multiplier = _ordre_multiplier(factors)
    ordre_without = composite_without * multiplier if multiplier is not None else None
    current_ranked = {'pch_final': round(pch_without, 6), 'composite': round(composite_without, 6), 'ordre_score': round(ordre_without, 6) if ordre_without is not None else None}
    return {
        'status': 'ANALYTIC_ONLY',
        'module': module_id,
        'removed_contribution_pch': round(contribution, 6),
        'scores_without_module': current_ranked,
        'delta_scores': {
            'pch_final': round(pch_without - pch_final, 6),
            'composite': round(composite_without - (composite or 0.0), 6),
            'ordre_score': round(ordre_without - (ordre or 0.0), 6) if ordre_without is not None else None,
        },
        'does_not_modify_ticket': True,
    }


def build_score_diagnostics_v3(export_data: Dict[str, Any], audit: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Construit les diagnostics V3 à partir de l’export pré-course et de l’audit éventuel."""
    export_data = export_data if isinstance(export_data, dict) else {}
    audit = audit if isinstance(audit, dict) else {}
    rows = [row for row in (export_data.get('partants') or []) if isinstance(row, dict)]
    rank_map = _rank_map(rows)
    ticket = _ticket_numbers(export_data.get('ticket_final') or export_data.get('ticket') or {})
    ticket_set = set(ticket)
    ordered_scores = sorted([_row_score(row, 'ordre_score') for row in rows if _row_score(row, 'ordre_score') is not None], reverse=True)
    rank8 = ordered_scores[7] if len(ordered_scores) >= 8 else None
    ticket_scores = [_row_score(row, 'ordre_score') for row in rows if int(row.get('numero', -1)) in ticket_set and _row_score(row, 'ordre_score') is not None]
    ticket_cutoff = min(ticket_scores) if ticket_scores else rank8
    official = ((audit.get('metrics') or {}).get('top5_officiel') or [])
    official_set = set(int(x) for x in official if str(x).isdigit())
    rows_out: Dict[str, Any] = {}
    module_aggregate: Dict[str, Dict[str, Any]] = {}

    for row in rows:
        try:
            number = int(row.get('numero'))
        except (TypeError, ValueError):
            continue
        scores = {
            'pch_brut': _row_score(row, 'pch_brut'),
            'pch_final': _row_score(row, 'pch_final'),
            'composite': _row_score(row, 'composite'),
            'ordre_score': _row_score(row, 'ordre_score'),
            'produit_mult_brut': _row_score(row, 'produit_mult_brut'),
            'produit_mult_ecrete': _row_score(row, 'produit_mult_ecrete'),
        }
        extended = row.get('extended_metrics') if isinstance(row.get('extended_metrics'), dict) else {}
        components = extended.get('composite_components') if isinstance(extended.get('composite_components'), dict) else {}
        factors = extended.get('ordre_factors') if isinstance(extended.get('ordre_factors'), dict) else {}
        recalibration_segment = extended.get('gru_recalibration_segment') if isinstance(extended.get('gru_recalibration_segment'), dict) else {'status': 'UNPROVEN', 'policy': 'SEGMENT_ONLY_NO_SCORE_IMPACT'}
        gru = _number(extended.get('gru_pch_contribution'))
        modules = _module_entries(row)
        module_sum = round(sum(item['impact_pch'] or 0.0 for item in modules if item['actif'] and item['module_id'] not in {'CSF', 'PDQ', 'P5P6', 'GHOST'}), 6)
        waterfall = [
            {'step': 'PCH_BRUT', 'value': scores['pch_brut'], 'status': 'OBSERVED' if scores['pch_brut'] is not None else 'UNPROVEN'},
            {'step': 'GRU', 'delta': gru, 'value_after': round((scores['pch_brut'] or 0.0) + (gru or 0.0), 6), 'status': 'CALCULATED' if gru is not None else 'UNPROVEN'},
            {'step': 'MODULES_PCH', 'delta': module_sum, 'value_after': scores['pch_final'], 'status': 'CALCULATED' if module_sum != 0 else 'NEUTRAL_OR_UNPROVEN'},
            {'step': 'PCH_FINAL', 'value': scores['pch_final'], 'status': 'CALCULATED' if scores['pch_final'] is not None else 'UNPROVEN'},
            {'step': 'COMPOSITE', 'value': scores['composite'], 'components': {key: components.get(key) for key in ('w_PCH', 'w_tocard', 'w_CSF', 'w_H2H', 'PCH_NORM', 'csf_norm', 'h2h_norm') if key in components}},
            {'step': 'ORDRE_SCORE', 'value': scores['ordre_score'], 'factors': {key: factors.get(key) for key in ('sov_v2', 'iql', 'tact_mult', 'stab_mult', 'all_mult', 'harville_mult', 'gru_enghien_mult') if key in factors}},
        ]
        contributions = []
        counterfactuals = {}
        if gru is not None and gru != 0:
            contributions.append({'source': 'GRU', 'module': 'GRU_TOTAL_PARTANT', 'delta_pch': round(gru, 6), 'status': 'CALCULATED'})
            counterfactuals['without_gru'] = _counterfactual(row, 'GRU_TOTAL_PARTANT', gru, scores, components, factors)
        for module in modules:
            if not module['actif']:
                continue
            delta = module['impact_pch']
            if delta is None or delta == 0:
                continue
            contributions.append({'source': 'MODULE', 'module': module['module_id'], 'delta_pch': delta, 'score_raw': module['score'], 'status': module['status'], 'path': module['path']})
            if module['module_id'] not in {'CSF', 'PDQ', 'P5P6', 'GHOST'}:
                counterfactuals[f"without_{module['module_id']}"] = _counterfactual(row, module['module_id'], delta, scores, components, factors)
            stats = module_aggregate.setdefault(module['module_id'], {'activated_count': 0, 'positive_count': 0, 'negative_count': 0, 'sum_delta_pch': 0.0, 'affected_horses': []})
            stats['activated_count'] += 1
            stats['positive_count'] += int(delta > 0)
            stats['negative_count'] += int(delta < 0)
            stats['sum_delta_pch'] += delta
            stats['affected_horses'].append(number)
        missing_fields = [key for key, value in (row.get('data_quality') or {}).items() if value in (None, '', 'NC', 'UNPROVEN') or (isinstance(value, str) and value.startswith(('NC:', 'UNPROVEN:')))]
        pre_rank = rank_map.get(number)
        score = scores['ordre_score']
        rank_delta_to_eight = (8 - pre_rank) if pre_rank is not None else None
        if number in official_set and number not in ticket_set:
            cause = 'MISSED_TOP5'
        elif number not in official_set and number in ticket_set:
            cause = 'FALSE_POSITIVE_TICKET'
        elif scores['pch_brut'] and scores['pch_final'] is not None and scores['pch_final'] <= 0 < scores['pch_brut']:
            cause = 'PCH_COLLAPSE'
        elif missing_fields:
            cause = 'DATA_GAP_OR_UNPROVEN'
        elif pre_rank is not None and pre_rank > 8:
            cause = 'RANK_BELOW_TICKET'
        else:
            cause = 'NO_DOMINANT_CAUSE'
        rows_out[str(number)] = {
            'numero': number,
            'nom': row.get('nom', 'NC'),
            'scores': scores,
            'rank_pre_course': pre_rank,
            'ticket_position': row.get('position_ticket'),
            'official_rank_top5': (official.index(number) + 1) if number in official_set else None,
            'distance_to_rank8': round((score - rank8), 6) if score is not None and rank8 is not None else None,
            'distance_to_ticket_cutoff': round((score - ticket_cutoff), 6) if score is not None and ticket_cutoff is not None else None,
            'rank_delta_to_ticket': rank_delta_to_eight,
            'missing_fields': missing_fields,
            'recalibration_segment': recalibration_segment,
            'positive_modules': [item['module'] for item in contributions if item['delta_pch'] > 0],
            'negative_modules': [item['module'] for item in contributions if item['delta_pch'] < 0],
            'module_contributions': contributions,
            'score_waterfall': waterfall,
            'counterfactuals': counterfactuals,
            'root_cause_class': cause,
            'counterfactual_policy': 'ANALYTIC_ONLY_NO_RETROACTIVE_TICKET_CHANGE',
        }

    for stats in module_aggregate.values():
        stats['sum_delta_pch'] = round(stats['sum_delta_pch'], 6)
        stats['mean_delta_pch'] = round(stats['sum_delta_pch'] / stats['activated_count'], 6) if stats['activated_count'] else 0.0
        stats['affected_horses'] = sorted(stats['affected_horses'])
    cause_counts: Dict[str, int] = {}
    for row in rows_out.values():
        cause = row['root_cause_class']
        cause_counts[cause] = cause_counts.get(cause, 0) + 1
    return {
        'schema': 'VANTAGE_SCORE_DIAGNOSTICS_V3',
        'status': 'DESCRIPTIVE_AND_COUNTERFACTUAL_ANALYTIC',
        'policy': 'No recalculation changes the frozen pre-course ticket or historical scores.',
        'ticket_numbers': ticket,
        'ticket_cutoff_ordre_score': ticket_cutoff,
        'rank8_ordre_score': rank8,
        'official_top5': official,
        'recalibration_context': (export_data.get('derived_metrics') or {}).get('gru_recalibration_context', {'status': 'UNPROVEN'}),
        'by_horse': rows_out,
        'aggregate_calibration': {
            'sample_size': 1,
            'status': 'DESCRIPTIVE_ONLY_SINGLE_RACE',
            'module_summary': module_aggregate,
            'root_cause_counts': cause_counts,
            'parameter_adjustment_allowed': False,
            'minimum_walk_forward_sample_recommended': 100,
            'segmentation_policy': 'OBSERVED_AXES_ONLY_NO_NEW_MAGNITUDE_NO_SCORE_IMPACT',
        },
    }
