"""Segments observables pour la future calibration des GRU.

Ce module ne modifie aucun score. Il transforme uniquement les données
observées en catégories de contexte et marque explicitement les dimensions
manquantes ou non prouvées.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, Optional
import unicodedata


KNOWN_TERRAIN = {
    'BON', 'LEGER', 'LÉGER', 'SOUPLE', 'MOYEN_SOUPLE', 'MOYEN SOUPLE',
    'LOURD', 'TRES_LOURD', 'TRÈS_LOURD', 'COLLANT', 'SEC', 'FERME',
}


def _norm(value: Any) -> str:
    text = str(value or '').strip().upper()
    return ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')


def _number(value: Any) -> Optional[float]:
    if value in (None, '', 'NC', 'UNPROVEN'):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _first_raw(partants: Iterable[Any], *keys: str) -> Any:
    for partant in partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        for key in keys:
            value = raw.get(key)
            if value not in (None, '', 'NC', 'UNPROVEN'):
                return value
    return None


def _axis(value: Any, status: str, reason: str, evidence: Optional[list] = None) -> Dict[str, Any]:
    return {
        'value': value,
        'status': status,
        'reason': reason,
        'evidence_fields': evidence or [],
    }


def _canonical_hippo(value: Any) -> str:
    return _norm(value).replace(' ', '-').replace('/', '-')


def build_gru_recalibration_context(course: Any) -> Dict[str, Any]:
    """Retourne le contexte segmenté et neutre pour la calibration future."""
    partants = list(getattr(course, 'partants', []) or [])
    hippo = _canonical_hippo(getattr(course, 'hippodrome', ''))
    discipline = _norm(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')))
    distance = _number(getattr(course, 'distance', None))
    surface = _norm(getattr(course, 'piste', ''))
    surface = _norm(_first_raw(partants, 'surface', 'surface_piste') or surface)
    terrain = _norm(getattr(course, 'terrain', ''))
    penetrometre = _number(getattr(course, 'penetrometre', None))
    type_depart = _norm(getattr(getattr(course, 'type_depart', None), 'value', getattr(course, 'type_depart', '')))

    if hippo == 'DEAUVILLE':
        if surface in {'PSF', 'SABLE-FIBRE', 'SABLE_FIBRE', 'SABLE FIBRE'} and distance == 1900:
            track_variant = _axis('PSF_1900', 'OBSERVED', 'Surface et distance observées', ['surface', 'distance'])
        elif distance == 2200 and (_first_raw(partants, 'piste_ronde', 'parcours_piste_ronde') is True):
            track_variant = _axis('PISTE_RONDE_2200', 'OBSERVED', 'Parcours rond explicitement observé', ['distance', 'piste_ronde'])
        elif distance == 1600 and (_first_raw(partants, 'ligne_droite', 'parcours_ligne_droite') is True):
            track_variant = _axis('LIGNE_DROITE_1600', 'OBSERVED', 'Ligne droite explicitement observée', ['distance', 'ligne_droite'])
        else:
            track_variant = _axis('UNPROVEN', 'UNPROVEN', 'Parcours Deauville exact non observé', ['surface', 'distance'])
    elif hippo == 'CHANTILLY':
        if surface in {'PSF', 'SABLE-FIBRE', 'SABLE_FIBRE', 'SABLE FIBRE'}:
            track_variant = _axis('PSF', 'OBSERVED', 'Surface PSF observée', ['surface'])
        elif _first_raw(partants, 'ligne_droite') is True:
            track_variant = _axis('LIGNE_DROITE', 'OBSERVED', 'Ligne droite explicitement observée', ['ligne_droite'])
        elif _first_raw(partants, 'virage_1600') is True:
            track_variant = _axis('VIRAGE_1600', 'OBSERVED', 'Virage 1600 explicitement observé', ['virage_1600'])
        else:
            track_variant = _axis('UNPROVEN', 'UNPROVEN', 'Parcours Chantilly exact non observé', ['surface', 'distance'])
    elif hippo == 'AUTEUIL':
        obstacle_type = _norm(_first_raw(partants, 'type_obstacle', 'parcours_obstacle', 'specialite_obstacle'))
        if discipline == 'HAIES' or 'HAIE' in obstacle_type:
            track_variant = _axis('HAIES', 'OBSERVED', 'Spécialité haies observée', ['discipline', 'type_obstacle'])
        elif discipline == 'OBSTACLE' and ('STEEPLE' in obstacle_type or _first_raw(partants, 'steeple') is True):
            track_variant = _axis('STEEPLE', 'OBSERVED', 'Spécialité steeple observée', ['discipline', 'type_obstacle'])
        else:
            track_variant = _axis('OBSTACLE_TYPE_UNPROVEN', 'UNPROVEN', 'Haies/steeple non séparé par une preuve explicite', ['discipline', 'type_obstacle'])
    elif hippo in {'CABOURG', 'VINCENNES'}:
        if type_depart in {'AUTOSTART', 'VOLTE'}:
            track_variant = _axis(f'{type_depart}_DIST_{int(distance) if distance is not None else "NC"}', 'OBSERVED', 'Mode de départ et distance observés', ['type_depart', 'distance'])
        else:
            track_variant = _axis('DEPART_UNPROVEN', 'UNPROVEN', 'Mode de départ non observé', ['type_depart'])
    else:
        track_variant = _axis('GENERIC', 'OBSERVED', 'Axe hippodrome générique sans nouvelle magnitude', ['hippodrome'])

    terrain_axis = _axis(terrain, 'OBSERVED', 'État du terrain fourni par la course', ['terrain']) if terrain in KNOWN_TERRAIN or terrain in {_norm(x) for x in KNOWN_TERRAIN} else None
    if terrain_axis is None and penetrometre is not None:
        terrain_axis = _axis('PENETROMETRE_OBSERVED', 'OBSERVED', 'Pénétromètre observé sans conversion silencieuse en état de terrain', ['penetrometre'])
    elif terrain_axis is None:
        terrain_axis = _axis('NC', 'NC', 'Terrain et pénétromètre absents', ['terrain', 'penetrometre'])

    meeting_position = _number(_first_raw(partants, 'num_course_dans_reunion', 'numero_course_reunion'))
    dynamic_axis = _axis('COURSE_7_PLUS', 'OBSERVED', 'Position dans la réunion observée', ['num_course_dans_reunion']) if meeting_position is not None and meeting_position >= 7 else _axis('NON_DETERMINE', 'UNPROVEN', 'Position ou dynamique intra-réunion non prouvée', ['num_course_dans_reunion'])

    if type_depart == 'AUTOSTART':
        positions = [_number((getattr(p, 'raw_data', {}) or {}).get('numero_autostart', (getattr(p, 'raw_data', {}) or {}).get('numero'))) for p in partants]
        positions = [int(x) for x in positions if x is not None and x > 0]
        start_axis = _axis({'mode': 'AUTOSTART', 'positions_observed': len(positions), 'positions': positions}, 'OBSERVED' if positions else 'UNPROVEN', 'Numéro derrière la voiture observé ou absent', ['type_depart', 'numero_autostart'])
    elif type_depart == 'VOLTE':
        start_axis = _axis({'mode': 'VOLTE'}, 'OBSERVED', 'Départ volté observé ; aucun numéro de corde substitué', ['type_depart'])
    else:
        start_axis = _axis({'mode': 'NC'}, 'NC', 'Mode de départ absent', ['type_depart'])

    required = {
        'hippodrome': _axis(hippo or 'NC', 'OBSERVED' if hippo else 'NC', 'Identité hippodrome', ['hippodrome']),
        'discipline': _axis(discipline or 'NC', 'OBSERVED' if discipline else 'NC', 'Discipline', ['discipline']),
        'distance': _axis(distance, 'OBSERVED' if distance is not None else 'NC', 'Distance', ['distance']),
        'surface': _axis(surface or 'NC', 'OBSERVED' if surface else 'NC', 'Surface', ['surface']),
    }
    return {
        'schema': 'VANTAGE_GRU_RECALIBRATION_CONTEXT_V1',
        'status': 'OBSERVED_PARTIAL',
        'policy': 'SEGMENT_ONLY_NO_NEW_MAGNITUDE_NO_SCORE_IMPACT',
        'axes': {
            'track_variant': track_variant,
            'terrain': terrain_axis,
            'meeting_dynamics': dynamic_axis,
            'departure': start_axis,
            **required,
        },
        'calibration_keys': [
            'hippodrome', 'track_variant', 'discipline', 'distance', 'surface',
            'terrain', 'type_depart', 'numero_autostart', 'meeting_dynamics',
            'peloton_size',
        ],
        'missing_or_unproven_axes': [
            key for key, value in {
                'track_variant': track_variant,
                'terrain': terrain_axis,
                'meeting_dynamics': dynamic_axis,
                'departure': start_axis,
            }.items() if value.get('status') in {'NC', 'UNPROVEN'}
        ],
    }
