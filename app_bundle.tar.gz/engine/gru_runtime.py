"""Runtime GRU géographique : règles explicites, conditionnelles et traçables."""
from __future__ import annotations

from typing import Any, Dict, List

from engine.models import Course, Partant, RegleGRU, TierGRU
from engine.gru_activation import calibrated_contribution, activation_state


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def _tier(level: str) -> TierGRU:
    return {'STRICT': TierGRU.A, 'DEGRADE': TierGRU.B, 'MINIMAL': TierGRU.C}.get(level, TierGRU.C)


def _add(regles: List[RegleGRU], code: str, hippo: str, level: str, description: str, contribution: float) -> None:
    effective, provenance = calibrated_contribution(code, contribution)
    regles.append(RegleGRU(
        code=code,
        hippodrome=hippo,
        tier=_tier(level),
        description=description,
        pch_contribution=effective,
        actif=True,
        calibration_provenance=provenance,
    ))


def appliquer_regles_gru(course: Course) -> Dict[str, Any]:
    hippo = (course.hippodrome or '').upper().replace('É', 'E').replace(' ', '-')
    # Le registre de course est reconstruit à chaque appel : le pipeline peut
    # être rejoué et ne doit jamais cumuler deux fois les mêmes règles.
    course.gru_regles.clear()
    course.gru_tier_c_prudence = False
    regles_par_partant: Dict[str, List[Dict[str, Any]]] = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        numero = int(_num(raw.get('numero_autostart', raw.get('numero', partant.numero)), partant.numero))
        stalle = _num(raw.get('numero_corde', raw.get('stalle', numero)))
        style = str(raw.get('style_mpa', '')).upper()
        rules: List[RegleGRU] = []
        direction_data = raw.get('top3_direction_counts')
        course_direction = str(raw.get('sens_rotation_course', raw.get('sens_hippodrome', '')) or '').upper()
        if isinstance(direction_data, dict):
            left = _num(direction_data.get('GAUCHE'), 0) or 0
            right = _num(direction_data.get('DROITE'), 0) or 0
            total_direction = left + right
            dominant = 'GAUCHE' if left >= right else 'DROITE'
            if total_direction >= 5 and max(left, right) / total_direction >= .60 and course_direction in {'GAUCHE', 'DROITE'}:
                contribution = 4 if dominant == course_direction else -4
                _add(rules, 'RAH-135', hippo, 'DEGRADE', 'GRU-DIRECTION sens de rotation >=60% Top3', contribution)

        discipline = str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')) or '').upper()
        age = _num(getattr(partant, 'age', None))
        # RAH-124 : âge × distance longue TROT.
        if discipline in {'TROT_ATTELE', 'TROT_MONTE'} and course.distance >= 2800 and age is not None:
            contribution = -8 if age >= 10 else -5 if age == 9 else -3 if age == 8 else 0 if age == 7 else 4
            _add(rules, 'RAH-124-GRU-DIST-1', hippo, 'DEGRADE', 'Âge × distance longue TROT (RAH-124)', contribution)
        # RAH-125 : sexe sur très longue distance, uniquement si le sexe est fourni.
        sexe = str(raw.get('sexe', raw.get('sex', '')) or '').upper().replace('É', 'E')
        male_entier = bool(raw.get('male_entier')) or sexe in {'MALE_ENTIER', 'ENTIER', 'ETALON'}
        jument = sexe in {'JUMENT', 'FEMELLE', 'FEMELLE_ENTIERE'}
        if discipline in {'TROT_ATTELE', 'TROT_MONTE'} and course.distance > 2800:
            if male_entier: _add(rules, 'RAH-125-GRU-DIST-2', hippo, 'DEGRADE', 'Mâle entier fond >2800m', 5)
            elif jument: _add(rules, 'RAH-125-GRU-DIST-2', hippo, 'DEGRADE', 'Jument fond >2800m', -5)
        # RAH-126 : style structurel du fond TROT, avec rythme lent atténuant.
        if discipline in {'TROT_ATTELE', 'TROT_MONTE'} and course.distance >= 2700:
            style_upper = style.replace('-', '_').replace('É', 'E')
            base = 5 if 'ATTENT' in style_upper else 3 if 'CHASSEUR' in style_upper else -3 if 'MENEUR_MODERE' in style_upper or 'MENEUR_MODERE' in style_upper else -6 if 'MENEUR_FORT' in style_upper else None
            if base is not None:
                if course.distance >= 3000: base *= 1.5
                if str(raw.get('rythme_projete', '') or '').upper() == 'LENT': base *= .5
                _add(rules, 'RAH-126-GRU-DIST-3', hippo, 'DEGRADE', 'Style structurel fond TROT (RAH-126)', max(-20, min(20, base)))
        # RAH-127 : changement de distance, avec preuve historique explicite.
        previous_distance = _num(raw.get('distance_precedente', raw.get('distance_derniere')))
        won_same_distance = raw.get('victoire_deja_distance_aujourd_hui') is True or raw.get('victoire_sur_distance_aujourdhui') is True
        if previous_distance is not None and not won_same_distance:
            change = course.distance - previous_distance
            if change < 0 and abs(change) <= 150: _add(rules, 'RAH-127-GRU-DIST-4', hippo, 'DEGRADE', 'Raccourcissement <=150m', 3)
            elif change < 0 and abs(change) <= 300: _add(rules, 'RAH-127-GRU-DIST-4', hippo, 'DEGRADE', 'Raccourcissement <=300m', 5)
            elif change >= 400: _add(rules, 'RAH-127-GRU-DIST-4', hippo, 'DEGRADE', 'Allongement >=400m', -5)
            elif change >= 200: _add(rules, 'RAH-127-GRU-DIST-4', hippo, 'DEGRADE', 'Allongement >=200m', -3)
        if discipline == 'PLAT' and str(raw.get('surface', getattr(course, 'piste', '')) or '').upper() == 'PSF' and raw.get('psf_premier_engagement') is True:
            _add(rules, 'RAH-127-GRU-DIST-4-PSF', hippo, 'DEGRADE', 'Premier engagement PSF PLAT', -4)
        # RAH-128 : numéro de départ à la volte, jamais numéro de corde.
        type_depart = str(getattr(getattr(course, 'type_depart', None), 'value', getattr(course, 'type_depart', '')) or '').upper()
        if type_depart == 'VOLTE':
            contribution = 5 if 13 <= numero <= 16 else 2 if 9 <= numero <= 12 else -4 if 1 <= numero <= 4 else 0
            if bool(raw.get('virages_nombreux')) and course.distance < 2000:
                contribution *= .5
            if contribution:
                _add(rules, 'RAH-128-GRU-VOLTE-1', hippo, 'DEGRADE', 'Numéro de classe au départ volté', contribution)
        # RAH-141 : Vincennes D4 sur piste mâchefer, amplification D42 ×1,2.
        surface_vincennes = str(raw.get('surface', getattr(course, 'piste', '')) or '').upper()
        if hippo == 'VINCENNES' and surface_vincennes in {'MACHEFER', 'MÂCHEFER'}:
            d42_value = _num(raw.get('d42_pch', raw.get('d42_value')))
            if d42_value is None:
                d42_value = next((_num(signal.valeur) for signal in getattr(partant, 'signaux', []) if getattr(signal, 'code', '') == 'D42' and getattr(signal, 'actif', False)), None)
            if d42_value is not None:
                _add(rules, 'RAH-141-GRU-VINCENNES-D4', hippo, 'DEGRADE', 'Piste mâchefer : D42 amplifié ×1,2', d42_value * .20)
        # RAH-140 : Compiègne, fiche Tier C à 40%.
        if hippo == 'COMPIEGNE' and course.distance == 1800:
            if 'MENEUR_FORT' in style or 'MENEUR FORT' in style:
                _add(rules, 'RAH-140-GRU-COMPIEGNE-MENEUR', hippo, 'MINIMAL', 'Compiègne 1800m MENEUR_FORT (+6 Tier C)', 6)
            elif 'ATTENT' in style:
                _add(rules, 'RAH-140-GRU-COMPIEGNE-ATTENTISTE', hippo, 'MINIMAL', 'Compiègne 1800m ATTENTISTE (-5 Tier C)', -5)
        if hippo == 'COMPIEGNE' and discipline in {'OBSTACLE', 'HAIES'}:
            terrain_souple = str(getattr(course, 'terrain', '') or '').upper() in {'SOUPLE', 'MOYEN_SOUPLE'}
            if terrain_souple:
                _add(rules, 'RAH-140-GRU-COMPIEGNE-SOUPLE', hippo, 'MINIMAL', 'Terrain souple : biais Compiègne neutralisé', 0)
            terrain_lourd = str(getattr(course, 'terrain', '') or '').upper() in {'LOURD', 'TRES_LOURD', 'TRÈS_LOURD', 'COLLANT'}
            if terrain_lourd and raw.get('specialiste_boue') is True:
                _add(rules, 'RAH-140-GRU-COMPIEGNE-BOUE', hippo, 'MINIMAL', 'Obstacle lourd spécialiste boue (+10 Tier C)', 10)
        # RAH-139 : Auteuil, profils obstacle et terrain lourd.
        if hippo == 'AUTEUIL' and discipline in {'OBSTACLE', 'HAIES'}:
            terrain_lourd = str(getattr(course, 'terrain', '') or '').upper() in {'LOURD', 'TRES_LOURD', 'TRÈS_LOURD', 'COLLANT'} or (_num(course.penetrometre) is not None and _num(course.penetrometre) > 4.5)
            if raw.get('debutant_auteuil') is True or raw.get('debutant') is True:
                _add(rules, 'RAH-139-GRU-AUTEUIL-DEBUTANT', hippo, 'DEGRADE', 'Auteuil débutant (-8 ×70%)', -8 * .70)
            if raw.get('specialiste_auteuil') is True or raw.get('specialiste_obstacle') is True:
                _add(rules, 'RAH-139-GRU-AUTEUIL-SPECIALISTE', hippo, 'DEGRADE', 'Auteuil spécialiste (+5 additionnel ×70%)', 5 * .70)
            if raw.get('chute_recente') is True or raw.get('chute_obstacle_recente') is True:
                _add(rules, 'RAH-139-GRU-AUTEUIL-CHUTE', hippo, 'DEGRADE', 'Chute récente (-10 ×70%)', -10 * .70)
            if terrain_lourd and raw.get('specialiste_boue') is True:
                _add(rules, 'RAH-139-GRU-AUTEUIL-BOUE', hippo, 'STRICT', 'Terrain lourd boue : spécialiste (+10)', 10)
            if partant.age is not None and partant.age >= 10:
                _add(rules, 'RAH-139-GRU-AUTEUIL-AGE', hippo, 'DEGRADE', 'Auteuil âge >=10 ans (-5 ×70%)', -5 * .70)
        # RAH-138 : Angers, recul 50m et driver local, Tier C (40%).
        driver = str(raw.get('driver', raw.get('driver_jockey', raw.get('jockey', ''))) or '').upper()
        if hippo == 'ANGERS' and driver in {'MONCLIN', 'MOTTIER'}:
            _add(rules, 'RAH-138-GRU-B12-LOCAL', hippo, 'MINIMAL', 'Driver local Monclin/Mottier : B12 renforcé à +12', 12)
        # RAH-136 : cheval inédit; neutralisation PDQ/B47/PENTE et bonus entraîneur TOP STRICT.
        premiere_course = raw.get('premiere_course') is True or raw.get('cheval_inedit') is True or raw.get('nb_courses_total') == 0
        if premiere_course and raw.get('entraineur_top_strict') is True:
            _add(rules, 'RAH-136-GRU-NOEUF-TOP', hippo, 'STRICT', 'Cheval inédit avec entraîneur TOP STRICT', 6)
        # RAH-134 : chevaux scandinaves au départ autostart, Tier C (40%).
        pays = str(raw.get('pays_origine', raw.get('nationalite', raw.get('pays', ''))) or '').upper()
        nordique = pays in {'SUEDE', 'SUÈDE', 'NORVEGE', 'NORVÈGE', 'FINLANDE', 'DANEMARK', 'SWEDEN', 'NORWAY', 'FINLAND', 'DENMARK'}
        if discipline in {'TROT_ATTELE', 'TROT_MONTE'} and type_depart == 'AUTOSTART' and nordique:
            _add(rules, 'RAH-134-GRU-ETRANGER', hippo, 'MINIMAL', 'Cheval scandinave autostart (+5 Tier C)', 5)
            if raw.get('premiere_course_france') is True or raw.get('premiere_course_en_france') is True:
                _add(rules, 'RAH-134-GRU-ETRANGER-DECOUVERTE', hippo, 'MINIMAL', 'Première course en France (-4 Tier C)', -4)
        # RAH-132 : terrain herbe PLAT/OBSTACLE, Tier B à 70%; PSF exclue.
        surface = str(raw.get('surface', getattr(course, 'piste', '')) or '').upper()
        terrain = str(getattr(course, 'terrain', '') or '').upper()
        if discipline in {'PLAT', 'OBSTACLE', 'HAIES'} and surface not in {'PSF', 'SYNTHETIQUE'}:
            if terrain in {'SOUPLE', 'MOYEN_SOUPLE'}:
                if 'ATTENT' in style:
                    _add(rules, 'RAH-132-GRU-TERRAIN-1', hippo, 'DEGRADE', 'Terrain souple : ATTENTISTE (+4 ×70%)', 4 * .70)
                elif 'MENEUR_FORT' in style or 'MENEUR FORT' in style:
                    _add(rules, 'RAH-132-GRU-TERRAIN-1', hippo, 'DEGRADE', 'Terrain souple : MENEUR_FORT (-4 ×70%)', -4 * .70)
            elif terrain in {'LOURD', 'TRÈS_LOURD', 'TRES_LOURD', 'COLLANT'}:
                if raw.get('specialiste_terrain_lourd') is True:
                    _add(rules, 'RAH-132-GRU-TERRAIN-1', hippo, 'DEGRADE', 'Terrain lourd : spécialiste (+12 ×70%)', 12 * .70)
                elif raw.get('experience_terrain_lourd') is False or raw.get('antecedent_terrain_lourd') is False:
                    _add(rules, 'RAH-132-GRU-TERRAIN-1', hippo, 'DEGRADE', 'Terrain lourd : aucun antécédent (-10 ×70%)', -10 * .70)
        if hippo == 'VINCENNES':
            if course.type_depart and str(course.type_depart.value).upper() == 'AUTOSTART' and course.distance == 2100:
                if numero in {4, 5, 6}: _add(rules, 'GRU-VINC-AUTO-CENTRE', hippo, 'STRICT', 'Autostart 2100m : positions centrales', 12)
                elif numero == 3: _add(rules, 'GRU-VINC-AUTO-3', hippo, 'STRICT', 'Autostart 2100m : proche centre', 8)
                elif numero in {1, 9}: _add(rules, 'GRU-VINC-AUTO-PIEGE', hippo, 'STRICT', 'Autostart 2100m : enfermement ou extérieur', -5)
                elif numero in {10, 11}: _add(rules, 'GRU-VINC-AUTO-2L-INT', hippo, 'STRICT', 'Autostart 2100m : deuxième ligne intérieure', -10)
                elif numero >= 13: _add(rules, 'GRU-VINC-AUTO-2L-EXT', hippo, 'STRICT', 'Autostart 2100m : deuxième ligne extérieure', -8)
            if course.distance >= 2700 and bool(raw.get('victoire_caen_enghien_2500')):
                _add(rules, 'GRU-VINC-ENDURANCE', hippo, 'DEGRADE', 'Vainqueur Caen/Enghien >=2500m', 10)
            if course.distance >= 2400 and bool(raw.get('pur_sprinter_sans_victoire_fond')):
                _add(rules, 'GRU-VINC-SPRINTER-FOND', hippo, 'DEGRADE', 'Pur sprinteur sans victoire sur fond', -8)
            if course.type_depart and str(course.type_depart.value).upper() == 'VOLTE' and bool(raw.get('driver_specialiste_vincennes')):
                _add(rules, 'GRU-VINC-VOLTE-DRIVER', hippo, 'DEGRADE', 'Driver spécialiste tactique à la volte', 0)
        elif hippo in {'LONGCHAMP', 'PARISLONGCHAMP'}:
            if course.distance == 1600 and stalle in {1, 2}: _add(rules, 'GRU-LONG-1600-CORDE', hippo, 'STRICT', 'Corde 1–2 sur 1600m', 5)
            if course.distance == 2100 and stalle in {4, 9}: _add(rules, 'GRU-LONG-2100-PEPITE', hippo, 'STRICT', 'Corde 4/9 sur 2100m', 8)
            if course.distance == 2100 and stalle in {5, 8}: _add(rules, 'GRU-LONG-2100-PIEGE', hippo, 'STRICT', 'Corde 5/8 sur 2100m', -8)
            if course.distance == 2100 and stalle in {13, 15, 16}: _add(rules, 'GRU-LONG-2100-EXTREME', hippo, 'STRICT', 'Corde extérieure défavorable sur 2100m', -12)
            if course.distance < 1600 and stalle is not None and stalle >= 14:
                contribution = -15 if len(course.partants) >= 14 and style.startswith('MENEUR') else -10
                _add(rules, 'GRU-LONG-CORDE-EXTREME-SPRINT', hippo, 'DEGRADE', 'Corde extérieure extrême sprint', contribution)
            penetro = _num(course.penetrometre)
            if course.distance == 2100 and penetro is not None and penetro >= 4.5:
                _add(rules, 'GRU-LONG-2100-LOURD', hippo, 'DEGRADE', 'Terrain lourd 2100m', 15 if bool(raw.get('specialiste_terrain_lourd')) else -10)
            if course.distance == 2400 and _num(partant.poids, 0) >= 60: _add(rules, 'GRU-LONG-TOPWEIGHT-2400', hippo, 'DEGRADE', 'Top-weight 2400m', -8)
            # RAH-130 : table empirique de corde optimale. Une fiche GRU
            # spécifique déjà active prime; la source ne donne pas de magnitude
            # PCH, donc aucune valeur numérique n’est inventée ici.
            rah130_range = None
            if course.distance < 1600:
                rah130_range = range(2, 11)
            elif course.distance == 1600:
                rah130_range = range(7, 11)
            elif 1700 <= course.distance <= 2100:
                rah130_range = range(6, 9)
            elif course.distance == 2400:
                rah130_range = range(4, 11)
            elif course.distance > 2400:
                rah130_range = range(3, 16)
            specific_longchamp = bool(rules)
            if rah130_range is not None and stalle in rah130_range and not specific_longchamp:
                _add(rules, 'RAH-130-GRU-LONGCHAMP', hippo, 'DEGRADE', 'Corde optimale empirique par distance; magnitude source NC, aucun bonus PCH inventé', 0.0)

        elif hippo == 'DEAUVILLE':
            if course.distance == 1900 and 11 <= stalle <= 13: _add(rules, 'GRU-DEAUV-1900-PEPITE', hippo, 'STRICT', 'PSF 1900m stalles 11–13', 6)
            if course.distance == 1900 and 14 <= stalle <= 16: _add(rules, 'GRU-DEAUV-1900-PIEGE', hippo, 'STRICT', 'PSF 1900m stalles 14–16', -8)
            if course.distance == 1500 and stalle <= 9: _add(rules, 'GRU-DEAUV-1500-CORDE', hippo, 'DEGRADE', 'PSF 1500m stalles 1–9', 5)
            if course.distance >= 1900 and bool(raw.get('specialiste_psf_hiver')): _add(rules, 'GRU-DEAUV-PSF-HIVER', hippo, 'DEGRADE', 'Spécialiste PSF hivernale', 6)
        elif hippo == 'CHANTILLY':
            if course.distance == 1900 and str(raw.get('surface', '')).upper() == 'PSF' and style.startswith('MENEUR') and stalle <= 4:
                _add(rules, 'GRU-CHAN-PSF-MENEUR', hippo, 'STRICT', 'Meneur corde 1–4 PSF 1900m', 12)
            if course.distance == 1900 and str(raw.get('surface', '')).upper() == 'PSF' and 'ATTENT' in style and stalle >= 12:
                _add(rules, 'GRU-CHAN-PSF-ATTENTISTE', hippo, 'STRICT', 'Attentiste corde extérieure PSF', -3 if raw.get('open_stretch') else -8)
            if course.distance in {2100, 2400} and bool(raw.get('specialiste_piste')): _add(rules, 'GRU-CHAN-SPECIALISTE', hippo, 'STRICT', 'Spécialiste du tracé', 10)
            # RAH-131 : Chantilly, biais inverse sur ligne droite / 1600m virage.
            # TIER C : magnitude normative ramenée à 40% et prudence obligatoire.
            ligne_droite = raw.get('ligne_droite') is True
            virage_1600 = raw.get('virage_1600') is True
            rah131_contribution = None
            rah131_description = None
            if course.distance < 1600 and ligne_droite and stalle == 18:
                rah131_contribution, rah131_description = 12 * .40, 'Chantilly ligne droite <1600m, corde18 avantagée (RAH-131 TIER C 40%)'
            elif course.distance < 1600 and ligne_droite and stalle == 1:
                rah131_contribution, rah131_description = -5 * .40, 'Chantilly ligne droite <1600m, corde1 défavorisée (RAH-131 TIER C 40%)'
            elif course.distance == 1600 and virage_1600 and stalle == 6:
                rah131_contribution, rah131_description = 12 * .40, 'Chantilly 1600m virage, corde6 avantagée (RAH-131 TIER C 40%)'
            if rah131_contribution is not None:
                _add(rules, 'RAH-131', hippo, 'MINIMAL', rah131_description, rah131_contribution)
                course.gru_tier_c_prudence = True
        elif hippo == 'NANTES':
            if course.distance == 1600:
                poids_moy = _num(raw.get('poids_moyen_champ'))
                poids = _num(raw.get('poids_actuel_kg', partant.poids))
                if poids is not None and poids_moy is not None:
                    ecart = poids - poids_moy
                    if ecart >= 4: _add(rules, 'RAH-111-M47', hippo, 'STRICT', 'M47 top-weight Nantes 1600m, écart >=4kg (calibration n=1)', -15)
                    elif ecart >= 3: _add(rules, 'RAH-111-M47', hippo, 'DEGRADE', 'M47 top-weight Nantes 1600m, écart >=3kg (calibration n=1)', -10)
                    elif ecart >= 2: _add(rules, 'RAH-111-M47', hippo, 'MINIMAL', 'M47 top-weight Nantes 1600m, écart >=2kg (calibration n=1)', -6)
                    elif ecart > 0: _add(rules, 'RAH-111-M47', hippo, 'DERNIER_RECOURS', 'M47 top-weight Nantes 1600m, écart >0kg (calibration n=1)', -3)
                sens = str(raw.get('sens_rotation_course', raw.get('sens_hippodrome', '')) or '').upper()
                stats_courses = _num(raw.get('nantes_stats_1600_courses', raw.get('stats_nantes_1600_courses')))
                if sens == 'GAUCHE' and stats_courses is not None and stats_courses >= 23:
                    stat_rules = {2: (8, 'stalle2'), 8: (6, 'stalle8'), 10: (8, 'stalle10'), 5: (-8, 'stalle5')}
                    if stalle in stat_rules:
                        contribution, label = stat_rules[stalle]
                        _add(rules, 'RAH-112-NANTES-1600', hippo, 'DEGRADE', f'RAH-112 {label}, statistiques {int(stats_courses)} courses', contribution)
                    elif 14 <= stalle <= 16:
                        _add(rules, 'RAH-112-NANTES-1600', hippo, 'DEGRADE', f'RAH-112 stalle {int(stalle)}, statistiques {int(stats_courses)} courses', -6)
        elif hippo == 'ENGHIEN':
            if 10 <= numero <= 13 and 'ATTENT' in style: _add(rules, 'GRU-ENGHIEN-ATTENTISTE', hippo, 'DEGRADE', 'Attentiste numéros 10–13', 10)
            if 10 <= numero <= 13 and style.startswith('MENEUR'): _add(rules, 'GRU-ENGHIEN-MENEUR', hippo, 'DEGRADE', 'Meneur numéros 10–13', -8)
            if bool(raw.get('cheval_fragile')): _add(rules, 'GRU-ENGHIEN-FRAGILE', hippo, 'DEGRADE', 'Piste réputée dure pour cheval fragile', -8)
            if bool(raw.get('d4_premiere_fois')): _add(rules, 'GRU-ENGHIEN-D4', hippo, 'DEGRADE', 'D4 première fois', 8)
        elif hippo == 'AUTEUIL':
            if course.distance >= 4000 and partant.age == 5: _add(rules, 'GRU-AUT-JEUNE-4400', hippo, 'DEGRADE', 'Jeune sur steeple long', -10)
            if partant.age is not None and partant.age >= 9 and not bool(raw.get('chute_obstacle_5')): _add(rules, 'GRU-AUT-VETERAN-FIABLE', hippo, 'DEGRADE', 'Vétéran fiable sans chute', 12)
            if _num(partant.poids) is not None and partant.poids < 62 and bool(raw.get('ecart_poids_champ_8')): _add(rules, 'GRU-AUT-PETIT-POIDS', hippo, 'DEGRADE', 'Petit poids avec écart de champ', 10)
            if bool(raw.get('retour_absence_2mois')): _add(rules, 'GRU-AUT-RENTREE', hippo, 'DEGRADE', 'Rentrant absent plus de deux mois', -8)
        elif hippo == 'SAINT-CLOUD':
            penetro = _num(course.penetrometre)
            if penetro is not None and penetro > 4.5 and bool(raw.get('specialiste_terrain_lourd')): _add(rules, 'GRU-STC-LOURD-PEPITE', hippo, 'DEGRADE', 'Spécialiste terrain lourd', 12)
            if penetro is not None and penetro > 4.5 and not bool(raw.get('experience_terrain_lourd')) and partant.cote is not None and partant.cote <= 5: _add(rules, 'GRU-STC-LOURD-PIEGE', hippo, 'DEGRADE', 'Favori sans expérience terrain lourd', -10)
            if course.distance == 2400 and _num(partant.poids, 0) >= 60: _add(rules, 'GRU-STC-TOPWEIGHT', hippo, 'DEGRADE', 'Top-weight 2400m', -8)
        elif hippo == 'CABOURG':
            if course.type_depart and str(course.type_depart.value).upper() == 'AUTOSTART':
                if numero in {3, 4, 5}: _add(rules, 'RAH-173-CABOURG-CENTRE', hippo, 'STRICT', 'Cabourg autostart centre', 10)
                elif numero in {1, 2}: _add(rules, 'RAH-173-CABOURG-INTERIEUR', hippo, 'DEGRADE', 'Cabourg autostart intérieur', 4)
                elif numero in {6, 7}: _add(rules, 'RAH-173-CABOURG-PIEGE', hippo, 'DEGRADE', 'Cabourg autostart piège', -7)
                elif numero >= 8: _add(rules, 'RAH-173-CABOURG-EXTERIEUR', hippo, 'STRICT', 'Cabourg seconde ligne/extérieur', -12)
            if 'ATTENT' in style:
                _add(rules, 'RAH-173-CABOURG-ATTENTISTE', hippo, 'DEGRADE', 'Attentiste pur ligne droite courte', -4)
            if 'CHASSEUR' in style and course.distance >= 2150:
                _add(rules, 'RAH-173-CABOURG-CHASSEUR', hippo, 'MINIMAL', 'Chasseur fond Cabourg', 4)
            if bool(raw.get('specialiste_local_cabourg')) and 'CHASSEUR' in style and course.distance >= 2000:
                _add(rules, 'RAH-173-CABOURG-SPECIALISTE_FOND', hippo, 'MINIMAL', 'Spécialiste local chasseur fond', 4)

        # RAH-133 : dégradation de piste en réunion; aucune réduction sans numéro de course.
        num_course_reunion = _num(raw.get('num_course_dans_reunion', raw.get('numero_course_reunion')))
        rah133_adjustment = {'status': 'NOT_TRIGGERED', 'num_course_dans_reunion': num_course_reunion, 'inner_rules_reduced': 0, 'outer_bonus': 0.0, 'magnitude_factor': .70}
        if num_course_reunion is not None and num_course_reunion >= 7:
            if stalle is not None and stalle <= 4:
                reduced = 0
                for rule in rules:
                    if rule.pch_contribution > 0 and ('CORDE' in rule.code or 'INTERIEUR' in rule.code or 'CENTRE' in rule.code):
                        rule.pch_contribution *= .50
                        reduced += 1
                rah133_adjustment.update({'status': 'CALCULATED', 'inner_rules_reduced': reduced})
            if stalle is not None and stalle >= 10:
                bonus = 3 * .70
                _add(rules, 'RAH-133-GRU-TERRAIN-2', hippo, 'DEGRADE', 'Réunion course>=7, corde>=10 (+3 ×70%)', bonus)
                rah133_adjustment.update({'status': 'CALCULATED', 'outer_bonus': bonus})
        if rah133_adjustment['status'] == 'CALCULATED':
            course.derived_metrics = getattr(course, 'derived_metrics', {}) or {}
            course.derived_metrics.setdefault('rah133', {})[str(partant.numero)] = rah133_adjustment
        # Conservation de l’association cheval → règles. `course.gru_regles`
        # reste un registre global pour l’audit, tandis que le scoring doit lire
        # exclusivement la liste du partant courant.
        setattr(partant, '_gru_regles', list(rules))
        partant.extended_metrics['gru_regles_partant'] = [
            {'code': r.code, 'tier': r.tier.value, 'contribution': r.pch_contribution, 'description': r.description, 'calibration_provenance': r.calibration_provenance}
            for r in rules
        ]
        partant.extended_metrics['gru_calibration_activation'] = activation_state()
        course.gru_regles.extend(rules)
        regles_par_partant[str(partant.numero)] = [
            {'code': r.code, 'tier': r.tier.value, 'contribution': r.pch_contribution, 'description': r.description, 'calibration_provenance': r.calibration_provenance}
            for r in rules
        ]
    return {'hippodrome': hippo, 'regles_actives': regles_par_partant, 'nb_regles': sum(len(v) for v in regles_par_partant.values()), 'calibration_activation': activation_state()}
