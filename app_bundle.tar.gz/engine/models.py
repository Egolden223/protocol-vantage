"""
PROTOCOL VANTAGE — Modèles de données
Structures de données pour les courses, partants, signaux et tickets.
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from enum import Enum


class Discipline(Enum):
    TROT_ATTELE = "TROT_ATTELE"
    TROT_MONTE = "TROT_MONTE"
    PLAT = "PLAT"
    OBSTACLE = "OBSTACLE"
    HAIES = "HAIES"


class SousCategoriePlat(Enum):
    SPRINT = "SPRINT"       # < 1400m
    MILE = "MILE"           # 1400-1999m
    FOND = "FOND"           # >= 2000m


class TypeDepart(Enum):
    AUTOSTART = "AUTOSTART"
    VOLTE = "VOLTE"
    CENTRE = "CENTRE"


class SignatureMSP(Enum):
    LOCK = "LOCK"
    STANDARD = "STANDARD"
    CHAOS = "CHAOS"
    MIXTE_LOCK = "MIXTE_LOCK"


class ProfilADO(Enum):
    PILIER = "PILIER"
    REGULIER = "REGULIER"
    VALEUR_MORTE = "VALEUR_MORTE"
    DISSIMULE_LEGER = "DISSIMULE_LEGER"
    DISSIMULE_FORT = "DISSIMULE_FORT"
    FAVORI_UNANIME = "FAVORI_UNANIME"


class CategoriesCote(Enum):
    FAIBLE = "FAIBLE"       # < 8/1
    MOYENNE = "MOYENNE"     # 8-20/1
    ELEVEE = "ELEVEE"       # > 20/1
    NC = "NC"               # cote non collectée


class TierGRU(Enum):
    A = "A"
    B = "B"
    C = "C"


class PhaseB(Enum):
    INTEGRALE = "INTEGRALE"
    DEGRADEE = "DEGRADEE"
    NEUTRALISEE = "NEUTRALISEE"


@dataclass
class Signal:
    """Un signal individuel (B01-B54, D, M, SF, CSF)"""
    code: str
    nom: str
    actif: bool = False
    valeur: float = 0.0
    niveau_fallback: str = "STRICT"  # STRICT, DEGRADE, MINIMAL, DERNIER_RECOURS
    famille: str = ""  # C, L, F, M, P
    source: str = ""
    flag_manquant: bool = False
    raison_manquant: str = ""


@dataclass
class ModuleResult:
    """Résultat d'un module de calcul"""
    nom: str
    score: float = 0.0
    actif: bool = True
    details: Dict[str, Any] = field(default_factory=dict)
    flags: List[str] = field(default_factory=list)


@dataclass
class Partant:
    """Un cheval partant dans la course"""
    numero: int
    nom: str
    cote: Optional[float] = None
    poids: Optional[float] = None
    driver_jockey: str = ""
    entraineur: str = ""
    ecurie: str = ""
    age: Optional[int] = None
    sexe: str = ""
    # Données TROT
    rk_brute: Optional[float] = None
    # Signaux
    signaux: List[Signal] = field(default_factory=list)
    # Scores calculés
    pch_brut: float = 0.0
    pch_final: float = 0.0
    composite: float = 0.0
    produit_mult: float = 0.0
    produit_mult_ecrete: float = 0.0
    ordre_base: float = 0.0
    ordre_score: float = 0.0
    # Modules
    modules_results: List[ModuleResult] = field(default_factory=list)
    # Profil
    profil_ado: Optional[ProfilADO] = None
    categorie_cote: Optional[CategoriesCote] = None
    tocard_score: float = 0.0
    # LEGACY et qualité des données
    legacy_flags: List[str] = field(default_factory=list)
    data_quality: Dict[str, str] = field(default_factory=dict)
    extended_metrics: Dict[str, Any] = field(default_factory=dict)
    raw_data: Dict[str, Any] = field(default_factory=dict)
    # Marché : observations horodatées, jamais remplacées silencieusement par une cote unique.
    market_data: Dict[str, Any] = field(default_factory=dict)
    valeur_pmu: Optional[float] = None
    catalogue_status: Dict[str, Any] = field(default_factory=dict)
    ghost_details: Dict[str, Any] = field(default_factory=dict)
    ssfo_details: Dict[str, Any] = field(default_factory=dict)
    gamma_details: Dict[str, Any] = field(default_factory=dict)
    longshots_details: Dict[str, Any] = field(default_factory=dict)
    # ICP
    icp_count: int = 0
    # Familles de signaux actives
    familles_actives: List[str] = field(default_factory=list)
    # Position ticket
    position_ticket: Optional[str] = None  # P1, P2, ..., P5, R1, R2
    # Flags
    flags: List[str] = field(default_factory=list)

    def get_categorie_cote(self) -> CategoriesCote:
        if self.cote is None or self.cote <= 0:
            return CategoriesCote.NC
        if self.cote < 8:
            return CategoriesCote.FAIBLE
        elif self.cote <= 20:
            return CategoriesCote.MOYENNE
        else:
            return CategoriesCote.ELEVEE


@dataclass
class RegleGRU:
    """Une règle GRU spécifique à un hippodrome"""
    code: str
    hippodrome: str
    tier: TierGRU
    description: str
    pch_contribution: float = 0.0
    actif: bool = False
    calibration_provenance: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Course:
    """Données complètes d'une course"""
    # Identité
    date: str = ""
    hippodrome: str = ""
    numero_course: int = 0
    nom_course: str = ""
    # Caractéristiques
    discipline: Optional[Discipline] = None
    distance: int = 0
    terrain: str = ""  # BON, SOUPLE, LOURD, COLLANT, LEGER, SEC
    penetrometre: Optional[float] = None
    piste: str = ""
    allocation: Optional[float] = None
    type_depart: Optional[TypeDepart] = None
    est_handicap: bool = False
    nb_partants: int = 0
    # Partants
    partants: List[Partant] = field(default_factory=list)
    # Calculs course
    p_lock: float = 0.0
    p_guerre: float = 0.0
    p_standard: float = 0.0
    iic: float = 0.0
    signature_msp: Optional[SignatureMSP] = None
    # GRU
    gru_actif: bool = False
    gru_regles: List[RegleGRU] = field(default_factory=list)
    gru_tier_c_prudence: bool = False
    # Phase B
    taux_legacy: float = 0.0
    phase_b: Optional[PhaseB] = None
    # SUPRA
    supra_modifications: int = 0
    supra_details: List[Dict[str, Any]] = field(default_factory=list)
    # Ticket final
    ticket: Dict[str, Any] = field(default_factory=dict)
    # Validation et traçabilité
    rah_verification: Dict[str, Any] = field(default_factory=dict)
    violations: List[str] = field(default_factory=list)
    ift_score: int = 100  # Indice de Fiabilité du Ticket
    collecte_meta: Dict[str, Any] = field(default_factory=dict)
    evidence_ledger: Dict[str, Any] = field(default_factory=dict)
    checkpoint_bloc_4: Dict[str, Any] = field(default_factory=dict)
    derived_metrics: Dict[str, Any] = field(default_factory=dict)
    catalogue_coverage: Dict[str, Any] = field(default_factory=dict)
    rah_details: Dict[str, Any] = field(default_factory=dict)
    mode_execution: str = "AUTO_CONTINUE"

    def get_sous_categorie_plat(self) -> Optional[SousCategoriePlat]:
        if self.discipline == Discipline.PLAT:
            if self.distance < 1400:
                return SousCategoriePlat.SPRINT
            elif self.distance < 2000:
                return SousCategoriePlat.MILE
            else:
                return SousCategoriePlat.FOND
        return None
