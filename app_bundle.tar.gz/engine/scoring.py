"""
PROTOCOL VANTAGE — Moteur de Scoring
Implémentation des formules PCH_FINAL, COMPOSITE, P(LOCK), IIC, ORDRE_SCORE
Conforme au ruleset v1.22.2-test (22/07/2026)
"""
import math
from statistics import median
from typing import List, Dict, Tuple, Optional
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.models import (
    Course, Partant, Signal, Discipline, SignatureMSP,
    CategoriesCote, ProfilADO, TierGRU, PhaseB
)
from engine.iic_universal import calculer_iic as calculer_iic_universal
from engine.iic_universal import calculer_p_guerre as calculer_p_guerre_universal


def clamp(min_val: float, max_val: float, value: float) -> float:
    """Clamp une valeur entre min et max."""
    return max(min_val, min(max_val, value))


# =============================================================================
# ÉTAPE 2 : CALCUL P(LOCK) v2
# =============================================================================

def calculer_p_lock(course: Course) -> float:
    """
    Calcul P(LOCK) selon §1.3 du protocole.
    P(LOCK) = clamp(0.15, 0.85, base + impacts)
    """
    base = 0.48

    # Impact meneurs (nombre de chevaux à cote < 8/1 avec signaux forts)
    nb_meneurs = sum(1 for p in course.partants if p.cote is not None and 0 < p.cote < 8 and len([s for s in p.signaux if s.actif]) >= 2)
    impact_meneurs_map = {0: 0.25, 1: 0.15, 2: 0.0, 3: -0.12, 4: -0.20}
    if nb_meneurs >= 5:
        impact_meneurs = -0.22
    else:
        impact_meneurs = impact_meneurs_map.get(nb_meneurs, 0.0)

    # Impact ICP global
    icp_global = max((p.icp_count for p in course.partants), default=0)
    if icp_global >= 5:
        impact_icp = -0.10
    elif icp_global <= 2:
        impact_icp = 0.08
    else:
        impact_icp = 0.0

    # Impact dispersion des cotes
    cotes_triees = sorted([p.cote for p in course.partants if p.cote > 0])
    if len(cotes_triees) >= 2:
        cote_repere_basse = cotes_triees[0]  # favori
        # Chercher un concurrent dans la zone 15-25/1
        cote_repere_haute = next(
            (c for c in cotes_triees if 15 <= c <= 25),
            cotes_triees[-1]
        )
        ratio = cote_repere_haute / cote_repere_basse if cote_repere_basse > 0 else 1
        if ratio < 4:
            impact_dispers = 0.10
        elif ratio > 15:
            impact_dispers = -0.15
        else:
            impact_dispers = 0.0
    else:
        impact_dispers = 0.0

    # Impact nombre de partants
    impact_partants = -0.02 * max(0, course.nb_partants - 12)

    p_lock = clamp(0.15, 0.85,
                   base + impact_meneurs + impact_icp + impact_dispers + impact_partants)
    return p_lock


def calculer_iic(course: Course) -> float:
    """Façade publique vers l’IIC universel V2."""
    return calculer_iic_universal(course)


def _calculer_iic_legacy(course: Course) -> float:
    """
    Calcul IIC (Indice d'Incertitude Course) — TROT uniquement.
    f(variance RK champ, nb meneurs, dispersion cotes)
    """
    if course.discipline not in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE):
        return 0.0

    rk_values = [p.rk_brute for p in course.partants if p.rk_brute is not None]
    if not rk_values:
        return 5.0  # valeur par défaut si pas de RK

    # Variance des RK
    mean_rk = sum(rk_values) / len(rk_values)
    variance_rk = sum((rk - mean_rk) ** 2 for rk in rk_values) / len(rk_values)
    std_rk = math.sqrt(variance_rk)

    # Nombre de meneurs
    nb_meneurs = sum(1 for p in course.partants if p.cote is not None and 0 < p.cote < 8)

    # Dispersion des cotes
    cotes = [p.cote for p in course.partants if p.cote > 0]
    if cotes:
        dispersion_cotes = max(cotes) / min(cotes) if min(cotes) > 0 else 1
    else:
        dispersion_cotes = 1

    # Formule IIC composite
    iic = 4.0 + (std_rk * 0.3) + (nb_meneurs * 0.5) + (math.log(dispersion_cotes) * 0.8)
    return clamp(0.0, 10.0, iic)


def calculer_p_guerre(course: Course) -> float:
    """Façade publique vers P(GUERRE) alimenté par l’IIC universel."""
    return calculer_p_guerre_universal(course)


def _calculer_p_guerre_legacy(course: Course) -> float:
    """Calcul P(GUERRE) basé sur IIC — TROT uniquement."""
    if course.discipline not in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE):
        return 0.0
    iic = course.iic
    if iic >= 9.0:
        return 0.70
    elif iic >= 8.5:
        return 0.60
    elif iic >= 8.0:
        return 0.55
    elif iic >= 7.0:
        return 0.35
    else:
        return 0.15


def determiner_signature_msp(course: Course) -> SignatureMSP:
    """
    Détermination de la signature MSP v2.
    LOCK: P(LOCK) >= 0.55
    CHAOS: P(GUERRE) >= 0.55 ET IIC >= 8.0
    MIXTE_LOCK: P(LOCK) in [0.45-0.55] ET DISSIMULÉ_FORT présent
    STANDARD: sinon
    """
    has_dissimule_fort = any(
        p.profil_ado == ProfilADO.DISSIMULE_FORT for p in course.partants
    )

    iic_details = (getattr(course, 'derived_metrics', {}) or {}).get('iic', {}) or {}
    if course.p_guerre >= 0.55 and course.iic >= 8.0 and iic_details.get('confidence') in {'FULL', 'DEGRADED'}:
        return SignatureMSP.CHAOS
    elif course.p_lock >= 0.55:
        return SignatureMSP.LOCK
    elif 0.45 <= course.p_lock <= 0.55 and has_dissimule_fort:
        return SignatureMSP.MIXTE_LOCK
    else:
        return SignatureMSP.STANDARD


# =============================================================================
# ÉTAPE 4-7 : CALCUL PCH ET COMPOSITE
# =============================================================================

def calculer_pente_score(partant: Partant) -> Dict[str, object]:
    """RAH-116/B47bis : trajectoire pondérée sur les quatre dernières courses."""
    raw = getattr(partant, 'raw_data', {}) or {}
    premiere_course = raw.get('premiere_course') is True or raw.get('cheval_inedit') is True or raw.get('nb_courses_total') == 0
    if premiere_course:
        return {'status': 'CALCULATED', 'pente_score': 0.0, 'contribution_pch': 0.0, 'classification': 'PENTE_NEUTRE_RAH136', 'flag': 'RAH136_NOEUF_PENTE_NEUTRALISEE'}
    score = raw.get('pente_score')
    try:
        score = float(score) if score not in (None, '', 'NC', 'UNPROVEN') else None
    except (TypeError, ValueError):
        score = None
    ranks = raw.get('rangs_4_dernieres')
    fields = raw.get('nb_partants_4_dernieres')
    incidents = raw.get('rang_incident_flag_4', [False, False, False, False])
    if isinstance(ranks, list) and isinstance(fields, list) and len(ranks) >= 4 and len(fields) >= 4:
        usable = []
        for idx, (rank, field_size) in enumerate(zip(ranks[-4:], fields[-4:])):
            try:
                rank_value, size_value = float(rank), float(field_size)
                if size_value <= 0 or (idx < len(incidents) and incidents[idx] is True):
                    continue
                usable.append(rank_value / size_value)
            except (TypeError, ValueError):
                continue
        if len(usable) >= 3:
            if len(usable) >= 4:
                d12, d23, d34 = usable[0] - usable[1], usable[1] - usable[2], usable[2] - usable[3]
                score = .25 * d12 + .35 * d23 + .40 * d34
            else:
                score = None
    if score is None:
        return {'status': 'UNPROVEN', 'pente_score': None, 'contribution_pch': 0.0, 'flag': 'PENTE_INSUFFISANT'}
    if score >= .15:
        contribution, classification, flag = 12.0, 'PENTE_FORTE', 'PS_FORT'
    elif score >= .07:
        contribution, classification, flag = 6.0, 'PENTE_MODEREE', 'PS_MODERE'
    elif score >= -.05:
        contribution, classification, flag = 0.0, 'PENTE_STABLE', 'PS_STABLE'
    elif score >= -.12:
        contribution, classification, flag = -4.0, 'PENTE_DECLIN', 'PS_DECLIN'
    else:
        contribution, classification, flag = -10.0, 'PENTE_CHUTE', 'PS_CHUTE'
    if _num_raw(raw.get('nb_courses_total', raw.get('nb_courses'))) is not None and float(raw.get('nb_courses_total', raw.get('nb_courses'))) < 6:
        contribution /= 2.0
        flag = f'{flag}|PENTE_JEUNE_CHEVAL'
    min_relative = min((float(x) for x in (raw.get('rangs_relatifs_4') or []) if isinstance(x, (int, float))), default=None)
    if classification == 'PENTE_CHUTE' and min_relative is not None and min_relative < .15:
        contribution = 0.0
        flag = f'{flag}|PENTE_CLASSE'
    factor = raw.get('rah244_pente_factor', 1.0)
    try:
        factor = float(factor)
    except (TypeError, ValueError):
        factor = 1.0
    contribution *= factor
    return {'status': 'CALCULATED', 'pente_score': score, 'classification': classification, 'contribution_pch': max(-10.0, min(12.0, contribution)), 'raw_contribution_pch': contribution, 'factor_rah244': factor, 'flag': flag}


def _num_raw(value):
    try:
        return float(value) if value not in (None, '', 'NC', 'UNPROVEN') else None
    except (TypeError, ValueError):
        return None


def calculer_pch_brut(partant: Partant, course: Course) -> float:
    """
    Calcul PCH brut à partir des signaux actifs.
    Somme pondérée des signaux par famille.
    """
    pch = 0.0
    poids_famille = {"C": 1.2, "L": 1.0, "F": 1.3, "M": 1.1, "P": 0.9}

    premiere_course = (getattr(partant, 'raw_data', {}) or {}).get('premiere_course') is True or (getattr(partant, 'raw_data', {}) or {}).get('cheval_inedit') is True or (getattr(partant, 'raw_data', {}) or {}).get('nb_courses_total') == 0
    active_signals = [signal for signal in partant.signaux if signal.actif and not signal.flag_manquant and not (premiere_course and signal.code == 'B47')]
    special_pair = [signal for signal in active_signals if signal.code in {'PLAT-04', 'SPE-01'}]
    pair_codes = {signal.code for signal in special_pair}
    for signal in active_signals:
        if pair_codes == {'PLAT-04', 'SPE-01'} and signal.code in pair_codes:
            continue
        poids = poids_famille.get(signal.famille, 1.0)
        pch += signal.valeur * poids
    if pair_codes == {'PLAT-04', 'SPE-01'}:
        pch += max(signal.valeur * poids_famille.get(signal.famille, 1.0) for signal in special_pair)

    raw_m13 = (getattr(partant, 'raw_data', {}) or {}).get('m13_contribution')
    try:
        raw_m13 = float(raw_m13) if raw_m13 not in (None, '', 'NC', 'UNPROVEN') else None
    except (TypeError, ValueError):
        raw_m13 = None
    if raw_m13 is not None:
        discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
        obstacle_type = str((getattr(partant, 'raw_data', {}) or {}).get('type_obstacle', '') or '').upper()
        m13_factor = 1.3 if discipline == 'HAIES' else 1.7 if obstacle_type in {'STEEPLE', 'STEEPLECHASE'} else 1.0
        pch += raw_m13 * m13_factor

    raw = getattr(partant, 'raw_data', {}) or {}
    nb_courses = _num_raw(raw.get('nb_courses_total', raw.get('nb_courses')))
    nb_handicaps = _num_raw(raw.get('nb_courses_handicap', raw.get('courses_handicap')))
    if nb_courses is not None and nb_handicaps is not None and nb_handicaps == 0:
        if getattr(partant, 'age', 0) == 3 and _num_raw(raw.get('nb_courses_conditions')) is not None and _num_raw(raw.get('nb_courses_conditions')) >= 5:
            pch -= 14.0
        elif nb_courses >= 3:
            pch -= 10.0
        elif nb_courses == 2:
            pch -= 6.0
        elif nb_courses == 1:
            pch -= 4.0
        elif nb_courses == 0:
            pch -= 2.0
    discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
    surcharge = _num_raw(raw.get('surcharge_poids_3_dernieres', raw.get('cumul_surcharge_poids_3')))
    if surcharge is not None and ((discipline == 'PLAT' and getattr(course, 'est_handicap', False)) or (str(discipline or '').startswith('TROT') and getattr(course, 'est_handicap', False))):
        if surcharge >= 9: m33 = -12.0
        elif surcharge >= 6: m33 = -8.0
        elif surcharge >= 3: m33 = -4.0
        elif surcharge >= 1: m33 = -2.0
        else: m33 = 0.0
        if str(discipline or '').startswith('TROT'):
            m33 *= .50
        pch += m33
    b50_bonus = _num_raw(raw.get('b50_bonus_pch'))
    if nb_courses is not None and nb_courses <= 5 and b50_bonus is not None:
        pch += b50_bonus

    pente_details = calculer_pente_score(partant)
    partant.raw_data['pente_details'] = pente_details
    pch += float(pente_details.get('contribution_pch', 0.0) or 0.0)
    return pch


def appliquer_gru(partant: Partant, course: Course) -> float:
    """
    Appliquer les contributions GRU du partant au PCH.

    Le registre global `course.gru_regles` sert à l’audit, mais ne doit pas
    être additionné pour chaque cheval : chaque règle est attachée à son
    partant par `engine.gru_runtime.appliquer_regles_gru`.
    Tier C = 40% de la valeur documentée (RAH-154).
    """
    gru_contribution = 0.0
    rules = getattr(partant, '_gru_regles', None)
    if rules is None:
        # Compatibilité avec les tests qui construisent directement un
        # partant sans passer par le générateur GRU : aucune règle globale ne
        # doit être appliquée par défaut à tous les chevaux.
        rules = []
    applied = []
    for regle in rules:
        if regle.actif:
            if regle.tier == TierGRU.C:
                gru_contribution += regle.pch_contribution * 0.40
                course.gru_tier_c_prudence = True
            else:
                gru_contribution += regle.pch_contribution
        applied.append({
            'code': regle.code,
            'tier': regle.tier.value if hasattr(regle.tier, 'value') else str(regle.tier),
            'contribution_brute': regle.pch_contribution,
            'contribution_appliquee': regle.pch_contribution * (0.40 if regle.tier == TierGRU.C else 1.0),
        })
    partant.extended_metrics['gru_pch_contribution'] = round(gru_contribution, 6)
    partant.extended_metrics['gru_pch_rules_applied'] = applied
    return gru_contribution


def calculer_pch_final(partant: Partant, course: Course) -> float:
    """PCH_FINAL = PCH_brut + GRU + modules, plafonné à 220 (RAH-60)."""
    pch = partant.pch_brut + appliquer_gru(partant, course)
    # Certains exécuteurs produisent volontairement un score documentaire ou
    # un score destiné à COMPOSITE/tocard_score, mais pas à PCH_FINAL.
    # Les exclure ici évite le double comptage et respecte le chemin d’effet
    # normatif du registre d’audit.
    non_pch_modules = {'CSF', 'PDQ', 'P5P6', 'GHOST'}
    excluded_impacts = []
    for module in partant.modules_results:
        if not module.actif:
            continue
        if module.nom in non_pch_modules:
            excluded_impacts.append({'module': module.nom, 'score': float(module.score or 0.0), 'effect_path': 'NON_PCH'})
            continue
        pch += module.score
    partant.extended_metrics.setdefault('pch_excluded_module_impacts', excluded_impacts)
    return clamp(0.0, 220.0, pch)


def _raw_value(partant: Partant, *keys):
    containers = [
        getattr(partant, 'market_data', {}) or {},
        getattr(partant, 'raw_data', {}) or {},
        getattr(partant, 'extended_metrics', {}) or {},
    ]
    raw_market = (getattr(partant, 'raw_data', {}) or {}).get('market_data')
    if isinstance(raw_market, dict):
        containers.insert(1, raw_market)
    aliases = {
        'cote_matin': ('cote_matin', 'cote_veille', 'cote_reference'),
        'cote_parution': ('cote_parution', 'cote_reference'),
        'cote_avant_course': ('cote_avant_course', 'cote_15m', 'last_pre_race_quote'),
        'cote_15min': ('cote_15min', 'cote_15m', 'cote_avant_course'),
    }
    for key in keys:
        lookup_keys = aliases.get(key, (key,))
        for container in containers:
            for lookup_key in lookup_keys:
                value = container.get(lookup_key) if isinstance(container, dict) else None
                if isinstance(value, dict) and 'value' in value:
                    value = value.get('value')
                if value not in (None, '', 'NC', 'UNPROVEN'):
                    return value
    return None


def _numeric(value):
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def calculer_pch_norm(partant: Partant) -> float:
    """PCH_NORM = clamp(0,1,PCH_FINAL/220) (RAH-60)."""
    return clamp(0.0, 1.0, float(partant.pch_final or 0.0) / 220.0)


def calculer_composite(partant: Partant, course: Course) -> float:
    """COMPOSITE v2 normatif, retourné sur [0,1] (RAH-52 et RAH-67)."""
    discipline = getattr(getattr(course, 'discipline', None), 'value', str(getattr(course, 'discipline', '')))
    signature = getattr(getattr(course, 'signature_msp', None), 'value', str(getattr(course, 'signature_msp', 'STANDARD')))
    key = f'{discipline}:{signature}'
    weights = {
        'PLAT:LOCK': (.50, .15, .25), 'PLAT:STANDARD': (.50, .20, .20), 'PLAT:CHAOS': (.44, .28, .18), 'PLAT:MIXTE_LOCK': (.48, .22, .20),
        'TROT_ATTELE:LOCK': (.58, .18, .14), 'TROT_ATTELE:STANDARD': (.53, .22, .15), 'TROT_ATTELE:CHAOS': (.46, .28, .16), 'TROT_ATTELE:MIXTE_LOCK': (.50, .24, .16),
        'TROT_MONTE:LOCK': (.58, .18, .14), 'TROT_MONTE:STANDARD': (.53, .22, .15), 'TROT_MONTE:CHAOS': (.46, .28, .16), 'TROT_MONTE:MIXTE_LOCK': (.50, .24, .16),
        'OBSTACLE:LOCK': (.46, .25, .19), 'OBSTACLE:STANDARD': (.42, .28, .20), 'OBSTACLE:CHAOS': (.36, .35, .19), 'OBSTACLE:MIXTE_LOCK': (.40, .30, .20),
        'HAIES:LOCK': (.46, .25, .19), 'HAIES:STANDARD': (.42, .28, .20), 'HAIES:CHAOS': (.36, .35, .19), 'HAIES:MIXTE_LOCK': (.40, .30, .20),
    }
    w_pch, w_tocard, w_csf = weights.get(key, (.50, .20, .20))
    csf_module = next((m for m in partant.modules_results if m.nom == 'CSF'), None)
    h2h_module = next((m for m in partant.modules_results if m.nom == 'H2H_GRAPH'), None)
    csf_norm = _numeric((csf_module.details or {}).get('csf_norm')) if csf_module else None
    h2h_norm = _numeric((h2h_module.details or {}).get('h2h_norm')) if h2h_module else None
    neutral_registry = (getattr(partant, 'raw_data', {}) or {}).get('neutral_imputations', {}) or {}
    csf_norm = clamp(0.0, 1.0, csf_norm) if csf_norm is not None else 0.0
    h2h_norm = clamp(-1.0, 1.0, h2h_norm) if h2h_norm is not None else 0.0
    pch_norm = calculer_pch_norm(partant)
    normalized = w_pch * pch_norm + w_tocard * clamp(0.0, 1.0, float(partant.tocard_score or 0.0)) + w_csf * csf_norm + 0.10 * h2h_norm
    composite = clamp(0.0, 1.0, normalized)
    partant.extended_metrics['composite_components'] = {
        'w_PCH': w_pch, 'w_tocard': w_tocard, 'w_CSF': w_csf, 'w_H2H': 0.10,
        'PCH_NORM': pch_norm, 'csf_norm': csf_norm, 'h2h_norm': h2h_norm,
        'status_csf': 'CALCULATED' if csf_module else 'UNPROVEN',
        'status_h2h': 'CALCULATED' if h2h_module else 'IMPUTED_NEUTRAL' if 'h2h_norm' in neutral_registry else 'UNPROVEN',
        'neutral_imputations_used': sorted(neutral_registry),
    }
    return composite


# =============================================================================
# ÉTAPE 8-9 : PRODUIT_MULT ET ORDRE_SCORE
# =============================================================================

def calculer_produit_mult(partant: Partant, course: Course) -> Tuple[float, float]:
    """Produit historique conservé pour traçabilité et tests de bornage RAH-153."""
    multiplicateurs = [1.08 if any(s.code in ('B04', 'B05') and s.actif for s in partant.signaux) else 1.0]
    if any(s.code in ('B01', 'B20', 'B47') and s.actif for s in partant.signaux):
        multiplicateurs.append(1.12)
    elif any(s.code == 'B47' and not s.actif for s in partant.signaux):
        multiplicateurs.append(0.88)
    else:
        multiplicateurs.append(1.0)
    multiplicateurs.extend([
        1.06 if any(s.code in ('B15', 'B17', 'B28') and s.actif for s in partant.signaux) else 1.0,
        1.05 if any(s.code in ('B09', 'B11', 'B12') and s.actif for s in partant.signaux) else 1.0,
        1.04 if any(s.code in ('B06', 'B16', 'B35') and s.actif for s in partant.signaux) else 1.0,
    ])
    stab_module = next((m for m in partant.modules_results if m.nom == 'STAB'), None)
    multiplicateurs.append(1.03 if stab_module and stab_module.score > 0 else 0.92 if stab_module and stab_module.score < 0 else 1.0)
    brut = math.prod(multiplicateurs)
    return brut, clamp(0.65, 1.45, brut)


def _calculer_iql_v2(partant: Partant, course: Course) -> Dict[str, object]:
    """IQL_v2 normatif : efficacité gains/allocation normalisée par le niveau du jour.

    La formule ne traite jamais une allocation seule comme un gain. Un historique
    sous forme numérique sans montant capté reste UNPROVEN et déclenche la cascade
    vers le legacy PMU, conformément à la politique zéro donnée inventée.
    """
    raw = getattr(partant, 'raw_data', {}) or {}
    current_allocation = _numeric(_raw_value(partant, 'allocation_course_actuelle', 'allocation'))
    observed = raw.get('allocations_3_dernieres', raw.get('allocations_last3'))
    records = []
    if isinstance(observed, (list, tuple)):
        for item in observed[-3:]:
            if not isinstance(item, dict):
                continue
            allocation = _numeric(item.get('allocation', item.get('allocation_course_i', item.get('allocation_i'))))
            montant = _numeric(item.get('montant', item.get('montant_i', item.get('gains', item.get('gain', item.get('montant_capté'))))))
            if allocation is not None and allocation > 0 and montant is not None and montant >= 0:
                records.append({'allocation': allocation, 'montant': montant, 'ratio_gains': montant / max(allocation, 1.0)})
    weights_full = (0.25, 0.35, 0.40)
    allocations = [record['allocation'] for record in records]
    ratios = [record['ratio_gains'] for record in records]
    legacy_current = _numeric(_raw_value(partant, 'valeur_pmu_actuelle', 'valeur_actuelle'))
    legacy_previous = _numeric(_raw_value(partant, 'valeur_pmu_precedente', 'valeur_precedente'))
    legacy_value = clamp(0.50, 1.50, legacy_current / legacy_previous) if legacy_current is not None and legacy_previous not in (None, 0) else None
    ratio_reference = None
    if current_allocation is not None and records:
        median_allocation = float(median(allocations)) if allocations else 0.0
        ratio_reference = current_allocation / max(median_allocation, 1.0) if median_allocation > 0 else None
        if len(records) >= 2 and ratio_reference is not None:
            weights = weights_full[-len(records):]
            total_weight = sum(weights)
            weighted_ratio = sum(record['ratio_gains'] * weight for record, weight in zip(records, weights)) / total_weight
            value = clamp(0.50, 1.50, weighted_ratio / max(ratio_reference, 1.0))
            status = f'IQL_V2_{len(records)}_ALLOC'
            source = f'allocations_gains_reelles_{len(records)}'
        elif len(records) == 1 and legacy_value is not None:
            one_ratio = records[0]['ratio_gains'] / max(ratio_reference or 1.0, 1.0)
            value = clamp(0.50, 1.50, 0.50 * one_ratio + 0.50 * legacy_value)
            status = 'IQL_V2_1_ALLOC_COMBINE_LEGACY'
            source = 'allocation_gain_plus_legacy_valeur_pmu'
        else:
            value = 1.0
            status = 'UNPROVEN_NEUTRAL'
            source = 'none'
    else:
        allocation_format_status = 'UNPROVEN_ALLOCATIONS_WITHOUT_GAINS' if isinstance(observed, (list, tuple)) and observed and not records else None
        if legacy_value is not None:
            value = legacy_value
            status = 'IQL_V2_LEGACY_VALEUR_PMU'
            source = 'legacy_valeur_pmu'
        else:
            value = 1.0
            status = allocation_format_status or 'UNPROVEN_NEUTRAL'
            source = 'none'
    neutral_registry = raw.get('neutral_imputations', {}) or {}
    if status in {'UNPROVEN_NEUTRAL', 'UNPROVEN_ALLOCATIONS_WITHOUT_GAINS'} and 'iql_v2' in neutral_registry:
        status = 'IMPUTED_NEUTRAL'
    details = {
        'value': value,
        'status': status,
        'source': source,
        'records_observes': records,
        'allocations_observees': allocations,
        'ratios_gains_observes': ratios,
        'allocation_course_actuelle': current_allocation,
        'ratio_reference': ratio_reference if 'ratio_reference' in locals() else None,
        'weights': weights_full,
        'formula': 'IQL_v2_brut = somme(poids_i × montant_i/max(allocation_i,1)) / max(allocation_course_actuelle/median(allocations_last3),1); clamp(0.50,1.50)',
        'fallback_cascade': ['3_allocations', '2_allocations', '1_allocation', 'legacy_valeur_pmu'],
    }
    raw['iql_v2'] = details
    partant.raw_data = raw
    return details


def _harville_nominal(partant: Partant, field_size: Optional[float]) -> Dict[str, object]:
    """Calcule le bonus Harville normatif si ses entrées sont explicitement prouvées."""
    raw = getattr(partant, 'raw_data', {}) or {}
    explicit_bonus = _numeric(_raw_value(partant, 'harville_bonus'))
    expected_position = _numeric(_raw_value(partant, 'position_attendue', 'expected_position', 'harville_position_attendue'))
    odds = _numeric(getattr(partant, 'cote', None)) or _numeric(_raw_value(partant, 'cote'))
    if explicit_bonus is not None:
        return {'bonus': explicit_bonus, 'status': 'OBSERVED_PRECOMPUTED', 'source': 'harville_bonus_observe', 'position_attendue': expected_position, 'cote': odds, 'prob_brut': None, 'prob_corr': None, 'delta': None}
    if field_size is None or field_size <= 1 or odds is None or odds <= 8 or expected_position not in {2.0, 3.0, 4.0, 5.0}:
        return {'bonus': 0.0, 'status': 'UNPROVEN', 'source': 'none', 'position_attendue': expected_position, 'cote': odds, 'prob_brut': None, 'prob_corr': None, 'delta': None}
    gamma = 0.81 if expected_position == 2.0 else 0.65
    prob_brut = (1.0 / odds) * ((field_size - 1.0) / field_size)
    numerator = prob_brut ** gamma
    denominator = numerator + ((1.0 - prob_brut) ** gamma)
    prob_corr = numerator / denominator if denominator else prob_brut
    delta = prob_corr - prob_brut
    if delta > 0.03 and odds > 12:
        bonus = 0.08
    elif delta > 0.01 and odds > 8:
        bonus = 0.04
    else:
        bonus = 0.0
    return {'bonus': bonus, 'status': 'CALCULATED', 'source': 'harville_nominal_formula', 'position_attendue': expected_position, 'cote': odds, 'prob_brut': prob_brut, 'prob_corr': prob_corr, 'delta': delta, 'gamma': gamma}


def _ordre_factors(partant: Partant, course: Course) -> Dict[str, object]:
    market = getattr(partant, 'market_data', {}) or {}
    raw = getattr(partant, 'raw_data', {}) or {}
    raw_snapshots = market.get('sov_snapshots') or raw.get('sov_snapshots') or (raw.get('market_data') or {}).get('sov_snapshots')
    matin = _numeric(_raw_value(partant, 'cote_matin', 'cote_parution'))
    avant = _numeric(_raw_value(partant, 'cote_avant_course', 'cote_15min'))
    fallback = _numeric(_raw_value(partant, 'cote_mediane_3_derniere_minutes', 'cote_mediane_3min'))
    legacy_two_points = matin is not None and matin > 0 and avant is not None and avant > 0
    snapshot_count = len(raw_snapshots) if isinstance(raw_snapshots, (list, tuple)) else None
    has_two_proven_points = legacy_two_points and (snapshot_count is None or snapshot_count >= 2)
    if has_two_proven_points:
        delta = (matin - avant) / matin
        sov = clamp(-0.10, 0.15, 0.4 * delta)
        sov_status = 'CALCULATED'
    elif matin and matin > 0 and fallback and fallback > 0:
        delta = (matin - fallback) / matin
        sov = clamp(-0.10, 0.15, 0.4 * delta)
        sov_status = 'FALLBACK_MEDIAN_3MIN'
    elif legacy_two_points and snapshot_count is not None and snapshot_count < 2:
        delta, sov, sov_status = None, 0.0, 'INSUFFICIENT_SOV_SNAPSHOTS_RAH28'
    else:
        delta, sov, sov_status = None, 0.0, 'UNPROVEN_NEUTRAL'
    if sov_status in {'UNPROVEN_NEUTRAL', 'INSUFFICIENT_SOV_SNAPSHOTS_RAH28'} and 'sov_v2' in (raw.get('neutral_imputations', {}) or {}):
        sov_status = 'IMPUTED_NEUTRAL'
    if sov > 0 and partant.cote and partant.cote < 20 and sov > 0.05:
        sov = 0.05
        sov_status = 'CALCULATED_T1_T2_CAP'

    iql_details = _calculer_iql_v2(partant, course)
    iql, iql_status = iql_details['value'], iql_details['status']

    discipline = getattr(getattr(course, 'discipline', None), 'value', str(getattr(course, 'discipline', '')))
    tact_module = next((m for m in partant.modules_results if m.nom == 'TACT'), None)
    tact_score = _numeric((tact_module.details or {}).get('tact_score')) if tact_module else None
    if discipline in ('TROT_ATTELE', 'TROT_MONTE') and tact_score is not None:
        tact, tact_status = clamp(0.75, 1.25, 1.0 + tact_score / 100.0), 'CALCULATED'
    elif discipline in ('TROT_ATTELE', 'TROT_MONTE'):
        tact, tact_status = 1.0, 'UNPROVEN_NEUTRAL'
    else:
        tact, tact_status = 1.0, 'NOT_APPLICABLE'

    stab_module = next((m for m in partant.modules_results if m.nom == 'STAB'), None)
    stab_score = _numeric(getattr(stab_module, 'score', None)) if stab_module else None
    stab = 1.0 + clamp(-0.20, 0.0, stab_score / 100.0) if stab_score is not None else 1.0
    all_score = _numeric(_raw_value(partant, 'all_score'))
    all_mult = 0.95 if all_score is not None and all_score < 0.70 else 1.03 if all_score is not None and all_score > 1.50 else 1.0
    field_size = _numeric(getattr(course, 'nb_partants', None))
    if field_size is None or field_size <= 0:
        field_size = float(len(getattr(course, 'partants', []) or [])) or None
    harville_details = _harville_nominal(partant, field_size)
    harville_bonus = _numeric(harville_details.get('bonus')) or 0.0
    individual_block = _raw_value(partant, 'overbet_surcote', 'm30_paradoxe_favori') is True
    if individual_block:
        harville_reliable, harville_status = False, 'DISABLED_INDIVIDUAL_RAH120'
    else:
        explicit_false = _raw_value(partant, 'harville_fiable') is False
        ifield = _numeric(getattr(course, 'ift_moyen_champ', None))
        vm = _numeric(getattr(course, 'nb_valeur_morte_champ', None))
        media = _numeric(getattr(course, 'overbet_media_count', None))
        kills = _numeric(getattr(course, 'kill_list_count', None))
        harville_reliable = (not explicit_false and ifield is not None and ifield >= 75 and vm is not None and vm <= 3 and media is not None and media <= 1 and kills is not None and field_size is not None and kills / field_size <= .15)
        harville_status = 'CALCULATED' if harville_reliable else 'DISABLED_UNPROVEN_RAH120'
    harville = 1.0 + harville_bonus if harville_bonus is not None and harville_reliable else 1.0

    ordre_base = partant.composite * (1.0 + sov) * iql * tact * stab * all_mult * harville
    autostart = _numeric(_raw_value(partant, 'numero_autostart', 'autostart_num'))
    hippodrome = str(getattr(course, 'hippodrome', '') or '').upper()
    gru_mult = 1.0 - 0.08 * (autostart - 8) / 8 if hippodrome == 'ENGHIEN' and autostart is not None and autostart >= 9 else 1.0
    final = ordre_base * gru_mult
    return {
        'sov_v2': sov, 'sov_status': sov_status, 'sov_delta': delta,
        'iql': iql, 'iql_status': iql_status, 'iql_v2': iql_details,
        'tact_mult': tact, 'tact_status': tact_status,
        'stab_mult': stab, 'all_mult': all_mult, 'harville_mult': harville, 'harville_bonus': harville_bonus, 'harville_details': harville_details, 'harville_status': harville_status, 'rah120_neutral_if_unreliable': True,
        'ordre_base': ordre_base, 'gru_enghien_mult': gru_mult, 'ordre_score': final,
    }


def calculer_ordre_score(partant: Partant, course: Course) -> float:
    """ORDRE_SCORE = COMPOSITE × (1+SOV) × IQL × TACT × STAB × ALL × Harville (RAH-61)."""
    factors = _ordre_factors(partant, course)
    partant.ordre_base = float(factors['ordre_base'])
    partant.extended_metrics['ordre_factors'] = factors
    return float(factors['ordre_score'])

# =============================================================================
# PROFILS ADO
# =============================================================================

def determiner_profil_ado(partant: Partant, course: Course) -> ProfilADO:
    """
    Détermination du profil ADO selon §1.5.
    """
    nb_signaux = len([s for s in partant.signaux if s.actif])
    nb_familles = len(set(partant.familles_actives))

    # FAVORI_UNANIME: ICP = total sources consultées
    total_sources = max(6, max((p.icp_count for p in course.partants), default=6))
    if partant.icp_count == total_sources and total_sources >= 5:
        return ProfilADO.FAVORI_UNANIME

    # DISSIMULÉ_FORT
    if partant.tocard_score >= 0.35:
        return ProfilADO.DISSIMULE_FORT

    # DISSIMULÉ_LÉGER
    if 0.20 <= partant.tocard_score < 0.35:
        return ProfilADO.DISSIMULE_LEGER

    # PILIER
    if partant.cote is not None and 0 < partant.cote < 8 and nb_signaux >= 2 and nb_familles >= 2:
        return ProfilADO.PILIER

    # VALEUR_MORTE
    if partant.cote is not None and partant.cote > 25 and nb_signaux == 0 and partant.tocard_score < 0.20:
        return ProfilADO.VALEUR_MORTE

    # RÉGULIER
    if partant.cote is not None and 8 <= partant.cote <= 25 and nb_signaux >= 1:
        return ProfilADO.REGULIER

    return ProfilADO.REGULIER


# =============================================================================
# PIPELINE PRINCIPAL
# =============================================================================

def executer_scoring_complet(course: Course) -> Course:
    """
    Exécution séquentielle du scoring complet (Étapes 2-9).
    """
    # Étape 2: Calcul signatures
    course.iic = calculer_iic(course)
    course.p_lock = calculer_p_lock(course)
    course.p_guerre = calculer_p_guerre(course)
    course.p_standard = 1.0 - course.p_lock - course.p_guerre
    if course.p_standard < 0:
        course.p_standard = 0.0
        # Renormaliser
        total = course.p_lock + course.p_guerre
        if total > 0:
            course.p_lock /= total
            course.p_guerre /= total

    # Étape 3-7: Calcul PCH et COMPOSITE pour chaque partant
    for partant in course.partants:
        # Catégorie cote
        partant.categorie_cote = partant.get_categorie_cote()

        # Familles actives
        partant.familles_actives = list(set(
            s.famille for s in partant.signaux if s.actif and s.famille
        ))

        # PCH brut
        partant.pch_brut = calculer_pch_brut(partant, course)

        # PCH final (avec GRU)
        partant.pch_final = calculer_pch_final(partant, course)

    # La signature MSP est nécessaire aux pondérations COMPOSITE v2.
    course.signature_msp = determiner_signature_msp(course)

    # COMPOSITE v2 (nécessite PCH_FINAL, modules CSF/H2H et signature MSP)
    for partant in course.partants:
        partant.composite = calculer_composite(partant, course)

    # Étape 8-9: PRODUIT_MULT et ORDRE_SCORE
    for partant in course.partants:
        partant.produit_mult, partant.produit_mult_ecrete = calculer_produit_mult(partant, course)
        partant.ordre_score = calculer_ordre_score(partant, course)

    course.derived_metrics['ordre_score_calculated_for'] = [p.numero for p in course.partants if p.ordre_score == p.ordre_score and p.ordre_score not in (float('inf'), float('-inf'))]

    # Profils ADO
    for partant in course.partants:
        partant.profil_ado = determiner_profil_ado(partant, course)

    return course
