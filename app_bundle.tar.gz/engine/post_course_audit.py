from __future__ import annotations

from datetime import datetime
from statistics import median
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from engine.analytic_audit_v3 import build_score_diagnostics_v3


CONSENSUS_STATUSES = {'OFFICIAL_CONSENSUS_2_SOURCES', 'OFFICIAL_CONSENSUS_3_SOURCES'}


def _numbers(values: Iterable[Any]) -> List[int]:
    result: List[int] = []
    for value in values or []:
        if isinstance(value, dict):
            value = value.get('numero', value.get('numPmu', value.get('number')))
        try:
            number = int(value)
        except (TypeError, ValueError):
            continue
        if 1 <= number <= 20 and number not in result:
            result.append(number)
    return result


def _official_order(data: Dict[str, Any]) -> List[int]:
    for key in ('arrivee_officielle', 'arrivee', 'ordre_arrivee', 'ordre'):
        values = data.get(key)
        numbers = _numbers(values)
        if numbers:
            return numbers
    rows = data.get('resultats', data.get('participants', []))
    if isinstance(rows, list):
        ordered = sorted((row for row in rows if isinstance(row, dict)), key=lambda r: r.get('place', r.get('rang', 999)))
        return _numbers(ordered)
    return []


def _ticket_numbers(pre_course: Dict[str, Any]) -> List[int]:
    ticket = pre_course.get('ticket', {}) or {}
    if isinstance(ticket, list):
        return _numbers(ticket)
    if isinstance(ticket, dict):
        return _numbers(ticket.values())
    return []


def _partants_by_number(pre_course: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
    result: Dict[int, Dict[str, Any]] = {}
    for row in pre_course.get('partants', []) or []:
        if isinstance(row, dict):
            try:
                result[int(row.get('numero'))] = row
            except (TypeError, ValueError):
                pass
    return result


def _is_missing(value: Any) -> bool:
    return value in (None, '', 'NC', 'UNPROVEN') or (isinstance(value, str) and value.startswith(('NC:', 'UNPROVEN:')))


def _number(value: Any) -> Optional[float]:
    try:
        if _is_missing(value):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _module_entries(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    modules = row.get('modules', {}) or {}
    entries: List[Dict[str, Any]] = []
    if isinstance(modules, dict):
        iterator = modules.items()
    elif isinstance(modules, list):
        iterator = ((item.get('nom', item.get('module_id', f'MODULE_{idx}')), item) for idx, item in enumerate(modules) if isinstance(item, dict))
    else:
        iterator = []
    for module_id, raw in iterator:
        if not isinstance(raw, dict):
            continue
        details = raw.get('details', {}) if isinstance(raw.get('details', {}), dict) else {}
        score = _number(raw.get('score', details.get('score')))
        status = raw.get('status', details.get('status', details.get('execution_status', 'UNPROVEN')))
        flags = list(raw.get('flags', details.get('flags', [])) or [])
        entries.append({
            'module_id': str(module_id),
            'score': score if score is not None else 0.0,
            'actif': bool(raw.get('actif', True)),
            'status': str(status or 'UNPROVEN'),
            'flags': flags,
            'formula': raw.get('formula', details.get('formula', details.get('formule'))),
            'impact_pch': _number(raw.get('impact_pch', details.get('impact_pch', raw.get('score')))),
            'inputs': raw.get('inputs', details.get('inputs', {})) or {},
        })
    return entries


def _catalogue_signal_entries(row: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    catalogue = row.get('catalogue_status', {}) or {}
    active: List[Dict[str, Any]] = []
    missing: List[Dict[str, Any]] = []
    if isinstance(catalogue, dict):
        for family, values in catalogue.items():
            if not isinstance(values, dict):
                continue
            for code, item in values.items():
                if not isinstance(item, dict):
                    continue
                status = str(item.get('status', 'UNPROVEN')).upper()
                evidence = item.get('evidence') or {}
                entry = {'code': code, 'family': (evidence.get('famille', family) if isinstance(evidence, dict) else family), 'status': status, 'value': _number(evidence.get('value')) if isinstance(evidence, dict) else None, 'source': evidence.get('source') if isinstance(evidence, dict) else None, 'reason': item.get('reason', '')}
                if status == 'ACTIVE':
                    active.append(entry)
                elif status in {'UNPROVEN', 'NC', 'INACTIVE'}:
                    missing.append(entry)
    explicit = row.get('signaux', []) or []
    if isinstance(explicit, list):
        for item in explicit:
            if not isinstance(item, dict):
                continue
            if bool(item.get('active', item.get('actif', False))):
                active.append({'code': item.get('code'), 'family': item.get('family', item.get('famille')), 'status': 'ACTIVE', 'value': _number(item.get('value', item.get('valeur'))), 'source': item.get('source'), 'reason': item.get('reason', '')})
    return active, missing


def _evidence_summary(row: Dict[str, Any], ranked_rows: Optional[List[Dict[str, Any]]] = None, ticket_numbers: Optional[List[int]] = None) -> Dict[str, Any]:
    scores = row.get('scores', {}) or {}
    quality = row.get('data_quality', {}) or {}
    modules = _module_entries(row)
    active_signals, missing_signals = _catalogue_signal_entries(row)
    missing_fields = sorted(key for key, value in quality.items() if _is_missing(value)) if isinstance(quality, dict) else []
    missing_modules = [module['module_id'] for module in modules if module['status'].upper() in {'NC', 'UNPROVEN', 'NOT_PROVEN', 'DEFERRED'} or any('NC' in str(flag).upper() or 'UNPROVEN' in str(flag).upper() or 'MANQU' in str(flag).upper() for flag in module['flags'])]
    positive_modules = [module['module_id'] for module in modules if module['actif'] and module['score'] > 0]
    negative_modules = [module['module_id'] for module in modules if module['actif'] and module['score'] < 0]
    module_contributions = [{key: module[key] for key in ('module_id', 'score', 'status', 'flags', 'formula', 'impact_pch', 'inputs')} for module in modules]
    family_weights = {'C': 1.2, 'L': 1.0, 'F': 1.3, 'M': 1.1, 'P': 0.9}
    signal_contributions = []
    for signal in active_signals:
        family = str(signal.get('family') or '').upper()
        value = signal.get('value') or 0.0
        weight = family_weights.get(family, 1.0)
        signal_contributions.append({**signal, 'family_weight': weight, 'pch_contribution': round(value * weight, 6), 'formula': f'value × poids_famille({weight})'})
    extended = row.get('extended_metrics', {}) or {}
    pch_brut = _number(scores.get('pch_brut'))
    pch_final = _number(scores.get('pch_final'))
    module_sum = round(sum(module['score'] for module in modules if module['actif']), 6)
    gru_derived = round(pch_final - pch_brut - module_sum, 6) if pch_brut is not None and pch_final is not None else None
    rank = None
    score_gap_to_ticket_cutoff = None
    score_gap_to_rank8 = None
    score = _number(scores.get('ordre_score'))
    if ranked_rows:
        ordered = sorted(ranked_rows, key=lambda item: (_number((item.get('scores') or {}).get('ordre_score')) or float('-inf')), reverse=True)
        for index, candidate in enumerate(ordered, start=1):
            if str(candidate.get('numero')) == str(row.get('numero')):
                rank = index
                break
    ticket_set = set(ticket_numbers or [])
    ticket_scores = [_number((candidate.get('scores') or {}).get('ordre_score')) for candidate in (ranked_rows or []) if _number((candidate.get('scores') or {}).get('ordre_score')) is not None and candidate.get('numero') in ticket_set]
    ticket_scores = [value for value in ticket_scores if value is not None]
    if score is not None and ticket_scores:
        score_gap_to_ticket_cutoff = round(score - min(ticket_scores), 6)
    if score is not None and ranked_rows:
        ordered_scores = sorted([_number((candidate.get('scores') or {}).get('ordre_score')) for candidate in ranked_rows], reverse=True)
        ordered_scores = [value for value in ordered_scores if value is not None]
        if len(ordered_scores) >= 8:
            score_gap_to_rank8 = round(score - ordered_scores[7], 6)
    market = row.get('market_data', {}) or {}
    market_summary = {key: market.get(key) for key in ('cote_reference', 'cote_matin', 'cote_veille', 'cote_avant_course', 'cote_15min', 'cote_finale', 'delta_cote', 'fluctuation_relative', 'sov_v2') if key in market}
    composite_components = extended.get('composite_components', {}) if isinstance(extended, dict) else {}
    ordre_factors = extended.get('ordre_factors', {}) if isinstance(extended, dict) else {}
    return {
        'scores': scores,
        'position_ticket': row.get('position_ticket'),
        'profil_ado': row.get('profil_ado'),
        'tocard_score': row.get('tocard_score'),
        'legacy_flags': row.get('legacy_flags', []),
        'missing_fields': missing_fields,
        'missing_modules': missing_modules,
        'active_signals': active_signals,
        'signal_contributions': signal_contributions,
        'signal_contribution_sum': round(sum(item['pch_contribution'] for item in signal_contributions), 6),
        'unproven_signals': missing_signals,
        'positive_modules': positive_modules,
        'negative_modules': negative_modules,
        'module_contributions': module_contributions,
        'pch_decomposition': {'pch_brut': pch_brut, 'module_sum': module_sum, 'gru_derived': gru_derived, 'pch_final': pch_final, 'pch_norm': round(pch_final / 220.0, 6) if pch_final is not None else None},
        'composite_components': composite_components,
        'ordre_factors': ordre_factors,
        'market_summary': market_summary,
        'rank_pre_course': rank,
        'score_gap_to_ticket_cutoff': score_gap_to_ticket_cutoff,
        'score_gap_to_rank8': score_gap_to_rank8,
    }


def _ranking_diagnosis(number: int, row: Dict[str, Any], pre: Dict[str, Any], ranked_rows: List[Dict[str, Any]], ticket: List[int]) -> List[Dict[str, Any]]:
    evidence = _evidence_summary(row, ranked_rows, ticket)
    scores = evidence['scores'] or {}
    causes: List[Dict[str, Any]] = []
    rank = evidence.get('rank_pre_course')
    ordre = _number(scores.get('ordre_score'))
    pch_final = _number(scores.get('pch_final'))
    composite = _number(scores.get('composite'))
    if not evidence.get('position_ticket'):
        causes.append({'code': 'EXCLUDED_BY_ORDRE_SCORE_RANK', 'type': 'DERIVED', 'description': 'Le cheval était hors ticket car son ORDRE_SCORE le plaçait sous le seuil effectif de sélection.', 'rank_pre_course': rank, 'ticket_size': len(ticket), 'ordre_score': ordre, 'gap_to_ticket_cutoff': evidence.get('score_gap_to_ticket_cutoff'), 'gap_to_score_rank8': evidence.get('score_gap_to_rank8')})
    if pch_final is not None and composite is not None and ranked_rows:
        pch_values = [_number((candidate.get('scores') or {}).get('pch_final')) for candidate in ranked_rows]
        pch_values = [value for value in pch_values if value is not None]
        composite_values = [_number((candidate.get('scores') or {}).get('composite')) for candidate in ranked_rows]
        composite_values = [value for value in composite_values if value is not None]
        if pch_values and pch_final < median(pch_values):
            causes.append({'code': 'PCH_BELOW_FIELD_MEDIAN', 'type': 'DERIVED', 'description': 'Le PCH_FINAL était inférieur à la médiane du champ, ce qui a réduit le PCH_NORM puis le COMPOSITE.', 'pch_final': pch_final, 'field_median_pch_final': round(median(pch_values), 6), 'pch_norm': evidence['pch_decomposition'].get('pch_norm')})
        if composite_values and composite < median(composite_values):
            causes.append({'code': 'COMPOSITE_BELOW_FIELD_MEDIAN', 'type': 'DERIVED', 'description': 'Le COMPOSITE était inférieur à la médiane du champ avant le calcul de l’ORDRE_FINAL.', 'composite': composite, 'field_median_composite': round(median(composite_values), 6)})
    missing_modules = evidence.get('missing_modules', [])
    if missing_modules:
        causes.append({'code': 'UNPROVEN_MODULES_NEUTRALIZED', 'type': 'OBSERVED', 'description': 'Des modules n’ont produit aucune contribution car leurs entrées étaient NC/UNPROVEN. Cela explique une absence de bonus, mais ne prouve pas que le cheval aurait dû être sélectionné.', 'modules': missing_modules})
    if evidence.get('unproven_signals'):
        causes.append({'code': 'UNPROVEN_CATALOGUE_SIGNALS', 'type': 'OBSERVED', 'description': 'Des signaux de catalogues étaient déclarés mais non prouvés par les données pré-course.', 'signals': [item.get('code') for item in evidence['unproven_signals'][:30]], 'count': len(evidence['unproven_signals'])})
    factors = evidence.get('ordre_factors', {}) or {}
    sov = _number(factors.get('sov_v2'))
    if sov is not None and sov < 0:
        causes.append({'code': 'MARKET_DRIFT_PENALTY', 'type': 'OBSERVED_DERIVED', 'description': 'La dérive de cote a produit un SOV_v2 négatif et a réduit le multiplicateur de classement.', 'sov_v2': sov, 'market_summary': evidence.get('market_summary', {}), 'ordre_factors': {'sov_status': factors.get('sov_status'), 'ordre_base': factors.get('ordre_base')}})
    if evidence.get('positive_modules'):
        causes.append({'code': 'POSITIVE_MODULES_NOT_ENOUGH_TO_REACH_TICKET', 'type': 'OBSERVED', 'description': 'Des contributions positives existaient, mais leur somme n’a pas compensé les modules non prouvés et les facteurs de classement.', 'positive_modules': evidence['positive_modules'], 'module_contributions': evidence['module_contributions']})
    if not causes:
        causes.append({'code': 'UNATTRIBUTED_VARIANCE', 'type': 'UNPROVEN', 'description': 'Les preuves pré-course disponibles ne permettent pas d’attribuer davantage l’écart.'})
    return causes


def _root_cause_for_missed(number: int, pre: Dict[str, Any], official_rank: int, ranked_rows: Optional[List[Dict[str, Any]]] = None, ticket: Optional[List[int]] = None) -> Dict[str, Any]:
    row = _partants_by_number(pre).get(number, {})
    evidence = _evidence_summary(row, ranked_rows or [], ticket or [])
    reasons: List[Dict[str, Any]] = []
    scores = evidence['scores'] or {}
    if evidence.get('missing_fields'):
        reasons.append({'code': 'DATA_INCOMPLETE', 'description': 'Des champs pré-course étaient NC ou UNPROVEN.', 'fields': evidence['missing_fields']})
    if _number(scores.get('pch_brut')) is not None and _number(scores.get('pch_final')) is not None and float(scores.get('pch_brut') or 0) > 0 and float(scores.get('pch_final') or 0) <= 0:
        reasons.append({'code': 'PCH_ZERO_AFTER_GOVERNANCE', 'description': 'Le PCH brut positif a été neutralisé ou plafonné à zéro avant COMPOSITE.', 'pch_brut': scores.get('pch_brut'), 'pch_final': scores.get('pch_final')})
    if float(scores.get('composite', 0) or 0) <= 0:
        reasons.append({'code': 'COMPOSITE_ZERO', 'description': 'Le COMPOSITE final était nul, empêchant un ORDRE_SCORE positif.'})
    if float(scores.get('ordre_score', 0) or 0) <= 0:
        reasons.append({'code': 'ORDRE_SCORE_ZERO', 'description': 'ORDRE_SCORE nul au moment de la sélection.'})
    if not evidence.get('position_ticket'):
        reasons.append({'code': 'EXCLUDED_BY_GMOV', 'description': 'Le cheval n’a pas reçu de position dans le ticket GMO-V.', 'decision': 'hors_ticket'})
    if evidence.get('legacy_flags'):
        reasons.append({'code': 'LEGACY_OR_RISK_FLAGS', 'description': 'Des flags legacy/risque étaient présents et ont influencé la gouvernance.', 'flags': evidence['legacy_flags']})
    if evidence.get('positive_modules') and not evidence.get('position_ticket'):
        reasons.append({'code': 'POSITIVE_MODULE_NOT_SUFFICIENT', 'description': 'Des modules positifs existaient mais ne satisfaisaient pas les contraintes de composition.', 'modules': evidence['positive_modules']})
    reasons.extend(_ranking_diagnosis(number, row, pre, ranked_rows or [], ticket or []))
    return {'numero': number, 'nom': row.get('nom', 'NC'), 'official_rank': official_rank, 'causes': reasons, 'evidence': evidence}


def _root_cause_for_outside(number: int, pre: Dict[str, Any], official_top5: Set[int], ranked_rows: Optional[List[Dict[str, Any]]] = None, ticket: Optional[List[int]] = None) -> Dict[str, Any]:
    row = _partants_by_number(pre).get(number, {})
    evidence = _evidence_summary(row, ranked_rows or [], ticket or [])
    scores = evidence['scores'] or {}
    reasons: List[Dict[str, Any]] = []
    if evidence.get('position_ticket'):
        reasons.append({'code': 'TICKET_POSITION_USED', 'description': 'Le cheval a été conservé dans le ticket malgré son absence du Top 5 réel.', 'position': evidence['position_ticket']})
    if float(evidence.get('tocard_score') or 0) >= .20:
        reasons.append({'code': 'LONGSHOT_OR_TOCARD_OVERWEIGHT', 'description': 'Le signal tocard/longshot a contribué à son maintien ou à sa promotion.', 'tocard_score': evidence.get('tocard_score')})
    if evidence.get('positive_modules'):
        reasons.append({'code': 'POSITIVE_MODULE_NOT_SUFFICIENTLY_CALIBRATED', 'description': 'Des modules positifs ont soutenu le cheval sans produire une arrivée Top 5.', 'modules': evidence['positive_modules'], 'module_contributions': evidence['module_contributions']})
    if float(scores.get('ordre_score', 0) or 0) > 0:
        reasons.append({'code': 'RANKING_SCORE_FALSE_POSITIVE', 'description': 'ORDRE_SCORE positif mais non confirmé par le résultat officiel.', 'ordre_score': scores.get('ordre_score')})
    if evidence.get('legacy_flags'):
        reasons.append({'code': 'LEGACY_OR_RISK_FLAGS_NOT_PENALIZING_ENOUGH', 'description': 'Des signaux de risque n’ont pas empêché la présence dans le ticket.', 'flags': evidence['legacy_flags']})
    if not reasons:
        reasons.append({'code': 'UNATTRIBUTED_VARIANCE', 'description': 'Aucune cause codifiée ne permet d’attribuer le faux positif avec les preuves pré-course disponibles.'})
    return {'numero': number, 'nom': row.get('nom', 'NC'), 'causes': reasons, 'evidence': evidence}


def auditer_post_course(pre_course: Dict[str, Any], officiel: Dict[str, Any], sources: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    official_order = _official_order(officiel)
    ticket = _ticket_numbers(pre_course)
    consensus = officiel.get('consensus', {}) or {}
    consulted = sources or officiel.get('sources_consultees', [])
    source_status = officiel.get('statut', 'NC')
    base = {
        'audit_type': 'POST_COURSE',
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'course_identity': pre_course.get('course', {}),
        'sources_consultees': consulted,
        'official_result': {'ordre': official_order if source_status in CONSENSUS_STATUSES else [], 'source_status': source_status, 'consensus': consensus, 'valid_results': officiel.get('valid_results', [])},
        'pre_course_ticket': ticket,
        'consensus_policy': {'minimum_independent_sources': 2, 'accepted_statuses': sorted(CONSENSUS_STATUSES), 'strong_consensus_status': 'OFFICIAL_CONSENSUS_3_SOURCES', 'minimum_consensus_status': 'OFFICIAL_CONSENSUS_2_SOURCES'},
        'retroactive_prediction_change': False,
    }
    if source_status not in CONSENSUS_STATUSES or len(official_order) < 5:
        base.update({'metrics': {'top5_officiel': [], 'captured_numbers': [], 'missed_top5_numbers': [], 'ticket_numbers_outside_top5': [], 'capture_top5_free_order_percent': None, 'captured_count': 0, 'missed_count': 0, 'outside_count': 0}, 'root_causes': {'missed_top5': [], 'ticket_outside_top5': [], 'aggregate': {}}, 'confidence': 'INSUFFICIENT_CONSENSUS', 'status': 'AUDIT_INCOMPLET_CONSENSUS_INSUFFISANT', 'warning': 'Aucune comparaison ni capture certifiée tant que deux sources indépendantes ne concordent pas.'})
        base['score_diagnostics_v3'] = build_score_diagnostics_v3(pre_course, base)
        return base

    partants = [row for row in pre_course.get('partants', []) or [] if isinstance(row, dict)]
    top5 = official_order[:5]
    top5_set = set(top5)
    ticket_set = set(ticket)
    captured = [number for number in top5 if number in ticket_set]
    missed = [number for number in top5 if number not in ticket_set]
    outside = [number for number in ticket if number not in top5_set]
    miss_analysis = [_root_cause_for_missed(number, pre_course, top5.index(number) + 1, partants, ticket) for number in missed]
    outside_analysis = [_root_cause_for_outside(number, pre_course, top5_set, partants, ticket) for number in outside]
    causes: Dict[str, int] = {}
    for item in miss_analysis + outside_analysis:
        for cause in item['causes']:
            code = cause['code']
            causes[code] = causes.get(code, 0) + 1
    ranking_diagnostics = []
    for row in sorted(partants, key=lambda item: (_number((item.get('scores') or {}).get('ordre_score')) or float('-inf')), reverse=True):
        number = row.get('numero')
        if number is None:
            continue
        evidence = _evidence_summary(row, partants, ticket)
        ranking_diagnostics.append({'numero': number, 'nom': row.get('nom', 'NC'), 'official_rank': top5.index(int(number)) + 1 if int(number) in top5 else None, 'pre_course_rank': evidence.get('rank_pre_course'), 'position_ticket': evidence.get('position_ticket'), 'ordre_score': _number((row.get('scores') or {}).get('ordre_score')), 'pch_final': _number((row.get('scores') or {}).get('pch_final')), 'composite': _number((row.get('scores') or {}).get('composite')), 'score_gap_to_ticket_cutoff': evidence.get('score_gap_to_ticket_cutoff'), 'score_gap_to_rank8': evidence.get('score_gap_to_rank8')})
    base.update({'metrics': {'top5_officiel': top5, 'captured_numbers': captured, 'missed_top5_numbers': missed, 'ticket_numbers_outside_top5': outside, 'capture_top5_free_order_percent': round(len(captured) / 5 * 100, 2), 'captured_count': len(captured), 'missed_count': len(missed), 'outside_count': len(outside)}, 'root_causes': {'missed_top5': miss_analysis, 'ticket_outside_top5': outside_analysis, 'aggregate': causes}, 'ranking_diagnostics': ranking_diagnostics, 'score_formula_audit': {'final_ranking_score': 'ORDRE_FINAL = COMPOSITE × PRODUIT_MULT_corrigé × malus_GRU_Enghien', 'composite': 'COMPOSITE = w_PCH×PCH_NORM + w_tocard×tocard_score + w_CSF×csf_norm + 0.10×h2h_norm', 'pch': 'PCH_FINAL = clamp(0,220,PCH_brut + GRU + somme_modules)', 'product': 'PRODUIT_MULT_corrigé = clamp(0.65,1.45,(1+SOV_v2)×IQL_v2×TACT_mult×STAB_mult×ALL_mult×Harville_mult)'}, 'confidence': 'HIGH' if source_status == 'OFFICIAL_CONSENSUS_3_SOURCES' else 'MEDIUM', 'consensus_strength': 'STRONG_3_PLUS' if source_status == 'OFFICIAL_CONSENSUS_3_SOURCES' else 'MINIMUM_2', 'conflict_present': bool(consensus.get('conflict_present', False)), 'status': 'AUDIT_COMPLET'})
    base['score_diagnostics_v3'] = build_score_diagnostics_v3(pre_course, base)
    return base
