"""Registre versionné des identifiants normatifs du protocole Vantage."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


CATALOGUE_PATH = Path(__file__).with_name('rules_catalogue.json')


def charger_catalogue() -> Dict[str, Any]:
    """Charge le catalogue embarqué, sans fallback silencieux."""
    if not CATALOGUE_PATH.exists():
        raise FileNotFoundError(f"Catalogue normatif absent: {CATALOGUE_PATH}")
    return json.loads(CATALOGUE_PATH.read_text(encoding='utf-8'))


def obtenir_regle(rule_id: str) -> Dict[str, Any]:
    """Retourne les références connues d'une règle RAH ou d'un signal."""
    catalogue = charger_catalogue()
    upper = rule_id.upper()
    for group, values in catalogue.get('occurrences', {}).items():
        if upper in values:
            return {
                'rule_id': upper,
                'catalogue': group,
                'source_lines': values[upper],
                'status': 'CATALOGUED',
            }
    return {
        'rule_id': upper,
        'catalogue': None,
        'source_lines': [],
        'status': 'NOT_FOUND_IN_EXTRACT',
    }


def preuve_regle(rule_id: str, status: str, evidence: Any = None, reason: str = '') -> Dict[str, Any]:
    """Construit une preuve uniforme sans transformer une règle inconnue en PASS."""
    allowed = {'PASS', 'FAIL', 'N_A', 'NC', 'UNPROVEN'}
    if status not in allowed:
        raise ValueError(f"Statut de règle invalide: {status}")
    ref = obtenir_regle(rule_id)
    if status == 'PASS' and ref['status'] != 'CATALOGUED':
        status = 'UNPROVEN'
    return {
        **ref,
        'status': status,
        'evidence': evidence,
        'reason': reason,
    }
