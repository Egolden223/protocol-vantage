"""Validation déterministe du rapport JSON intégral fusionné."""
from __future__ import annotations
from typing import Any, Dict, List

REQUIRED_TOP_LEVEL = {
    'schema', 'report_type', 'analysis_id', 'course_identity', 'course_summary',
    'ticket', 'export', 'execution_trace', 'post_course_audit', 'diagnostics', 'integrity'
}


def valider_rapport_integral(document: Any) -> Dict[str, Any]:
    errors: List[str] = []
    warnings: List[str] = []
    if not isinstance(document, dict):
        return {'valid': False, 'errors': ['Le rapport intégral doit être un objet JSON'], 'warnings': []}
    missing = sorted(REQUIRED_TOP_LEVEL - set(document))
    errors.extend(f'Champ absent: {key}' for key in missing)
    if document.get('schema') != 'VANTAGE_INTEGRAL_REPORT_V2':
        errors.append('Schéma VANTAGE_INTEGRAL_REPORT_V2 attendu')
    ticket = document.get('ticket')
    if not isinstance(ticket, dict):
        errors.append('ticket doit être un objet')
    else:
        for key in ('visible', 'final_certified', 'prevented', 'status', 'pre_course_locked'):
            if key not in ticket:
                errors.append(f'ticket.{key} absent')
    trace = document.get('execution_trace')
    if not isinstance(trace, dict):
        errors.append('execution_trace doit être un objet')
    else:
        for key in ('final', 'ticket_trace', 'ticket_status'):
            if key not in trace:
                errors.append(f'execution_trace.{key} absent')
        if isinstance(ticket, dict) and ticket.get('status') == 'NON_CERTIFIABLE_PREVENTED':
            if not trace.get('ticket_trace'):
                errors.append('Ticket empêché absent de execution_trace.ticket_trace')
            if not isinstance(trace.get('final'), dict) or not trace['final'].get('ticket'):
                errors.append('Ticket empêché absent de execution_trace.final.ticket')
    diagnostics = document.get('diagnostics')
    if not isinstance(diagnostics, dict):
        errors.append('diagnostics doit être un objet')
    else:
        for key in ('official_top5', 'captured_top5', 'missed_top5', 'ticket_outside_top5', 'ranking_diagnostics', 'score_formula_audit'):
            if key not in diagnostics:
                warnings.append(f'diagnostics.{key} absent')
    integrity = document.get('integrity')
    if isinstance(integrity, dict):
        if trace and trace.get('ticket_trace') and integrity.get('trace_ticket_present') is not True:
            errors.append('integrity.trace_ticket_present incohérent')
    else:
        errors.append('integrity doit être un objet')
    return {'valid': not errors, 'errors': errors, 'warnings': warnings}
