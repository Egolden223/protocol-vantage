"""Politique d'équité de collecte entre partants.

Principe : l'absence d'une donnée ne constitue jamais une observation négative.
Une donnée absente pour un cheval alors qu'elle est observée pour d'autres est
classée COLLECTION_GAP et ne reçoit aucune pénalité individuelle PCH/IFT.
"""
from __future__ import annotations

from typing import Any, Dict, List

from engine.quality_governance import QUALITY_FIELDS, _missing


VALID_ABSENCE = {None, '', 'NC', 'UNPROVEN'}


def build_equity_report(course) -> Dict[str, Any]:
    parts = list(getattr(course, 'partants', []) or [])
    n = len(parts)
    missing_by_number: Dict[str, List[str]] = {}
    observed_counts = {field: 0 for field in QUALITY_FIELDS}
    for partant in parts:
        missing = set(_missing(partant))
        missing_by_number[str(partant.numero)] = sorted(missing)
        for field in QUALITY_FIELDS:
            if field not in missing:
                observed_counts[field] += 1

    fields = {}
    for field, observed in observed_counts.items():
        coverage = observed / n if n else 0.0
        fields[field] = {
            'observed_count': observed,
            'partants_count': n,
            'coverage_rate': round(coverage, 6),
            'coverage_percent': round(coverage * 100.0, 2),
            'status': 'FULL_COVERAGE' if n and observed == n else 'PARTIAL_COVERAGE' if observed else 'NO_COVERAGE',
            'individual_penalty_policy': 'NONE_FOR_COLLECTION_GAP',
        }

    rows = []
    for partant in parts:
        missing = missing_by_number[str(partant.numero)]
        collection_gap = [field for field in missing if observed_counts[field] > 0]
        global_unobserved = [field for field in missing if observed_counts[field] == 0]
        rows.append({
            'numero': partant.numero,
            'missing_fields': missing,
            'collection_gap_fields': collection_gap,
            'global_unobserved_fields': global_unobserved,
            'equity_status': 'COMPARABLE' if not collection_gap else 'PARTIAL_COVERAGE',
            'individual_pch_adjustment': 0.0,
            'individual_ift_penalty': 0,
            'reason': 'ABSENCE_IS_NOT_NEGATIVE_EVIDENCE',
        })

    return {
        'policy_version': 'EQUITY_NEUTRALITY_V1',
        'principle': 'A missing observation never becomes a negative observation.',
        'fields': fields,
        'partants': rows,
        'course_level_quality': 'FULL' if all(item['status'] == 'FULL_COVERAGE' for item in fields.values()) else 'PARTIAL' if any(item['observed_count'] for item in fields.values()) else 'LOW',
        'course_level_ift_penalty': 0,
        'individual_penalties_disabled_for_collection_gaps': True,
        'audit_action': 'RETRY_SOURCE_OR_USE_COHORT_NEUTRAL_BASELINE',
    }
