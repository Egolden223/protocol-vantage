"""Signaux historiques déterministes compatibles avec Protocol Vantage v1.22.2-test.

Ce module reprend uniquement les règles dont les entrées sont observables dans le
contrat actuel (historique distance/terrain/hippodrome). Il ne fabrique jamais
une performance : une règle sans échantillon suffisant reste UNPROVEN et ne
produit aucun signal actif. Les valeurs et leurs entrées sont conservées dans
``raw_data['historical_catalogue_audit']`` pour la trace d'audit intégrale.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple

from engine.models import Course, Partant, Signal


def _num(value: Any) -> Optional[float]:
    try:
        if value in (None, "", "NC", "UNPROVEN"):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _date(value: Any) -> Optional[date]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).date()
    except (TypeError, ValueError):
        return None


def _rows(raw: Dict[str, Any], key: str, aliases: Iterable[str] = ()) -> List[Dict[str, Any]]:
    values = raw.get(key)
    if values in (None, "", "NC", "UNPROVEN"):
        for alias in aliases:
            values = raw.get(alias)
            if values not in (None, "", "NC", "UNPROVEN"):
                break
    if not isinstance(values, (list, tuple)):
        return []
    result: List[Dict[str, Any]] = []
    for item in values:
        if isinstance(item, dict):
            result.append({
                "rang": _num(item.get("rang", item.get("notre_rang", item.get("rank", item.get("resultat"))))),
                "distance": _num(item.get("distance_m", item.get("distance"))),
                "terrain": _num(item.get("penetrometre", item.get("penetrometre_approx", item.get("terrain_indice")))),
                "hippodrome": item.get("hippodrome", item.get("course_hippodrome")),
                "date": item.get("date", item.get("date_course")),
                "partants": _num(item.get("partants", item.get("nb_partants", item.get("field_size")))),
            })
        elif isinstance(item, (list, tuple)):
            if len(item) >= 2:
                result.append({"distance": _num(item[0]), "rang": _num(item[1])})
    return [row for row in result if any(value is not None for value in row.values())]


def _norm(value: Any) -> str:
    return str(value or "").strip().upper().replace("-", " ").replace("'", "")


def _add_signal(partant: Partant, code: str, value: float, family: str, reason: str,
                confidence: str, formula: str, inputs: Dict[str, Any], audit: Dict[str, Any]) -> None:
    signal = next((s for s in partant.signaux if s.code == code), None)
    if signal is None:
        signal = Signal(code=code, nom=code, famille=family)
        partant.signaux.append(signal)
    signal.actif = True
    signal.valeur = float(value)
    signal.famille = family
    signal.niveau_fallback = confidence
    signal.source = "HISTORIQUE_OBSERVE"
    signal.flag_manquant = False
    signal.raison_manquant = ""
    audit["signals"].append({
        "code": code, "status": "ACTIVE", "value": float(value),
        "confidence": confidence, "source": "HISTORIQUE_OBSERVE",
        "reason": reason, "formula": formula, "inputs": inputs,
    })


def _audit_missing(audit: Dict[str, Any], code: str, reason: str, inputs: Dict[str, Any]) -> None:
    audit["signals"].append({"code": code, "status": "UNPROVEN", "value": None,
                             "confidence": "NC", "source": "NONE", "reason": reason,
                             "formula": None, "inputs": inputs})
    audit["missing_inputs"].append({"code": code, "reason": reason, "inputs": inputs})


def appliquer_signaux_historiques(partant: Partant, course: Course) -> Dict[str, Any]:
    """Calcule les catalogues historiques observables et les attache au partant."""
    raw = getattr(partant, "raw_data", {}) or {}
    audit: Dict[str, Any] = {
        "status": "UNPROVEN", "source_contract": "OBSERVED_FIELDS_ONLY",
        "signals": [], "missing_inputs": [], "formulas_version": "CLAUDE_REVIEW_PORT_V1",
    }
    hippo = _norm(getattr(course, "hippodrome", ""))
    course_distance = _num(getattr(course, "distance", None))
    course_penetro = _num(getattr(course, "penetrometre", None))

    # B04/M23 : affinité hippodrome. L'historique détaillé est exigé ; le seul
    # texte de musique ne suffit pas à prouver une affinité de lieu.
    history = _rows(raw, "historique_parcours_exact", ("historique_detaille", "historique_courses"))
    on_hippo = [r for r in history if _norm(r.get("hippodrome")) == hippo and r.get("rang") is not None]
    if len(on_hippo) < 3 or not hippo:
        _audit_missing(audit, "B04", "Moins de trois performances datées et identifiées sur l'hippodrome", {"observed": len(on_hippo), "required": 3})
        _audit_missing(audit, "M23", "Historique hippodrome insuffisant", {"observed": len(on_hippo), "required": 3})
    else:
        top5 = sum(1 for r in on_hippo if r["rang"] <= 5)
        top3 = sum(1 for r in on_hippo if r["rang"] <= 3)
        rate = top5 / len(on_hippo)
        base = 12.0 if top5 >= 3 and len(on_hippo) >= 4 else 6.0 if rate >= .20 else 3.0 if top3 >= 1 else 0.0
        if base > 0:
            dated = [(_date(r.get("date")), r) for r in on_hippo if _date(r.get("date"))]
            coeff = .60
            if dated and getattr(course, "date", None):
                ref = _date(course.date)
                delays = [(ref - d).days for d, _ in dated if ref and d and (ref - d).days >= 0]
                if delays:
                    delay = min(delays)
                    coeff = 1.0 if delay <= 90 else .75 if delay <= 180 else .50 if delay <= 365 else .25
            final = max(1.0, round(base * coeff))
            _add_signal(partant, "B04", final, "L", f"{len(on_hippo)} performances à {getattr(course, 'hippodrome', '')}, {top5} Top5, coefficient temps={coeff}", "STRICT" if dated else "DEGRADE", "base(B04)×coeff_temps; base=12 si ≥3 Top5/≥4 courses, 6 si taux Top5≥20%, 3 si ≥1 Top3", {"courses": len(on_hippo), "top5": top5, "top3": top3, "coeff_temps": coeff}, audit)
        else:
            _audit_missing(audit, "B04", "Aucune performance Top5 observée sur l'hippodrome", {"courses": len(on_hippo), "top5": top5})
        if top5 == 0:
            _add_signal(partant, "M23", -10.0 if len(on_hippo) >= 3 else -5.0, "M", f"{len(on_hippo)} courses à {getattr(course, 'hippodrome', '')}, 0 Top5", "DEGRADE", "-10 si ≥3 courses sans Top5, sinon -5", {"courses": len(on_hippo), "top5": top5}, audit)
        else:
            _audit_missing(audit, "M23", "Au moins un Top5 observé sur l'hippodrome", {"courses": len(on_hippo), "top5": top5})

    # B05/M04 : compatibilité de distance.
    dist_rows = _rows(raw, "historique_distances_perf", ("historique_distance",))
    if course_distance is None or not dist_rows:
        _audit_missing(audit, "B05", "Historique de distance ou distance de course absent", {"rows": len(dist_rows), "course_distance": course_distance})
        _audit_missing(audit, "M04", "Historique de distance absent", {"rows": len(dist_rows), "course_distance": course_distance})
    else:
        similar = [r for r in dist_rows if r.get("distance") is not None and r.get("rang") is not None and abs(r["distance"] - course_distance) <= 50]
        top5 = sum(1 for r in similar if r["rang"] <= 5)
        top2 = sum(1 for r in similar if r["rang"] <= 2)
        if top5 >= 4:
            value, conf = 8.0, "STRICT"
        elif top5 >= 2:
            value, conf = 4.0, "DEGRADE"
        elif top2 >= 1:
            value, conf = 2.0, "MINIMAL"
        else:
            value, conf = 0.0, "NC"
        if value:
            _add_signal(partant, "B05", value, "L", f"{top5} Top5 sur distance ±50m", conf, "8 si ≥4 Top5; 4 si ≥2; 2 si ≥1 Top2", {"similar_rows": len(similar), "top5": top5, "top2": top2, "tolerance_m": 50}, audit)
        else:
            _audit_missing(audit, "B05", "Aucun résultat positif suffisant sur distance ±50m", {"similar_rows": len(similar), "top5": top5, "top2": top2})
        poor = [r for r in dist_rows if r.get("distance") is not None and r.get("rang") is not None and abs(r["distance"] - course_distance) <= 100 and r["rang"] > 7]
        if len(poor) >= 3:
            _add_signal(partant, "M04", -10.0, "M", f"{len(poor)} rangs >7 sur distance ±100m", "STRICT", "-10 si ≥3 rangs >7; -5 si 2", {"poor_rows": len(poor), "tolerance_m": 100}, audit)
        elif len(poor) >= 2:
            _add_signal(partant, "M04", -5.0, "M", f"{len(poor)} rangs >7 sur distance ±100m", "DEGRADE", "-10 si ≥3 rangs >7; -5 si 2", {"poor_rows": len(poor), "tolerance_m": 100}, audit)
        else:
            _audit_missing(audit, "M04", "Pas de série négative suffisante sur distance ±100m", {"poor_rows": len(poor)})

    # B17/M03/M10/M21 : terrain. Le pénétromètre historique doit être observé;
    # la musique seule ne permet pas de déduire une aptitude au terrain.
    terrain_rows = _rows(raw, "historique_terrain_perf", ("historique_terrain",))
    if course_penetro is None or not terrain_rows:
        for code in ("B17", "M03", "M10", "M21"):
            _audit_missing(audit, code, "Pénétromètre actuel ou historique terrain absent", {"rows": len(terrain_rows), "course_penetrometre": course_penetro})
    else:
        similar = [r for r in terrain_rows if r.get("terrain") is not None and r.get("rang") is not None and abs(r["terrain"] - course_penetro) <= .5]
        top3 = sum(1 for r in similar if r["rang"] <= 3)
        poor = sum(1 for r in similar if r["rang"] > 7)
        if top3 >= 3:
            _add_signal(partant, "B17", 10.0, "L", f"{top3} Top3 sur pénétromètre ±0,5", "STRICT", "10 si ≥3 Top3; 5 si ≥2; 2 si ≥1 Top2", {"similar_rows": len(similar), "top3": top3, "tolerance": .5}, audit)
        elif top3 >= 2:
            _add_signal(partant, "B17", 5.0, "L", f"{top3} Top3 sur pénétromètre ±0,5", "DEGRADE", "10 si ≥3 Top3; 5 si ≥2; 2 si ≥1 Top2", {"similar_rows": len(similar), "top3": top3, "tolerance": .5}, audit)
        elif any(r["rang"] <= 2 for r in similar):
            _add_signal(partant, "B17", 2.0, "L", "1 Top2 sur pénétromètre ±0,5", "MINIMAL", "10 si ≥3 Top3; 5 si ≥2; 2 si ≥1 Top2", {"similar_rows": len(similar), "top3": top3, "tolerance": .5}, audit)
        else:
            _audit_missing(audit, "B17", "Aucun Top2/Top3 suffisant sur terrain similaire", {"similar_rows": len(similar), "top3": top3})
        if poor >= 3:
            _add_signal(partant, "M03", -12.0, "M", f"{poor} rangs >7 sur terrain similaire", "STRICT", "-12 si ≥3; -6 si 2", {"similar_rows": len(similar), "poor": poor}, audit)
        elif poor >= 2:
            _add_signal(partant, "M03", -6.0, "M", f"{poor} rangs >7 sur terrain similaire", "DEGRADE", "-12 si ≥3; -6 si 2", {"similar_rows": len(similar), "poor": poor}, audit)
        else:
            _audit_missing(audit, "M03", "Pas de série négative terrain suffisante", {"similar_rows": len(similar), "poor": poor})
        if not similar:
            _add_signal(partant, "M10", -8.0, "M", "Aucune course historique sur terrain similaire", "STRICT", "-8 si aucune; -4 si une seule", {"terrain_rows": len(terrain_rows), "similar_rows": 0}, audit)
        elif len(similar) == 1:
            _add_signal(partant, "M10", -4.0, "M", "Une seule course historique sur terrain similaire", "DEGRADE", "-8 si aucune; -4 si une seule", {"similar_rows": len(terrain_rows), "similar_rows": 1}, audit)
        else:
            _audit_missing(audit, "M10", "Au moins deux courses sur terrain similaire", {"similar_rows": len(similar)})
        heavy = [r for r in terrain_rows if r.get("terrain") is not None and r.get("rang") is not None and r["terrain"] >= 5.0]
        heavy_top5 = sum(1 for r in heavy if r["rang"] <= 5)
        if len(heavy) >= 5 and heavy_top5 == 0:
            _add_signal(partant, "M21", -10.0, "M", f"0 Top5 sur {len(heavy)} courses lourdes", "STRICT", "-10 si ≥5 courses lourdes sans Top5; -5 si ≥3", {"heavy_rows": len(heavy), "heavy_top5": heavy_top5}, audit)
        elif len(heavy) >= 3 and heavy_top5 == 0:
            _add_signal(partant, "M21", -5.0, "M", f"0 Top5 sur {len(heavy)} courses lourdes", "DEGRADE", "-10 si ≥5 courses lourdes sans Top5; -5 si ≥3", {"heavy_rows": len(heavy), "heavy_top5": heavy_top5}, audit)
        else:
            _audit_missing(audit, "M21", "Série lourde insuffisante ou Top5 observé", {"heavy_rows": len(heavy), "heavy_top5": heavy_top5})

    # B19 : spécialiste conditions exactes.
    exact = [r for r in history if _norm(r.get("hippodrome")) == hippo and r.get("distance") is not None and course_distance is not None and abs(r["distance"] - course_distance) <= 100 and r.get("rang") is not None]
    top3_exact = sum(1 for r in exact if r["rang"] <= 3)
    if top3_exact >= 3:
        _add_signal(partant, "B19", 15.0, "L", f"{top3_exact} Top3 sur hippodrome + distance", "STRICT", "15 si ≥3 Top3 exacts; 8 si ≥1 Top3 sur ≥2 courses", {"exact_rows": len(exact), "top3": top3_exact}, audit)
    elif top3_exact >= 1 and len(exact) >= 2:
        _add_signal(partant, "B19", 8.0, "L", f"{top3_exact} Top3 sur conditions proches", "DEGRADE", "15 si ≥3 Top3 exacts; 8 si ≥1 Top3 sur ≥2 courses", {"exact_rows": len(exact), "top3": top3_exact}, audit)
    else:
        _audit_missing(audit, "B19", "Historique conditions exactes insuffisant", {"exact_rows": len(exact), "top3": top3_exact})

    audit["active_codes"] = [item["code"] for item in audit["signals"] if item["status"] == "ACTIVE"]
    audit["status"] = "CALCULATED" if audit["active_codes"] else "UNPROVEN"
    raw["historical_catalogue_audit"] = audit
    partant.raw_data = raw
    return audit
