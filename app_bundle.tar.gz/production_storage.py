"""Stockage durable de production pour les analyses Vantage.

Le moteur de calcul reste indépendant du stockage. Ce module conserve une copie
structurée en SQLite pour l'historique et des artefacts JSON séparés pour les
exports, preuves de collecte et audits post-course.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import tempfile
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from drive_backup import upload_json_detailed
from huggingface_backup import upload_json_gz_detailed
from engine.integral_report_validator import valider_rapport_integral
from engine.analytic_audit_v3 import build_score_diagnostics_v3


PROJECT_ROOT = Path(__file__).resolve().parent


def _json_default(value: Any):
    if hasattr(value, "value"):
        return value.value
    if hasattr(value, "__dict__"):
        return value.__dict__
    return str(value)


def _json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=_json_default, sort_keys=True)


def _json_loads(value: Optional[str], default: Any):
    if not value:
        return default
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def _configured_path(name: str, default: Path) -> Path:
    configured = os.environ.get(name)
    return Path(configured).expanduser() if configured else default


def database_path() -> Path:
    return _configured_path("VANTAGE_DB_PATH", PROJECT_ROOT / "data" / "vantage.sqlite3")


def artifacts_root() -> Path:
    return _configured_path("VANTAGE_ARTIFACTS_ROOT", PROJECT_ROOT / "data" / "courses")


def backup_root() -> Optional[Path]:
    configured = os.environ.get("VANTAGE_BACKUP_DIR")
    return Path(configured).expanduser() if configured else None


def _connect() -> sqlite3.Connection:
    path = database_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA foreign_keys=ON")
    return connection


def initialize_storage() -> None:
    with _connect() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS analyses (
                id INTEGER PRIMARY KEY,
                date_execution TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_analyses_date_execution ON analyses(date_execution)"
        )


def load_analyses() -> List[Dict[str, Any]]:
    initialize_storage()
    with _connect() as connection:
        rows = connection.execute(
            "SELECT payload_json FROM analyses ORDER BY id ASC"
        ).fetchall()
    return [item for row in rows if (item := _json_loads(row[0], None)) is not None]


def get_analysis(analysis_id: int) -> Optional[Dict[str, Any]]:
    initialize_storage()
    with _connect() as connection:
        row = connection.execute(
            "SELECT payload_json FROM analyses WHERE id = ?", (int(analysis_id),)
        ).fetchone()
    return _json_loads(row[0], None) if row else None


def load_analysis_summaries() -> List[Dict[str, Any]]:
    """Charge l’historique sans désérialiser les rapports JSON volumineux."""
    initialize_storage()
    summaries: List[Dict[str, Any]] = []
    with _connect() as connection:
        try:
            rows = connection.execute(
                """
                SELECT id, date_execution,
                       json_extract(payload_json, '$.course'),
                       json_extract(payload_json, '$.discipline'),
                       json_extract(payload_json, '$.nb_partants'),
                       json_extract(payload_json, '$.signature'),
                       json_extract(payload_json, '$.ift_score'),
                       json_extract(payload_json, '$.statut'),
                       json_extract(payload_json, '$.ticket'),
                       json_extract(payload_json, '$.ticket_final'),
                       json_extract(payload_json, '$.ticket_prevented'),
                       json_extract(payload_json, '$.ticket_status'),
                       json_extract(payload_json, '$.url_source')
                FROM analyses ORDER BY id ASC
                """
            ).fetchall()
        except sqlite3.OperationalError as exc:
            raise RuntimeError("SQLite JSON1 est obligatoire pour charger l’historique sans saturation mémoire") from exc
    for row in rows:
        ticket = _json_loads(row[8], {}) or _json_loads(row[9], {}) or _json_loads(row[10], {}) or {}
        status = row[11] or ("CERTIFIED" if row[9] else ("NON_CERTIFIABLE_PREVENTED" if row[10] else "NOT_AVAILABLE"))
        summaries.append({
            "id": int(row[0]),
            "date_execution": row[1],
            "course": row[2] or "NC",
            "discipline": row[3] or "NC",
            "nb_partants": row[4] or 0,
            "signature": row[5] or "NC",
            "ift_score": row[6] or 0,
            "statut": row[7] or "NC",
            "ticket": ticket,
            "ticket_status": status,
            "url_source": row[12] or "",
        })
    return summaries


def save_analysis(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """Persiste une analyse; SQLite génère l'ID pour toute nouvelle analyse."""
    initialize_storage()
    now = datetime.now(timezone.utc).isoformat()
    requested_id = analysis.get("id")
    with _connect() as connection:
        if requested_id in (None, ""):
            payload_without_id = dict(analysis)
            payload_without_id.pop("id", None)
            payload = _json_dumps(payload_without_id)
            cursor = connection.execute(
                """
                INSERT INTO analyses(date_execution, payload_json, created_at, updated_at)
                VALUES(?, ?, ?, ?)
                """,
                (analysis.get("date_execution", now), payload, now, now),
            )
            analysis["id"] = int(cursor.lastrowid)
            # Le payload durable doit inclure l'identifiant effectivement attribué.
            payload = _json_dumps(analysis)
            connection.execute(
                "UPDATE analyses SET payload_json = ? WHERE id = ?",
                (payload, analysis["id"]),
            )
        else:
            analysis_id = int(requested_id)
            payload = _json_dumps(analysis)
            connection.execute(
                """
                INSERT INTO analyses(id, date_execution, payload_json, created_at, updated_at)
                VALUES(?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    date_execution=excluded.date_execution,
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (analysis_id, analysis.get("date_execution", now), payload, now, now),
            )
    _write_pre_course_artifacts(analysis)
    return analysis


def persisted_export_path(analysis: Dict[str, Any]) -> Path:
    """Retourne le chemin durable de l’export JSON pré-course."""
    path = _analysis_dir(analysis) / "pre_course" / "05_export_pre_course.json"
    if not path.exists():
        _write_json(path, analysis.get("json_export", analysis.get("rapport_complet", {})))
    return path


def persisted_execution_report_path(analysis: Dict[str, Any]) -> Path:
    """Retourne le chemin durable du journal d’exécution séquentiel."""
    path = _analysis_dir(analysis) / "pre_course" / "08_rapport_execution_integral.json"
    if not path.exists():
        _write_json(path, analysis.get("execution_report", {}))
    return path


def build_integral_report(analysis: Dict[str, Any]) -> Dict[str, Any]:
    """Fusionne toutes les preuves dans un seul contrat JSON téléchargeable."""
    export_data = analysis.get("json_export", {}) or {}
    execution_trace = analysis.get("execution_report", {}) or {}
    audit = analysis.get("audit_post_course") or export_data.get("audit_post_course") or execution_trace.get("post_course_audit")
    report = analysis.get("rapport_complet", {}) or {}
    certified = report.get("ticket") or export_data.get("ticket_final") or analysis.get("ticket_final") or {}
    prevented = report.get("ticket_prevented") or export_data.get("ticket_prevented") or analysis.get("ticket_prevented") or {}
    visible = certified or prevented or analysis.get("ticket") or export_data.get("ticket") or {}
    status = "CERTIFIED" if certified else ("NON_CERTIFIABLE_PREVENTED" if prevented else "NOT_AVAILABLE")
    trace = dict(execution_trace) if isinstance(execution_trace, dict) else {}
    trace.setdefault("final", {}).update({
        "ticket": visible,
        "ticket_final": certified,
        "ticket_prevented": prevented,
        "ticket_status": status,
        "ticket_certifie": bool(certified),
    })
    trace["ticket_trace"] = visible
    trace["ticket_status"] = status
    if audit:
        trace["post_course_audit"] = audit
        trace["final"]["post_course_audit_status"] = audit.get("status")
    export_snapshot = dict(export_data) if isinstance(export_data, dict) else {}
    export_snapshot["ticket"] = visible
    export_snapshot["ticket_final"] = certified
    export_snapshot["ticket_prevented"] = prevented
    export_snapshot["ticket_status"] = status
    export_snapshot["execution_report"] = trace
    export_snapshot["audit_post_course"] = audit
    root_causes = (audit or {}).get("root_causes", {}) if isinstance(audit, dict) else {}
    score_diagnostics_v3 = (audit or {}).get('score_diagnostics_v3') if isinstance(audit, dict) else None
    if not isinstance(score_diagnostics_v3, dict):
        score_diagnostics_v3 = build_score_diagnostics_v3(export_snapshot, audit)
    diagnostics = {
        "score_diagnostics_v3": score_diagnostics_v3,
        "official_top5": (audit or {}).get("metrics", {}).get("top5_officiel", []) if isinstance(audit, dict) else [],
        "captured_top5": (audit or {}).get("metrics", {}).get("captured_numbers", []) if isinstance(audit, dict) else [],
        "missed_top5": root_causes.get("missed_top5", []) if isinstance(root_causes, dict) else [],
        "ticket_outside_top5": root_causes.get("ticket_outside_top5", []) if isinstance(root_causes, dict) else [],
        "ranking_diagnostics": (audit or {}).get("ranking_diagnostics", []) if isinstance(audit, dict) else [],
        "score_formula_audit": (audit or {}).get("score_formula_audit", {}) if isinstance(audit, dict) else {},
        "constraints_and_certification": {
            "ticket_status": status,
            "certification": analysis.get("rapport_complet", {}).get("certification", {}),
            "checkpoint_bloc_4": analysis.get("json_export", {}).get("checkpoint_bloc_4", {}),
        },
    }
    return {
        "schema": "VANTAGE_INTEGRAL_REPORT_V2",
        "report_type": "PRE_COURSE_EXECUTION_AND_POST_COURSE_AUDIT",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "analysis_id": analysis.get("id"),
        "course_identity": analysis.get("identifiants", {}),
        "course_summary": {key: analysis.get(key) for key in ("course", "discipline", "nb_partants", "signature", "date_execution", "ift_score", "statut")},
        "ticket": {
            "visible": visible,
            "final_certified": certified,
            "prevented": prevented,
            "status": status,
            "pre_course_locked": True,
        },
        "export": export_snapshot,
        "execution_trace": trace,
        "post_course_audit": audit,
        "diagnostics": diagnostics,
        "score_diagnostics_v3": score_diagnostics_v3,
        "integrity": {
            "trace_ticket_present": bool(trace.get("ticket_trace")),
            "trace_final_ticket_present": bool((trace.get("final") or {}).get("ticket")),
            "post_course_present": bool(audit),
            "retroactive_prediction_change": bool((audit or {}).get("retroactive_prediction_change")) if isinstance(audit, dict) else False,
            "ticket_hash": _stable_hash(visible),
            "pre_course_ticket_hash": _stable_hash(analysis.get("ticket", {})),
        },
    }


def persisted_integral_report_path(analysis: Dict[str, Any]) -> Path:
    """Retourne le chemin de l’unique rapport JSON fusionné au nom canonique."""
    path = _analysis_dir(analysis) / canonical_integral_report_filename(analysis)
    report = build_integral_report(analysis)
    validation = valider_rapport_integral(report)
    if not validation.get('valid'):
        raise ValueError(f"Rapport intégral invalide: {validation.get('errors')}")
    report.setdefault('integrity', {})['schema_validation'] = validation
    _write_json(path, report)
    return path


def update_analysis_audit(analysis_id: int, audit: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    analysis = get_analysis(analysis_id)
    if analysis is None:
        return None
    analysis["audit_post_course"] = audit

    # La trace intégrale est enrichie après le contrôle officiel, sans modifier
    # le ticket gelé ni les données de décision pré-course.
    execution_report = analysis.get('execution_report', {}) or {}
    if isinstance(execution_report, dict):
        phases = execution_report.setdefault('phases', [])
        phases = [phase for phase in phases if phase.get('name') != 'AUDIT_POST_COURSE']
        phases.append({
            'sequence': 8,
            'name': 'AUDIT_POST_COURSE',
            'status': 'PASS' if audit.get('status') == 'AUDIT_COMPLET' else 'BLOCKED',
            'data': audit,
            'errors': [] if audit.get('status') == 'AUDIT_COMPLET' else [audit.get('warning', 'Consensus officiel insuffisant')],
        })
        execution_report['phases'] = phases
        execution_report['post_course_audit'] = audit
        execution_report.setdefault('final', {})['post_course_audit_status'] = audit.get('status')
        analysis['execution_report'] = execution_report

    export_data = analysis.get('json_export', {}) or {}
    if isinstance(export_data, dict):
        export_data['audit_post_course'] = audit
        export_data['post_course_status'] = audit.get('status')
        audit_trace = export_data.setdefault('audit_trace', {})
        if isinstance(audit_trace, dict):
            audit_trace['post_course'] = audit
            audit_trace['post_course_status'] = audit.get('status')
            audit_trace.setdefault('phase_outputs', {})['AUDIT_POST_COURSE'] = audit
        analysis['json_export'] = export_data

    save_analysis(analysis)
    _write_post_course_artifacts(analysis, audit)
    return analysis


def _safe_filename_piece(value: Any, fallback: str = "NC") -> str:
    """Normalise une composante de nom de fichier sans accents ni séparateurs."""
    text = str(value or fallback).strip()
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_").upper()
    return text or fallback


def _analysis_identity_parts(analysis: Dict[str, Any]) -> Dict[str, str]:
    identifiers = analysis.get("identifiants", {}) or {}
    course_label = str(analysis.get("course", "") or "")
    hippo = course_label.split(" - Course ", 1)[0].strip() if " - Course " in course_label else course_label
    date = identifiers.get("date") or analysis.get("date_course") or "DATE_NC"
    try:
        date = datetime.strptime(str(date)[:10], "%Y-%m-%d").strftime("%Y%m%d")
    except ValueError:
        date = _safe_filename_piece(date, "DATE_NC")
    reunion = identifiers.get("reunion") or identifiers.get("R") or "NC"
    numero = identifiers.get("numero_course") or identifiers.get("course") or "NC"
    discipline = analysis.get("discipline") or identifiers.get("discipline") or "NC"
    return {
        "date": _safe_filename_piece(date, "DATE_NC"),
        "course_ref": f"R{_safe_filename_piece(reunion)}C{_safe_filename_piece(numero)}",
        "discipline": _safe_filename_piece(discipline),
        "hippodrome": _safe_filename_piece(hippo, "HIPPODROME_NC"),
    }


def canonical_integral_report_filename(analysis: Dict[str, Any], compressed: bool = False) -> str:
    """Nom canonique : date, R/C, discipline, hippodrome et identifiant analyse."""
    parts = _analysis_identity_parts(analysis)
    analysis_id = _safe_filename_piece(analysis.get("id"), "NC")
    suffix = ".json.gz" if compressed else ".json"
    return (
        f"vantage_rapport_integral_{parts['date']}_{parts['course_ref']}_"
        f"{parts['discipline']}_{parts['hippodrome']}_A{analysis_id}{suffix}"
    )


def _course_slug(analysis: Dict[str, Any]) -> str:
    parts = _analysis_identity_parts(analysis)
    return f"{parts['date']}_{parts['course_ref']}_{parts['discipline']}_{parts['hippodrome']}"


def _analysis_dir(analysis: Dict[str, Any]) -> Path:
    path = artifacts_root() / _course_slug(analysis)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, ensure_ascii=False, indent=2, default=_json_default)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False) as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
            temporary = Path(handle.name)
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink(missing_ok=True)


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(_json_dumps(value).encode("utf-8")).hexdigest()


def _write_pre_course_artifacts(analysis: Dict[str, Any]) -> None:
    course_dir = _analysis_dir(analysis)
    pre_dir = course_dir / "pre_course"
    report = analysis.get("rapport_complet", {})
    export_data = analysis.get("json_export", {})
    collection = analysis.get("rapport_collecte", {})
    ledger = analysis.get("evidence_ledger", {})
    ticket = analysis.get("ticket", {})
    _write_json(pre_dir / "02_rapport_collecte.json", collection)
    _write_json(pre_dir / "03_evidence_ledger.json", ledger)
    _write_json(pre_dir / "04_rapport_pre_course.json", report)
    _write_json(pre_dir / "05_export_pre_course.json", export_data)
    _write_json(pre_dir / "06_ticket_freeze.json", {
        "mode_execution": "AUTO_CONTINUE",
        "course_identity": analysis.get("identifiants", {}),
        "ticket": ticket,
        "ticket_hash": _stable_hash(ticket),
        "input_snapshot_hash": _stable_hash({"identifiants": analysis.get("identifiants", {}), "partants": export_data.get("partants", []), "collecte": collection}),
        "ruleset_hash": _stable_hash({"protocol": "PROTOCOL_VANTAGE", "version": "v1.22.2-test", "ruleset_gel": "22/07/2026"}),
        "post_course_locked_until_explicit_call": True,
    })
    _write_json(pre_dir / "08_rapport_execution_integral.json", analysis.get("execution_report", {}))
    _write_json(course_dir / canonical_integral_report_filename(analysis), build_integral_report(analysis))
    _write_json(pre_dir / "07_pre_course_state.json", {
        "analysis_id": analysis.get("id"),
        "course_dir": str(course_dir),
        "pre_course_dir": str(pre_dir),
        "identifiants": analysis.get("identifiants", {}),
        "ticket": ticket,
        "partants": export_data.get("partants", []),
        "post_course_status": "COMPLETED" if analysis.get("audit_post_course") else "LOCKED",
        "created_at": analysis.get("date_execution"),
    })
    _write_backup_copy(analysis, "pre_course")
    drive_results = _sync_drive_artifacts(analysis, "pre_course", {
        "rapport_collecte.json": collection,
        "evidence_ledger.json": ledger,
        "rapport_pre_course.json": report,
        "export_pre_course.json": export_data,
        "execution_report_integral.json": analysis.get("execution_report", {}),
        "ticket_freeze.json": {"ticket": ticket, "ticket_hash": _stable_hash(ticket)},
    })
    _write_json(pre_dir / "09_drive_backup_manifest.json", {"phase": "pre_course", "uploads": drive_results})


def _write_post_course_artifacts(analysis: Dict[str, Any], audit: Dict[str, Any]) -> None:
    course_dir = _analysis_dir(analysis)
    post_dir = course_dir / "post_course"
    _write_json(post_dir / "02_audit_post_course.json", audit)
    # Copies enrichies pour consultation et sauvegarde Drive; le ticket original
    # reste disponible dans pre_course/06_ticket_freeze.json.
    _write_json(course_dir / "pre_course" / "08_rapport_execution_integral.json", analysis.get('execution_report', {}))
    _write_json(post_dir / "04_export_integral_enrichi_post_course.json", analysis.get('json_export', {}))
    _write_json(post_dir / "05_rapport_execution_integral_enrichi.json", analysis.get('execution_report', {}))
    _write_json(course_dir / canonical_integral_report_filename(analysis), build_integral_report(analysis))
    _write_json(post_dir / "03_post_course_manifest.json", {
        "audited_at": datetime.now(timezone.utc).isoformat(),
        "analysis_id": analysis.get("id"),
        "pre_course_ticket_hash": _stable_hash(analysis.get("ticket", {})),
        "post_course_does_not_modify_pre_course": True,
    })
    _write_backup_copy(analysis, "post_course", audit)
    drive_results = _sync_drive_artifacts(analysis, "post_course", {
        "audit_post_course.json": audit,
        "export_integral_enrichi_post_course.json": analysis.get('json_export', {}),
        "rapport_execution_integral_enrichi.json": analysis.get('execution_report', {}),
    })
    _write_json(post_dir / "06_drive_backup_manifest.json", {"phase": "post_course", "uploads": drive_results})


def _sync_drive_artifacts(analysis: Dict[str, Any], phase: str, artifacts: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Synchronise les artefacts vers les destinations optionnelles.

    Le stockage local reste la source de vérité. Chaque destination indique son
    propre statut et une panne distante ne bloque jamais l’analyse.
    """
    slug = _course_slug(analysis)
    results = []
    for filename, payload in artifacts.items():
        remote_name = f"{slug}_{phase}_{filename}"
        results.append({
            'name': remote_name,
            'drive': upload_json_detailed(remote_name, payload, folder_name=f"{slug}/{phase}"),
            'huggingface': upload_json_gz_detailed(remote_name, payload, folder_name=f"{slug}/{phase}"),
        })
    return results


def _write_backup_copy(analysis: Dict[str, Any], phase: str, audit: Optional[Dict[str, Any]] = None) -> None:
    root = backup_root()
    if root is None:
        return
    target = root / "courses" / _course_slug(analysis) / phase
    target.mkdir(parents=True, exist_ok=True)
    _write_json(target / canonical_integral_report_filename(analysis), build_integral_report(analysis))
    if audit is not None:
        _write_json(target / f"vantage_audit_post_course_{_safe_filename_piece(analysis.get('id'), 'NC')}.json", audit)
