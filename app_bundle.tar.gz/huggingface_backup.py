"""Sauvegarde facultative des rapports vers Hugging Face.

Le stockage local persistant reste la source active de Protocol Vantage. Cet
adaptateur sert uniquement à répliquer des rapports JSON vers un dépôt privé ou
un Storage Bucket Hugging Face configuré par l'utilisateur. Il ne bloque jamais
le calcul si le token, le dépôt ou la bibliothèque optionnelle sont absents.
"""
from __future__ import annotations

import gzip
import io
import json
import logging
import os
from typing import Any, Dict

LOGGER = logging.getLogger(__name__)


def _configured() -> bool:
    return bool(os.environ.get('HF_TOKEN', '').strip() and os.environ.get('HF_BACKUP_REPO_ID', '').strip())


def configured() -> bool:
    return _configured()


def upload_json_gz_detailed(name: str, payload: Any, folder_name: str = 'Protocol_Vantage') -> Dict[str, Any]:
    """Téléverse un rapport gzip vers un dépôt privé ou bucket configuré.

    `HF_BACKUP_REPO_TYPE` vaut `dataset` par défaut et peut être `model`,
    `space` ou `dataset`. Pour un Storage Bucket, utiliser le type/identifiant
    documenté par la version de `huggingface_hub` installée et tester le montage
    avant production. Le statut est toujours explicite.
    """
    if not _configured():
        return {'status': 'SKIPPED_NOT_CONFIGURED', 'name': name, 'remote_path': None}
    try:
        from huggingface_hub import HfApi

        token = os.environ['HF_TOKEN'].strip()
        repo_id = os.environ['HF_BACKUP_REPO_ID'].strip()
        repo_type = os.environ.get('HF_BACKUP_REPO_TYPE', 'dataset').strip() or 'dataset'
        create_repo = os.environ.get('HF_BACKUP_CREATE_REPO', '0') == '1'
        if create_repo:
            HfApi(token=token).create_repo(repo_id=repo_id, repo_type=repo_type, private=True, exist_ok=True)
        remote_path = '/'.join(part.strip('/') for part in (folder_name, name) if part)
        data = json.dumps(payload, ensure_ascii=False, indent=2, default=str).encode('utf-8')
        compressed = gzip.compress(data, mtime=0)
        if not remote_path.endswith('.gz'):
            remote_path += '.json.gz'
        api = HfApi(token=token)
        result = api.upload_file(
            path_or_fileobj=io.BytesIO(compressed),
            path_in_repo=remote_path,
            repo_id=repo_id,
            repo_type=repo_type,
            commit_message=f'Protocol Vantage backup {name}',
        )
        return {'status': 'UPLOADED', 'name': name, 'remote_path': remote_path, 'url': str(result)}
    except Exception as exc:  # pragma: no cover - dépend de l'accès externe
        LOGGER.warning('Sauvegarde Hugging Face non effectuée: %s', exc)
        return {'status': 'FAILED', 'name': name, 'remote_path': None, 'error_type': type(exc).__name__}
