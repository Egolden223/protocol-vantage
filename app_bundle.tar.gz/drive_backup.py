"""Synchronisation facultative des artefacts Vantage vers Google Drive.

L'application fonctionne sans cet adaptateur. Pour activer la sauvegarde Drive,
configurer GOOGLE_SERVICE_ACCOUNT_JSON (chemin vers le fichier JSON ou contenu
JSON) et GOOGLE_DRIVE_FOLDER_ID. Les erreurs Drive sont journalisées et ne
bloquent jamais le calcul Vantage ni l'audit.
"""
from __future__ import annotations

import io
import json
import logging
import os
from typing import Any, Dict, Optional

LOGGER = logging.getLogger(__name__)
SCOPES = ["https://www.googleapis.com/auth/drive.file"]


def _credentials():
    from google.oauth2 import service_account

    configured = os.environ.get("GOOGLE_SERVICE_ACCOUNT_JSON", "").strip()
    if not configured:
        return None
    if configured.startswith("{"):
        info = json.loads(configured)
        return service_account.Credentials.from_service_account_info(info, scopes=SCOPES)
    return service_account.Credentials.from_service_account_file(configured, scopes=SCOPES)


def _service():
    folder_id = os.environ.get("GOOGLE_DRIVE_FOLDER_ID", "").strip()
    if not folder_id:
        return None, None
    credentials = _credentials()
    if credentials is None:
        return None, None
    from googleapiclient.discovery import build
    return build("drive", "v3", credentials=credentials, cache_discovery=False), folder_id


def upload_json_detailed(name: str, payload: Any, folder_name: str = "Protocol_Vantage") -> Dict[str, Any]:
    """Téléverse un JSON et retourne un statut explicite, sans bloquer le calcul."""
    try:
        service, folder_id = _service()
        if service is None or folder_id is None:
            return {"status": "SKIPPED_NOT_CONFIGURED", "name": name, "file_id": None}
        from googleapiclient.http import MediaIoBaseUpload

        body = {
            "name": name,
            "parents": [folder_id],
            "description": f"Protocol Vantage — {folder_name}",
        }
        media = MediaIoBaseUpload(
            io.BytesIO(json.dumps(payload, ensure_ascii=False, indent=2, default=str).encode("utf-8")),
            mimetype="application/json",
            resumable=False,
        )
        result = service.files().create(body=body, media_body=media, fields="id,name").execute()
        return {"status": "UPLOADED", "name": name, "file_id": result.get("id")}
    except Exception as exc:  # pragma: no cover - dépend du réseau et des identifiants
        LOGGER.warning("Sauvegarde Google Drive non effectuée: %s", exc)
        return {"status": "FAILED", "name": name, "file_id": None, "error_type": type(exc).__name__}


def upload_json(name: str, payload: Any, folder_name: str = "Protocol_Vantage") -> Optional[str]:
    """Compatibilité historique : retourne uniquement l'identifiant Drive ou None."""
    return upload_json_detailed(name, payload, folder_name).get("file_id")


def configured() -> bool:
    return bool(os.environ.get("GOOGLE_SERVICE_ACCOUNT_JSON", "").strip() and os.environ.get("GOOGLE_DRIVE_FOLDER_ID", "").strip())
