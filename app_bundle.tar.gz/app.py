"""
PROTOCOL VANTAGE — Application Flask
Interface web + API REST pour l'exécution du protocole hippique.
Version: v1.22.2-test (22/07/2026)
"""
import gzip
import hashlib
import hmac
import json
import logging
import os
import secrets
import shutil
import tempfile
import traceback
import uuid
from pathlib import Path
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file, redirect, make_response
from flask_cors import CORS

from engine.models import Course
from engine.pipeline import executer_pipeline_complet, generer_json_export
from collectors.pmu_collector import (
    collecter_programme_pmu, construire_course_depuis_saisie,
    collecter_participants_course, collecter_cotes_course
)
from collectors.auto_scraper import collecter_automatique
from collectors.race_resolver import collecter_course_par_identifiants, CourseResolutionError
from collectors.post_course_collector import collecter_resultat_officiel
from engine.post_course_audit import auditer_post_course
from production_storage import (
    initialize_storage,
    load_analyses,
    load_analysis_summaries,
    get_analysis,
    save_analysis,
    update_analysis_audit,
    persisted_export_path,
    persisted_execution_report_path,
    persisted_integral_report_path,
    canonical_integral_report_filename,
)

app = Flask(__name__)
LOGGER = logging.getLogger("protocol_vantage")
VANTAGE_ENV = os.environ.get("VANTAGE_ENV", "production").strip().lower()
IS_DEVELOPMENT = VANTAGE_ENV in {"development", "dev", "test"}
SESSION_SECRET = os.environ.get("VANTAGE_SESSION_SECRET", "").strip()
ACCESS_TOKEN = os.environ.get("VANTAGE_ACCESS_TOKEN", "").strip()
CONFIGURATION_ERRORS = []
if not SESSION_SECRET:
    if IS_DEVELOPMENT:
        SESSION_SECRET = secrets.token_hex(32)
    else:
        CONFIGURATION_ERRORS.append("VANTAGE_SESSION_SECRET manquant")
        SESSION_SECRET = secrets.token_hex(32)
if not ACCESS_TOKEN and not IS_DEVELOPMENT:
    CONFIGURATION_ERRORS.append("VANTAGE_ACCESS_TOKEN manquant")
app.secret_key = SESSION_SECRET
app.config.update(
    MAX_CONTENT_LENGTH=int(os.environ.get("VANTAGE_MAX_CONTENT_LENGTH", "262144")),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=not IS_DEVELOPMENT,
    SESSION_COOKIE_SAMESITE="Lax",
)
_ALLOWED_ORIGINS = [item.strip() for item in os.environ.get("VANTAGE_ALLOWED_ORIGINS", "").split(",") if item.strip()]
if _ALLOWED_ORIGINS:
    CORS(app, origins=_ALLOWED_ORIGINS)
BUILD_ID = os.environ.get("VANTAGE_BUILD_ID", "v1.22.2-test-production-20260815-source-audit")


def _code_fingerprint() -> str:
    """Empreinte courte des fichiers qui contrôlent le parcours d’analyse."""
    digest = hashlib.sha256()
    root = Path(__file__).resolve().parent
    for relative in (
        "app.py",
        "collectors/race_resolver.py",
        "collectors/auto_scraper.py",
        "collectors/source_orchestrator.py",
    ):
        path = root / relative
        if path.exists():
            digest.update(path.read_bytes())
    return digest.hexdigest()[:16]


@app.before_request
def _protect_production_routes():
    if request.path == "/health":
        return None
    if CONFIGURATION_ERRORS and not IS_DEVELOPMENT:
        if request.path.startswith("/api/"):
            return jsonify({"succes": False, "erreur": "Service mal configuré", "code": "PRODUCTION_CONFIGURATION_ERROR"}), 503
        return "Service mal configuré", 503
    if request.path == "/login":
        return None
    if IS_DEVELOPMENT and not ACCESS_TOKEN:
        return None
    supplied = request.headers.get("X-Vantage-Token") or request.cookies.get("vantage_access_token", "")
    if supplied and ACCESS_TOKEN and hmac.compare_digest(str(supplied), ACCESS_TOKEN):
        return None
    if request.path.startswith("/api/"):
        return jsonify({"succes": False, "erreur": "Authentification requise"}), 401
    return redirect("/login")


def _safe_server_error(exc, context):
    error_id = uuid.uuid4().hex[:12]
    LOGGER.error("Erreur interne %s dans %s: %s\n%s", error_id, context, exc, traceback.format_exc())
    return {"succes": False, "erreur": "Erreur interne du serveur", "code": "INTERNAL_ERROR", "error_id": error_id}


@app.after_request
def _security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
    return response

# Le cache mémoire accélère les réponses ; la source durable est SQLite.
initialize_storage()
# Ne pas charger les rapports JSON volumineux au démarrage : les détails sont lus
# à la demande depuis SQLite pour rester compatible avec plusieurs workers.
analyses_historique = []



def _persist_analysis(analysis):
    save_analysis(analysis)
    return analysis


def _json_safe(value):
    """Convertit récursivement les objets du moteur en valeurs JSON transportables."""
    def default(obj):
        if hasattr(obj, "value"):
            return obj.value
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        return str(obj)
    return json.loads(json.dumps(value, ensure_ascii=False, default=default))


def _visible_ticket_data(rapport=None, export_data=None, analyse=None):
    """Retourne le ticket visible et distingue certifié, empêché et indisponible."""
    rapport = rapport if isinstance(rapport, dict) else {}
    export_data = export_data if isinstance(export_data, dict) else {}
    analyse = analyse if isinstance(analyse, dict) else {}
    certified = rapport.get("ticket") or export_data.get("ticket_final") or analyse.get("ticket_final") or {}
    prevented = rapport.get("ticket_prevented") or export_data.get("ticket_prevented") or analyse.get("ticket_prevented") or {}
    visible = certified or prevented or export_data.get("ticket") or analyse.get("ticket") or {}
    status = "CERTIFIED" if certified else ("NON_CERTIFIABLE_PREVENTED" if prevented else "NOT_AVAILABLE")
    return visible, status, certified, prevented


def _synchronize_ticket_trace(execution_report, export_data, rapport, audit=None):
    """Synchronise le ticket, son statut et l’audit post-course dans toutes les traces."""
    execution_report = execution_report if isinstance(execution_report, dict) else {}
    export_data = export_data if isinstance(export_data, dict) else {}
    visible, status, certified, prevented = _visible_ticket_data(rapport, export_data)
    execution_report["ticket_trace"] = visible
    execution_report["ticket_status"] = status
    execution_report.setdefault("final", {}).update({
        "ticket": visible,
        "ticket_final": certified,
        "ticket_prevented": prevented,
        "ticket_status": status,
        "ticket_certifie": bool(certified),
    })
    if audit is not None:
        execution_report["post_course_audit"] = audit
        execution_report.setdefault("final", {})["post_course_audit_status"] = audit.get("status")
    trace = export_data.setdefault("audit_trace", {})
    if isinstance(trace, dict):
        trace["ticket_trace"] = visible
        trace["ticket_status"] = status
        trace["ticket_certifie"] = bool(certified)
        trace["ticket_prevented"] = prevented
        trace["final"] = execution_report.get("final", {})
        if audit is not None:
            trace["post_course"] = audit
            trace["post_course_status"] = audit.get("status")
            trace.setdefault("phase_outputs", {})["AUDIT_POST_COURSE"] = audit
    return execution_report, export_data


def _build_execution_report(input_payload, collecte=None, course=None, rapport=None, json_export=None, error=None):
    """Construit un journal JSON séquentiel complet, y compris en cas d'échec."""
    collecte = collecte if isinstance(collecte, dict) else {}
    resolution = collecte.get("resolution", {}) or {}
    rapport_collecte = collecte.get("rapport_collecte", {}) or {}
    evidence = collecte.get("evidence_ledger", {}) or {}
    pipeline = rapport if isinstance(rapport, dict) else {}
    report = {
        "schema": "VANTAGE_EXECUTION_TRACE_V1",
        "generated_at": datetime.now().isoformat(),
        "status": "ERROR" if error else "COMPLETED",
        "mode_execution": (input_payload or {}).get("mode_execution", "AUTO_CONTINUE"),
        "input": input_payload or {},
        "phases": [],
        "final": {},
        "ticket_trace": {},
        "ticket_status": "NOT_AVAILABLE",
    }

    def add(number, name, status, data=None, errors=None):
        report["phases"].append({
            "sequence": number,
            "name": name,
            "status": status,
            "data": data if data is not None else {},
            "errors": errors or [],
        })

    add(1, "INPUT_IDENTIFIANTS", "PASS", {"payload": input_payload or {}})
    if collecte:
        coherence = resolution.get("coherence", {}) or {}
        add(2, "RESOLUTION_IDENTITE_COURSE", "PASS" if coherence.get("statut") == "PASS" else "FAIL", {
            "identifiants": resolution.get("identifiants", {}),
            "urls_candidates": resolution.get("urls_candidates", []),
            "coherence": coherence,
            "tentatives": resolution.get("tentatives", collecte.get("tentatives", [])),
        }, coherence.get("erreurs", []))
        add(3, "COLLECTE_PRIMAIRE_ET_SOURCES", "PASS" if collecte.get("statut") == "OK" else "FAIL", {
            "rapport_collecte": rapport_collecte,
            "sources_consultees": rapport_collecte.get("sources_consultees", []),
            "sources_prioritaires": rapport_collecte.get("sources_prioritaires", []),
            "source_attempts": rapport_collecte.get("source_attempts", []),
        }, rapport_collecte.get("erreurs", []))
        add(4, "REGISTRE_PREUVES", "PASS" if evidence else "NC", evidence)
    else:
        add(2, "RESOLUTION_IDENTITE_COURSE", "NOT_EXECUTED")
        add(3, "COLLECTE_PRIMAIRE_ET_SOURCES", "NOT_EXECUTED")
        add(4, "REGISTRE_PREUVES", "NOT_EXECUTED")

    if course is not None:
        add(5, "CONSTRUCTION_COURSE_ET_PARTANTS", "PASS", {
            "hippodrome": getattr(course, "hippodrome", None),
            "discipline": getattr(getattr(course, "discipline", None), "value", getattr(course, "discipline", None)),
            "distance": getattr(course, "distance", None),
            "terrain": getattr(course, "terrain", None),
            "numero_course": getattr(course, "numero_course", None),
            "nb_partants": len(getattr(course, "partants", []) or []),
            "partants": [getattr(partant, "__dict__", {}) for partant in (getattr(course, "partants", []) or [])],
        })
    else:
        add(5, "CONSTRUCTION_COURSE_ET_PARTANTS", "NOT_EXECUTED")

    if rapport:
        visible_ticket, ticket_status, certified_ticket, prevented_ticket = _visible_ticket_data(pipeline)
        add(6, "PIPELINE_VANTAGE_COMPLET", "PASS", {
            "etapes": pipeline.get("etapes", {}),
            "statut_final": pipeline.get("statut_final"),
            "ift_score": pipeline.get("ift_score"),
            "ticket": visible_ticket,
            "ticket_final": certified_ticket,
            "ticket_prevented": prevented_ticket,
            "ticket_status": ticket_status,
            "rah_verification": pipeline.get("rah_verification", {}),
        })
        report["final"] = {
            "statut": pipeline.get("statut_final"),
            "ticket": visible_ticket,
            "ticket_final": certified_ticket,
            "ticket_prevented": prevented_ticket,
            "ticket_status": ticket_status,
            "ticket_certifie": bool(certified_ticket),
            "ift_score": pipeline.get("ift_score"),
        }
        report["ticket_trace"] = visible_ticket
        report["ticket_status"] = ticket_status
    else:
        add(6, "PIPELINE_VANTAGE_COMPLET", "NOT_EXECUTED")

    if json_export is not None:
        add(7, "EXPORT_JSON_RIGIDE", "PASS", json_export)
    else:
        add(7, "EXPORT_JSON_RIGIDE", "NOT_EXECUTED")

    if error:
        report["error"] = {
            "type": type(error).__name__,
            "message": str(error),
        }
    return _json_safe(report)


def _find_analysis(analysis_id):
    """Cherche d’abord dans le cache puis dans SQLite pour les workers distincts."""
    try:
        analysis_id = int(analysis_id)
    except (TypeError, ValueError):
        return None
    durable = get_analysis(analysis_id)
    if durable is not None:
        return durable
    return next((item for item in analyses_historique if int(item.get("id", -1)) == analysis_id), None)


# =============================================================================
# ROUTES WEB
# =============================================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        data = request.get_json(silent=True) or request.form
        supplied = str(data.get("token", ""))
        if ACCESS_TOKEN and hmac.compare_digest(supplied, ACCESS_TOKEN):
            response = make_response(redirect("/"))
            response.set_cookie("vantage_access_token", supplied, httponly=True, secure=not IS_DEVELOPMENT, samesite="Lax", max_age=86400 * 30)
            return response
        return render_template("login.html", error="Jeton invalide."), 401
    return render_template("login.html", error="")


@app.route("/")
def index():
    """Page d'accueil — Dashboard principal."""
    return render_template("index.html")


@app.route("/nouvelle-analyse")
def nouvelle_analyse():
    """Le parcours de production unique est la page d’identification par course."""
    return redirect("/")


@app.route("/historique")
def historique():
    """Page d'historique des analyses."""
    return render_template("historique.html")


# =============================================================================
# API REST
# =============================================================================


def _executer_analyse_collectee(collecte, mode_execution="AUTO_CONTINUE"):
    """Construit la Course, attache les preuves et exécute tout le pipeline."""
    course = construire_course_depuis_saisie(collecte)
    course.mode_execution = mode_execution
    course.collecte_meta = collecte.get("rapport_collecte", {})
    course.evidence_ledger = collecte.get("evidence_ledger", {})
    gate = course.collecte_meta.get("multisource_gate", {}) if isinstance(course.collecte_meta, dict) else {}
    production_collection = os.environ.get("VANTAGE_PRIORITY_SOURCES_ENABLED", "1") == "1" and not IS_DEVELOPMENT
    if production_collection and gate.get("status") != "PASS":
        raise ValueError("GARDE_MULTISOURCE_BLOQUE: trois sources effectives et 80% de couverture sont obligatoires")

    if not course.partants:
        raise ValueError("Aucun partant exploitable après collecte")
    if not course.discipline:
        raise ValueError("Discipline non résolue : aucune valeur par défaut appliquée")
    if not course.hippodrome or course.hippodrome == "INCONNU":
        raise ValueError("Hippodrome non résolu : aucune valeur par défaut appliquée")

    rapport = executer_pipeline_complet(course)
    json_export = generer_json_export(course, rapport)
    export_data = json.loads(json_export)
    display_ticket = rapport.get("ticket") or rapport.get("ticket_prevented") or {}
    ticket_status = "CERTIFIED" if rapport.get("ticket") else ("NON_CERTIFIABLE_PREVENTED" if rapport.get("ticket_prevented") else "NOT_AVAILABLE")
    export_data["ticket"] = display_ticket
    export_data["ticket_final"] = rapport.get("ticket", {})
    export_data["ticket_prevented"] = rapport.get("ticket_prevented", {})
    export_data["ticket_status"] = ticket_status
    export_data["ticket_explanation"] = (rapport.get("certification", {}) or {}).get("raisons", [])
    export_data["collecte"] = course.collecte_meta
    export_data["evidence_ledger"] = course.evidence_ledger
    export_data["mode_execution"] = course.mode_execution
    execution_stub, export_data = _synchronize_ticket_trace({"final": {}}, export_data, rapport)
    export_data["ticket_trace"] = execution_stub.get("ticket_trace", {})
    export_data["ticket_status"] = execution_stub.get("ticket_status", ticket_status)
    return course, rapport, export_data


@app.route("/api/analyser-course", methods=["POST"])
def api_analyser_course():
    """Analyse automatique depuis date/réunion/course, sans PDF ni URL utilisateur."""
    try:
        data = request.get_json(silent=True) or {}
        mode_execution = data.get("mode_execution", "AUTO_CONTINUE")
        if mode_execution != "AUTO_CONTINUE":
            return jsonify({"succes": False, "erreur": "Le mode unique autorisé est AUTO_CONTINUE"}), 400

        collecte = collecter_course_par_identifiants(data)
        if collecte.get("statut") != "OK":
            execution_report = _build_execution_report(data, collecte=collecte, error=ValueError(collecte.get("erreur_code", "COLLECTE_ECHEC")))
            return jsonify({
                "succes": False,
                "erreur": collecte.get("erreur_code", "COLLECTE_ECHEC"),
                "resolution": collecte.get("resolution", {}),
                "rapport_collecte": collecte.get("rapport_collecte", {}),
                "tentatives": collecte.get("tentatives", []),
                "execution_report": execution_report,
            }), 422
        gate = (collecte.get("rapport_collecte", {}) or {}).get("multisource_gate", {})
        if os.environ.get("VANTAGE_PRIORITY_SOURCES_ENABLED", "1") == "1" and not IS_DEVELOPMENT and gate.get("status") != "PASS":
            error = ValueError("GARDE_MULTISOURCE_BLOQUE")
            execution_report = _build_execution_report(data, collecte=collecte, error=error)
            return jsonify({
                "succes": False,
                "erreur": "GARDE_MULTISOURCE_BLOQUE",
                "rapport_collecte": collecte.get("rapport_collecte", {}),
                "execution_report": execution_report,
            }), 422

        course, rapport, json_export = _executer_analyse_collectee(collecte, mode_execution)
        execution_report = _build_execution_report(data, collecte=collecte, course=course, rapport=rapport, json_export=json_export)
        execution_report, json_export = _synchronize_ticket_trace(execution_report, json_export, rapport)
        json_export["execution_report"] = execution_report
        analyse = {
            "id": None,
            "date_execution": datetime.now().isoformat(),
            "course": f"{course.hippodrome} - Course {course.numero_course}",
            "discipline": course.discipline.value if course.discipline else "NC",
            "nb_partants": course.nb_partants,
            "signature": course.signature_msp.value if course.signature_msp else "NC",
            "ticket": rapport.get("ticket") or rapport.get("ticket_prevented") or {},
            "ticket_status": "CERTIFIED" if rapport.get("ticket") else ("NON_CERTIFIABLE_PREVENTED" if rapport.get("ticket_prevented") else "NOT_AVAILABLE"),
            "ift_score": rapport.get("ift_score", 0),
            "statut": rapport.get("statut_final", "NC"),
            "rapport_complet": rapport,
            "json_export": json_export,
            "identifiants": collecte.get("resolution", {}).get("identifiants", {}),
            "rapport_collecte": collecte.get("rapport_collecte", {}),
            "evidence_ledger": collecte.get("evidence_ledger", {}),
            "execution_report": execution_report,
            "ticket_prevented": rapport.get("ticket_prevented", {}),
            "ticket_final": rapport.get("ticket", {}),
            "ticket_trace": execution_report.get("ticket_trace", {}),
        }
        analyse = _persist_analysis(analyse)
        analyses_historique.append(analyse)
        return jsonify({
            "succes": True,
            "analyse_id": analyse["id"],
            "rapport": rapport,
            "json_export": json_export,
            "ticket": analyse.get("ticket", {}),
            "ticket_status": analyse.get("ticket_status", "NOT_AVAILABLE"),
            "identifiants": analyse["identifiants"],
            "rapport_collecte": analyse["rapport_collecte"],
            "evidence_ledger": analyse["evidence_ledger"],
            "execution_report": execution_report,
            "ticket_final": analyse.get("ticket_final", {}),
            "ticket_prevented": analyse.get("ticket_prevented", {}),
            "rapport_integral_url": f"/api/report-integral/{analyse['id']}",
        })
    except CourseResolutionError as exc:
        return jsonify({"succes": False, "erreur": str(exc), "type": "COURSE_IDENTIFIER_INVALID", "execution_report": _build_execution_report(locals().get("data", {}), error=exc)}), 400
    except Exception as exc:
        return jsonify({**_safe_server_error(exc, "api_analyser_course"), "execution_report": _build_execution_report(locals().get("data", {}), collecte=locals().get("collecte"), error=exc)}), 500


@app.route("/health", methods=["GET"])
def health():
    """Sonde légère utilisée par l’hébergeur et les contrôles de disponibilité."""
    return jsonify({
        "status": "ok" if not CONFIGURATION_ERRORS else "misconfigured",
        "service": "protocol-vantage",
        "version": "v1.22.2-test",
        "build_id": BUILD_ID,
        "code_fingerprint": _code_fingerprint(),
        "identity_route": "/api/analyser-course",
        "source_orchestration": "11_priority_sources",
        "configuration_errors": CONFIGURATION_ERRORS if IS_DEVELOPMENT else (["PRODUCTION_CONFIGURATION_ERROR"] if CONFIGURATION_ERRORS else []),
    }), (503 if CONFIGURATION_ERRORS and not IS_DEVELOPMENT else 200)


@app.route("/api/programme", methods=["GET"])
def api_programme():
    """Récupère le programme PMU du jour."""
    date_param = request.args.get("date", None)
    result = collecter_programme_pmu(date_param)
    return jsonify(result)


@app.route("/api/participants/<date_course>/<int:reunion>/<int:course_num>", methods=["GET"])
def api_participants(date_course, reunion, course_num):
    """Récupère les participants d'une course."""
    result = collecter_participants_course(date_course, reunion, course_num)
    return jsonify(result)


@app.route("/api/analyser-url", methods=["POST"])
def api_analyser_url():
    """Endpoint historique désactivé pour fermer la surface SSRF."""
    return jsonify({
        "succes": False,
        "erreur": "Ce parcours est désactivé. Utilisez date, réunion et numéro de course.",
        "code": "URL_ANALYSIS_DISABLED"
    }), 410


@app.route("/api/analyser", methods=["POST"])
def api_analyser():
    """Endpoint historique désactivé car il contournait la collecte multisource."""
    return jsonify({
        "succes": False,
        "erreur": "Ce parcours est désactivé. Utilisez date, réunion et numéro de course.",
        "code": "MANUAL_ANALYSIS_DISABLED"
    }), 410


def _audit_post_course_ui_payload(audit):
    """Retourne une vue compacte pour le navigateur; le détail complet reste persisté."""
    audit = audit if isinstance(audit, dict) else {}
    official = audit.get('official_result') if isinstance(audit.get('official_result'), dict) else {}
    consensus = official.get('consensus') if isinstance(official.get('consensus'), dict) else {}
    raw_metrics = audit.get('metrics') if isinstance(audit.get('metrics'), dict) else {}
    metric_keys = ('capture_top5_free_order_percent', 'captured_count', 'top5_officiel', 'captured_numbers', 'missed_top5_numbers', 'ticket_numbers_outside_top5')
    metrics = {key: raw_metrics.get(key) for key in metric_keys}
    ui = {
        'status': audit.get('status'),
        'confidence': audit.get('confidence'),
        'consensus_strength': audit.get('consensus_strength'),
        'conflict_present': bool(audit.get('conflict_present')),
        'metrics': metrics,
        'official_result': {
            'source_status': official.get('source_status'),
            'consensus': {
                'support_count': consensus.get('support_count'),
                'supporting_sources': consensus.get('supporting_sources', []),
                'consensus_level': consensus.get('consensus_level'),
            },
        },
        'sources_consultees': [
            {'source': source.get('source'), 'statut': source.get('statut')}
            for source in (audit.get('sources_consultees') or [])
            if isinstance(source, dict)
        ],
    }
    compact_root_causes = {}
    for group in ('missed_top5', 'ticket_outside_top5'):
        compact_items = []
        for item in ((audit.get('root_causes') or {}).get(group) or []):
            if not isinstance(item, dict):
                continue
            causes = []
            for cause in item.get('causes') or []:
                if isinstance(cause, str):
                    causes.append(cause)
                elif isinstance(cause, dict):
                    causes.append({'code': cause.get('code'), 'description': cause.get('description')})
            compact_items.append({
                'numero': item.get('numero'),
                'nom': item.get('nom'),
                'official_rank': item.get('official_rank'),
                'causes': causes,
            })
        compact_root_causes[group] = compact_items
    ui['root_causes'] = compact_root_causes
    v3 = audit.get('score_diagnostics_v3') if isinstance(audit.get('score_diagnostics_v3'), dict) else {}
    v3_rows = v3.get('by_horse') if isinstance(v3.get('by_horse'), dict) else {}
    relevant_numbers = set()
    for item in compact_root_causes.get('missed_top5', []) + compact_root_causes.get('ticket_outside_top5', []):
        if item.get('numero') is not None:
            relevant_numbers.add(str(item['numero']))
    ui['score_diagnostics_v3'] = {
        'schema': v3.get('schema'),
        'status': v3.get('status'),
        'ticket_cutoff_ordre_score': v3.get('ticket_cutoff_ordre_score'),
        'rank8_ordre_score': v3.get('rank8_ordre_score'),
        'official_top5': v3.get('official_top5', []),
        'aggregate_calibration': v3.get('aggregate_calibration', {}),
        'relevant_horses': {
            number: {
                'numero': row.get('numero'),
                'nom': row.get('nom'),
                'root_cause_class': row.get('root_cause_class'),
                'rank_pre_course': row.get('rank_pre_course'),
                'distance_to_ticket_cutoff': row.get('distance_to_ticket_cutoff'),
                'distance_to_rank8': row.get('distance_to_rank8'),
                'negative_modules': row.get('negative_modules', []),
                'positive_modules': row.get('positive_modules', []),
            }
            for number, row in v3_rows.items() if number in relevant_numbers and isinstance(row, dict)
        },
    }
    return ui


@app.route('/api/audit-post-course', methods=['POST'])
def api_audit_post_course():
    """Recherche l’arrivée officielle et évalue le ticket pré-course sans le modifier."""
    try:
        data = request.get_json(silent=True) or {}
        analyse_id = data.get('analyse_id')
        analyse = _find_analysis(analyse_id) if analyse_id is not None else None
        if analyse is None:
            return jsonify({'succes': False, 'erreur': 'Analyse pré-course introuvable'}), 404
        ids = analyse.get('identifiants', {}) or {}
        date = data.get('date', ids.get('date'))
        reunion = int(data.get('reunion', ids.get('reunion')))
        numero_course = int(data.get('numero_course', ids.get('numero_course', ids.get('course'))))
        officiel = collecter_resultat_officiel(
            date, reunion, numero_course,
            discipline=analyse.get('discipline', ''),
            hippodrome=str(analyse.get('course', '')).split(' - Course ')[0],
        )
        persisted_export = analyse.get('json_export') or {}
        pre_course = {
            'course': {'date': date, 'reunion': reunion, 'numero_course': numero_course, 'analyse_id': analyse_id},
            'ticket': analyse.get('ticket') or persisted_export.get('ticket') or persisted_export.get('ticket_prevented') or (analyse.get('rapport_complet') or {}).get('ticket_prevented', {}),
            'partants': persisted_export.get('partants', []),
        }
        audit = auditer_post_course(pre_course, officiel, officiel.get('sources_consultees', []))
        analyse['ticket'] = pre_course['ticket']
        analyse['ticket_status'] = 'CERTIFIED' if (analyse.get('rapport_complet', {}) or {}).get('ticket') else ('NON_CERTIFIABLE_PREVENTED' if pre_course['ticket'] else 'NOT_AVAILABLE')
        analyse['audit_post_course'] = audit
        analyse['execution_report'], analyse['json_export'] = _synchronize_ticket_trace(
            analyse.get('execution_report', {}), analyse.get('json_export', {}), analyse.get('rapport_complet', {}), audit
        )
        updated = update_analysis_audit(int(analyse_id), audit)
        if updated is not None:
            analyse = updated
        # La réponse navigateur reste compacte : les objets volumineux sont
        # persistés et récupérables via le rapport intégral fusionné.
        audit_ui = _audit_post_course_ui_payload(audit)
        return jsonify({
            'succes': True,
            'analyse_id': analyse_id,
            'audit_post_course': audit_ui,
            'rapport_integral_url': f'/api/report-integral/{analyse_id}',
            'post_course_artifacts': {
                'consensus_status': (audit.get('official_result', {}) or {}).get('source_status'),
                'audit_status': audit.get('status'),
                'missed_top5_count': len((audit.get('root_causes', {}) or {}).get('missed_top5') or []),
                'ticket_outside_top5_count': len((audit.get('root_causes', {}) or {}).get('ticket_outside_top5') or []),
            },
        })
    except (TypeError, ValueError) as exc:
        return jsonify({'succes': False, 'erreur': str(exc), 'type': 'AUDIT_IDENTIFIER_INVALID'}), 400
    except Exception as exc:
        return jsonify(_safe_server_error(exc, "api_audit_post_course")), 500


@app.route("/api/historique", methods=["GET"])
def api_historique():
    """Retourne l'historique des analyses."""
    historique_leger = []
    historique_source = load_analysis_summaries() or analyses_historique
    for a in historique_source:
        historique_leger.append({
            "id": a["id"],
            "date_execution": a["date_execution"],
            "course": a["course"],
            "discipline": a["discipline"],
            "nb_partants": a["nb_partants"],
            "signature": a["signature"],
            "ift_score": a["ift_score"],
            "statut": a["statut"],
            "ticket": a["ticket"],
            "url_source": a.get("url_source", "")
        })
    return jsonify(historique_leger)


@app.route("/api/analyse/<int:analyse_id>", methods=["GET"])
def api_analyse_detail(analyse_id):
    """Retourne le détail complet d'une analyse."""
    analyse = _find_analysis(analyse_id)
    if not analyse:
        return jsonify({"erreur": "Analyse non trouvée"}), 404
    report = analyse.get("rapport_complet", {}) or {}
    visible_ticket = analyse.get("ticket") or report.get("ticket") or report.get("ticket_prevented") or {}
    visible_status = analyse.get("ticket_status") or ("CERTIFIED" if report.get("ticket") else ("NON_CERTIFIABLE_PREVENTED" if report.get("ticket_prevented") else "NOT_AVAILABLE"))
    response_data = dict(analyse)
    response_data["ticket"] = visible_ticket
    response_data["ticket_status"] = visible_status
    response_data["ticket_final"] = report.get("ticket", {})
    response_data["ticket_prevented"] = report.get("ticket_prevented", {})
    response_data["rapport_integral_url"] = f"/api/report-integral/{analyse_id}"
    return jsonify(response_data)


def _compressed_integral_path(filepath):
    """Crée un JSON gzip à côté du rapport, sans laisser de fichier partiel."""
    filepath = Path(filepath)
    compressed = filepath.with_name(filepath.name + '.gz')
    if compressed.exists() and compressed.stat().st_mtime_ns >= filepath.stat().st_mtime_ns:
        return compressed
    compressed.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f'.{filepath.name}.', suffix='.tmp', dir=str(compressed.parent))
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        with filepath.open('rb') as source, gzip.open(temporary, 'wb', compresslevel=9) as target:
            shutil.copyfileobj(source, target, length=1024 * 1024)
        os.replace(temporary, compressed)
        return compressed
    finally:
        temporary.unlink(missing_ok=True)


@app.route("/api/report-integral/<int:analyse_id>.gz", methods=["GET"])
def api_report_integral_gzip(analyse_id):
    """Télécharge le rapport intégral complet sous forme JSON gzip."""
    analyse = _find_analysis(analyse_id)
    if not analyse:
        return jsonify({"erreur": "Analyse non trouvée"}), 404
    filepath = persisted_integral_report_path(analyse)
    compressed = _compressed_integral_path(filepath)
    return send_file(compressed, as_attachment=True, download_name=canonical_integral_report_filename(analyse, compressed=True), mimetype="application/gzip")


@app.route("/api/report-integral/<int:analyse_id>", methods=["GET"])
def api_report_integral(analyse_id):
    """Télécharge l’unique rapport JSON intégral fusionné."""
    analyse = _find_analysis(analyse_id)
    if not analyse:
        return jsonify({"erreur": "Analyse non trouvée"}), 404
    filepath = persisted_integral_report_path(analyse)
    return send_file(filepath, as_attachment=True, download_name=canonical_integral_report_filename(analyse), mimetype="application/json")


@app.route("/api/execution-report/<int:analyse_id>", methods=["GET"])
def api_execution_report(analyse_id):
    """Compatibilité historique : sert le même rapport intégral fusionné."""
    return api_report_integral(analyse_id)


@app.route("/api/export/<int:analyse_id>", methods=["GET"])
def api_export(analyse_id):
    """Compatibilité historique : sert le même rapport intégral fusionné."""
    return api_report_integral(analyse_id)


@app.route("/api/sources", methods=["GET"])
def api_sources():
    """Retourne la liste des sources de données configurées."""
    from collectors.pmu_collector import SOURCES_HIERARCHIE
    return jsonify(SOURCES_HIERARCHIE)


@app.route("/api/hippodromes", methods=["GET"])
def api_hippodromes():
    """Retourne la liste des 22 hippodromes GRU."""
    from engine.pipeline import HIPPODROMES_GRU
    return jsonify(HIPPODROMES_GRU)


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get('VANTAGE_DEBUG', '0') == '1'
    app.run(host="0.0.0.0", port=port, debug=debug, use_reloader=debug)
