"""Accès HTTP prudent aux sources publiques du protocole.

Le module ne contourne aucun anti-robot et ne transforme jamais une page
accessible en preuve de donnée. Il retire seulement le bruit HTML connu
(publicités, popups et scripts) avant l'extraction structurée.
"""
from __future__ import annotations

import re
import shutil
import subprocess
from typing import Any, Dict, Tuple

import requests
from bs4 import BeautifulSoup

from collectors.auto_scraper import get_headers

BLOCK_MARKERS = (
    "captcha",
    "access denied",
    "access_denied",
    "cloudflare ray id",
    "just a moment",
    "checking your browser",
    "enable javascript",
    "verify you are human",
    "robot check",
    "accès refusé",
    "acces refuse",
)

AD_SELECTOR_RE = re.compile(
    r"(advert|ad[-_]?slot|adsbygoogle|publicite|publicité|popup|pop[-_]?up|modal|cookie|consent|cmp|interstitial|overlay)",
    re.IGNORECASE,
)


def nettoyer_html_public(html: str) -> Tuple[str, Dict[str, Any]]:
    """Retire les éléments publicitaires connus sans supprimer le contenu métier."""
    soup = BeautifulSoup(html or "", "html.parser")
    removed = 0
    data_script_markers = ('"participants"', 'dateReunion', 'rdaRawData')
    for tag in soup.find_all(["script", "noscript", "iframe"]):
        if tag.name == 'script' and any(marker in (tag.string or tag.get_text() or '') for marker in data_script_markers):
            continue
        tag.decompose()
        removed += 1
    for tag in list(soup.find_all(True)):
        tag_attrs = getattr(tag, "attrs", None) or {}
        attrs = " ".join(
            [str(tag_attrs.get("id", "")), " ".join(str(x) for x in (tag_attrs.get("class") or []))]
        )
        if attrs and AD_SELECTOR_RE.search(attrs):
            tag.decompose()
            removed += 1
    return str(soup), {
        "ad_elements_removed": removed,
        "popup_handling": "HTML_CLEANUP_PRESERVING_STRUCTURED_DATA_SCRIPTS",
        "note": "Les fenêtres natives ne sont pas exécutées côté serveur; les pages nécessitant une interaction restent UNPROVEN.",
    }


def detecter_blocage(html: str, status_code: int, content_type: str) -> str | None:
    """Retourne la cause d'un blocage probable sans tenter de le contourner."""
    if status_code in {401, 403, 406, 409, 429, 451, 503}:
        return f"HTTP_{status_code}"
    soup = BeautifulSoup(html or "", "html.parser")
    text = soup.get_text(" ", strip=True).lower()
    title = (soup.title.get_text(" ", strip=True).lower() if soup.title else '')
    if re.search(r'acc.{0,8}s\\s+refus', title) or ('noindex' in str(soup).lower() and 'refus' in title):
        return 'PAGE_ACCESS_DENIED'
    for marker in BLOCK_MARKERS:
        if marker in text:
            return f"PAGE_BLOCK_MARKER:{marker}"
    if status_code == 200 and "html" not in (content_type or "").lower():
        return "NON_HTML_RESPONSE"
    return None


def _fetch_with_curl(url: str, headers: Dict[str, str], timeout: int) -> Dict[str, Any] | None:
    """Repli HTTP standard et borné pour les pages publiques mal servies par requests."""
    curl = shutil.which('curl')
    if not curl or not str(url).lower().startswith(('http://', 'https://')):
        return None
    command = [curl, '-L', '--compressed', '--max-time', str(max(5, int(timeout))), '-sS']
    user_agent = headers.get('User-Agent') if isinstance(headers, dict) else None
    if user_agent:
        command.extend(['-A', str(user_agent)])
    for key in ('Accept', 'Accept-Language'):
        if isinstance(headers, dict) and headers.get(key):
            command.extend(['-H', f'{key}: {headers[key]}'])
    command.extend(['--', str(url)])
    try:
        completed = subprocess.run(command, capture_output=True, text=True, timeout=max(8, int(timeout) + 5), check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    if completed.returncode != 0 or not completed.stdout:
        return None
    return {'html': completed.stdout, 'transport': 'curl', 'stderr': completed.stderr[-500:] if completed.stderr else ''}


def fetcher_source(candidate: Dict[str, Any], timeout: int = 20) -> Dict[str, Any]:
    """Télécharge une source et retourne le HTML nettoyé avec sa provenance.

    Le registre peut fournir ``http_timeout_seconds`` pour les pages lourdes;
    ce délai n’est jamais utilisé pour contourner un blocage HTTP.
    """
    try:
        timeout = int(candidate.get('http_timeout_seconds', timeout) or timeout)
    except (TypeError, ValueError):
        timeout = timeout
    result: Dict[str, Any] = {
        "http_status": None,
        "content_bytes": 0,
        "url_finale": candidate.get("url"),
        "redirects": [],
        "statut": "ERREUR",
        "data_status": "UNPROVEN",
        "warnings": [],
        "fetch_meta": {},
    }
    try:
        response = requests.get(
            candidate["url"],
            headers=candidate.get('http_headers') or get_headers(),
            timeout=timeout,
            allow_redirects=True,
        )
        content_type = response.headers.get("content-type", "")
        result.update({
            "http_status": response.status_code,
            "content_bytes": len(response.content),
            "url_finale": response.url,
            "redirects": [item.url for item in response.history],
            "statut": "OK" if response.ok else "ERREUR",
        })
        blocked = detecter_blocage(response.text, response.status_code, content_type)
        raw_html = response.text
        transport = 'requests'
        if blocked:
            fallback = _fetch_with_curl(candidate.get('url', ''), candidate.get('http_headers') or get_headers(), timeout)
            if fallback and not detecter_blocage(fallback.get('html', ''), 200, content_type):
                raw_html = fallback['html']
                transport = fallback.get('transport', 'curl')
                blocked = None
                result['warnings'].append('REQUESTS_SOFT_BLOCK_CURL_FALLBACK')
            else:
                result["statut"] = "BLOCKED"
                result["block_reason"] = blocked
                result["warnings"].append("SOURCE_BLOCKED_OR_INTERACTIVE")
                return result
        if not response.ok and transport == 'requests':
            return result
        cleaned, cleanup = nettoyer_html_public(raw_html)
        result["html"] = cleaned
        result["fetch_meta"] = {"content_type": content_type, 'transport': transport, **cleanup}
        return result
    except requests.RequestException as exc:
        result["message"] = str(exc)
        result["warnings"].append("SOURCE_REQUEST_FAILED")
        return result
