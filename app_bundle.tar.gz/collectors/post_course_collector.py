"""Collecte post-course multi-source et validation stricte de l'arrivée officielle."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup

from collectors.auto_scraper import get_headers
from collectors.priority_adapters import resoudre_candidat


POST_COURSE_SOURCES = ('PMU_OFFICIEL', 'EQUIDIA_RESULTATS', 'ZONE_TURF_RESULTATS', 'CANALTURF_RESULTATS')
MIN_CONSENSUS_SOURCES = 2


def _date_pmu(date: str) -> str:
    return datetime.strptime(date, '%Y-%m-%d').strftime('%d%m%Y')


def _date_words(date: str) -> Tuple[str, str]:
    value = datetime.strptime(date, '%Y-%m-%d')
    weekdays = ('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche')
    months = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre')
    return weekdays[value.weekday()], f'{value.day} {months[value.month - 1]} {value.year}'


def _numbers(values: Any) -> List[int]:
    if not isinstance(values, (list, tuple)):
        return []
    result: List[int] = []
    for item in values:
        if isinstance(item, dict):
            item = item.get('numPmu', item.get('numero', item.get('number', item.get('placeNumber'))))
        try:
            number = int(item)
        except (TypeError, ValueError):
            continue
        if 1 <= number <= 20 and number not in result:
            result.append(number)
    return result


def _extract_json_order(data: Any) -> List[int]:
    if isinstance(data, dict):
        for key in ('arrivee', 'arriveeDefinitive', 'ordreArrivee', 'ordre_arrivee', 'ordre', 'resultats'):
            order = _numbers(data.get(key))
            if len(order) >= 5:
                return order
        for key in ('course', 'result', 'data', 'arrival', 'arrivee'):
            if key in data:
                order = _extract_json_order(data[key])
                if len(order) >= 5:
                    return order
        rows = data.get('participants') or data.get('partants')
        if isinstance(rows, list):
            sorted_rows = sorted(
                (r for r in rows if isinstance(r, dict)),
                key=lambda r: r.get('place', r.get('rang', r.get('ordreArrivee', 999))),
            )
            order = _numbers(sorted_rows)
            if len(order) >= 5:
                return order
    return []


def _identity_proof(text: str, date: str, reunion: int, course: int, hippodrome: str, url: str) -> Dict[str, Any]:
    normalized = ' '.join((text or '').replace('\xa0', ' ').split()).lower()
    date_compact = date.replace('-', '')
    weekday, date_words = _date_words(date)
    date_markers = [date.lower(), date_compact.lower(), date_words.lower(), date_words.replace('é', 'e').replace('û', 'u').lower()]
    date_ok = any(marker in normalized for marker in date_markers) or date_compact in url.replace('-', '')
    reunion_ok = (
        bool(re.search(rf'\bR\s*0*{reunion}\b', normalized, re.IGNORECASE))
        or bool(re.search(rf'\br{reunion}\b', url, re.IGNORECASE))
        or bool(re.search(rf'\br[ée]union\s*0*{reunion}\b', normalized, re.IGNORECASE))
    )
    course_ok = (
        bool(re.search(rf'\bC\s*0*{course}\b', normalized, re.IGNORECASE))
        or bool(re.search(rf'\bc{course}\b', url, re.IGNORECASE))
        or bool(re.search(rf'\bcourse\s*(?:n[°º]?\s*)?0*{course}\b', normalized, re.IGNORECASE))
    )
    hippo_ok = not hippodrome or hippodrome.lower() in normalized or hippodrome.lower() in url.lower()
    return {
        'date': date_ok, 'reunion': reunion_ok, 'course': course_ok, 'hippodrome': hippo_ok,
        'complete': bool(date_ok and reunion_ok and course_ok and hippo_ok),
        'markers': {'date': date, 'reunion': f'R{reunion}', 'course': f'C{course}', 'hippodrome': hippodrome},
    }


def _extract_explicit_order(text: str, date: str = '') -> List[int]:
    compact = ' '.join((text or '').replace('\xa0', ' ').split())
    patterns = []
    if date:
        value = datetime.strptime(date, '%Y-%m-%d')
        for marker in (value.strftime('%d/%m/%y'), value.strftime('%d/%m/%Y')):
            patterns.append(r'(?:arriv[ée]e?|ordre)[^\d]{0,120}' + re.escape(marker) + r'[^:]{0,120}:\s*((?:\d{1,2}\s*[-–]\s*){4,}\d{1,2})')
    patterns.extend((
        r'(?:arriv[ée]e?|ordre)\s+(?:officielle?|d[ée]finitive?)?\s*[:\-]\s*((?:\d{1,2}\s*[-–]\s*){4,}\d{1,2})',
        r'(?:arriv[ée]e?|ordre)\s+(?:officielle?|d[ée]finitive?)?\s+((?:\d{1,2}\s*[-–]\s*){4,}\d{1,2})',
        r'(?:arriv[ée]e?|ordre)[^\d]{0,120}:\s*((?:\d{1,2}\s*[-–]\s*){4,}\d{1,2})',
    ))
    for pattern in patterns:
        match = re.search(pattern, compact, re.IGNORECASE)
        if match:
            order = _numbers(re.findall(r'\d{1,2}', match.group(1)))
            if len(order) >= 5:
                return order
    return []


def _extract_table_order(soup: BeautifulSoup) -> List[int]:
    ranked: Dict[int, int] = {}
    for row in soup.find_all('tr'):
        cells = [' '.join(cell.get_text(' ', strip=True).split()) for cell in row.find_all(['th', 'td'])]
        if len(cells) < 2:
            continue
        rank_match = re.match(r'^\s*(\d{1,2})\s*(?:er|e|ème|eme|re|ère|)\s*$', cells[0], re.IGNORECASE)
        if not rank_match:
            rank_match = re.match(r'^\s*(\d{1,2})\s*[.)-]\s*$', cells[0])
        if not rank_match:
            continue
        rank = int(rank_match.group(1))
        if not 1 <= rank <= 5:
            continue
        number = None
        for cell in cells[1:]:
            # Le numéro est généralement le premier nombre de la cellule cheval.
            match = re.match(r'^\s*(\d{1,2})(?:\s|$)', cell)
            if match and 1 <= int(match.group(1)) <= 20:
                number = int(match.group(1))
                break
        if number is not None and number not in ranked.values():
            ranked[rank] = number
    if all(rank in ranked for rank in range(1, 6)):
        return [ranked[rank] for rank in range(1, 6)]
    return []


def _extract_html_order(text: str, source: str = '', date: str = '') -> List[int]:
    soup = BeautifulSoup(text or '', 'html.parser')
    explicit = _extract_explicit_order(soup.get_text(' ', strip=True), date=date)
    if len(explicit) >= 5:
        return explicit
    # La table des partants n’est pas une arrivée. Zone-Turf est explicitement
    # exclu de ce repli car sa page contient cette table avant la ligne officielle.
    if source != 'ZONE_TURF_RESULTATS':
        table = _extract_table_order(soup)
        if len(table) >= 5:
            return table
    plain = ' '.join(soup.get_text(' ', strip=True).split())
    # Repli strict pour les pages Equidia/CanalTurf dont le tableau est rendu
    # sous forme de texte avec « 1er | 10 », jamais sur une page d'index.
    if source in {'EQUIDIA_RESULTATS', 'CANALTURF_RESULTATS', 'PMU_OFFICIEL'}:
        match = re.search(
            r'\b1\s*(?:er|e)\s*[|:]\s*(\d{1,2}).{0,900}?\b2\s*(?:e|ème)\s*[|:]\s*(\d{1,2}).{0,900}?\b3\s*(?:e|ème)\s*[|:]\s*(\d{1,2}).{0,900}?\b4\s*(?:e|ème)\s*[|:]\s*(\d{1,2}).{0,900}?\b5\s*(?:e|ème)\s*[|:]\s*(\d{1,2})',
            plain, re.IGNORECASE,
        )
        if match:
            order = _numbers([int(value) for value in match.groups()])
            if len(order) == 5:
                return order
    return []


def _fetch(url: str, source: str, date: str, reunion: int, course: int, hippodrome: str) -> Dict[str, Any]:
    attempt: Dict[str, Any] = {'source': source, 'url': url}
    try:
        response = requests.get(url, headers=get_headers(), timeout=35)
        attempt.update({'http_status': response.status_code, 'statut': 'HTTP_OK' if response.ok else 'HTTP_ERROR'})
        if not response.ok:
            return {'attempt': attempt, 'order': [], 'identity': {'complete': False}}
        text = response.text
        identity = _identity_proof(text, date, reunion, course, hippodrome, url)
        order = _extract_html_order(text, source, date=date)
        attempt['identity'] = identity
        attempt['order_observee'] = order
        if not identity['complete']:
            attempt['statut'] = 'IDENTITY_UNPROVEN'
            return {'attempt': attempt, 'order': [], 'identity': identity}
        if len(order) < 5:
            attempt['statut'] = 'ARRIVAL_UNPARSED'
            return {'attempt': attempt, 'order': [], 'identity': identity}
        attempt['statut'] = 'ARRIVAL_OBSERVED'
        return {'attempt': attempt, 'order': order, 'identity': identity}
    except requests.RequestException as exc:
        attempt.update({'statut': 'NETWORK_ERROR', 'message': str(exc)})
        return {'attempt': attempt, 'order': [], 'identity': {'complete': False}}


def _source_urls(date: str, reunion: int, course: int, hippodrome: str) -> List[Tuple[str, str]]:
    date_pmu = _date_pmu(date)
    identity = {'date': date, 'reunion': reunion, 'numero_course': course, 'discipline': 'TROT_ATTELE', 'hippodrome': hippodrome}
    urls: List[Tuple[str, str]] = [
        ('PMU_OFFICIEL', f'https://www.pmu.fr/turf/{date_pmu.lower()}/r{reunion}/c{course}/'),
        ('EQUIDIA_RESULTATS', f'https://www.equidia.fr/courses/{date}/R{reunion}/C{course}'),
    ]
    for source, label in (('ZONE_TURF', 'ZONE_TURF_RESULTATS'), ('CANALTURF', 'CANALTURF_RESULTATS')):
        try:
            resolved = resoudre_candidat({'source': source, 'identity': identity})
            if resolved.get('url') and resolved.get('status') == 'RESOLVED':
                resolved_url = resolved['url']
                if source == 'CANALTURF':
                    resolved_url = resolved_url.replace('/pronostics-PMU/', '/resultats-PMU/')
                urls.append((label, resolved_url))
        except Exception:
            pass
    return urls


def _consensus(valid_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    groups: Dict[Tuple[int, ...], List[Dict[str, Any]]] = {}
    for result in valid_results:
        key = tuple(result['order'][:5])
        groups.setdefault(key, []).append(result)
    ranked = sorted(groups.items(), key=lambda item: len(item[1]), reverse=True)
    if not ranked:
        return {'status': 'UNRESOLVED_CONSENSUS', 'reason': 'Aucune arrivée avec identité complète et cinq positions', 'consensus_order': [], 'supporting_sources': [], 'groups': {}}
    order, supporters = ranked[0]
    groups_json = {'-'.join(map(str, key)): [item['source'] for item in rows] for key, rows in groups.items()}
    support_count = len({str(item.get('source', '')).upper() for item in supporters if item.get('source')})
    if support_count < MIN_CONSENSUS_SOURCES:
        return {
            'status': 'UNRESOLVED_CONSENSUS',
            'reason': f'Consensus insuffisant : {support_count}/{MIN_CONSENSUS_SOURCES} sources indépendantes',
            'consensus_order': list(order),
            'supporting_sources': [item['source'] for item in supporters],
            'support_count': support_count,
            'consensus_level': 'INSUFFICIENT',
            'conflict_present': len(ranked) > 1,
            'groups': groups_json,
        }
    conflict_present = len(ranked) > 1
    if support_count >= 3:
        status = 'OFFICIAL_CONSENSUS_3_SOURCES'
        level = 'STRONG_3_PLUS'
        reason = 'Arrivée identique corroborée par au moins trois sources indépendantes'
    else:
        status = 'OFFICIAL_CONSENSUS_2_SOURCES'
        level = 'MINIMUM_2'
        reason = 'Arrivée identique corroborée par au moins deux sources indépendantes'
    return {
        'status': status,
        'reason': reason,
        'consensus_order': list(order),
        'supporting_sources': [item['source'] for item in supporters],
        'support_count': support_count,
        'consensus_level': level,
        'conflict_present': conflict_present,
        'groups': groups_json,
    }


def collecter_resultat_officiel(date: str, reunion: int, course: int, discipline: str = '', hippodrome: str = '') -> Dict[str, Any]:
    attempts: List[Dict[str, Any]] = []
    valid_results: List[Dict[str, Any]] = []
    for source, url in _source_urls(date, reunion, course, hippodrome):
        result = _fetch(url, source, date, reunion, course, hippodrome)
        attempts.append(result['attempt'])
        if len(result['order']) >= 5 and result['identity'].get('complete'):
            valid_results.append({'source': source, 'url': url, 'order': result['order'], 'identity': result['identity']})

    consensus = _consensus(valid_results)
    identity = {'date': date, 'reunion': reunion, 'course': course, 'discipline': discipline, 'hippodrome': hippodrome}
    if consensus['status'] in {'OFFICIAL_CONSENSUS_2_SOURCES', 'OFFICIAL_CONSENSUS_3_SOURCES'}:
        source_label = 'CONSENSUS_3_SOURCES' if consensus['status'] == 'OFFICIAL_CONSENSUS_3_SOURCES' else 'CONSENSUS_2_SOURCES'
        return {
            'statut': consensus['status'], 'source': source_label, 'url': None,
            'arrivee_officielle': consensus['consensus_order'], 'sources_consultees': attempts,
            'valid_results': valid_results, 'consensus': consensus, 'identity': identity,
        }
    return {
        'statut': 'UNRESOLVED_CONSENSUS', 'source': None, 'url': None,
        'arrivee_officielle': [], 'sources_consultees': attempts, 'valid_results': valid_results,
        'consensus': consensus, 'identity': identity,
        'warning': 'Arrivée non auditée : au moins deux sources indépendantes concordantes sont obligatoires.'
,
    }
