"""Sources complémentaires, séparées de l'ordre normatif des 11 sources.

Ces sources sont des enrichissements ou contrôles croisés. Aucun statut
UNPROVEN/OBSERVED_CAPABILITY ne peut modifier le ticket sans adaptateur
spécialisé et identité exacte.
"""
from __future__ import annotations

from typing import Any, Dict, List
from urllib.parse import urlencode

COMPLEMENTARY_SOURCE_REGISTRY: List[Dict[str, Any]] = [
    {
        'source': 'FRANCE_GALOP_COURSES',
        'url': 'https://www.france-galop.com/fr/courses/aujourdhui',
        'source_class': 'OFFICIAL', 'authority_level': 'A',
        'adapter_status': 'PARTIAL', 'collection_mode': 'IDENTITY_PROGRAMME',
        'data_groups': ['identity_programme', 'terrain'],
        'allowed_effects': ['identity', 'programme', 'terrain', 'conditions'],
    },
    {
        'source': 'FRANCE_GALOP_TRACKING',
        'url': 'https://www.france-galop.com/en/content/national-rollout-mclloyd-tracking-system-french-premium-courses',
        'source_class': 'OFFICIAL_TECHNICAL', 'authority_level': 'A',
        'adapter_status': 'UNPROVEN', 'collection_mode': 'SPECIALIZED_REPORT_REQUIRED',
        'data_groups': ['speed_and_incidents', 'context_history'],
        'allowed_effects': ['chrono', 'tracking', 'cre', 'supra'],
    },
    {
        'source': 'IFCE_SIRE',
        'url': 'https://www.ifce.fr/ifce/sire-demarches/',
        'source_class': 'INSTITUTIONAL', 'authority_level': 'A',
        'adapter_status': 'UNPROVEN', 'collection_mode': 'HORSE_IDENTITY_REQUIRED',
        'data_groups': ['identity_programme', 'form_history'],
        'allowed_effects': ['horse_identity', 'genealogy', 'performance_control'],
    },
    {
        'source': 'IFCE_STATS_ACTEURS',
        'url': 'https://statscartes.ifce.fr/utilisations/courses/acteurs_d47',
        'source_class': 'INSTITUTIONAL', 'authority_level': 'A',
        'adapter_status': 'OBSERVATION_ONLY', 'collection_mode': 'ANNUAL_CONTEXT',
        'data_groups': ['jockey_trainer_windows'],
        'allowed_effects': ['context_only', 'catalogue_context'],
    },
    {
        'source': 'IFCE_STATS_PARIS',
        'url': 'https://statscartes.ifce.fr/utilisations/courses/paris-hippiques_d4',
        'source_class': 'INSTITUTIONAL', 'authority_level': 'A',
        'adapter_status': 'OBSERVATION_ONLY', 'collection_mode': 'MACRO_CONTEXT',
        'data_groups': ['participants_and_market'],
        'allowed_effects': ['macro_context_only'],
    },
    {
        'source': 'ZETURF',
        'url': 'https://www.zeturf.fr/fr/courses-evenements-ze-5-ordre/resultats',
        'source_class': 'SPECIALIST', 'authority_level': 'B',
        'adapter_status': 'PARTIAL', 'collection_mode': 'RESULTS_NON_RUNNERS',
        'data_groups': ['results', 'identity_programme', 'press_top5_consensus'],
        'allowed_effects': ['results_control', 'non_runners_control', 'press_secondary'],
    },
    {
        'source': 'ITURF',
        'url': 'https://www.iturf.fr/quinte/jockey.php',
        'source_class': 'SPECIALIST', 'authority_level': 'B',
        'adapter_status': 'PARTIAL', 'collection_mode': 'SECONDARY_STATS',
        'data_groups': ['jockey_trainer_windows', 'participants_and_market'],
        'allowed_effects': ['secondary_jockey_trainer_control', 'corde_control'],
        'period_semantics': 'ONE_YEAR_DEFAULT',
    },
    {
        'source': 'TURFOSTATS',
        'url': 'https://turfostats.com/',
        'source_class': 'SECONDARY_DATABASE', 'authority_level': 'B',
        'adapter_status': 'UNPROVEN', 'collection_mode': 'GALOP_HISTORY',
        'data_groups': ['form_history', 'equipment_and_changes', 'context_history'],
        'allowed_effects': ['history_control', 'equipment_control'],
    },
    {
        'source': 'FRANCE_SIRE',
        'url': 'https://www.france-sire.com/partants.php',
        'source_class': 'SPECIALIST_MEDIA', 'authority_level': 'B',
        'adapter_status': 'PARTIAL', 'collection_mode': 'GALOP_EDITORIAL',
        'data_groups': ['identity_programme', 'results', 'form_history'],
        'allowed_effects': ['editorial_control', 'black_type_control'],
    },
    {
        'source': 'OPEN_PMU_API',
        'url': 'https://github.com/open-pmu-api/open-pmu-api',
        'source_class': 'OPEN_SOURCE_NON_OFFICIAL', 'authority_level': 'B/C',
        'adapter_status': 'UNPROVEN', 'collection_mode': 'HISTORICAL_CONTROL',
        'data_groups': ['results', 'form_history'],
        'allowed_effects': ['historical_baseline', 'post_course_control'],
    },
    {
        'source': 'EQUIDIA_API',
        'url': 'https://apiv2.pp.equidia.fr/api/docs?ui=re_doc',
        'source_class': 'TECHNICAL_API', 'authority_level': 'B',
        'adapter_status': 'UNPROVEN', 'collection_mode': 'ACCESS_REQUIRED',
        'data_groups': ['participants_and_market', 'jockey_trainer_windows', 'press_top5_consensus'],
        'allowed_effects': ['none_until_access'],
    },
    {
        'source': 'PROVINCE_COURSES',
        'url': 'https://province-courses.fr/resultats.php',
        'source_class': 'SPECIALIST_TROT', 'authority_level': 'B',
        'adapter_status': 'UNPROVEN', 'collection_mode': 'ACCESS_REQUIRED',
        'data_groups': ['results', 'form_history'],
        'allowed_effects': ['none_until_access'],
    },
    {
        'source': 'RACING_POST',
        'url': 'https://www.racingpost.com/',
        'source_class': 'INTERNATIONAL_SPECIALIST', 'authority_level': 'B',
        'adapter_status': 'UNPROVEN', 'collection_mode': 'ACCESS_REQUIRED',
        'data_groups': ['form_history', 'results', 'participants_and_market'],
        'allowed_effects': ['none_until_access'],
    },
]


def construire_registre_complementaire(date: str, reunion: int, course: int) -> List[Dict[str, Any]]:
    query = urlencode({'date': date, 'reunion': reunion, 'course': course})
    rows = []
    for rank, item in enumerate(COMPLEMENTARY_SOURCE_REGISTRY, start=1):
        row = dict(item)
        row['rank_complementary'] = rank
        row['identity'] = {'date': date, 'reunion': reunion, 'numero_course': course}
        row['url_candidate'] = row['url'] + ('&' if '?' in row['url'] else '?') + query
        row['status_policy'] = 'UNPROVEN_UNTIL_SPECIALIZED_ADAPTER_AND_EXACT_IDENTITY'
        rows.append(row)
    return rows
