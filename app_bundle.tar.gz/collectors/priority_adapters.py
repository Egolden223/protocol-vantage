"""Adaptateurs prudents de résolution des pages prioritaires.

Les adaptateurs ne fabriquent jamais d’URL de course : ils recherchent un lien
qui contient l’identité attendue et renvoient UNPROVEN lorsqu’il est absent.
"""
from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

from collectors.auto_scraper import get_headers

PRIORITY_SOURCE_ADAPTERS = {
    'EQUIDIA': {'index_url': 'https://www.equidia.fr/pronostics', 'method': 'GENERIC_EXACT_IDENTITY'},
    'GENY': {'index_url': 'https://www.geny.com/programme/', 'method': 'GENY_PROGRAM_INDEX'},
    'TURFOO': {'index_url': 'https://www.turfoo.fr/programmes-courses/', 'method': 'TURFOO_DATE_INDEX'},
    'ZONE_TURF': {'index_url': 'https://www.zone-turf.fr/programmes/', 'method': 'ZONE_TURF_PROGRAM_INDEX'},
    'PARIS_TURF': {'index_url': 'https://www.paris-turf.com/', 'method': 'GENERIC_EXACT_IDENTITY'},
    'FREQUENCE_TURF': {'index_url': 'https://www.frequence-turf.fr/', 'method': 'FREQUENCE_TURF_ARTICLE_INDEX'},
    'FRANCE_GALOP': {'index_url': 'https://www.france-galop.com/fr', 'method': 'GENERIC_EXACT_IDENTITY'},
    'LETROT': {'index_url': 'https://www.letrot.com/courses/aujourd-hui', 'method': 'GENERIC_EXACT_IDENTITY'},
    'TURF_BZH': {'index_url': 'https://www.turf.bzh/pronostics-pmu', 'method': 'GENERIC_EXACT_IDENTITY'},
    'RTL': {'index_url': 'https://www.rtl.fr/sport/hippisme', 'method': 'GENERIC_EXACT_IDENTITY'},
    'CANALTURF': {'index_url': 'https://www.canalturf.com/courses_liste_pronostics.php', 'method': 'CANALTURF_DAILY_INDEX'},
}


def _identity_tokens(identity: Dict[str, Any]):
    date = str(identity.get('date', ''))
    return date, date.replace('-', ''), int(identity.get('reunion', 0) or 0), int(identity.get('numero_course', 0) or 0)


def _resolve_canalturf(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {})
    date, date_compact, reunion, course = _identity_tokens(identity)
    list_url = f'https://www.canalturf.com/courses_liste_pronostics.php?date={date}&reunion={reunion}&course={course}'
    response = requests.get(list_url, headers=get_headers(), timeout=35)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href', '')
        text = ' '.join(anchor.get_text(' ', strip=True).split())
        if date not in href and date_compact not in href:
            continue
        match = re.match(r'\s*0*([0-9]{1,2})\s+', text)
        if match and int(match.group(1)) == course:
            # Le numéro de course est recherché dans le bloc R{reunion};
            # lorsqu’il est ambigu, l’adaptateur refuse plutôt que d’inventer.
            parent_text = ' '.join(anchor.parent.get_text(' ', strip=True).split()) if anchor.parent else text
            if re.search(rf'\bR\s*0*{reunion}\b', parent_text, re.IGNORECASE) or reunion == 1:
                return {'status': 'RESOLVED', 'url': urljoin(list_url, href), 'method': 'CANALTURF_DAILY_INDEX', 'identity': identity}
    return {'status': 'UNPROVEN', 'url': candidate.get('url') or list_url, 'method': 'CANALTURF_DAILY_INDEX', 'reason': 'Lien exact date/réunion/course absent'}


def _resolve_letrot(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {})
    date, _date_compact, reunion, course = _identity_tokens(identity)
    list_url = f'https://www.letrot.com/courses/{date}'
    response = requests.get(list_url, headers=get_headers(), timeout=50)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    heading = soup.find('h2', string=re.compile(rf'R\s*0*{reunion}\s*\u00a0?CABOURG', re.IGNORECASE))
    if heading is None:
        heading = soup.find(string=re.compile(rf'R\s*0*{reunion}\s*\u00a0?CABOURG', re.IGNORECASE))
    if heading:
        container = heading if hasattr(heading, 'find_all') else heading.parent
        for _ in range(9):
            if container is None:
                break
            links = container.find_all('a', href=True)
            exact = [a for a in links if re.search(rf'/courses/{re.escape(date)}/[^/]+/{course}(?:[?#].*)?$', a.get('href', ''))]
            if exact:
                return {'status': 'RESOLVED', 'url': urljoin(list_url, exact[0]['href']), 'method': 'LETROT_DATE_INDEX', 'identity': identity}
            container = container.parent
    # Repli strict : le lien doit appartenir à une séquence R{réunion} et C{course}.
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href', '')
        if re.search(rf'/courses/{re.escape(date)}/[^/]+/{course}(?:[?#].*)?$', href):
            text = ' '.join(anchor.get_text(' ', strip=True).split())
            parent_text = ' '.join((anchor.parent or anchor).get_text(' ', strip=True).split())
            if re.search(rf'\bC\s*0*{course}\b', text, re.IGNORECASE) and re.search(rf'\bR\s*0*{reunion}\b', parent_text, re.IGNORECASE):
                return {'status': 'RESOLVED', 'url': urljoin(list_url, href), 'method': 'LETROT_DATE_INDEX', 'identity': identity}
    return {'status': 'UNPROVEN', 'url': list_url, 'method': 'LETROT_DATE_INDEX', 'reason': 'Lien LeTROT exact date/réunion/course absent'}


def _turfoo_slug(value: str) -> str:
    import unicodedata
    normalized = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode('ascii')
    return re.sub(r'[^a-z0-9]+', '-', normalized.lower()).strip('-')


def _resolve_turfoo(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {})
    date, _date_compact, reunion, course = _identity_tokens(identity)
    if len(date) != 10:
        return {'status': 'UNPROVEN', 'url': candidate.get('url'), 'method': 'TURFOO_DATE_INDEX', 'reason': 'Date invalide'}
    compact = date[2:4] + date[5:7] + date[8:10]
    index_url = f'https://www.turfoo.fr/programmes-courses/{compact}/'
    response = requests.get(index_url, headers=get_headers(), timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    hippo = _turfoo_slug(identity.get('hippodrome', ''))
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href', '')
        if not re.search(rf'/programmes-courses/{compact}/reunion0*{reunion}-[^/]+/course0*{course}-[^/]+/?$', href, re.IGNORECASE):
            continue
        if hippo and hippo not in href.lower():
            continue
        resolved_url = urljoin(index_url, href)
        press_url = resolved_url.rstrip('/') + '/pronostics-presse/'
        try:
            press_response = requests.get(press_url, headers=get_headers(), timeout=25)
            if press_response.ok and re.search(r'pronostics presse', BeautifulSoup(press_response.text, 'html.parser').get_text(' ', strip=True), re.IGNORECASE):
                resolved_url = press_url
        except requests.RequestException:
            pass
        return {'status': 'RESOLVED', 'url': resolved_url, 'method': 'TURFOO_DATE_INDEX', 'identity': identity}
    return {'status': 'UNPROVEN', 'url': index_url, 'method': 'TURFOO_DATE_INDEX', 'identity': identity, 'reason': 'Lien Turfoo exact date/réunion/course absent'}


def _resolve_zone_turf(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {})
    date, date_compact, reunion, course = _identity_tokens(identity)
    list_url = 'https://www.zone-turf.fr/programmes/'
    try:
        year, month, day = [int(x) for x in date.split('-')]
        weekdays = ('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche')
        months_ascii = ('janvier', 'fevrier', 'mars', 'avril', 'mai', 'juin', 'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'decembre')
        months_french = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre')
        from datetime import date as date_cls
        dated_url = f'https://www.zone-turf.fr/quinte/{weekdays[date_cls(year, month, day).weekday()]}-{day}-{months_ascii[month - 1]}-{year}/'
        dated_response = requests.get(dated_url, headers=get_headers(), timeout=50)
        if dated_response.ok:
            dated_soup = BeautifulSoup(dated_response.text, 'html.parser')
            dated_text = ' '.join(dated_soup.get_text(' ', strip=True).split())
            date_markers = (f'{day} {months_ascii[month - 1]} {year}', f'{day} {months_french[month - 1]} {year}')
            if re.search(rf'R\s*0*{reunion}\s+Course\s+N[°º]?\s*0*{course}\b', dated_text, re.IGNORECASE) and any(marker.lower() in dated_text.lower() for marker in date_markers):
                return {'status': 'RESOLVED', 'url': dated_url, 'method': 'ZONE_TURF_QUINTE_DATED', 'identity': identity}
    except (ValueError, IndexError):
        pass
    response = requests.get(list_url, headers=get_headers(), timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    page_text = ' '.join(soup.get_text(' ', strip=True).split())
    months = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre')
    try:
        year, month, day = [int(x) for x in date.split('-')]
        date_words = f'{day} {months[month - 1]} {year}'
    except (ValueError, IndexError):
        date_words = ''
    date_ok = any(token and token in page_text for token in (date, date_compact, '/'.join(reversed(date.split('-'))), date_words))
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href', '')
        href_match = re.search(r'/programmes/r0*([0-9]+)-[^/]+-[0-9]+\.html(?:[?#].*)?$', href, re.IGNORECASE)
        if not href_match or int(href_match.group(1)) != reunion:
            continue
        row = anchor.find_parent('tr')
        row_text = ' '.join((row or anchor.parent or anchor).get_text(' ', strip=True).split())
        number_match = re.match(r'\s*0*([0-9]{1,2})\s+', row_text)
        if number_match and int(number_match.group(1)) == course and (date_ok or not date):
            return {'status': 'RESOLVED', 'url': urljoin(list_url, href), 'method': 'ZONE_TURF_PROGRAM_INDEX', 'identity': identity}
    return {'status': 'UNPROVEN', 'url': candidate.get('url') or list_url, 'method': 'ZONE_TURF_PROGRAM_INDEX', 'reason': 'Lien exact date/réunion/course absent'}


def _frequence_break_window(date: str) -> Dict[str, Any]:
    return {
        'start': '2026-07-19',
        'end': '2026-08-17',
        'resume': '2026-08-18',
        'applies': bool(date and '2026-07-19' <= date <= '2026-08-17'),
    }


def _parse_turfoo_top5(html: str) -> Dict[str, Any]:
    soup = BeautifulSoup(html, 'html.parser')
    for table in soup.find_all('table'):
        header = ' '.join(table.find('tr').get_text(' ', strip=True).split()).lower() if table.find('tr') else ''
        if 'numéro' not in header or ('cheval' not in header and 'citation' not in header):
            continue
        numbers = []
        for row in table.find_all('tr')[1:]:
            cells = [re.sub(r'[^0-9]', '', cell.get_text(' ', strip=True)) for cell in row.find_all(['td', 'th'])]
            if cells and cells[0].isdigit():
                number = int(cells[0])
                if 1 <= number <= 99 and number not in numbers:
                    numbers.append(number)
            if len(numbers) >= 5:
                break
        if len(numbers) >= 5:
            return {'status': 'OBSERVED', 'top5': [{'numero': n} for n in numbers[:5]], 'reason': ''}
    return {'status': 'UNPROVEN', 'top5': [], 'reason': 'Table Turfoo de sélection presse introuvable'}


def _parse_frequence_top5(html: str) -> Dict[str, Any]:
    soup = BeautifulSoup(html, 'html.parser')
    numbers = []

    # Format « synthèse de presse » : le premier classement agrégé est la
    # sélection éditoriale la plus directement exploitable. On ne lit jamais
    # les tables de statistiques (jockeys, gains, records) comme un Top 5.
    for heading in soup.find_all(['h2', 'h3', 'h4']):
        heading_text = ' '.join(heading.get_text(' ', strip=True).split())
        if re.search(r'synthèse.*presse\s*n[°º]?\s*1|synthèse des pronostics', heading_text, re.IGNORECASE):
            table = heading.find_next('table')
            if table:
                for row in table.find_all('tr'):
                    first_cell = row.find(['th', 'td'])
                    row_text = ' '.join(first_cell.get_text(' ', strip=True).split()) if first_cell else ''
                    match = re.match(r'\s*0*(\d{1,2})\s*[–-]', row_text)
                    if match:
                        number = int(match.group(1))
                        if number not in numbers:
                            numbers.append(number)
                    if len(numbers) >= 5:
                        break
            if len(numbers) >= 5:
                break

    # Format « pronostic du jour » : les premiers titres N° correspondent aux
    # quatre sélections principales puis aux premières candidatures retenues.
    if len(numbers) < 5:
        for heading in soup.find_all(['h2', 'h3', 'h4']):
            text = ' '.join(heading.get_text(' ', strip=True).split())
            match = re.search(r'N[°º]\s*0*(\d{1,2})', text, re.IGNORECASE)
            if match:
                number = int(match.group(1))
                if number not in numbers:
                    numbers.append(number)
            if len(numbers) >= 5:
                break
    return {'status': 'OBSERVED' if len(numbers) >= 5 else 'UNPROVEN', 'top5': [{'numero': n} for n in numbers[:5]], 'reason': '' if len(numbers) >= 5 else 'Sélection Fréquence-Turf historique insuffisante'}


def _resolve_frequence_turf(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {})
    date, _date_compact, reunion, course = _identity_tokens(identity)
    home_url = 'https://www.frequence-turf.fr/'
    window = _frequence_break_window(date)
    if window['applies']:
        return {
            'status': 'UNAVAILABLE_SCHEDULED_BREAK',
            'url': home_url,
            'method': 'FREQUENCE_TURF_ARTICLE_INDEX',
            'identity': identity,
            'availability_window': window,
            'reason': 'Pause éditoriale officielle couvrant la date demandée',
        }
    response = requests.get(home_url, headers=get_headers(), timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    date_display = f'{date[8:10]}/{date[5:7]}/{date[:4]}' if len(date) == 10 else date
    months = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre')
    try:
        year, month, day = [int(x) for x in date.split('-')]
        date_words = f'{day} {months[month - 1]} {year}'
    except (ValueError, IndexError):
        date_words = ''
    candidate_urls = []
    try:
        weekday_map = {0: 'lundi', 1: 'mardi', 2: 'mercredi', 3: 'jeudi', 4: 'vendredi', 5: 'samedi', 6: 'dimanche'}
        parsed_date = datetime.strptime(date, '%Y-%m-%d')
        weekday = weekday_map[parsed_date.weekday()]
        month_words = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre')
        day_month_year = f'{parsed_date.day}-{month_words[parsed_date.month - 1]}-{parsed_date.year}'
        candidate_urls.extend([
            f'{home_url}meilleurs-pronostics-presse-quinte-pmu-{weekday}-{day_month_year}/',
            f'{home_url}pronostic-quinte-pmu-base-tocard-{weekday}-{day_month_year}/',
        ])
    except ValueError:
        pass
    for anchor in soup.find_all('a', href=True):
        href = urljoin(home_url, anchor.get('href', ''))
        text = ' '.join(anchor.get_text(' ', strip=True).split())
        if not re.search(r'frequence-turf\.fr/(?:pronostic|meilleurs-pronostics)', href, re.IGNORECASE):
            continue
        if date_words.lower() in (text + ' ' + href).lower() or date_display in (text + ' ' + href):
            candidate_urls.append(href)
    seen_urls = set()
    for href in candidate_urls:
        if href in seen_urls:
            continue
        seen_urls.add(href)
        article = requests.get(href, headers=get_headers(), timeout=30)
        if not article.ok:
            continue
        article_text = ' '.join(BeautifulSoup(article.text, 'html.parser').get_text(' ', strip=True).split())
        rc = bool(re.search(rf'R[ée]union\s*(?:n[°º]?\s*)?0*{reunion}\s*[–-]?\s*Course\s*(?:n[°º]?\s*)?0*{course}\b', article_text, re.IGNORECASE))
        if date_words.lower() in article_text.lower() and rc:
            return {'status': 'RESOLVED', 'url': href, 'method': 'FREQUENCE_TURF_ARTICLE_INDEX', 'identity': identity, 'availability_window': window}
    return {'status': 'UNPROVEN', 'url': home_url, 'method': 'FREQUENCE_TURF_ARTICLE_INDEX', 'identity': identity, 'availability_window': window, 'reason': 'Article historique exact date/réunion/course absent'}


def _resolve_geny(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {})
    date, date_compact, reunion, course = _identity_tokens(identity)
    list_url = f'https://www.geny.com/programme/{date}/orga/PMU'
    response = requests.get(list_url, headers={'User-Agent': 'Googlebot/2.1 (+http://www.google.com/bot.html)'}, timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    date_display = f'{date[8:10]}/{date[5:7]}/{date[:4]}' if len(date) == 10 else date
    page_text = ' '.join(soup.get_text(' ', strip=True).split())
    months = ('janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre')
    try:
        year, month, day = [int(x) for x in date.split('-')]
        date_words = f'{day} {months[month - 1]} {year}'
    except (ValueError, IndexError):
        date_words = ''
    if date_display not in page_text and date not in page_text and date_words not in page_text:
        return {'status': 'UNPROVEN', 'url': list_url, 'method': 'GENY_PROGRAM_INDEX', 'reason': 'Date de programme non prouvée'}
    # L’index Geny expose directement les IDs numériques de course. On
    # associe le lien C{course} au bloc de réunion, puis on force une page
    # stable de détail plutôt que d’accepter un simple lien de navigation.
    current_reunion = None
    for node in soup.find_all(['h2', 'h3', 'div', 'a']):
        text = ' '.join(node.get_text(' ', strip=True).split())
        meeting = re.match(r'R\s*0*([0-9]+)\s*\|', text, re.IGNORECASE)
        if meeting:
            current_reunion = int(meeting.group(1))
        href = node.get('href', '') if getattr(node, 'get', None) else ''
        course_match = re.match(rf'C\s*0*{course}\b', text, re.IGNORECASE)
        if href and '/course/' in href and current_reunion == reunion and course_match:
            course_path = urljoin(list_url, href).split('/arrivee-rapports')[0].split('/cotes')[0].split('/partants-pronostics')[0]
            return {'status': 'RESOLVED', 'url': course_path + '/partants-pronostics', 'market_url': course_path + '/cotes', 'method': 'GENY_PROGRAM_INDEX', 'identity': identity}
    # Repli strict : le bloc R1/Cabourg expose les liens C1..Cn dans
    # l’ordre. On choisit l’ID observé à la position C{course}, jamais un ID
    # fabriqué ni le premier ancêtre contenant simplement le texte C4.
    hippo = str(identity.get('hippodrome') or '').strip()
    ordered_ids = []
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href', '')
        match_id = re.search(r'/course/(\d+)/arrivee-rapports', href)
        if not match_id:
            continue
        node = anchor
        in_meeting = False
        for _ in range(8):
            node = node.parent if node else None
            if node is None:
                break
            ancestor = ' '.join(node.get_text(' ', strip=True).split())
            if re.search(rf'\bR\s*0*{reunion}\s+{re.escape(hippo)}\b', ancestor, re.IGNORECASE) and not re.search(r'\bR\s*0*[2-9]\b', ancestor, re.IGNORECASE):
                in_meeting = True
                break
        if in_meeting and match_id.group(1) not in ordered_ids:
            ordered_ids.append(match_id.group(1))
    if len(ordered_ids) >= course:
        course_path = f'https://www.geny.com/course/{ordered_ids[course - 1]}'
        return {'status': 'RESOLVED', 'url': course_path + '/partants-pronostics', 'market_url': course_path + '/cotes', 'method': 'GENY_PROGRAM_INDEX', 'identity': identity, 'evidence': ['date', f'R{reunion}', f'C{course}', hippo]}
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href', '')
        if not re.search(r'/course/\d+', href):
            continue
        text = ' '.join(anchor.get_text(' ', strip=True).split())
        node = anchor
        ancestor_texts = []
        for _ in range(8):
            node = node.parent if node else None
            if node is not None:
                ancestor_texts.append(' '.join(node.get_text(' ', strip=True).split()))
        evidence = ' '.join([text, *ancestor_texts])
        hippo = str(identity.get('hippodrome') or '').strip()
        exact_rc = re.search(rf'\bC\s*0*{course}\b', evidence, re.IGNORECASE) and re.search(rf'\bR\s*0*{reunion}\b', evidence, re.IGNORECASE)
        exact_hippo = not hippo or hippo.lower() in evidence.lower()
        if exact_rc and exact_hippo:
            course_path = urljoin(list_url, href).split('/arrivee-rapports')[0]
            return {'status': 'RESOLVED', 'url': course_path + '/partants-pronostics', 'market_url': course_path + '/cotes', 'method': 'GENY_PROGRAM_INDEX', 'identity': identity}
    return {'status': 'UNPROVEN', 'url': list_url, 'method': 'GENY_PROGRAM_INDEX', 'reason': 'Lien exact date/réunion/course absent'}


def _rtl_slug(value: str) -> str:
    import unicodedata
    normalized = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode('ascii')
    return re.sub(r'[^a-z0-9]+', '-', normalized.lower()).strip('-')


def _resolve_rtl(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {}) or {}
    date, _date_compact, reunion, course = _identity_tokens(identity)
    try:
        from datetime import date as date_cls
        year, month, day = [int(x) for x in date.split('-')]
        weekdays = ('lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche')
        months = ('janvier', 'fevrier', 'mars', 'avril', 'mai', 'juin', 'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'decembre')
        slug_date = f'{weekdays[date_cls(year, month, day).weekday()]}-{day}-{months[month - 1]}'
    except (ValueError, IndexError):
        return {'status': 'UNPROVEN', 'url': candidate.get('url'), 'method': 'RTL_COURSES_INDEX', 'reason': 'Date RTL invalide'}
    index_url = 'https://www.rtl.fr/sujet/courses'
    response = requests.get(index_url, headers={'User-Agent': 'Googlebot/2.1 (+http://www.google.com/bot.html)'}, timeout=30)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    hippo = _rtl_slug(identity.get('hippodrome', ''))
    for anchor in soup.find_all('a', href=True):
        href = urljoin(index_url, anchor.get('href', ''))
        text = ' '.join(anchor.get_text(' ', strip=True).split())
        haystack = (href + ' ' + text).lower()
        if f'quinte-du-{slug_date}' not in haystack or hippo not in haystack:
            continue
        if 'pronostics' not in href.lower():
            continue
        return {'status': 'RESOLVED', 'url': href, 'method': 'RTL_COURSES_INDEX', 'identity': identity, 'identity_scope': 'DAILY_QUINTE', 'evidence': [slug_date, hippo], 'reason': 'Article RTL quotidien trouvé; numéro R/C non publié par RTL'}
    return {'status': 'UNPROVEN', 'url': index_url, 'method': 'RTL_COURSES_INDEX', 'reason': 'Article RTL daté et hippodrome exact absent'}


def _parse_rtl_top5(html: str) -> Dict[str, Any]:
    soup = BeautifulSoup(html, 'html.parser')
    text = '\n'.join(soup.get_text('\n', strip=True).splitlines())
    marker = re.search(r'Les pronostics', text, re.IGNORECASE)
    if not marker:
        return {'status': 'UNPROVEN', 'top5': [], 'reason': 'Rubrique RTL Les pronostics absente'}
    numbers = []
    for line in text[marker.end():].splitlines():
        match = re.match(r'\s*(\d{1,2})\s+', line)
        if match:
            number = int(match.group(1))
            if 1 <= number <= 99 and number not in numbers:
                numbers.append(number)
        if len(numbers) >= 5:
            break
    if len(numbers) < 5:
        return {'status': 'UNPROVEN', 'top5': [{'numero': n} for n in numbers], 'reason': 'Moins de cinq numéros RTL observés'}
    return {'status': 'OBSERVED', 'top5': [{'numero': n} for n in numbers[:5]], 'reason': ''}


def _resolve_france_galop(candidate: Dict[str, Any]) -> Dict[str, Any]:
    identity = candidate.get('identity', {}) or {}
    discipline = str(identity.get('discipline') or '').upper()
    if 'TROT' in discipline:
        return {
            'status': 'UNPROVEN',
            'url': candidate.get('url') or PRIORITY_SOURCE_ADAPTERS['FRANCE_GALOP']['index_url'],
            'method': 'FRANCE_GALOP_DISCIPLINE_GATE',
            'identity': identity,
            'reason': 'FRANCE_GALOP_GALOP_ONLY_NOT_APPLICABLE_FOR_TROT',
            'data_status': 'UNPROVEN',
        }
    return _resolve_generic_priority(candidate)


def _resolve_generic_priority(candidate: Dict[str, Any]) -> Dict[str, Any]:
    source = str(candidate.get('source', '')).upper()
    meta = PRIORITY_SOURCE_ADAPTERS.get(source, {})
    url = candidate.get('url') or meta.get('index_url')
    identity = candidate.get('identity', {}) or {}
    date, date_compact, reunion, course = _identity_tokens(identity)
    if not candidate.get('url'):
        return {'status': 'UNPROVEN', 'url': url, 'method': meta.get('method', 'GENERIC_EXACT_IDENTITY'), 'reason': 'Index prioritaire connu mais lien exact date/réunion/course absent'}
    response = requests.get(url, headers=get_headers(), timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    page_text = ' '.join(soup.get_text(' ', strip=True).split())
    identity_markers = [token for token in (date, date_compact, f'R{reunion}', f'C{course}') if token]
    exact = all(marker.lower() in page_text.lower() for marker in identity_markers)
    if exact:
        return {'status': 'RESOLVED', 'url': url, 'method': meta.get('method', 'GENERIC_EXACT_IDENTITY'), 'identity': identity, 'evidence': identity_markers}
    return {'status': 'UNPROVEN', 'url': url, 'method': meta.get('method', 'GENERIC_EXACT_IDENTITY'), 'reason': 'Identité exacte non prouvée sur la page source', 'required_markers': identity_markers}


def resoudre_candidat(candidate: Dict[str, Any]) -> Dict[str, Any]:
    source = str(candidate.get('source', '')).upper()
    try:
        if source == 'CANALTURF':
            return _resolve_canalturf(candidate)
        if source == 'ZONE_TURF':
            return _resolve_zone_turf(candidate)
        if source == 'TURFOO':
            return _resolve_turfoo(candidate)
        if source == 'LETROT':
            return _resolve_letrot(candidate)
        if source == 'GENY':
            return _resolve_geny(candidate)
        if source == 'RTL':
            return _resolve_rtl(candidate)
        if source == 'FREQUENCE_TURF':
            return _resolve_frequence_turf(candidate)
        if source == 'FRANCE_GALOP':
            return _resolve_france_galop(candidate)
        if source in PRIORITY_SOURCE_ADAPTERS:
            return _resolve_generic_priority(candidate)
    except requests.RequestException as exc:
        fallback_url = candidate.get('url') or PRIORITY_SOURCE_ADAPTERS.get(source, {}).get('index_url')
        return {'status': 'UNPROVEN', 'url': fallback_url, 'method': 'NETWORK_UNPROVEN', 'reason': f'Page source inaccessible ou identité exacte non prouvée: {exc}'}
    return {'status': 'UNPROVEN', 'url': candidate.get('url'), 'method': 'GENERIC_REGISTRY_ONLY', 'reason': 'Adaptateur spécifique non disponible'}
