"""
PROTOCOL VANTAGE — Collecteur de données PMU
Scraping des sources publiques PMU pour alimenter le moteur.
Hiérarchie de 10 sources obligatoires.
"""
import requests
import html as html_lib
from bs4 import BeautifulSoup
from typing import Dict, Any, List, Optional
from datetime import datetime, date
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.models import Course, Partant, Discipline, TypeDepart, Signal
from engine.historical_catalogues import appliquer_signaux_historiques


# Sources de données (hiérarchie de collecte v1.22.2)
SOURCES_HIERARCHIE = [
    {"nom": "PMU.fr Programme", "url": "https://www.pmu.fr/turf/", "type": "programme"},
    {"nom": "PMU.fr Cotes", "url": "https://www.pmu.fr/turf/", "type": "cotes"},
    {"nom": "Turfomania", "url": "https://www.turfomania.fr/", "type": "pronostics"},
    {"nom": "Paris-Turf", "url": "https://www.paris-turf.com/", "type": "pronostics"},
    {"nom": "Geny Courses", "url": "https://www.geny.com/", "type": "pronostics"},
    {"nom": "Zone-Turf", "url": "https://www.zone-turf.fr/", "type": "pronostics"},
    {"nom": "Tiercé Magazine", "url": "https://www.tierce-magazine.com/", "type": "pronostics"},
    {"nom": "Le Trot", "url": "https://www.letrot.com/", "type": "stats_trot"},
    {"nom": "France Galop", "url": "https://www.france-galop.com/", "type": "stats_galop"},
    {"nom": "Equidia", "url": "https://www.equidia.fr/", "type": "analyses"},
]


def get_headers() -> Dict[str, str]:
    """Headers HTTP pour les requêtes."""
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7",
    }


def collecter_programme_pmu(date_course: str = None) -> Dict[str, Any]:
    """
    Collecte le programme PMU du jour.
    Retourne les courses disponibles avec leurs partants.
    """
    if not date_course:
        date_course = date.today().strftime("%d%m%Y")

    try:
        url = f"https://offline.turfinfo.api.pmu.fr/rest/client/1/programme/{date_course}"
        response = requests.get(url, headers=get_headers(), timeout=15)

        if response.status_code == 200:
            data = response.json()
            return {
                "statut": "OK",
                "source": "PMU API",
                "date": date_course,
                "data": data
            }
        else:
            return {
                "statut": "ERREUR",
                "source": "PMU API",
                "code": response.status_code,
                "message": "API PMU indisponible"
            }
    except Exception as e:
        return {
            "statut": "ERREUR",
            "source": "PMU API",
            "message": str(e)
        }


def collecter_participants_course(date_course: str, reunion: int, course_num: int) -> Dict[str, Any]:
    """
    Collecte les participants d'une course spécifique via l'API PMU.
    """
    try:
        url = f"https://offline.turfinfo.api.pmu.fr/rest/client/1/programme/{date_course}/R{reunion}/C{course_num}/participants"
        response = requests.get(url, headers=get_headers(), timeout=15)

        if response.status_code == 200:
            data = response.json()
            return {
                "statut": "OK",
                "source": "PMU API Participants",
                "data": data
            }
        else:
            return {"statut": "ERREUR", "code": response.status_code}
    except Exception as e:
        return {"statut": "ERREUR", "message": str(e)}


def collecter_cotes_course(date_course: str, reunion: int, course_num: int) -> Dict[str, Any]:
    """
    Collecte les cotes actuelles d'une course.
    """
    try:
        url = f"https://offline.turfinfo.api.pmu.fr/rest/client/1/programme/{date_course}/R{reunion}/C{course_num}/pronostics"
        response = requests.get(url, headers=get_headers(), timeout=15)

        if response.status_code == 200:
            data = response.json()
            return {
                "statut": "OK",
                "source": "PMU API Pronostics",
                "data": data
            }
        else:
            return {"statut": "ERREUR", "code": response.status_code}
    except Exception as e:
        return {"statut": "ERREUR", "message": str(e)}


def parser_discipline(specialite: str) -> Optional[Discipline]:
    """Convertit la spécialité PMU en Discipline."""
    specialite = specialite.upper() if specialite else ""
    if "TROT" in specialite and "ATTEL" in specialite:
        return Discipline.TROT_ATTELE
    elif "TROT" in specialite and "MONT" in specialite:
        return Discipline.TROT_MONTE
    elif "TROT" in specialite:
        return Discipline.TROT_ATTELE
    elif "PLAT" in specialite:
        return Discipline.PLAT
    elif "STEEPLE" in specialite or "OBSTACLE" in specialite:
        return Discipline.OBSTACLE
    elif "HAIE" in specialite:
        return Discipline.HAIES
    elif "PLAT" in specialite:
        return Discipline.PLAT
    elif "CROSS" in specialite:
        return Discipline.OBSTACLE
    return None


def parser_participants_pmu(data: Dict[str, Any], course: Course) -> Course:
    """
    Parse les données de participants PMU et crée les objets Partant.
    """
    data = data if isinstance(data, dict) else {}
    nested_data = data.get("data")
    nested_participants = nested_data.get("participants", []) if isinstance(nested_data, dict) else []
    participants = data.get("participants") or nested_participants or []

    if isinstance(participants, dict):
        participants = participants.get("participants", [])

    for p_data in participants:
        if isinstance(p_data, dict):
            partant = Partant(
                numero=p_data.get("numPmu", p_data.get("numero", 0)),
                nom=html_lib.unescape(str(p_data.get("nom", "INCONNU") or "")).strip(),
                cote=p_data.get("coteDirect", {}).get("coteDirect", 0) if isinstance(p_data.get("coteDirect"), dict) else p_data.get("coteDirect", 0),
                valeur_pmu=_float_or_none(p_data.get("valeurPmu", p_data.get("valeurPMU", p_data.get("gainsParticipant")))),
                poids=p_data.get("poidsConditionMonte", p_data.get("handicapPoids", 0)),
                driver_jockey=p_data.get("driver", p_data.get("jockey", "")),
                entraineur=p_data.get("entraineur", ""),
                age=p_data.get("age", 0),
                sexe=p_data.get("sexe", ""),
            )

            # Initialiser les signaux de base
            partant.signaux = creer_signaux_base(partant, course)
            course.partants.append(partant)

    course.nb_partants = len(course.partants)
    return course


def creer_signaux_base(partant: Partant, course: Course) -> List[Signal]:
    """
    Crée la liste de signaux de base pour un partant.
    Chaque signal sera évalué ultérieurement.
    """
    signaux = [
        # Famille F (Forme)
        Signal(code="B01", nom="Forme récente positive", famille="F"),
        Signal(code="B20", nom="Régularité places", famille="F"),
        Signal(code="B23", nom="H2H avantage", famille="F"),
        Signal(code="B24", nom="Progression", famille="F"),
        Signal(code="B25", nom="Série en cours", famille="F"),
        Signal(code="B47", nom="Dernière course significative", famille="F"),
        Signal(code="B54", nom="Repos optimal", famille="F"),

        # Famille L (Lieu)
        Signal(code="B04", nom="Terrain favorable", famille="L"),
        Signal(code="B05", nom="Terrain spécialiste", famille="L"),
        Signal(code="B15", nom="Distance confirmée", famille="L"),
        Signal(code="B17", nom="Distance optimale", famille="L"),
        Signal(code="B19", nom="Hippodrome favorable", famille="L"),
        Signal(code="B28", nom="Parcours connu", famille="L"),
        Signal(code="B33", nom="Corde favorable", famille="L"),

        # Famille C (Conseil)
        Signal(code="B09", nom="Jockey/Driver top", famille="C"),
        Signal(code="B11", nom="Tandem gagnant", famille="C"),
        Signal(code="B12", nom="Entraîneur en forme", famille="C"),
        Signal(code="B38", nom="Pronostic expert", famille="C"),
        Signal(code="B51", nom="Consensus pronostiqueurs", famille="C"),

        # Famille M (Marché)
        Signal(code="B06", nom="Cote en baisse", famille="M"),
        Signal(code="B16", nom="Support marché", famille="M"),
        Signal(code="B35", nom="SOV favorable", famille="M"),
        Signal(code="B36", nom="Mouvement tardif", famille="M"),
        Signal(code="B41", nom="Consensus cotes", famille="M"),

        # Famille P (Physique)
        Signal(code="B21", nom="Poids favorable", famille="P"),
        Signal(code="B42", nom="Équipement changé", famille="P"),
        Signal(code="B43", nom="Condition physique", famille="P"),
    ]

    return signaux


def construire_course_depuis_saisie(data: Dict[str, Any]) -> Course:
    """
    Construit un objet Course à partir des données saisies par l'utilisateur.
    """
    def _float_or_none(value):
        """Convertit une valeur numérique sans jamais inventer une donnée absente."""
        try:
            return float(value) if value not in (None, "", "NC") else None
        except (TypeError, ValueError):
            return None

    def _int_or_none(value):
        """Convertit un entier ; les valeurs absentes ou invalides restent NC."""
        try:
            return int(value) if value not in (None, "", "NC") else None
        except (TypeError, ValueError):
            return None

    course = Course(
        date=data.get("date", datetime.now().strftime("%Y-%m-%d")),
        hippodrome=data.get("hippodrome", ""),
        numero_course=data.get("numero_course", 1),
        nom_course=data.get("nom_course", ""),
        discipline=parser_discipline(data.get("discipline", "")),
        distance=int(data.get("distance", 0) or 0),
        terrain=data.get("terrain", ""),
        penetrometre=_float_or_none(data.get("penetrometre")),
        piste=data.get("piste", ""),
        allocation=_float_or_none(data.get("allocation", data.get("allocation_course_actuelle"))),
        est_handicap=data.get("est_handicap", False),
        nb_partants=int(data.get("nb_partants", 0) or 0),
    )

    # Type de départ
    type_depart = str(data.get("type_depart") or "").upper()
    if type_depart == "AUTOSTART":
        course.type_depart = TypeDepart.AUTOSTART
    elif type_depart == "VOLTE":
        course.type_depart = TypeDepart.VOLTE
    elif type_depart == "CENTRE":
        course.type_depart = TypeDepart.CENTRE

    # Partants
    partants_data = data.get("partants", [])
    for p_data in partants_data:
        # Les champs absents sont conservés comme NC dans les données brutes et
        # dans data_quality ; aucune valeur numérique fictive n'est créée.
        data_quality = dict(p_data.get("data_quality", {}) or {})
        for field in ("cote", "poids", "age", "rk_brute", "icp_count"):
            if p_data.get(field) in (None, "", "NC"):
                data_quality.setdefault(field, "NC: valeur absente ou non collectée")

        partant = Partant(
            numero=_int_or_none(p_data.get("numero")) or 0,
            nom=html_lib.unescape(str(p_data.get("nom", "") or "")).strip(),
            cote=_float_or_none(p_data.get("cote")),
            valeur_pmu=_float_or_none(p_data.get("valeur_pmu", p_data.get("valeurPmu", p_data.get("valeurPMU", p_data.get("gainsParticipant"))))),
            poids=_float_or_none(p_data.get("poids")),
            driver_jockey=p_data.get("driver_jockey", ""),
            entraineur=p_data.get("entraineur", ""),
            ecurie=p_data.get("ecurie", ""),
            age=_int_or_none(p_data.get("age")),
            sexe=p_data.get("sexe", ""),
            rk_brute=_float_or_none(p_data.get("rk_brute")),
            # Le compteur ICP reste à 0 en interne pour préserver les agrégations
            # existantes ; la valeur brute et data_quality signalent explicitement NC.
            icp_count=_int_or_none(p_data.get("icp_count")) or 0,
            legacy_flags=list(p_data.get("legacy_flags", p_data.get("flags_legacy", [])) or []),
            data_quality=data_quality,
            raw_data=dict(p_data),
            market_data=dict(p_data.get("market_data", {}) or {}),
        )

        # Signaux
        partant.signaux = creer_signaux_base(partant, course)

        # Activer les signaux fournis (avec valeurs et sources)
        signaux_actifs = p_data.get("signaux_actifs", [])
        signaux_details = {s["code"]: s for s in p_data.get("signaux_details", [])}

        for code in signaux_actifs:
            for signal in partant.signaux:
                if signal.code == code:
                    signal.actif = True
                    # Priorité aux détails enrichis du scraper
                    if code in signaux_details:
                        signal.valeur = float(signaux_details[code].get("valeur", 5.0))
                        signal.source = signaux_details[code].get("raison", "auto_scraper")
                        signal.famille = signaux_details[code].get("famille", signal.famille)
                    else:
                        signal.valeur = float(p_data.get(f"signal_{code}_valeur", 5.0))
                        signal.source = p_data.get(f"signal_{code}_source", "saisie_utilisateur")
                    break
            else:
                # Signal non trouvé dans la base → créer dynamiquement
                if code in signaux_details:
                    detail = signaux_details[code]
                    new_signal = Signal(
                        code=code,
                        nom=detail.get("raison", code),
                        actif=True,
                        valeur=float(detail.get("valeur", 5.0)),
                        famille=detail.get("famille", ""),
                        source=detail.get("raison", "auto_scraper")
                    )
                    partant.signaux.append(new_signal)

        # Évalue les catalogues historiques uniquement sur les champs
        # structurés et observés présents dans raw_data.
        historique_audit = appliquer_signaux_historiques(partant, course)
        partant.extended_metrics['historical_catalogue_audit'] = historique_audit
        course.partants.append(partant)

    if not course.nb_partants:
        course.nb_partants = len(course.partants)

    return course
