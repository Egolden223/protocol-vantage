"""Registre normatif des sources de collecte du Bloc 3.

Chaque source possède son propre profil d'accès. Une URL d'index n'est jamais
considérée comme une URL de course résolue : l'adaptateur doit encore prouver
la date, la réunion et le numéro de course dans la page cible.
"""
from __future__ import annotations

from typing import Any, Dict, List
from urllib.parse import urlencode

from collectors.data_requirements import DATA_REQUIREMENTS

PRIORITY_SOURCE_ORDER = [
    ('EQUIDIA', 'https://www.equidia.fr/pronostics', 'presse_top5'),
    ('GENY', 'https://www.geny.com/programme/', 'presse_top5'),
    ('TURFOO', 'https://www.turfoo.fr/programmes-pmu', 'presse_top5'),
    ('ZONE_TURF', 'https://www.zone-turf.fr/programmes/', 'presse_top5_resultats'),
    ('PARIS_TURF', 'https://www.paris-turf.com/', 'presse_top5'),
    ('FREQUENCE_TURF', 'https://www.frequence-turf.fr/', 'presse_top5'),
    ('FRANCE_GALOP', 'https://www.france-galop.com/fr/content/programme-des-courses-agenda', 'officiel_galop_terrain_resultats'),
    ('LETROT', 'https://www.letrot.com/courses/aujourd-hui', 'officiel_trot_partants_resultats'),
    ('TURF_BZH', 'https://www.turf.bzh/pronostics-pmu', 'partants_cotes_indicateurs'),
    ('RTL', 'https://www.rtl.fr/sport/hippisme', 'presse_top5'),
    ('CANALTURF', 'https://www.canalturf.com/courses_liste_pronostics.php', 'presse_top5_resultats'),
]

SOURCE_PROFILES: Dict[str, Dict[str, Any]] = {
    'EQUIDIA': {'url_strategy': 'INDEX_QUERY', 'adapter_method': 'GENERIC_EXACT_IDENTITY', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'GENY': {'url_strategy': 'DATE_ORGA_INDEX', 'adapter_method': 'GENY_PROGRAM_INDEX', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'TURFOO': {'url_strategy': 'DATE_PROGRAM_INDEX', 'adapter_method': 'TURFOO_DATE_INDEX', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'ZONE_TURF': {'url_strategy': 'PROGRAMME_INDEX_DISCOVERY', 'adapter_method': 'ZONE_TURF_PROGRAM_INDEX', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'PARIS_TURF': {'url_strategy': 'INDEX_QUERY', 'adapter_method': 'GENERIC_EXACT_IDENTITY', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'FREQUENCE_TURF': {'url_strategy': 'HOME_AVAILABILITY_AND_ARTICLE', 'adapter_method': 'FREQUENCE_TURF_ARTICLE_INDEX', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'FRANCE_GALOP': {'url_strategy': 'AGENDA_INDEX', 'adapter_method': 'FRANCE_GALOP_DISCIPLINE_GATE', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'LETROT': {'url_strategy': 'CALENDAR_DATE_INDEX', 'adapter_method': 'LETROT_DATE_INDEX', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'TURF_BZH': {'url_strategy': 'DIRECT_DATE_REUNION_COURSE', 'adapter_method': 'GENERIC_EXACT_IDENTITY', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'RTL': {'url_strategy': 'RTL_COURSES_INDEX', 'adapter_method': 'RTL_COURSES_INDEX', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
    'CANALTURF': {'url_strategy': 'DAILY_INDEX_DISCOVERY', 'adapter_method': 'CANALTURF_DAILY_INDEX', 'popup_policy': 'HTML_CLEANUP_NO_INTERACTION'},
}


def _requirements_for_source(source: str) -> List[Dict[str, Any]]:
    return [
        {
            'requirement_id': req['id'],
            'fields': req['fields'],
            'criticality': req['criticality'],
            'extraction_targets': req['extraction_targets'],
            'consumers': req['consumers'],
            'missing_policy': req['missing_policy'],
        }
        for req in DATA_REQUIREMENTS
        if source in req['primary_sources'] or source in req['fallback_sources']
    ]


def _build_source_url(name: str, base: str, date: str, date_pmu: str, reunion: int, course: int) -> str:
    """Construit l'URL initiale propre à la source, sans prétendre résoudre le lien final."""
    if name == 'TURF_BZH':
        return f'https://www.turf.bzh/pronostics-pmu-{date_pmu}-R{reunion}C{course}.html'
    if name == 'EQUIDIA':
        return f'https://www.equidia.fr/courses/{date}/R{reunion}/C{course}'
    if name == 'CANALTURF':
        return f'https://www.canalturf.com/courses_liste_pronostics.php?date={date}&reunion={reunion}&course={course}'
    if name == 'GENY':
        return f'https://www.geny.com/programme/{date}/orga/PMU'
    if name == 'TURFOO':
        return f'https://www.turfoo.fr/programmes-courses/{date[2:4]}{date[5:7]}{date[8:10]}/'
    if name == 'RTL':
        return 'https://www.rtl.fr/sujet/courses'
    if name == 'FREQUENCE_TURF':
        return 'https://www.frequence-turf.fr/'
    if name == 'ZONE_TURF':
        return 'https://www.zone-turf.fr/programmes/'
    if name == 'LETROT':
        return f'https://www.letrot.com/courses/{date}'
    query = urlencode({'date': date, 'reunion': reunion, 'course': course})
    return f'{base}&{query}' if '?' in base else f'{base}?{query}'


def construire_registre_sources(date: str, reunion: int, course: int, discipline: str = '', hippodrome: str = '') -> List[Dict[str, Any]]:
    date_pmu = date.replace('-', '')
    registry: List[Dict[str, Any]] = []
    for rank, (name, base, role) in enumerate(PRIORITY_SOURCE_ORDER, start=1):
        profile = SOURCE_PROFILES[name]
        registry.append({
            'rank': rank,
            'source': name,
            'url': _build_source_url(name, base, date, date_pmu, reunion, course),
            'base_url': base,
            'role': role,
            'url_strategy': profile['url_strategy'],
            'adapter_method': profile['adapter_method'],
            'popup_policy': profile['popup_policy'],
            'http_timeout_seconds': {'LETROT': 50, 'EQUIDIA': 35, 'CANALTURF': 35, 'GENY': 30, 'ZONE_TURF': 50, 'RTL': 35}.get(name, 25),
            'identity_required': True,
            'top5_required': role.startswith('presse'),
            'identity': {'date': date, 'reunion': reunion, 'numero_course': course, 'discipline': discipline, 'hippodrome': hippodrome},
            'search_parameters': {'date': date, 'date_pmu': date_pmu, 'reunion': reunion, 'course': course},
            'data_requirements': _requirements_for_source(name),
            'http_headers': {'User-Agent': 'Googlebot/2.1 (+http://www.google.com/bot.html)'} if name in {'GENY', 'RTL'} else {},
        })
    return registry
