"""Plan de collecte Protocol Vantage : donnée -> sources -> consommateurs.

Ce registre ne transforme jamais une absence en valeur. Il sert à piloter la
recherche, à documenter les champs attendus et à mesurer la preuve réellement
observée par course.
"""
from __future__ import annotations

from typing import Any, Dict, List

SOURCE_ORDER = [
    'EQUIDIA', 'GENY', 'TURFOO', 'ZONE_TURF', 'PARIS_TURF',
    'FREQUENCE_TURF', 'FRANCE_GALOP', 'LETROT', 'TURF_BZH', 'RTL', 'CANALTURF',
]

DATA_REQUIREMENTS: List[Dict[str, Any]] = [
    {
        'id': 'identity_programme',
        'criticality': 'P0',
        'fields': ['date', 'reunion', 'numero_course', 'hippodrome', 'discipline', 'distance', 'terrain', 'penetrometre', 'piste', 'allocation', 'nb_partants', 'type_depart', 'est_handicap'],
        'primary_sources': ['FRANCE_GALOP', 'LETROT', 'TURF_BZH'],
        'fallback_sources': ['GENY', 'ZONE_TURF', 'EQUIDIA', 'TURFOO'],
        'extraction_targets': ['programme officiel', 'bloc identité date/R/C', 'discipline/distance', 'terrain/pénétromètre', 'piste/départ', 'allocation/conditions'],
        'consumers': ['Course', 'GRU', 'P_LOCK', 'IIC', 'TACT', 'MODULE_POIDS', 'MODULE_RECUL', 'MODULE_TERRAIN_DYN', 'MODULE_DIST_ADAPT', 'MPA_CHAMP', 'GMO-V'],
        'missing_policy': 'BLOCKED_IDENTITY ou NC selon le champ; aucune discipline/hippodrome par défaut',
    },
    {
        'id': 'participants_and_market',
        'criticality': 'P0',
        'fields': ['numero', 'nom', 'cote_matin', 'cote_avant_course', 'cote_15min', 'sov_snapshots', 'valeur_pmu', 'driver_jockey', 'entraineur', 'ecurie', 'proprietaire', 'age', 'sexe', 'poids_actuel_kg', 'numero_corde', 'numero_autostart', 'recul_m', 'rk_brute'],
        'primary_sources': ['TURF_BZH', 'LETROT', 'FRANCE_GALOP'],
        'fallback_sources': ['GENY', 'ZONE_TURF', 'TURFOO', 'CANALTURF'],
        'extraction_targets': ['table des partants', 'cotes et snapshots horodatés', 'valeur PMU', 'driver/jockey/entraîneur', 'poids', 'corde/autostart/recul', 'RK'],
        'consumers': ['signaux B06/B35/B36/B41', 'SOV_v2', 'IQL_v2', 'NRC', 'MODULE_POIDS', 'MODULE_RECUL', 'ORDRE_SCORE', 'GMO-V'],
        'missing_policy': 'Champ NC; SOV=0 avec statut UNPROVEN/IFT selon RAH-28/309; aucun snapshot inventé',
    },
    {
        'id': 'press_top5_consensus',
        'criticality': 'P0',
        'fields': ['press_top5', 'press_top5_sources', 'press_distinct_sources', 'press_mentions', 'press_divergence', 'consensus_outsider'],
        'primary_sources': SOURCE_ORDER,
        'fallback_sources': [],
        'extraction_targets': ['Top 5 presse de chaque source', 'date/R/C sur la page', 'numéros et ordre libre', 'source/paywall/parsabilité'],
        'consumers': ['D46-D22', 'B38', 'B51', 'ICP', 'RAH-212', 'RAH-232', 'SUPRA Phase 4', 'LONGSHOTS'],
        'missing_policy': 'Chaque source = OK/ECHEC/UNPROVEN; consensus calculé uniquement sur Top5 OBSERVED; absence ne vaut pas non-citation prouvée',
    },
    {
        'id': 'equipment_and_changes',
        'criticality': 'P0',
        'fields': ['deferrage', 'deferrage_4_pieds', 'deferrage_4_pieds_premiere', 'oeilleres', 'premieres_oeilleres', 'changement_ferrure', 'changement_driver', 'changement_entraineur', 'commentaire_derniere_course'],
        'primary_sources': ['LETROT', 'FRANCE_GALOP', 'TURF_BZH', 'GENY'],
        'fallback_sources': ['ZONE_TURF', 'TURFOO', 'EQUIDIA', 'CANALTURF'],
        'extraction_targets': ['ferrure/déferrage', 'œillères', 'changements', 'commentaires dernière course', 'mots-clés excuse'],
        'consumers': ['STAB', 'TACT', 'IFF_v2', 'B11', 'M48-B42', 'D09bis', 'RAH-243/245/263/265', 'SUPRA'],
        'missing_policy': 'NC/UNPROVEN; standard uniquement si la source officielle indique explicitement standard, jamais par silence de page',
    },
    {
        'id': 'form_history',
        'criticality': 'P0',
        'fields': ['rangs_6_dernieres', 'rangs_4_dernieres', 'nb_partants_4_dernieres', 'rangs_relatifs_4', 'rangs_3_dernieres', 'gains_totaux_eur', 'nb_courses_total', 'victoires_total', 'places_total', 'repos', 'allocations_last3', 'categories_allocations_6', 'ee_categories_6', 'ee_scores_6', 'macro_groupe'],
        'primary_sources': ['LETROT', 'FRANCE_GALOP', 'GENY', 'TURF_BZH'],
        'fallback_sources': ['ZONE_TURF', 'TURFOO', 'CANALTURF'],
        'extraction_targets': ['historique 3/4/6 courses', 'rangs et tailles de champ', 'gains/victoires/places', 'repos', 'allocations et catégories'],
        'consumers': ['FORME_LINEAIRE', 'PENTE', 'STAB', 'CRE_PROXY', 'SRI', 'TANDEM', 'IQL', 'B47', 'RAH-243/245/253'],
        'missing_policy': 'Module calculé seulement sur un échantillon suffisant; sinon UNPROVEN/NC sans moyenne fictive',
    },
    {
        'id': 'context_history',
        'criticality': 'P0',
        'fields': ['historique_terrain_perf', 'historique_distances_perf', 'historique_parcours_exact', 'nb_courses_hippodrome', 'profil_hippodrome_similaire', 'style_mpa', 'rythme_projete', 'rythme_effectif', 'positions_mi_course_5', 'position_mi_course_historique', 'numero_corde', 'sens_corde_officiel', 'sens_rotation_historique'],
        'primary_sources': ['LETROT', 'FRANCE_GALOP', 'GENY', 'TURF_BZH'],
        'fallback_sources': ['ZONE_TURF', 'TURFOO', 'EQUIDIA'],
        'extraction_targets': ['performances par terrain/distance/hippodrome', 'profil corde/piste', 'style de course', 'rythme et positions intermédiaires'],
        'consumers': ['MODULE_TERRAIN_DYN', 'MODULE_DIST_ADAPT', 'MPA_CHAMP', 'GRU', 'RAH-85/89', 'RAH-118/124-141'],
        'missing_policy': 'UNPROVEN si historique ou contexte non documenté; aucune déduction depuis la seule cote',
    },
    {
        'id': 'jockey_trainer_windows',
        'criticality': 'P1',
        'fields': ['jockey_windows', 'trainer_windows', 'driver_classement_national', 'driver_classement_hebdomadaire', 'driver_classement_12m', 'taux_victoires', 'taux_place', 'feu_equidia', 'bio_rythme_saisonnier'],
        'primary_sources': ['EQUIDIA', 'GENY', 'LETROT', 'FRANCE_GALOP'],
        'fallback_sources': ['TURF_BZH', 'ZONE_TURF', 'TURFOO'],
        'extraction_targets': ['fenêtres 7/14/30/60j', 'classements', 'taux de victoire/place', 'feu/forme jockey-driver', 'rythme saisonnier'],
        'consumers': ['BSH_v3v4', 'BSC_v3', 'IFF_v2', 'TACT', 'RAH-82', 'GAMMA'],
        'missing_policy': 'Fenêtre non disponible = module UNPROVEN; pas de taux 0 implicite',
    },
    {
        'id': 'speed_and_incidents',
        'criticality': 'P1',
        'fields': ['chrono_200m', 'chrono_1km', 'rk_array', 'rk_incident_flag', 'rk_ref_tiers', 'commentaire_derniere_course', 'delai_j', 'nb_courses_30j', 'iff_seuil_surmenage'],
        'primary_sources': ['LETROT', 'FRANCE_GALOP', 'EQUIDIA', 'GENY'],
        'fallback_sources': ['TURF_BZH', 'ZONE_TURF', 'TURFOO'],
        'extraction_targets': ['chronos', 'RK par course', 'incidents', 'commentaires et excuses', 'délais et surmenage'],
        'consumers': ['CRE_v2', 'CRE_PROXY_v3', 'TACT', 'IFF_v2', 'SRI', 'D45', 'SUPRA'],
        'missing_policy': 'CRE v2 bascule vers proxy seulement si ≥3 RK exploitables; sinon NC/UNPROVEN',
    },
    {
        'id': 'h2h_tandem_and_relations',
        'criticality': 'P1',
        'fields': ['h2h_avg', 'h2h_scores', 'taux_top5_tandem', 'coeff_nb_tandem', 'coeff_temps_tandem', 'nb_courses_ensemble', 'synergie_jch', 'harville_correlation_matrix'],
        'primary_sources': ['GENY', 'EQUIDIA', 'LETROT', 'FRANCE_GALOP'],
        'fallback_sources': ['TURF_BZH', 'ZONE_TURF', 'TURFOO'],
        'extraction_targets': ['confrontations directes', 'association cheval/jockey-driver', 'matrice de corrélation sourcée'],
        'consumers': ['H2H_GRAPH', 'TANDEM_BONUS', 'COMPOSITE', 'Harville', 'ORDRE_SCORE'],
        'missing_policy': 'H2H/TANDEM/Harville UNPROVEN ou neutres selon formule; proxy silencieux interdit',
    },
    {
        'id': 'supra_longshots_and_catalogues',
        'criticality': 'P1',
        'fields': ['score_sim', 'press_distinct_sources', 'press_sources', 'consensus_outsider', 'ssfo_signals', 'gamma_signals', 'ghost_signals', 'supra_omission_candidate', 'supra_retrait_candidate'],
        'primary_sources': ['EQUIDIA', 'GENY', 'TURFOO', 'ZONE_TURF', 'PARIS_TURF', 'FREQUENCE_TURF', 'RTL', 'CANALTURF', 'TURF_BZH'],
        'fallback_sources': ['LETROT', 'FRANCE_GALOP'],
        'extraction_targets': ['divergence presse', 'signaux GHOST/SSFO/GAMMA', 'historique similaire', 'candidats omission/retrait'],
        'consumers': ['GHOST', 'SSFO', 'GAMMA', 'LONGSHOTS', 'SUPRA', 'GMO-V'],
        'missing_policy': 'Signal non prouvé = UNPROVEN; aucun bonus de catalogue ou changement de ticket sans preuve',
    },
]


def construire_plan_collecte(date: str, reunion: int, course: int) -> Dict[str, Any]:
    # Import local pour éviter le cycle: conditional_data_contract réutilise
    # SOURCE_ORDER comme registre canonique des onze sources.
    from collectors.conditional_data_contract import CONDITIONAL_DATA_CONTRACTS
    return {
        'identity': {'date': date, 'reunion': reunion, 'numero_course': course},
        'mandatory_source_order': list(SOURCE_ORDER),
        'requirements': DATA_REQUIREMENTS,
        'conditional_contracts': CONDITIONAL_DATA_CONTRACTS,
        'policy': {
            'identity_required': True,
            'source_exact_identity_required': True,
            'missing_data': 'NC',
            'unproven_data': 'UNPROVEN',
            'no_silent_defaults': True,
            'press_consensus_only_observed': True,
            'official_source_preferred_for_identity': True,
        },
    }


def indexer_champs() -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    for req in DATA_REQUIREMENTS:
        for field in req['fields']:
            index[field] = {'requirement_id': req['id'], 'criticality': req['criticality'], 'primary_sources': req['primary_sources'], 'fallback_sources': req['fallback_sources'], 'consumers': req['consumers'], 'missing_policy': req['missing_policy']}
    return index
