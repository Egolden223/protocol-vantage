"""Contrat opérationnel des données conditionnelles Protocol Vantage.

Chaque entrée décrit une donnée publiquement visible mais non garantie sur
chaque fiche. Le collecteur doit tenter les sources dans l'ordre exact,
conserver la preuve par champ et retourner NC/UNPROVEN sans valeur silencieuse.
"""
from __future__ import annotations

from typing import Any, Dict, List

from collectors.data_requirements import SOURCE_ORDER


CONDITIONAL_DATA_CONTRACTS: List[Dict[str, Any]] = [
    {
        'id': 'conditional_equipment_changes',
        'phase': 'PRE_COURSE',
        'criticality': 'P0',
        'fields': ['deferrage', 'deferrage_4_pieds', 'deferrage_4_pieds_premiere', 'oeilleres', 'premieres_oeilleres', 'changement_ferrure', 'changement_driver', 'changement_entraineur', 'commentaire_derniere_course'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['LETROT', 'FRANCE_GALOP', 'TURF_BZH', 'GENY', 'ZONE_TURF', 'TURFOO', 'EQUIDIA', 'CANALTURF'],
        'resolution': ['fiche exacte date/R/C', 'ancre partant numéro+nom', 'table programme ou fiche cheval'],
        'evidence': ['numero', 'nom_normalise', 'libelle_equipement', 'source_url', 'retrieval_timestamp'],
        'normalization': 'Conserver la valeur textuelle et le code normalisé séparément; une cellule vide ou une absence d’icône ne vaut pas STANDARD.',
        'minimum_evidence': {'field_value': 1, 'source_identity': True},
        'fallback': 'Passer à la source suivante; conserver la raison et le sélecteur non trouvé.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'STAB/TACT/IFF/SSFO utilisent uniquement OBSERVED; le module devient UNPROVEN si le seuil requis manque.',
        'consumers': ['STAB', 'TACT', 'IFF_v2', 'D45', 'SSFO', 'RAH-243', 'RAH-245', 'RAH-263', 'RAH-265'],
    },
    {
        'id': 'conditional_career_value_rates',
        'phase': 'PRE_COURSE',
        'criticality': 'P0',
        'fields': ['valeur_pmu', 'gains_totaux_eur', 'nb_courses_total', 'victoires_total', 'places_total', 'taux_victoires', 'taux_place', 'niveau_max', 'niveau_max_type'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['GENY', 'EQUIDIA', 'LETROT', 'FRANCE_GALOP', 'TURF_BZH', 'CANALTURF'],
        'resolution': ['fiche carrière du cheval', 'bloc statistiques carrière rattaché au numéro', 'programme exact date/R/C'],
        'evidence': ['numero', 'nom_normalise', 'periode_statistique', 'valeur', 'source_url', 'retrieval_timestamp'],
        'normalization': 'Ne pas recalculer victoires/places à partir de taux arrondis; conserver unité, période et libellé Groupe/Listed.',
        'minimum_evidence': {'field_value': 1, 'source_identity': True},
        'fallback': 'Utiliser une fiche carrière secondaire seulement si le cheval et l’identité sont reliés explicitement.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'SRI/PDQ/M30-M35 utilisent la valeur seulement si période et unité sont prouvées; sinon branche dégradée.',
        'consumers': ['SRI', 'PDQ', 'M30', 'M31', 'M32', 'M34', 'M35', 'RAH-264'],
    },
    {
        'id': 'conditional_form_allocation_history',
        'phase': 'PRE_COURSE',
        'criticality': 'P0',
        'fields': ['rangs_3_dernieres', 'rangs_4_dernieres', 'rangs_6_dernieres', 'nb_partants_4_dernieres', 'rangs_relatifs_4', 'allocations_last3', 'categories_allocations_6', 'ee_categories_6', 'ee_scores_6', 'macro_groupe'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['GENY', 'LETROT', 'FRANCE_GALOP', 'TURF_BZH', 'ZONE_TURF', 'CANALTURF'],
        'resolution': ['historique rattaché au cheval', 'fiche course précédente', 'musique avec rang explicitement parsable'],
        'evidence': ['numero', 'nom_normalise', 'date_course_anterieure', 'rang', 'partants_course', 'source_url'],
        'normalization': 'Rang et taille du champ restent séparés; une musique sans date ou sans taille de champ ne permet pas de fabriquer un rang relatif.',
        'minimum_evidence': {'rangs_3_dernieres': 3, 'rangs_4_dernieres': 4, 'rangs_6_dernieres': 6, 'source_identity': True},
        'fallback': 'Accepter un échantillon plus court uniquement en mode DEGRADED et enregistrer le nombre observé.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'FORME/PENTE/STAB/CRE_PROXY ne calculent que sur l’échantillon observé; aucune moyenne fictive.',
        'consumers': ['FORME_LINEAIRE', 'PENTE', 'STAB', 'CRE_PROXY', 'SRI', 'IQL', 'B47'],
    },
    {
        'id': 'conditional_context_distance_terrain',
        'phase': 'PRE_COURSE',
        'criticality': 'P0',
        'fields': ['historique_terrain_perf', 'historique_distances_perf', 'historique_parcours_exact', 'nb_courses_hippodrome', 'profil_hippodrome_similaire', 'numero_corde', 'sens_corde_officiel', 'sens_rotation_historique', 'meteo_snapshot', 'penetrometre'],
        'disciplines': ['PLAT', 'OBSTACLE', 'HAIES', 'TROT_ATTELE', 'TROT_MONTE'],
        'source_order': ['FRANCE_GALOP', 'LETROT', 'GENY', 'EQUIDIA', 'TURF_BZH', 'ZONE_TURF'],
        'resolution': ['programme officiel', 'fiche hippodrome', 'historique filtré distance ±50 m', 'météo horodatée'],
        'evidence': ['date', 'hippodrome', 'distance', 'terrain', 'piste', 'corde', 'source_url', 'retrieval_timestamp'],
        'normalization': 'Conserver distance, terrain et piste de l’observation; ne pas assimiler une prévision météo au terrain officiel.',
        'minimum_evidence': {'current_context': True, 'historical_match': 1, 'source_identity': True},
        'fallback': 'Le contexte courant peut rester OBSERVED sans historique; le module historique devient UNPROVEN.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'TERRAIN_DYN/DIST_ADAPT/GRU ne doivent activer un bonus que si la correspondance est explicite.',
        'consumers': ['MODULE_TERRAIN_DYN', 'MODULE_DIST_ADAPT', 'GRU', 'RAH-85', 'RAH-89', 'RAH-118'],
    },
    {
        'id': 'conditional_jockey_trainer_windows',
        'phase': 'PRE_COURSE',
        'criticality': 'P1',
        'fields': ['jockey_windows', 'trainer_windows', 'driver_classement_national', 'driver_classement_hebdomadaire', 'driver_classement_12m', 'taux_victoires', 'taux_place', 'feu_equidia', 'bio_rythme_saisonnier'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['EQUIDIA', 'GENY', 'LETROT', 'FRANCE_GALOP', 'TURF_BZH', 'ZONE_TURF'],
        'resolution': ['fiche jockey/driver', 'fiche entraîneur', 'tableau daté 7/14/30/60 jours'],
        'evidence': ['nom_personne', 'date_debut', 'date_fin', 'population', 'denominateur', 'source_url'],
        'normalization': 'Toute fenêtre doit porter ses dates; un taux sans dénominateur ou sans période est UNPROVEN.',
        'minimum_evidence': {'window_period': True, 'denominator': True, 'source_identity': True},
        'fallback': 'Repli vers une fenêtre plus longue seulement avec statut DEGRADÉ explicite; ne pas convertir l’absence en 0.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'BSH/BSC/IFF/GAMMA utilisent la fenêtre correspondante ou restent UNPROVEN.',
        'consumers': ['BSH_v3v4', 'BSC_v3', 'IFF_v2', 'TACT', 'GAMMA', 'RAH-82'],
    },
    {
        'id': 'conditional_speed_incidents',
        'phase': 'PRE_COURSE',
        'criticality': 'P1',
        'fields': ['chrono_200m', 'chrono_1km', 'rk_array', 'rk_incident_flag', 'rk_ref_tiers', 'commentaire_derniere_course', 'delai_j', 'nb_courses_30j', 'iff_seuil_surmenage'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['LETROT', 'FRANCE_GALOP', 'EQUIDIA', 'GENY', 'TURF_BZH', 'ZONE_TURF'],
        'resolution': ['fiche performance précédente', 'chronomètre détaillé', 'incident ou disqualification explicitement publié'],
        'evidence': ['date_course', 'distance', 'chrono', 'incident_type', 'source_url', 'retrieval_timestamp'],
        'normalization': 'Ne jamais confondre RK brute, classement d’arrivée et rang presse; conserver chaque type dans une clé différente.',
        'minimum_evidence': {'rk_for_cre_v2': 3, 'source_identity': True},
        'fallback': 'CRE_PROXY seulement si au moins trois RK/performances admissibles sont observées; sinon NC/UNPROVEN.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'RK absente ne remplit jamais rk_brute; RAH-29 TROT conserve son STOP historique.',
        'consumers': ['CRE_v2', 'CRE_PROXY_v3', 'TACT', 'IFF_v2', 'SRI', 'D45', 'SUPRA'],
    },
    {
        'id': 'conditional_h2h_tandem',
        'phase': 'PRE_COURSE',
        'criticality': 'P1',
        'fields': ['h2h_avg', 'h2h_scores', 'taux_top5_tandem', 'coeff_nb_tandem', 'coeff_temps_tandem', 'nb_courses_ensemble', 'synergie_jch', 'harville_correlation_matrix'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['GENY', 'EQUIDIA', 'LETROT', 'FRANCE_GALOP', 'TURF_BZH', 'ZONE_TURF'],
        'resolution': ['fiche H2H', 'fiche tandem cheval-personne', 'résultats communs identifiés par date'],
        'evidence': ['horse_number', 'person_name', 'shared_race_date', 'shared_race_count', 'source_url'],
        'normalization': 'Les courses communes et l’identité des partenaires doivent être observées; aucune synergie depuis le seul nom.',
        'minimum_evidence': {'h2h_shared_races': 1, 'tandem_shared_races': 1, 'source_identity': True},
        'fallback': 'H2H/TANDEM neutre ou UNPROVEN; Harville n’est calculé que sur corrélation sourcée.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'COMPOSITE/ORDRE ne reçoit aucun bonus relationnel silencieux.',
        'consumers': ['H2H_GRAPH', 'TANDEM_BONUS', 'COMPOSITE', 'Harville', 'ORDRE_SCORE'],
    },
    {
        'id': 'conditional_declarations_and_qualitative',
        'phase': 'PRE_COURSE',
        'criticality': 'P1',
        'fields': ['declaration_entraineur_pre_course', 'turf_bzh_avis', 'turf_bzh_sigma', 'press_top5', 'press_top5_sources', 'press_divergence', 'ssfo_signals', 'gamma_signals', 'ghost_signals'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['TURF_BZH', 'EQUIDIA', 'GENY', 'ZONE_TURF', 'CANALTURF', 'RTL', 'FREQUENCE_TURF', 'TURFOO', 'PARIS_TURF'],
        'resolution': ['article ou bloc éditorial date/R/C', 'auteur et horodatage', 'numéro cité explicitement'],
        'evidence': ['source_url', 'retrieval_timestamp', 'author_or_editor', 'quoted_text_hash', 'cited_numbers'],
        'normalization': 'Conserver texte brut, hash et extraction structurée; une page accessible sans citation exacte est UNPROVEN.',
        'minimum_evidence': {'top5_numbers': 5, 'source_identity': True},
        'fallback': 'Chaque source est tentée indépendamment; aucun silence ne devient non-citation.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'Presse et catalogues influencent le moteur uniquement sur citations OBSERVED; consensus minimum selon politique presse.',
        'consumers': ['ICP', 'SUPRA', 'LONGSHOTS', 'GHOST', 'SSFO', 'GAMMA', 'RAH-212', 'RAH-232'],
    },
    {
        'id': 'conditional_post_course_details',
        'phase': 'POST_COURSE',
        'criticality': 'P0',
        'fields': ['rapports_officiels', 'non_runners', 'disqualifications', 'fall_or_incident', 'dead_heat_or_special_case', 'arrival_position_per_runner'],
        'disciplines': ['TROT_ATTELE', 'TROT_MONTE', 'PLAT', 'OBSTACLE', 'HAIES'],
        'source_order': ['PMU_OFFICIEL', 'EQUIDIA_RESULTATS', 'ZONE_TURF_RESULTATS', 'CANALTURF_RESULTATS'],
        'resolution': ['fiche résultat exacte date/R/C', 'identité complète par source', 'table arrivée ou texte officiel'],
        'evidence': ['date', 'reunion', 'numero_course', 'hippodrome', 'source_url', 'retrieval_timestamp', 'source_order_hash'],
        'normalization': 'Chaque détail est stocké par source; ne jamais déduire une disqualification, chute ou rapport à partir d’une arrivée seule.',
        'minimum_evidence': {'identity_sources': 2, 'arrival_top5_sources': 2},
        'fallback': 'Deux sources concordantes autorisent l’audit avec MEDIUM; trois ou plus donnent HIGH; conflit conservé.',
        'missing_status': 'NC',
        'unproven_status': 'UNPROVEN',
        'module_policy': 'Les causes racines utilisent uniquement les incidents et rapports prouvés; sinon cause `DATA_UNPROVEN`.',
        'consumers': ['POST_COURSE_AUDIT', 'ROOT_CAUSES', 'CAPTURE_TOP5', 'REPORTS'],
    },
]


def construire_plan_conditionnel(date: str, reunion: int, numero_course: int, discipline: str = '') -> Dict[str, Any]:
    """Retourne le plan de collecte conditionnelle pour une course."""
    discipline_u = str(discipline or '').upper()
    contracts = [
        contract for contract in CONDITIONAL_DATA_CONTRACTS
        if not discipline_u or discipline_u in contract['disciplines']
    ]
    return {
        'identity': {'date': date, 'reunion': reunion, 'numero_course': numero_course, 'discipline': discipline or None},
        'contracts': contracts,
        'source_order': list(SOURCE_ORDER),
        'policy': {
            'exact_identity_required': True,
            'observed_only_for_scoring': True,
            'missing_status': 'NC',
            'unproven_status': 'UNPROVEN',
            'no_silent_defaults': True,
            'retain_attempt_reason': True,
        },
    }


def valider_contrat_conditionnel() -> List[str]:
    """Valide la complétude structurelle du contrat sans sonder le réseau."""
    errors: List[str] = []
    required_keys = ('id', 'phase', 'fields', 'disciplines', 'source_order', 'resolution', 'evidence', 'minimum_evidence', 'fallback', 'missing_status', 'unproven_status', 'module_policy', 'consumers')
    for contract in CONDITIONAL_DATA_CONTRACTS:
        for key in required_keys:
            if not contract.get(key):
                errors.append(f"{contract.get('id', 'UNKNOWN')}: clé absente {key}")
        if contract.get('missing_status') != 'NC':
            errors.append(f"{contract.get('id', 'UNKNOWN')}: missing_status doit être NC")
        if contract.get('unproven_status') != 'UNPROVEN':
            errors.append(f"{contract.get('id', 'UNKNOWN')}: unproven_status doit être UNPROVEN")
    return errors
