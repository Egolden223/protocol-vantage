"""
Résolution et collecte d'une course à partir de ses identifiants.

Le module ne suppose jamais qu'une URL ou un PDF a été fourni par l'utilisateur.
Il dérive des URL candidates à partir de date/réunion/course, consulte les
collecteurs existants et conserve un journal de résolution exploitable par
l'application.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from collectors.auto_scraper import collecter_automatique, scraper_api_pmu
from collectors.source_orchestrator import (
    enrichir_rapport_sources,
    appliquer_preuves_presse_partants,
    appliquer_preuves_marche_partants,
    consolider_tableau_donnees,
    appliquer_tableau_consolide_aux_partants,
    evaluer_garde_multisource,
)


class CourseResolutionError(ValueError):
    """Erreur lorsqu'une course ne peut pas être identifiée sans ambiguïté."""


def _optionnel_texte(payload: Dict[str, Any], key: str) -> Optional[str]:
    """Normalise un champ optionnel sans transformer une absence en valeur réelle."""
    value = payload.get(key)
    if value is None:
        return None
    text = str(value).strip().upper()
    return None if text in {"", "NONE", "NULL", "NC", "N/A", "NA"} else text


def normaliser_identifiants_course(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Valide et normalise les identifiants fournis par l'utilisateur."""
    if not isinstance(payload, dict):
        raise CourseResolutionError("Le corps de requête doit être un objet JSON")

    date_value = str(payload.get("date", "")).strip()
    reunion_value = payload.get("reunion")
    course_value = payload.get("numero_course", payload.get("course"))

    if not date_value:
        raise CourseResolutionError("Le champ date est obligatoire")
    try:
        date_obj = datetime.strptime(date_value, "%Y-%m-%d")
    except ValueError as exc:
        raise CourseResolutionError("La date doit respecter le format AAAA-MM-JJ") from exc

    try:
        reunion = int(reunion_value)
        numero_course = int(course_value)
    except (TypeError, ValueError) as exc:
        raise CourseResolutionError("reunion et numero_course doivent être des entiers") from exc

    if reunion < 1 or reunion > 20:
        raise CourseResolutionError("La réunion doit être comprise entre 1 et 20")
    if numero_course < 1 or numero_course > 20:
        raise CourseResolutionError("Le numéro de course doit être compris entre 1 et 20")

    return {
        "date": date_obj.strftime("%Y-%m-%d"),
        "date_pmu": date_obj.strftime("%d%m%Y"),
        "reunion": reunion,
        "numero_course": numero_course,
        "hippodrome_attendu": _optionnel_texte(payload, "hippodrome_attendu"),
        "discipline_attendue": _optionnel_texte(payload, "discipline_attendue"),
        "heure_depart_attendue": payload.get("heure_depart_attendue"),
        "mode_execution": payload.get("mode_execution", "AUTO_CONTINUE"),
    }


def construire_urls_candidates(ids: Dict[str, Any]) -> List[str]:
    """Construit les URL publiques candidates sans demander d'URL à l'utilisateur."""
    date_pmu = ids["date_pmu"]
    reunion = ids["reunion"]
    course = ids["numero_course"]
    return [
        f"https://www.turf.bzh/pronostics-pmu-{date_pmu}-R{reunion}C{course}.html",
        f"https://www.pmu.fr/turf/programme/{date_pmu}/R{reunion}/C{course}",
    ]


def _normaliser_participants_pmu(participants: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convertit les participants PMU bruts vers le contrat de l'application."""
    normalises: List[Dict[str, Any]] = []
    for raw in participants:
        if not isinstance(raw, dict):
            continue
        cote = raw.get("coteDirect", raw.get("dernierRapportDirect", None))
        if isinstance(cote, dict):
            cote = cote.get("coteDirect", cote.get("rapport", None))
        try:
            cote_value = float(cote) if cote not in (None, "") else None
        except (TypeError, ValueError):
            cote_value = None
        poids = raw.get("poidsConditionMonte", raw.get("handicapPoids", None))
        try:
            poids_value = float(poids) / 10 if poids not in (None, "") else None
        except (TypeError, ValueError):
            poids_value = None
        normalises.append({
            "numero": raw.get("numPmu", raw.get("numero")),
            "nom": raw.get("nom"),
            "cote": cote_value,
            "driver_jockey": raw.get("driver", raw.get("jockey")),
            "entraineur": raw.get("entraineur"),
            "age": raw.get("age"),
            "sexe": raw.get("sexe"),
            "poids": poids_value,
            "rk_brute": raw.get("rkBrute", raw.get("rk_brute")),
            "source_status": "OBSERVED",
        })
    return normalises


def _appliquer_identifiants_utilisateur(resultat: Dict[str, Any], ids: Dict[str, Any]) -> None:
    """Utilise uniquement les champs facultatifs explicitement saisis par l'utilisateur.

    Ce repli ne fabrique aucune donnée : un hippodrome ou une discipline ne peut
    être repris que si l'utilisateur l'a fourni dans la requête et si la source
    correspondante n'a pas résolu le champ.
    """
    hippodrome = str(resultat.get("hippodrome", "") or "").strip().upper()
    attendu_hippo = ids.get("hippodrome_attendu")
    if attendu_hippo and (not hippodrome or hippodrome in {"NC", "INCONNU", "NONE"}):
        resultat["hippodrome"] = attendu_hippo
        resultat.setdefault("rapport_collecte", {}).setdefault("warnings", []).append(
            "Hippodrome fourni par l'utilisateur utilisé car non résolu par les sources"
        )

    discipline = str(resultat.get("discipline", "") or "").strip().upper()
    attendu_disc = ids.get("discipline_attendue")
    if attendu_disc and (not discipline or discipline in {"NC", "INCONNU", "NONE"}):
        resultat["discipline"] = attendu_disc
        resultat.setdefault("rapport_collecte", {}).setdefault("warnings", []).append(
            "Discipline fournie par l'utilisateur utilisée car non résolue par les sources"
        )


def _identite_coherente(resultat: Dict[str, Any], ids: Dict[str, Any]) -> Dict[str, Any]:
    """Contrôle les informations identifiantes sans inventer les champs absents."""
    erreurs: List[str] = []
    hippodrome = str(resultat.get("hippodrome", "")).strip().upper()
    discipline = str(resultat.get("discipline", "")).strip().upper()
    nb_partants = int(resultat.get("nb_partants") or len(resultat.get("partants", [])))

    if not hippodrome or hippodrome == "INCONNU":
        erreurs.append("HIPpodrome non résolu")
    if not discipline or discipline in {"NC", "NONE"}:
        erreurs.append("Discipline non résolue")
    if nb_partants <= 0:
        erreurs.append("Aucun partant collecté")

    attendu_hippo = ids.get("hippodrome_attendu")
    if attendu_hippo and hippodrome and attendu_hippo not in hippodrome:
        erreurs.append(f"Conflit hippodrome: attendu={attendu_hippo}, obtenu={hippodrome}")

    attendu_disc = ids.get("discipline_attendue")
    if attendu_disc and discipline and attendu_disc not in discipline:
        erreurs.append(f"Conflit discipline: attendu={attendu_disc}, obtenu={discipline}")

    return {
        "statut": "PASS" if not erreurs else "FAIL",
        "erreurs": erreurs,
        "hippodrome": hippodrome or None,
        "discipline": discipline or None,
        "nb_partants": nb_partants,
    }


def construire_evidence_ledger(collecte: Dict[str, Any], ids: Dict[str, Any]) -> Dict[str, Any]:
    """Construit une traçabilité minimale pour les champs de course et partants."""
    collecte_report = collecte.get("rapport_collecte", {})
    sources = list(collecte_report.get("sources_prioritaires", [])) + list(collecte_report.get("sources_consultees", [])) + list(collecte_report.get("sources_secondaires", []))
    ledger: List[Dict[str, Any]] = []

    def add(path: str, value: Any, source: str, status: str, reason: str = "") -> None:
        ledger.append({
            "path": path,
            "value": value,
            "source": source,
            "status": status,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "reason": reason,
        })

    source_names = [s.get("source", "UNKNOWN") for s in sources]
    source_label = ", ".join(source_names) if source_names else "NONE"
    course_fields = ["date", "hippodrome", "discipline", "distance", "terrain", "nb_partants"]
    for field in course_fields:
        value = collecte.get(field)
        if value not in (None, "", 0, "NC", "INCONNU"):
            add(f"course.{field}", value, source_label, "OBSERVED")
        else:
            add(f"course.{field}", None, source_label, "NC", "Champ absent après collecte autorisée")

    for partant in collecte.get("partants", []):
        numero = partant.get("numero", "NC")
        field_sources = partant.get("field_sources", {}) or {}
        field_quality = partant.get("data_quality", {}) or {}
        for field in ("nom", "cote", "driver_jockey", "entraineur", "age", "sexe", "poids"):
            value = partant.get(field)
            source = field_sources.get(field, source_label)
            quality = field_quality.get(field)
            if value not in (None, "", 0, "NC") and source not in (None, "", "NONE"):
                add(f"partants[{numero}].{field}", value, source, quality or "OBSERVED")
            else:
                add(f"partants[{numero}].{field}", None, source or "NONE", "NC", "Champ absent après collecte autorisée")

    return {
        "identifiants_entree": ids,
        "sources": sources,
        "entries": ledger,
        "nb_entries": len(ledger),
    }


def collecter_course_par_identifiants(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Résout et collecte une course sans PDF ni URL imposée à l'utilisateur."""
    ids = normaliser_identifiants_course(payload)
    urls = construire_urls_candidates(ids)
    tentatives: List[Dict[str, Any]] = []
    collecte_finale: Optional[Dict[str, Any]] = None

    # La première URL est le fournisseur de données riche ; le collecteur appelle
    # également l'API PMU officielle avec les identifiants de la course.
    for url in urls[:1]:
        resultat = collecter_automatique(url)
        tentatives.append({
            "url": url,
            "statut": resultat.get("statut", "ERREUR"),
            "rapport": resultat.get("rapport_collecte", {}),
        })
        if resultat.get("statut") == "OK" and resultat.get("partants"):
            collecte_finale = resultat
            break

    # Repli officiel direct, sans considérer un champ absent comme observé.
    if collecte_finale is None:
        pmu = scraper_api_pmu(ids["date_pmu"], ids["reunion"], ids["numero_course"])
        tentatives.append({
            "source": "API_PMU_DIRECTE",
            "statut": pmu.get("statut", "ERREUR"),
            "participants": len(pmu.get("participants", [])),
        })
        if pmu.get("statut") == "OK" and pmu.get("participants"):
            info = pmu.get("course_info", {})
            collecte_finale = {
                "statut": "OK",
                "date": ids["date"],
                "hippodrome": str(info.get("hippodrome", "")).upper() or "NC",
                "numero_course": ids["numero_course"],
                "nom_course": info.get("libelle", ""),
                "discipline": info.get("discipline", info.get("specialite", "")) or "NC",
                "distance": info.get("distance"),
                "terrain": info.get("terrain"),
                "type_depart": info.get("conditions", ""),
                "est_handicap": "HANDICAP" in str(info.get("conditions", "")).upper(),
                "nb_partants": len(pmu["participants"]),
                "partants": _normaliser_participants_pmu(pmu["participants"]),
                "rapport_collecte": {"sources_consultees": [{"source": "API_PMU_DIRECTE", "statut": "OK"}], "warnings": []},
            }

    if collecte_finale is None:
        return {
            "statut": "ERREUR",
            "erreur_code": "COURSE_NOT_RESOLVED",
            "identifiants": ids,
            "tentatives": tentatives,
            "rapport_collecte": {"sources_consultees": [], "erreurs": ["Course non résolue"]},
        }

    ids = {**ids, 'discipline': collecte_finale.get('discipline', ''), 'hippodrome': collecte_finale.get('hippodrome', '')}
    collecte_finale["rapport_collecte"] = enrichir_rapport_sources(
        ids,
        collecte_finale.get("rapport_collecte", {}),
        collecte_finale.get("partants", []),
        course_context=collecte_finale,
    )
    _appliquer_identifiants_utilisateur(collecte_finale, ids)
    collecte_finale["partants"] = appliquer_preuves_marche_partants(
        collecte_finale.get("partants", []), collecte_finale.get("rapport_collecte", {})
    )
    collecte_finale["partants"] = appliquer_preuves_presse_partants(
        collecte_finale.get("partants", []),
        collecte_finale["rapport_collecte"].get("press_consensus", {}),
    )
    final_tableau = consolider_tableau_donnees(
        collecte_finale.get('partants', []),
        collecte_finale.get('rapport_collecte', {}).get('source_attempts', []),
        collecte_finale.get('rapport_collecte', {}).get('sources_consultees', []),
        course_context=collecte_finale,
    )
    collecte_finale['rapport_collecte']['consolidated_data_table'] = final_tableau
    # Le tableau consolidé est la source d’entrée du moteur, et pas seulement
    # une pièce de reporting. Les cellules OBSERVED sont réinjectées avant la
    # garde finale; les cellules NC/UNPROVEN restent explicitement absentes.
    collecte_finale['partants'] = appliquer_tableau_consolide_aux_partants(
        collecte_finale.get('partants', []), final_tableau
    )
    # Baseline neutre uniquement après épuisement multisource démontré :
    # aucune valeur factuelle n’est créée et aucun champ OBSERVED n’est écrasé.
    from engine.neutral_imputation import apply_neutral_imputations
    collecte_finale['partants'], neutral_report = apply_neutral_imputations(
        collecte_finale.get('partants', []),
        final_tableau,
        collecte_finale.get('rapport_collecte', {}),
    )
    collecte_finale['rapport_collecte']['neutral_imputation'] = neutral_report
    collecte_finale['rapport_collecte']['multisource_gate'] = evaluer_garde_multisource(
        collecte_finale.get('rapport_collecte', {}), final_tableau
    )
    coherence = _identite_coherente(collecte_finale, ids)
    collecte_finale["resolution"] = {
        "identifiants": ids,
        "urls_candidates": urls,
        "tentatives": tentatives,
        "coherence": coherence,
    }
    collecte_finale["evidence_ledger"] = construire_evidence_ledger(collecte_finale, ids)

    gate = collecte_finale.get('rapport_collecte', {}).get('multisource_gate', {})
    if coherence["statut"] != "PASS":
        collecte_finale["statut"] = "ERREUR"
        collecte_finale["erreur_code"] = "COURSE_IDENTITY_INCOMPLETE"
    elif gate.get('blocking'):
        collecte_finale['statut'] = 'ERREUR'
        collecte_finale['erreur_code'] = 'MULTISOURCE_COVERAGE_INSUFFICIENT'
        collecte_finale['erreur'] = {
            'code': 'MULTISOURCE_COVERAGE_INSUFFICIENT',
            'reasons': gate.get('reasons', []),
            'minimum_sources': gate.get('minimum_sources', 3),
            'effective_source_count': gate.get('effective_source_count', 0),
            'coverage_percent': gate.get('coverage_percent', 0.0),
            'coverage_threshold_percent': gate.get('coverage_threshold_percent', 80.0),
            'all_partants_couverture': gate.get('all_partants_couverture', False),
            'policy': 'AUCUNE_POURSUIVRE_AVANT_COLLECTE_CONSOLIDEE',
        }

    return collecte_finale
