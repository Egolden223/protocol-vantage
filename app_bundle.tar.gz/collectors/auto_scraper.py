"""
PROTOCOL VANTAGE — Auto-Scraper Multi-Sources v2
Collecte automatique COMPLÈTE depuis une URL de course.
Exploite les données JSON embarquées de turf.bzh (rdaRawData) + API PMU officielle.
Détecte les signaux automatiquement à partir des données réelles.
"""
import re
import html as html_lib
import requests
from bs4 import BeautifulSoup
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import time
import math

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.models import Course, Partant, Discipline, TypeDepart, Signal


# =============================================================================
# HEADERS HTTP
# =============================================================================

def _normaliser_nom_cheval(value: Any) -> str:
    """Décode les entités HTML sans modifier le nom observé autrement."""
    return html_lib.unescape(str(value or "")).strip()


def get_headers() -> Dict[str, str]:
    return {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.7",
        "Connection": "keep-alive",
    }


def _market_quote(report: Any, source: str, kind: str) -> Dict[str, Any]:
    """Normalise un rapport de cote sans transformer une absence en observation."""
    if isinstance(report, dict):
        value = report.get("rapport")
        timestamp_ms = report.get("dateRapport")
        try:
            value = float(value) if value not in (None, "", "NC") and float(value) > 0 else None
        except (TypeError, ValueError):
            value = None
        try:
            timestamp = datetime.fromtimestamp(float(timestamp_ms) / 1000.0).isoformat() if timestamp_ms else None
        except (TypeError, ValueError, OverflowError):
            timestamp = None
        return {
            "value": value,
            "timestamp": timestamp,
            "timestamp_ms": timestamp_ms,
            "source": source,
            "kind": kind,
            "status": "OBSERVED" if value is not None and timestamp else "UNPROVEN",
            "raw": report,
        }
    return {"value": None, "timestamp": None, "source": source, "kind": kind, "status": "UNPROVEN", "raw": report}


def construire_market_data_pmu(pmu_partant: Dict[str, Any], turf_partant: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Construit le contrat marché avec deux rapports PMU indépendants."""
    reference = _market_quote(pmu_partant.get("dernierRapportReference"), "API_PMU", "REFERENCE")
    direct = _market_quote(pmu_partant.get("dernierRapportDirect"), "API_PMU", "LAST_PRE_RACE")
    secondary = []
    turf_quote = (turf_partant or {}).get("cote")
    try:
        turf_quote = float(turf_quote) if turf_quote not in (None, "", "NC") and float(turf_quote) > 0 else None
    except (TypeError, ValueError):
        turf_quote = None
    if turf_quote is not None:
        secondary.append({"value": turf_quote, "timestamp": None, "source": "TURF_BZH", "kind": "UNSTAMPED_CURRENT", "status": "OBSERVED_UNTIMESTAMPED"})
    ref_value = reference.get("value")
    last_value = direct.get("value")
    delta = None
    fluctuation = None
    if ref_value and last_value:
        delta = ref_value - last_value
        fluctuation = delta / ref_value
    snapshots = [item for item in (reference, direct) if item.get("status") == "OBSERVED"]
    return {
        "reference_quote": reference,
        "last_pre_race_quote": direct,
        "sov_snapshots": snapshots,
        "secondary_observations": secondary,
        "cote_matin": None,
        "cote_veille": None,
        "cote_reference": ref_value,
        "cote_avant_course": last_value,
        "cote_15m": last_value,
        "cote_finale": last_value or turf_quote,
        "delta_cote": delta,
        "fluctuation_relative": fluctuation,
        "sov_v2_input_status": "READY_TWO_POINTS" if ref_value and last_value else "UNPROVEN",
        "source_policy": "API_PMU_REFERENCE_PLUS_DIRECT; TURF_BZH_SECONDARY_UNSTAMPED",
    }


# =============================================================================
# EXTRACTION D'INFOS DEPUIS L'URL
# =============================================================================

def extraire_info_url(url: str) -> Dict[str, Any]:
    """Extrait date, réunion, course depuis l'URL."""
    info = {"url": url, "date": None, "reunion": None, "course": None, "date_pmu": None}

    # Format turf.bzh: pronostics-pmu-DDMMYYYY-R1C1.html
    match = re.search(r'(\d{8})-R(\d+)C(\d+)', url)
    if match:
        date_str = match.group(1)
        info["date"] = f"{date_str[4:8]}-{date_str[2:4]}-{date_str[0:2]}"
        info["date_pmu"] = date_str
        info["reunion"] = int(match.group(2))
        info["course"] = int(match.group(3))
        return info

    # Format PMU: /turf/DDMMYYYY/R1/C1 ou /DDMMYYYY/R1/C1
    match = re.search(r'(\d{8})/R(\d+)/C(\d+)', url)
    if match:
        date_str = match.group(1)
        info["date"] = f"{date_str[4:8]}-{date_str[2:4]}-{date_str[0:2]}"
        info["date_pmu"] = date_str
        info["reunion"] = int(match.group(2))
        info["course"] = int(match.group(3))
        return info

    # Format avec date YYYY-MM-DD
    match = re.search(r'(\d{4}-\d{2}-\d{2})', url)
    if match:
        info["date"] = match.group(1)
        date_obj = datetime.strptime(match.group(1), "%Y-%m-%d")
        info["date_pmu"] = date_obj.strftime("%d%m%Y")

    match = re.search(r'R(\d+)', url, re.IGNORECASE)
    if match:
        info["reunion"] = int(match.group(1))
    match = re.search(r'C(\d+)', url, re.IGNORECASE)
    if match:
        info["course"] = int(match.group(1))

    return info


# =============================================================================
# SCRAPING TURF.BZH — Extraction des données JSON embarquées
# =============================================================================

def _extraire_course_info_embedded_json(page_html: str) -> Dict[str, Any]:
    """Extrait uniquement les scalaires du programme PMU embedded observés dans la page."""
    info: Dict[str, Any] = {}
    text_patterns = {
        "libelle": r'"libelle"\s*:\s*"([^"]+)"',
        "discipline": r'"discipline"\s*:\s*"([^"]+)"',
        "specialite": r'"specialite"\s*:\s*"([^"]+)"',
        "corde": r'"corde"\s*:\s*"([^"]+)"',
        "categorieParticularite": r'"categorieParticularite"\s*:\s*"([^"]+)"',
        "conditions": r'"conditions"\s*:\s*"((?:[^"\\]|\\.)*)"',
    }
    for key, pattern in text_patterns.items():
        match = re.search(pattern, page_html, re.IGNORECASE | re.DOTALL)
        if match and match.group(1).strip():
            info[key] = match.group(1).strip()
    # `specialite` est le champ normatif du programme; il prime sur les occurrences
    # éditoriales génériques de `discipline` présentes ailleurs dans la page.
    if info.get('specialite'):
        info['discipline'] = info['specialite']
    numeric_patterns = {
        "distance": r'"distance"\s*:\s*(\d+)',
        "montantTotalOffert": r'"montantTotalOffert"\s*:\s*(\d+(?:\.\d+)?)',
        "nombreDeclaresPartants": r'"nombreDeclaresPartants"\s*:\s*(\d+)',
    }
    for key, pattern in numeric_patterns.items():
        match = re.search(pattern, page_html, re.IGNORECASE)
        if match:
            info[key] = float(match.group(1)) if '.' in match.group(1) else int(match.group(1))
    return info


def _extraire_hippodrome_embedded_json(page_html: str) -> Optional[str]:
    """Extrait le libellé court de l'hippodrome depuis l'objet programme embedded."""
    patterns = (
        r'"hippodrome"\s*:\s*\{.*?"libelleCourt"\s*:\s*"([^"]+)"',
        r'"hippodrome"\s*:\s*"([^"]+)"',
    )
    for pattern in patterns:
        match = re.search(pattern, page_html, re.IGNORECASE | re.DOTALL)
        if match and match.group(1).strip():
            return match.group(1).strip()
    return None


def _extraire_discipline_embedded_json(page_html: str) -> Optional[str]:
    """Extrait la discipline du programme embarqué sans déduire depuis un texte éditorial."""
    patterns = (
        r'"specialite"\s*:\s*"([^"]+)"',
        r'"discipline"\s*:\s*"([^"]+)"',
        r'\bdisciplineCode\s*:\s*["\']([^"\']+)["\']',
    )
    for pattern in patterns:
        match = re.search(pattern, page_html, re.IGNORECASE)
        if match and match.group(1).strip():
            return match.group(1).strip()
    return None


def scraper_turf_bzh(url: str) -> Dict[str, Any]:
    """
    Scrape turf.bzh et extrait les données JSON embarquées (rdaRawData).
    C'est la source la plus riche : cotes, ELO, IA, taux, repos, etc.
    """
    try:
        response = requests.get(url, headers=get_headers(), timeout=20)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        html = response.text

        result = {
            "statut": "OK",
            "source": "turf.bzh",
            "course_info": {},
            "partants": [],
            "pronostics_gagnant": [],
            "pronostics_place": [],
            "analyses_ia": [],
        }

        # 1. Extraire les infos de course depuis les tbz-stat
        stats = soup.find_all(class_='tbz-stat')
        for s in stats:
            lbl = s.find(class_='tbz-stat-lbl')
            val = s.find(class_='tbz-stat-val')
            if lbl and val:
                label = lbl.get_text(strip=True).lower()
                value = val.get_text(strip=True)
                if 'hippodrome' in label:
                    result["course_info"]["hippodrome"] = value.upper()
                elif 'discipline' in label:
                    result["course_info"]["discipline"] = value.upper()
                elif 'distance' in label:
                    dist_match = re.search(r'(\d[\d\s]*)', value)
                    if dist_match:
                        result["course_info"]["distance"] = int(dist_match.group(1).replace(' ', ''))
                elif 'partants' in label:
                    result["course_info"]["nb_partants"] = int(value)

        embedded_info = _extraire_course_info_embedded_json(html)
        if embedded_info:
            result["course_info"].update({key: value for key, value in embedded_info.items() if value not in (None, "")})
            result["course_info"]["embedded_program_source"] = "turf.bzh:embedded_program_json"

        # Le nouveau gabarit turf.bzh expose l’identité dans le JSON du programme,
        # même lorsque les blocs tbz-stat ne contiennent plus l’hippodrome ou la discipline.
        if not result["course_info"].get("hippodrome"):
            embedded_hippodrome = _extraire_hippodrome_embedded_json(html)
            if embedded_hippodrome:
                result["course_info"]["hippodrome"] = embedded_hippodrome.upper()
                result["course_info"]["hippodrome_source"] = "turf.bzh:embedded_program_json"
        if not result["course_info"].get("discipline"):
            embedded_discipline = _extraire_discipline_embedded_json(html)
            if embedded_discipline:
                result["course_info"]["discipline"] = embedded_discipline.upper()
                result["course_info"]["discipline_source"] = "turf.bzh:embedded_program_json"

        # Terrain
        terrain_match = re.search(r'Terrain\s+(Souple|Bon|Lourd|Collant|Léger|Sec)\s*\((\d+[.,]\d+)\)', html)
        if terrain_match:
            result["course_info"]["terrain"] = terrain_match.group(1).upper()
            result["course_info"]["terrain_indice"] = float(terrain_match.group(2).replace(',', '.'))

        if result["course_info"].get("categorieParticularite") and not result["course_info"].get("type_depart"):
            result["course_info"]["type_depart"] = result["course_info"]["categorieParticularite"]
        if result["course_info"].get("corde") and not result["course_info"].get("piste"):
            result["course_info"]["piste"] = result["course_info"]["corde"]
        if result["course_info"].get("montantTotalOffert") is not None and not result["course_info"].get("allocation"):
            result["course_info"]["allocation"] = result["course_info"]["montantTotalOffert"]

        # Handicap
        if re.search(r'[Hh]andicap', html):
            result["course_info"]["est_handicap"] = True
        else:
            result["course_info"]["est_handicap"] = False

        # 2. Extraire rdaRawData (données JSON complètes des partants)
        scripts = soup.find_all('script')
        for s in scripts:
            text = s.string or ''
            if 'rdaRawData' in text:
                match = re.search(r'rdaRawData\s*=\s*(\[.*?\]);', text, re.DOTALL)
                if match:
                    try:
                        raw_data = json.loads(match.group(1))
                        result["partants"] = raw_data
                    except json.JSONDecodeError:
                        pass
                break

        # 3. Extraire les pronostics (tables de classement)
        tables = soup.find_all('table')
        # Table 2 = pronostics gagnant complet (12 partants)
        if len(tables) > 2:
            rows = tables[2].find_all('tr')
            for rank, row in enumerate(rows, 1):
                cells = row.find_all('td')
                if cells:
                    name_text = cells[0].get_text(strip=True)
                    pct_text = cells[1].get_text(strip=True) if len(cells) > 1 else "0%"
                    num_match = re.match(r'(\d+)\s*-\s*(.*)', name_text)
                    if num_match:
                        result["pronostics_gagnant"].append({
                            "rang": rank,
                            "numero": int(num_match.group(1)),
                            "nom": num_match.group(2).strip(),
                            "pourcentage": float(pct_text.replace('%', '').replace(',', '.'))
                        })

        # Table 5 = pronostics placé complet
        if len(tables) > 5:
            rows = tables[5].find_all('tr')
            for rank, row in enumerate(rows, 1):
                cells = row.find_all('td')
                if cells:
                    name_text = cells[0].get_text(strip=True)
                    pct_text = cells[1].get_text(strip=True) if len(cells) > 1 else "0%"
                    num_match = re.match(r'(\d+)\s*-\s*(.*)', name_text)
                    if num_match:
                        result["pronostics_place"].append({
                            "rang": rank,
                            "numero": int(num_match.group(1)),
                            "nom": num_match.group(2).strip(),
                            "pourcentage": float(pct_text.replace('%', '').replace(',', '.'))
                        })

        # 4. Extraire les analyses IA du tableau des partants (table 6)
        if len(tables) > 6:
            rows = tables[6].find_all('tr')[1:]  # Skip header
            for row in rows:
                cells = row.find_all('td')
                if len(cells) >= 4:
                    num = cells[0].get_text(strip=True)
                    nom = cells[1].get_text(strip=True)
                    avis = cells[2].get_text(strip=True)
                    analyse = cells[3].get_text(strip=True)
                    if num.isdigit():
                        result["analyses_ia"].append({
                            "numero": int(num),
                            "nom": nom,
                            "avis_note": avis,
                            "analyse": analyse[:500]
                        })

        return result

    except Exception as e:
        return {"statut": "ERREUR", "source": "turf.bzh", "message": str(e)}


# =============================================================================
# API PMU OFFICIELLE
# =============================================================================

def scraper_api_pmu(date_pmu: str, reunion: int, course_num: int) -> Dict[str, Any]:
    """
    Récupère les données depuis l'API PMU officielle.
    Fournit : jockeys, entraîneurs, poids, dernières cotes, historique.
    """
    result = {
        "statut": "ERREUR",
        "source": "API_PMU",
        "course_info": {},
        "participants": []
    }

    try:
        # Programme de la course
        url_prog = f"https://offline.turfinfo.api.pmu.fr/rest/client/1/programme/{date_pmu}/R{reunion}/C{course_num}"
        resp = requests.get(url_prog, headers=get_headers(), timeout=15)
        if resp.status_code == 200:
            try:
                data = resp.json()
            except (ValueError, TypeError):
                data = None
            if isinstance(data, dict):
                hippodrome_data = data.get("hippodrome")
                hippodrome_value = hippodrome_data.get("libelleCourt", "") if isinstance(hippodrome_data, dict) else (hippodrome_data or "")
                result["course_info"] = {
                    "libelle": data.get("libelle", ""),
                    "hippodrome": hippodrome_value,
                    "distance": data.get("distance", 0),
                    "discipline": data.get("discipline") or data.get("specialite", ""),
                    "specialite": data.get("specialite", ""),
                    "nb_partants": data.get("nombreDeclaresPartants", 0),
                    "conditions": data.get("conditions", ""),
                    "categorie": data.get("categorieParticularite", ""),
                }
                result["statut"] = "OK"
            else:
                result["message"] = "Réponse programme PMU vide ou JSON non objet"
                result["warnings"] = ["API_PMU_PROGRAMME_JSON_NON_OBJET"]

        # Participants
        url_part = f"https://offline.turfinfo.api.pmu.fr/rest/client/1/programme/{date_pmu}/R{reunion}/C{course_num}/participants"
        resp2 = requests.get(url_part, headers=get_headers(), timeout=15)
        if resp2.status_code == 200:
            try:
                data2 = resp2.json()
            except (ValueError, TypeError):
                data2 = None
            if isinstance(data2, dict):
                result["participants"] = data2.get("participants") or []
                result["statut"] = "OK"
            elif isinstance(data2, list):
                result["participants"] = data2
                result["statut"] = "OK"
            else:
                result.setdefault("warnings", []).append("API_PMU_PARTICIPANTS_JSON_NON_OBJET")

    except Exception as e:
        result["message"] = str(e)

    return result


# =============================================================================
# DÉTECTION AUTOMATIQUE DES SIGNAUX (basée sur données réelles)
# =============================================================================

def detecter_signaux(partant_data: Dict, pmu_data: Dict, course_info: Dict,
                     pronostics_gagnant: List, pronostics_place: List,
                     analyse_ia: str, all_partants: List) -> List[Dict]:
    """
    Détecte les signaux actifs pour un partant basé sur les données collectées.
    Retourne une liste de signaux avec leur code, valeur et justification.
    """
    signaux = []
    num = partant_data.get("numPmu", 0)
    nom = partant_data.get("nom", "")
    def observed_number(mapping: Dict[str, Any], key: str):
        value = mapping.get(key)
        if value in (None, "", "NC"):
            return None
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    cote = observed_number(partant_data, "cote")

    # Données ELO et IA : l’absence reste None, jamais une valeur moyenne fictive.
    elo_jockey = observed_number(partant_data, "pointsJockey")
    elo_trainer = observed_number(partant_data, "pointsTrainer")
    elo_cheval = observed_number(partant_data, "pointsCheval")
    top1_ia = observed_number(partant_data, "Top1IA")
    top5_ia = observed_number(partant_data, "top5IA")
    esp_victoire = observed_number(partant_data, "Esp_Victoire")
    taux_victoire = observed_number(partant_data, "tauxVictoire")
    taux_place = observed_number(partant_data, "tauxPlace")
    nb_courses = observed_number(partant_data, "nbCourses")
    repos = observed_number(partant_data, "repos")
    synergie = observed_number(partant_data, "synergie_jch")
    gains_course = observed_number(partant_data, "gainParCourse")

    # Données PMU
    pmu_victoires = observed_number(pmu_data, "nombreVictoires")
    pmu_places = observed_number(pmu_data, "nombrePlaces")
    pmu_courses = observed_number(pmu_data, "nombreCourses")

    # Rang dans les pronostics
    rang_gagnant = next((p["rang"] for p in pronostics_gagnant if p["numero"] == num), 99)
    rang_place = next((p["rang"] for p in pronostics_place if p["numero"] == num), 99)
    pct_gagnant = next((p["pourcentage"] for p in pronostics_gagnant if p["numero"] == num), 0)

    # Calcul des rangs ELO relatifs
    all_elo_jockey = sorted([observed_number(p, "pointsJockey") for p in all_partants if observed_number(p, "pointsJockey") is not None], reverse=True)
    all_elo_trainer = sorted([observed_number(p, "pointsTrainer") for p in all_partants if observed_number(p, "pointsTrainer") is not None], reverse=True)
    rang_elo_j = all_elo_jockey.index(elo_jockey) + 1 if elo_jockey in all_elo_jockey else 99
    rang_elo_t = all_elo_trainer.index(elo_trainer) + 1 if elo_trainer in all_elo_trainer else 99

    # --- FAMILLE F (Forme) ---

    # B01 - Forme récente positive
    if (taux_victoire is not None and taux_victoire > 0) or (taux_place is not None and taux_place > 30):
        signaux.append({"code": "B01", "famille": "F", "valeur": 6.0,
                        "raison": f"Taux victoire={taux_victoire}%, place={taux_place}%"})
    elif nb_courses is not None and nb_courses > 0 and taux_place is not None and taux_place > 0:
        signaux.append({"code": "B01", "famille": "F", "valeur": 3.0,
                        "raison": f"Taux place={taux_place}% sur {nb_courses} courses"})

    # B20 - Régularité places
    if taux_place is not None and nb_courses is not None and taux_place >= 50 and nb_courses >= 3:
        signaux.append({"code": "B20", "famille": "F", "valeur": 5.0,
                        "raison": f"Régularité: {taux_place}% placé sur {nb_courses} courses"})

    # B24 - Progression (IA élevée par rapport à la cote)
    if top1_ia is not None and cote is not None and top1_ia > 0.12 and cote > 8:
        signaux.append({"code": "B24", "famille": "F", "valeur": 4.0,
                        "raison": f"IA Top1={top1_ia:.3f} vs cote={cote} → potentiel sous-estimé"})

    # B25 - Série en cours
    if pmu_victoires is not None and pmu_victoires >= 2:
        signaux.append({"code": "B25", "famille": "F", "valeur": 5.0,
                        "raison": f"{pmu_victoires} victoires en carrière"})

    # B47 - Dernière course significative
    if nb_courses is not None and nb_courses > 0 and gains_course is not None and gains_course > 0:
        signaux.append({"code": "B47", "famille": "F", "valeur": 4.0,
                        "raison": f"Gains/course={gains_course}€, actif"})

    # B54 - Repos optimal (14-90 jours)
    if repos is not None and 14 <= repos <= 90:
        signaux.append({"code": "B54", "famille": "F", "valeur": 3.5,
                        "raison": f"Repos={repos}j (optimal 14-90j)"})
    elif repos is not None and 90 < repos <= 150:
        signaux.append({"code": "B54", "famille": "F", "valeur": 2.0,
                        "raison": f"Repos={repos}j (acceptable)"})

    # --- FAMILLE L (Lieu) ---

    # B04 - Terrain favorable (basé sur analyse IA)
    analyse_lower = analyse_ia.lower()
    if any(mot in analyse_lower for mot in ["terrain", "souple", "bon terrain", "s'adapte"]):
        if not any(mot in analyse_lower for mot in ["inadapté", "n'aime pas", "déteste"]):
            signaux.append({"code": "B04", "famille": "L", "valeur": 4.0,
                            "raison": "Terrain compatible (analyse IA)"})

    # B15 - Distance confirmée
    if any(mot in analyse_lower for mot in ["distance", "parcours", "3400", "endurance"]):
        if not any(mot in analyse_lower for mot in ["trop long", "trop court", "inadapté"]):
            signaux.append({"code": "B15", "famille": "L", "valeur": 4.0,
                            "raison": "Distance compatible (analyse IA)"})

    # B19 - Hippodrome favorable
    if any(mot in analyse_lower for mot in ["hippodrome", "piste", "connait", "habitué"]):
        signaux.append({"code": "B19", "famille": "L", "valeur": 3.5,
                        "raison": "Hippodrome familier (analyse IA)"})

    # --- FAMILLE C (Conseil) ---

    # B09 - Jockey/Driver top (ELO >= 1460)
    if elo_jockey is not None and elo_jockey >= 1460:
        signaux.append({"code": "B09", "famille": "C", "valeur": 5.0,
                        "raison": f"ELO jockey={elo_jockey} (top)"})
    elif elo_jockey is not None and elo_jockey >= 1430:
        signaux.append({"code": "B09", "famille": "C", "valeur": 3.0,
                        "raison": f"ELO jockey={elo_jockey} (bon)"})

    # B11 - Tandem gagnant (synergie jockey-cheval)
    if synergie is not None and synergie > 0.5:
        signaux.append({"code": "B11", "famille": "C", "valeur": 5.0,
                        "raison": f"Synergie J-Ch={synergie:.2f}"})
    elif elo_jockey is not None and elo_trainer is not None and elo_jockey >= 1450 and elo_trainer >= 1450:
        signaux.append({"code": "B11", "famille": "C", "valeur": 3.5,
                        "raison": f"Tandem ELO jockey={elo_jockey} + trainer={elo_trainer}"})

    # B12 - Entraîneur en forme (ELO trainer top)
    if elo_trainer is not None and elo_trainer >= 1470:
        signaux.append({"code": "B12", "famille": "C", "valeur": 4.5,
                        "raison": f"ELO entraîneur={elo_trainer} (top)"})

    # B38 - Pronostic expert (rang dans pronostics IA)
    if rang_gagnant <= 3:
        signaux.append({"code": "B38", "famille": "C", "valeur": 5.0,
                        "raison": f"Top {rang_gagnant} pronostic gagnant ({pct_gagnant}%)"})
    elif rang_gagnant <= 5:
        signaux.append({"code": "B38", "famille": "C", "valeur": 3.0,
                        "raison": f"Top {rang_gagnant} pronostic gagnant ({pct_gagnant}%)"})

    # B51 - Consensus pronostiqueurs (dans top 5 gagnant ET top 5 placé)
    if rang_gagnant <= 5 and rang_place <= 5:
        signaux.append({"code": "B51", "famille": "C", "valeur": 4.5,
                        "raison": f"Consensus: rang {rang_gagnant} gagnant + rang {rang_place} placé"})

    # --- FAMILLE M (Marché) ---

    # B06 - Cote en baisse / favori marché
    if cote is not None and 0 < cote <= 5:
        signaux.append({"code": "B06", "famille": "M", "valeur": 5.0,
                        "raison": f"Favori marché: cote={cote}"})
    elif cote is not None and 0 < cote <= 8:
        signaux.append({"code": "B06", "famille": "M", "valeur": 3.0,
                        "raison": f"Cote favorable: {cote}"})

    # B35 - SOV favorable (espérance victoire IA élevée)
    if esp_victoire is not None and esp_victoire > 0.35:
        signaux.append({"code": "B35", "famille": "M", "valeur": 5.5,
                        "raison": f"Espérance victoire IA={esp_victoire:.3f} (élevée)"})
    elif esp_victoire is not None and esp_victoire > 0.30:
        signaux.append({"code": "B35", "famille": "M", "valeur": 3.5,
                        "raison": f"Espérance victoire IA={esp_victoire:.3f} (bonne)"})

    # B36 - Mouvement tardif (cote BZH vs cote PMU)
    cote_bzh = observed_number(partant_data, "cote_bzh")
    if cote_bzh is not None and cote is not None and cote_bzh > 0 and cote > 0 and cote_bzh < cote * 0.8:
        signaux.append({"code": "B36", "famille": "M", "valeur": 4.0,
                        "raison": f"Mouvement: cote_bzh={cote_bzh} vs cote_pmu={cote}"})

    # B41 - Consensus cotes (top5 IA élevé)
    if top5_ia is not None and top5_ia > 0.55:
        signaux.append({"code": "B41", "famille": "M", "valeur": 4.5,
                        "raison": f"Top5 IA={top5_ia:.3f} (forte probabilité quinté)"})
    elif top5_ia is not None and top5_ia > 0.45:
        signaux.append({"code": "B41", "famille": "M", "valeur": 3.0,
                        "raison": f"Top5 IA={top5_ia:.3f} (bonne probabilité quinté)"})

    # --- FAMILLE P (Physique) ---

    # B21 - Poids favorable (pour les courses à handicap)
    poids = observed_number(pmu_data, "handicapPoids")
    if poids is not None and poids > 0:
        all_poids = [observed_number(p, "handicapPoids") for p in all_partants if observed_number(p, "handicapPoids") is not None and observed_number(p, "handicapPoids") > 0]
        if all_poids:
            poids_min = min(all_poids) if all_poids else poids
            if poids <= poids_min:
                signaux.append({"code": "B21", "famille": "P", "valeur": 4.0,
                                "raison": f"Poids minimum={poids/10}kg"})
            elif poids <= poids_min + 20:
                signaux.append({"code": "B21", "famille": "P", "valeur": 2.5,
                                "raison": f"Poids léger={poids/10}kg (min={poids_min/10})"})

    # B43 - Condition physique (ELO cheval élevé)
    if elo_cheval is not None:
        all_elo_ch = sorted([p.get("pointsCheval", 1361) for p in all_partants], reverse=True)
        rang_ch = all_elo_ch.index(elo_cheval) + 1 if elo_cheval in all_elo_ch else 99
        if rang_ch <= 3:
            signaux.append({"code": "B43", "famille": "P", "valeur": 4.0,
                            "raison": f"ELO cheval={elo_cheval} (rang {rang_ch})"})

    return signaux


# =============================================================================
# CALCUL ICP (Indice de Consensus Pronostiqueurs)
# =============================================================================

def calculer_icp(num: int, pronostics_gagnant: List, pronostics_place: List,
                 top5_ia: float) -> int:
    """
    Calcule l'ICP basé sur le nombre de sources qui citent ce cheval.
    Sources: pronostic gagnant, pronostic placé, IA top5.
    """
    icp = 0

    # Dans le top 5 gagnant turf.bzh
    if any(p["numero"] == num and p["rang"] <= 5 for p in pronostics_gagnant):
        icp += 1

    # Dans le top 5 placé turf.bzh
    if any(p["numero"] == num and p["rang"] <= 5 for p in pronostics_place):
        icp += 1

    # IA top5 > 0.50 (forte probabilité d'être dans le quinté)
    if top5_ia is not None and top5_ia > 0.50:
        icp += 1

    # IA top5 > 0.55 (très forte)
    if top5_ia is not None and top5_ia > 0.55:
        icp += 1

    # Dans le top 3 gagnant (bonus)
    if any(p["numero"] == num and p["rang"] <= 3 for p in pronostics_gagnant):
        icp += 1

    return icp


# =============================================================================
# MAPPER LA DISCIPLINE
# =============================================================================

def mapper_discipline(disc_str: str) -> str:
    """Mappe la discipline depuis les sources vers le format Protocol Vantage."""
    disc_upper = disc_str.upper().strip()

    if disc_upper in ("HAIE", "HAIES"):
        return "HAIES"
    elif disc_upper in ("STEEPLE", "STEEPLE-CHASE", "OBSTACLE"):
        return "OBSTACLE"
    elif disc_upper in ("PLAT", "GALOP"):
        return "PLAT"
    elif disc_upper in ("TROT ATTELÉ", "TROT ATTELE", "ATTELE", "ATTELÉ"):
        return "TROT_ATTELE"
    elif disc_upper in ("TROT MONTÉ", "TROT MONTE", "MONTÉ", "MONTE"):
        return "TROT_MONTE"
    elif disc_upper in ("CROSS", "CROSS-COUNTRY"):
        return "OBSTACLE"
    else:
        return disc_upper


# =============================================================================
# FONCTION PRINCIPALE: COLLECTE AUTOMATIQUE
# =============================================================================

def collecter_automatique(url: str) -> Dict[str, Any]:
    """
    Collecte automatique complète depuis une URL.
    1. Extrait les infos de l'URL (date, R, C)
    2. Scrape turf.bzh (données JSON riches)
    3. Appelle l'API PMU (jockeys, entraîneurs, poids)
    4. Détecte automatiquement les signaux
    5. Calcule l'ICP
    6. Retourne les données prêtes pour le pipeline
    """
    rapport_collecte = {
        "url_source": url,
        "sources_consultees": [],
        "partants_trouves": 0,
        "donnees_enrichies": False,
        "signaux_detectes": 0,
        "erreurs": [],
        "warnings": []
    }

    # Étape 1: Extraire les infos depuis l'URL
    info_url = extraire_info_url(url)
    if not info_url.get("reunion") or not info_url.get("course"):
        rapport_collecte["erreurs"].append("Impossible d'extraire R/C depuis l'URL")
        return {"statut": "ERREUR", "rapport_collecte": rapport_collecte}

    # Étape 2: Scraper turf.bzh
    turf_data = scraper_turf_bzh(url)
    rapport_collecte["sources_consultees"].append({
        "source": "turf.bzh",
        "statut": turf_data["statut"],
        "partants_extraits": len(turf_data.get('partants', [])),
        "partants": turf_data.get('partants', []),
        "details": f"{len(turf_data.get('partants', []))} partants JSON"
    })

    if turf_data["statut"] != "OK" or not turf_data.get("partants"):
        rapport_collecte["erreurs"].append("Échec extraction données turf.bzh")
        # Tenter quand même l'API PMU
        turf_data = {"partants": [], "course_info": {}, "pronostics_gagnant": [], "pronostics_place": [], "analyses_ia": []}

    # Étape 3: API PMU
    pmu_data = {"participants": [], "course_info": {}}
    if info_url.get("date_pmu"):
        pmu_data = scraper_api_pmu(
            info_url["date_pmu"],
            info_url["reunion"],
            info_url["course"]
        )
        rapport_collecte["sources_consultees"].append({
            "source": "API PMU",
            "statut": pmu_data["statut"],
            "partants_extraits": len(pmu_data.get('participants', [])),
            "partants": pmu_data.get('participants', []),
            "details": f"{len(pmu_data.get('participants', []))} participants"
        })

    # Étape 4: Fusionner les données de course
    course_info = turf_data.get("course_info", {})
    pmu_course = pmu_data.get("course_info", {})

    # Priorité: turf.bzh pour hippodrome/discipline, PMU pour compléter
    hippodrome = course_info.get("hippodrome", "")
    if not hippodrome:
        # Tenter d'extraire depuis le libellé PMU ou l'hippodrome PMU
        if pmu_course.get("hippodrome"):
            hippodrome = pmu_course["hippodrome"].upper()
        elif pmu_course.get("libelle"):
            # Extraire l'hippodrome depuis le libellé (ex: "Prix de Clairefontaine")
            libelle = pmu_course["libelle"]
            # Chercher dans les hippodromes connus
            hippodromes_connus = [
                "VINCENNES", "LONGCHAMP", "CHANTILLY", "AUTEUIL", "SAINT-CLOUD",
                "DEAUVILLE", "ENGHIEN", "MAISONS-LAFFITTE", "CAGNES-SUR-MER",
                "LYON-PARILLY", "TOULOUSE", "BORDEAUX", "MARSEILLE-BORELY",
                "NANTES", "STRASBOURG", "COMPIEGNE", "FONTAINEBLEAU", "CRAON",
                "CABOURG", "LAVAL", "VICHY", "CLAIREFONTAINE"
            ]
            for h in hippodromes_connus:
                if h.lower().replace('-', ' ') in libelle.lower().replace('-', ' '):
                    hippodrome = h
                    break
            if not hippodrome:
                hippodrome = "INCONNU"

    discipline_raw = course_info.get("discipline", pmu_course.get("discipline", ""))
    discipline = mapper_discipline(discipline_raw)

    distance = course_info.get("distance", pmu_course.get("distance", 0))
    terrain = course_info.get("terrain")
    penetrometre = course_info.get("terrain_indice")
    piste = course_info.get("piste")
    allocation = course_info.get("allocation")
    est_handicap = course_info.get("est_handicap") if course_info.get("est_handicap") is not None else None
    nb_partants = course_info.get("nb_partants", len(turf_data.get("partants", [])))

    # Étape 5: Construire les partants avec toutes les données
    partants_final = []
    turf_partants = turf_data.get("partants", [])
    pmu_participants = pmu_data.get("participants", [])
    pronostics_g = turf_data.get("pronostics_gagnant", [])
    pronostics_p = turf_data.get("pronostics_place", [])
    analyses = turf_data.get("analyses_ia", [])

    # Créer un index PMU par numéro
    pmu_index = {p.get("numPmu", 0): p for p in pmu_participants}

    for turf_p in turf_partants:
        num = turf_p.get("numPmu", 0)
        pmu_p = pmu_index.get(num, {})

        # Analyse IA pour ce partant
        analyse_text = ""
        for a in analyses:
            if a.get("numero") == num:
                analyse_text = a.get("analyse", "")
                break

        # Détecter les signaux
        signaux = detecter_signaux(
            turf_p, pmu_p, course_info,
            pronostics_g, pronostics_p,
            analyse_text, turf_partants
        )

        # Calculer ICP
        icp = calculer_icp(num, pronostics_g, pronostics_p, turf_p.get("top5IA", 0))

        # Construire un paquet brut plat à partir des champs réellement observés.
        # Les alias facilitent les modules normatifs sans inventer de valeur.
        raw_observed = {}
        for source_payload in (turf_p, pmu_p):
            for raw_key, raw_value in source_payload.items():
                if raw_value not in (None, "", "NC"):
                    raw_observed.setdefault(raw_key, raw_value)
        aliases = {
            "cote": turf_p.get("cote", pmu_p.get("coteDirect")),
            "nb_courses": turf_p.get("nbCourses"),
            "gains_totaux": turf_p.get("gainsTotaux", pmu_p.get("gainsTotaux")),
            "gains_totaux_eur": turf_p.get("gainsTotaux", pmu_p.get("gainsTotaux")),
            "cote_avant_course": turf_p.get("cote", pmu_p.get("coteDirect")),
            "valeur_pmu": turf_p.get("valeurPmu", turf_p.get("valeurPMU", turf_p.get("valeur_pmu", pmu_p.get("valeurPmu", pmu_p.get("gainsParticipant"))))),
            "valeur_pmu_alternative": turf_p.get("valeurPmuAlternative"),
            "cote_bzh": turf_p.get("cote_bzh", turf_p.get("coteBzh", turf_p.get("cote"))),
            "repos": turf_p.get("repos"),
            "taux_victoire": turf_p.get("tauxVictoire"),
            "taux_place": turf_p.get("tauxPlace"),
        }
        raw_observed.update({key: value for key, value in aliases.items() if value not in (None, "", "NC")})
        raw_observed.update({"turf_bzh": turf_p, "api_pmu": pmu_p, "analyse_ia": analyse_text})

        # Construire le bloc marché avant le partant : aucune cote temporelle n'est dupliquée.
        market_data = construire_market_data_pmu(pmu_p, turf_p)
        raw_observed['market_data'] = market_data

        # Construire le partant
        partant = {
            "numero": num,
            "nom": _normaliser_nom_cheval(turf_p.get("nom", pmu_p.get("nom", ""))),
            "valeur_pmu": turf_p.get("valeurPmu", turf_p.get("valeurPMU", turf_p.get("valeur_pmu", pmu_p.get("valeurPmu", pmu_p.get("gainsParticipant"))))),
            "cote_bzh": turf_p.get("cote_bzh", turf_p.get("coteBzh", turf_p.get("cote"))),
            # `cote` est la cote de référence pour T1-T4 ; la dernière cote reste dans market_data.
            "cote": market_data.get("cote_reference") or market_data.get("cote_finale") or turf_p.get("cote", pmu_p.get("coteDirect", None)),
            "market_data": market_data,
            "driver_jockey": pmu_p.get("driver", pmu_p.get("jockey", "")),
            "entraineur": pmu_p.get("entraineur", ""),
            "age": turf_p.get("age", pmu_p.get("age", None)),
            "sexe": pmu_p.get("sexe", None),
            "poids": pmu_p.get("handicapPoids", 0) / 10 if pmu_p.get("handicapPoids") else None,
            "icp_count": icp,
            "signaux_actifs": [s["code"] for s in signaux],
            "signaux_details": signaux,
            # Données enrichies
            "elo_jockey": turf_p.get("pointsJockey"),
            "elo_trainer": turf_p.get("pointsTrainer"),
            "elo_cheval": turf_p.get("pointsCheval"),
            "top1_ia": turf_p.get("Top1IA"),
            "top5_ia": turf_p.get("top5IA"),
            "esp_victoire": turf_p.get("Esp_Victoire"),
            "taux_victoire": turf_p.get("tauxVictoire"),
            "taux_place": turf_p.get("tauxPlace"),
            "nb_courses": turf_p.get("nbCourses"),
            "repos": turf_p.get("repos"),
            "synergie": turf_p.get("synergie_jch"),
            "rang_pronostic_gagnant": next((p["rang"] for p in pronostics_g if p["numero"] == num), 99),
            "rang_pronostic_place": next((p["rang"] for p in pronostics_p if p["numero"] == num), 99),
            "legacy_flags": list(turf_p.get("legacy_flags", turf_p.get("flags_legacy", [])) or []),
            "data_quality": {
                field: ("OBSERVED" if (turf_p.get(field) not in (None, "", 0) or pmu_p.get(field) not in (None, "", 0)) else "NC")
                for field in ("nom", "cote", "age", "repos", "tauxVictoire", "tauxPlace")
            },
            "field_sources": {
                "nom": "turf.bzh" if turf_p.get("nom") else "API_PMU",
                "cote": "turf.bzh" if turf_p.get("cote") not in (None, "", 0) else "API_PMU" if pmu_p.get("coteDirect") not in (None, "", 0) else "NONE",
                "driver_jockey": "API_PMU" if pmu_p.get("driver", pmu_p.get("jockey")) else "NONE",
                "entraineur": "API_PMU" if pmu_p.get("entraineur") else "NONE",
                "age": "turf.bzh" if turf_p.get("age") not in (None, "", 0) else "API_PMU" if pmu_p.get("age") not in (None, "", 0) else "NONE",
                "sexe": "API_PMU" if pmu_p.get("sexe") else "NONE",
                "poids": "API_PMU" if pmu_p.get("handicapPoids") not in (None, "", 0) else "NONE",
            },
            "raw_data": raw_observed,
        }

        partants_final.append(partant)

    # Si pas de partants depuis turf.bzh, utiliser PMU
    if not partants_final and pmu_participants:
        for pmu_p in pmu_participants:
            num = pmu_p.get("numPmu", 0)
            cote = 0
            rapport_direct = pmu_p.get("dernierRapportDirect")
            if isinstance(rapport_direct, (int, float)):
                cote = float(rapport_direct)
            elif isinstance(rapport_direct, dict):
                cote = float(rapport_direct.get("rapport", 0))

            market_data = construire_market_data_pmu(pmu_p, None)
            partant = {
                "numero": num,
                "nom": _normaliser_nom_cheval(pmu_p.get("nom", "")),
                "valeur_pmu": pmu_p.get("valeurPmu", pmu_p.get("valeurPMU", pmu_p.get("gainsParticipant"))),
                "cote_bzh": pmu_p.get("cote_bzh", pmu_p.get("coteBzh")),
                "market_data": market_data,
                "cote": market_data.get("cote_reference") or (cote if cote > 0 else None),
                "driver_jockey": pmu_p.get("driver", pmu_p.get("jockey", "")),
                "entraineur": pmu_p.get("entraineur", ""),
                "age": pmu_p.get("age", None),
                "sexe": pmu_p.get("sexe", None),
                "poids": pmu_p.get("handicapPoids", 0) / 10 if pmu_p.get("handicapPoids") else None,
                "icp_count": 0,
                "signaux_actifs": [],
                "signaux_details": [],
                "data_quality": {field: ("OBSERVED" if pmu_p.get(field) not in (None, "", 0) else "NC") for field in ("nom", "age", "sexe", "entraineur")},
                "field_sources": {field: "API_PMU" if pmu_p.get(field) not in (None, "", 0) else "NONE" for field in ("nom", "age", "sexe", "entraineur", "driver_jockey", "poids")},
                "raw_data": {
                    "api_pmu": pmu_p,
                    "valeur_pmu": pmu_p.get("valeurPmu", pmu_p.get("valeurPMU", pmu_p.get("gainsParticipant"))),
                    "cote_bzh": pmu_p.get("cote_bzh", pmu_p.get("coteBzh")),
                    "market_data": market_data,
                },
            }
            partants_final.append(partant)

    # Statistiques
    total_signaux = sum(len(p.get("signaux_actifs", [])) for p in partants_final)
    rapport_collecte["partants_trouves"] = len(partants_final)
    rapport_collecte["signaux_detectes"] = total_signaux
    rapport_collecte["donnees_enrichies"] = True

    if not partants_final:
        rapport_collecte["erreurs"].append("Aucun partant trouvé")
        return {"statut": "ERREUR", "rapport_collecte": rapport_collecte}

    # Warnings
    if not hippodrome or hippodrome == "INCONNU":
        rapport_collecte["warnings"].append("Hippodrome non détecté")
    if not discipline:
        rapport_collecte["warnings"].append("Discipline non détectée — statut NC conservé")

    # Résultat final
    resultat = {
        "statut": "OK",
        "date": info_url.get("date", datetime.now().strftime("%Y-%m-%d")),
        "hippodrome": hippodrome,
        "numero_course": info_url.get("course", 1),
        "nom_course": pmu_course.get("libelle") or course_info.get("libelle", ""),
        "discipline": discipline or "NC",
        "distance": distance,
        "terrain": terrain,
        "penetrometre": penetrometre,
        "piste": piste,
        "allocation": allocation,
        "type_depart": str(course_info.get("type_depart") or pmu_course.get("conditions") or "").upper() or None,
        "est_handicap": est_handicap,
        "nb_partants": len(partants_final),
        "partants": partants_final,
        "rapport_collecte": rapport_collecte
    }

    return resultat
