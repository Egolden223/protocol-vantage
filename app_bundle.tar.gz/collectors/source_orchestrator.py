"""Orchestration multi-source avec extraction prudente et provenance.

Aucune source non structurée ne peut remplacer une valeur observée. Les pages
accessibles mais non parsables sont conservées comme preuve de tentative, pas
comme preuve de donnée.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup

from collectors.auto_scraper import get_headers
from collectors.priority_sources import construire_registre_sources
from collectors.priority_adapters import resoudre_candidat, _parse_frequence_top5, _parse_turfoo_top5, _parse_rtl_top5
from collectors.data_requirements import construire_plan_collecte
from collectors.complementary_sources import construire_registre_complementaire
from collectors.source_fetch import fetcher_source


def _date_kind(date_iso: str) -> str:
    try:
        target = datetime.strptime(date_iso, '%Y-%m-%d').date()
        today = datetime.utcnow().date()
        if target == today:
            return 'today'
        if target > today:
            return 'future'
        return 'past'
    except ValueError:
        return 'unknown'


def construire_sources_candidates(ids: Dict[str, Any]) -> List[Dict[str, Any]]:
    date = ids['date']
    date_pmu = ids['date_pmu']
    reunion = ids['reunion']
    course = ids['numero_course']
    kind = _date_kind(date)
    sources = [
        {'source': 'turf.bzh_html', 'url': f'https://www.turf.bzh/pronostics-pmu-{date_pmu}-R{reunion}C{course}.html', 'role': 'programme_partants_cotes'},
        {'source': 'API_PMU', 'url': f'https://offline.turfinfo.api.pmu.fr/rest/client/1/programme/{date_pmu}/R{reunion}/C{course}', 'role': 'programme_officiel'},
        {'source': 'API_PMU_PARTICIPANTS', 'url': f'https://offline.turfinfo.api.pmu.fr/rest/client/1/programme/{date_pmu}/R{reunion}/C{course}/participants', 'role': 'partants_officiels'},
    ]
    if kind in {'today', 'future'}:
        sources.append({'source': 'LETROT_PUBLIC', 'url': f'https://www.letrot.com/courses/{"aujourd-hui" if kind == "today" else "prochains-jours"}', 'role': 'programme_trot'})
        sources.append({'source': 'FRANCE_GALOP_PUBLIC', 'url': 'https://www.france-galop.com/fr', 'role': 'programme_galop'})
    api_key = os.getenv('TURF_BZH_API_KEY')
    if api_key:
        sources.append({'source': 'TURF_BZH_API', 'url': f'https://www.turf.bzh/api/v1/courses/{date}/R{reunion}C{course}?api_key={api_key}', 'role': 'indicateurs_cotes_historique'})
    return sources


def _parse_equidia_top5(soup: BeautifulSoup) -> List[int]:
    numbers: List[int] = []
    for card in soup.select('.ticket-prono--analysis--list--partant'):
        span = card.select_one('.ticket-prono--analysis--list--partant--card span')
        if not span:
            continue
        match = re.search(r'(?<!\d)(\d{1,2})(?!\d)', span.get_text(' ', strip=True))
        if match:
            number = int(match.group(1))
            if number not in numbers:
                numbers.append(number)
        if len(numbers) >= 5:
            break
    return numbers[:5]


def _parse_canalturf_rows(html: str, source: str = 'CANALTURF') -> List[Dict[str, Any]]:
    """Parse la fiche exacte Canalturf sans confondre publicité et partants.

    La table `#TablePartants` expose, selon la discipline, la corde ou la
    ferrure, le jockey/driver, l'entraîneur, le poids, la musique et les cotes.
    Chaque valeur reste absente si la colonne ou la preuve n'existe pas.
    """
    soup = BeautifulSoup(html, 'html.parser')
    table = soup.select_one('#TablePartants')
    if table is None:
        return []
    header_cells = table.find('tr').find_all(['th', 'td']) if table.find('tr') else []
    headers = [' '.join(cell.get_text(' ', strip=True).split()).lower() for cell in header_cells]
    rows: List[Dict[str, Any]] = []

    def index_of(*terms: str) -> Optional[int]:
        for idx, header in enumerate(headers):
            if any(term in header for term in terms):
                return idx
        return None

    idx_horse = 1
    idx_corde = index_of('corde')
    idx_def = index_of('def.')
    idx_actor = index_of('jockey/entr', 'driver/entr')
    idx_weight = index_of('poids')
    idx_10h = index_of('à 10h', 'a 10h')
    for tr in table.find_all('tr')[1:]:
        cells_nodes = tr.find_all(['th', 'td'])
        cells = [' '.join(cell.get_text(' ', strip=True).split()) for cell in cells_nodes]
        if len(cells) < 2 or not re.fullmatch(r'0*\d{1,2}', cells[0]):
            continue
        number = int(cells[0])
        if any(existing['numero'] == number for existing in rows):
            continue
        horse_node = cells_nodes[idx_horse] if len(cells_nodes) > idx_horse else None
        horse_anchor = horse_node.find('a', title=re.compile(r'fiche du cheval', re.IGNORECASE)) if horse_node else None
        strong = horse_anchor.find('strong') if horse_anchor else None
        horse_label = ' '.join((strong or horse_anchor or horse_node).get_text(' ', strip=True).split()) if (strong or horse_anchor or horse_node) else ''
        age = None
        sexe = None
        age_match = re.search(r'\(([A-Za-z])\s*(\d{1,2})\)', horse_label)
        if age_match:
            sexe = age_match.group(1).upper()
            age = int(age_match.group(2))
        name = re.sub(r'\s*\([^)]+\).*$', '', horse_label).strip()
        if not name:
            name = re.sub(r'\s*\([^)]*\).*$', '', cells[idx_horse]).strip()
        row: Dict[str, Any] = {'numero': number, 'nom': name, 'source': source}
        if age is not None:
            row['age'] = age
        if sexe:
            row['sexe'] = sexe
        if horse_anchor:
            music_node = horse_anchor.find('small')
            if music_node:
                music = ' '.join(music_node.get_text(' ', strip=True).split())
                if music:
                    row['musique'] = music
        if idx_actor is not None and len(cells_nodes) > idx_actor:
            actor = cells_nodes[idx_actor]
            jockey = actor.find('a', title=re.compile(r'fiche du jockey|fiche du driver', re.IGNORECASE))
            trainer = actor.find('a', title=re.compile(r'fiche de l.?entraineur', re.IGNORECASE))
            if jockey:
                row['driver_jockey'] = ' '.join(jockey.get_text(' ', strip=True).split())
            if trainer:
                row['entraineur'] = ' '.join(trainer.get_text(' ', strip=True).split())
        if idx_corde is not None and len(cells) > idx_corde:
            match = re.search(r'\b(\d{1,2})\b', cells[idx_corde])
            if match:
                row['numero_corde'] = int(match.group(1))
        if idx_weight is not None and len(cells) > idx_weight:
            match = re.search(r'(\d+(?:[.,]\d+)?)\s*kg', cells[idx_weight], re.IGNORECASE)
            if match:
                row['poids_actuel_kg'] = float(match.group(1).replace(',', '.'))
                row['poids'] = row['poids_actuel_kg']
        if idx_def is not None and len(cells_nodes) > idx_def:
            def_node = cells_nodes[idx_def]
            def_text = ' '.join(def_node.get_text(' ', strip=True).split())
            alt = ' '.join(img.get('alt', '') for img in def_node.find_all('img'))
            def_value = def_text or alt
            if def_value:
                row['deferrage'] = def_value
        numeric = []
        for cell in cells[2:]:
            token = cell.replace(',', '.').replace('€', '').strip()
            if re.fullmatch(r'\d+(?:\.\d+)?', token):
                numeric.append(float(token))
        if numeric:
            row['cote'] = numeric[-1]
            if idx_10h is not None and len(cells) > idx_10h:
                token = cells[idx_10h].replace(',', '.').strip()
                if re.fullmatch(r'\d+(?:\.\d+)?', token):
                    row['cote_matin'] = float(token)
        rows.append(row)
    return rows


def _extract_balanced_json_fragment(text: str, start: int, opening: str = '[', closing: str = ']') -> Optional[str]:
    """Extrait un fragment JSON équilibré sans exécuter le JavaScript de la page."""
    depth = 0
    quoted = False
    escaped = False
    for index in range(start, len(text)):
        char = text[index]
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\\\':
                escaped = True
            elif char == '"':
                quoted = False
            continue
        if char == '"':
            quoted = True
        elif char == opening:
            depth += 1
        elif char == closing:
            depth -= 1
            if depth == 0:
                return text[start:index + 1]
    return None


def _extract_geny_embedded_participants(html: str) -> List[Dict[str, Any]]:
    """Extrait le bloc `participants` du JSON Next.js embarqué par GENY."""
    soup = BeautifulSoup(html, 'html.parser')
    for script in soup.find_all('script'):
        raw = script.string or script.get_text() or ''
        if 'participants' not in raw or 'dateReunion' not in raw:
            continue
        candidates = [raw]
        wrapper = re.search(r'\[\s*1\s*,\s*("(?:\\.|[^"\\])*")\s*\]\s*\)', raw, re.DOTALL)
        if wrapper:
            try:
                candidates.insert(0, json.loads(wrapper.group(1)))
            except (TypeError, ValueError, json.JSONDecodeError):
                pass
        for text in candidates:
            for match in re.finditer(r'"participants"\s*:\s*\[', text):
                fragment = _extract_balanced_json_fragment(text, match.end() - 1)
                if not fragment:
                    continue
                try:
                    values = json.loads(fragment)
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
                if isinstance(values, list) and values and isinstance(values[0], dict) and isinstance(values[0].get('cheval'), dict):
                    return values
    return []


def _person_name(person: Any) -> Optional[str]:
    if not isinstance(person, dict):
        return None
    name = ' '.join(str(value).strip() for value in (person.get('prenom'), person.get('nom')) if value not in (None, ''))
    return name or None


def _geny_music_parts(music: Any) -> List[str]:
    if isinstance(music, dict) and isinstance(music.get('parts'), list):
        return [str(value) for value in music['parts'] if value not in (None, '')]
    if isinstance(music, str):
        return re.findall(r'\d{1,2}[a-zA-Z]', music)
    return []


def _parse_geny_program_rows(html: str, source: str = 'GENY') -> List[Dict[str, Any]]:
    """Parse les participants GENY et leurs champs de programme prouvés."""
    participants = _extract_geny_embedded_participants(html)
    rows: List[Dict[str, Any]] = []
    for participant in participants:
        cheval = participant.get('cheval') or {}
        number = participant.get('numero')
        if number is None:
            continue
        row: Dict[str, Any] = {
            'numero': number,
            'nom': cheval.get('nom') or '',
            'source': source,
            'source_method': 'GENY_NEXT_EMBEDDED_PARTICIPANTS',
            'etat_participation': participant.get('etatParticipation'),
        }
        jockey = _person_name(participant.get('jockey'))
        trainer = _person_name(participant.get('entraineur'))
        owner = _person_name(participant.get('proprietaire'))
        if jockey:
            row['driver_jockey'] = jockey
        if trainer:
            row['entraineur'] = trainer
        if owner:
            row['proprietaire'] = owner
        for target, source_key in (
            ('age', 'age'), ('sexe', 'sexe'), ('poids_actuel_kg', 'poids'),
            ('numero_corde', 'positionDepart'), ('deferrage', 'deferre'),
            ('valeur_handicap', 'valeurHandicap'), ('cote', 'cotePmu'),
            ('cote_geny', 'coteGeny'), ('gains_totaux_eur', 'gain'),
        ):
            value = participant.get(source_key)
            if value not in (None, '', 'NC'):
                row[target] = value
        if 'poids_actuel_kg' in row:
            row['poids'] = row['poids_actuel_kg']
        if 'valeur_handicap' in row:
            row['valeur_pmu'] = row['valeur_handicap']
            row['valeur_pmu_semantics'] = 'VALEUR_HANDICAP_GENY'
        music_parts = _geny_music_parts(participant.get('musique'))
        if music_parts:
            row['musique'] = ''.join(music_parts)
            row['rangs_6_dernieres'] = music_parts[:6]
            row['rangs_4_dernieres'] = music_parts[:4]
            row['rangs_3_dernieres'] = music_parts[:3]
        if participant.get('oeilleres') not in (None, '', 'NC'):
            row['oeilleres'] = participant.get('oeilleres')
        if participant.get('bonnet') is not None:
            row['bonnet'] = participant.get('bonnet')
        if participant.get('attacheLangue') is not None:
            row['attache_langue'] = participant.get('attacheLangue')
        if participant.get('cotePmu') not in (None, '', 'NC'):
            row['cote_avant_course'] = participant.get('cotePmu')
        row['raw_geny_participant'] = participant
        rows.append(row)
    return rows


def _merge_rows_by_number(program_rows: List[Dict[str, Any]], market_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Fusionne les observations GENY de programme et de marché sans écraser une preuve existante."""
    market_by_number = {str(row.get('numero')): row for row in market_rows or [] if row.get('numero') is not None}
    merged = []
    for program_row in program_rows or []:
        row = dict(program_row)
        market_row = market_by_number.get(str(row.get('numero')), {})
        for key, value in market_row.items():
            if key == 'market_data' and isinstance(value, dict):
                existing = row.get('market_data', {}) if isinstance(row.get('market_data'), dict) else {}
                row['market_data'] = {**value, **existing}
            elif not _observed_value(row.get(key)) and _observed_value(value):
                row[key] = value
        merged.append(row)
    existing_numbers = {str(row.get('numero')) for row in merged}
    merged.extend(dict(row) for row in (market_rows or []) if str(row.get('numero')) not in existing_numbers)
    return merged


def _parse_table_rows(html: str, table_selector: str, source: str) -> List[Dict[str, Any]]:
    soup = BeautifulSoup(html, 'html.parser')
    tables = soup.select(table_selector)
    if not tables:
        return []
    candidate_tables = []
    for table in tables:
        numeric_rows = 0
        for tr in table.find_all('tr'):
            cells = [' '.join(cell.get_text(' ', strip=True).split()) for cell in tr.find_all(['th', 'td'])]
            if cells and re.fullmatch(r'0*\d{1,2}', cells[0]):
                numeric_rows += 1
        candidate_tables.append((table, numeric_rows))
    table = max(candidate_tables, key=lambda item: item[1])[0]
    rows: List[Dict[str, Any]] = []
    for tr in table.find_all('tr'):
        cells = [' '.join(cell.get_text(' ', strip=True).split()) for cell in tr.find_all(['th', 'td'])]
        if len(cells) < 2:
            continue
        match = re.fullmatch(r'0*(\d{1,2})', cells[0])
        if not match:
            continue
        number = int(match.group(1))
        if any(existing['numero'] == number for existing in rows):
            continue
        name = ''
        anchor = tr.select_one('a[href*="/stats/chevaux/"]') or tr.select_one('a[title*="fiche du cheval"]')
        if anchor:
            name = ' '.join(anchor.get_text(' ', strip=True).split())
        if not name:
            name = re.sub(r'\s*\([^)]*\).*$', '', cells[1]).strip()
        row: Dict[str, Any] = {'numero': number, 'nom': name, 'source': source}
        numeric = []
        for cell in cells[2:]:
            token = cell.replace(',', '.').replace('€', '').strip()
            if re.fullmatch(r'\d+(?:\.\d+)?', token):
                numeric.append(float(token))
        if numeric:
            row['cote'] = numeric[-1]
        rows.append(row)
    return rows


def _parse_visible_rows(html: str) -> List[Dict[str, Any]]:
    """Extrait uniquement les lignes explicitement numérotées et nommées."""
    soup = BeautifulSoup(html, 'html.parser')
    rows: List[Dict[str, Any]] = []
    for row in soup.find_all(['tr', 'li']):
        text = ' '.join(row.get_text(' ', strip=True).split())
        match = re.match(r'^(\d{1,2})[.\-–]\s*([A-Za-zÀ-ÿ][^|]{2,80})', text)
        if not match:
            continue
        number = int(match.group(1))
        name = match.group(2).strip()
        if any(existing['numero'] == number for existing in rows):
            continue
        cote_match = re.search(r'(?:cote|rapport)\s*[:=]?\s*(\d+(?:[.,]\d+)?)', text, re.IGNORECASE)
        rows.append({'numero': number, 'nom': name, 'cote': float(cote_match.group(1).replace(',', '.')) if cote_match else None, 'raw_text_hash': hashlib.sha256(text.encode('utf-8')).hexdigest()[:16]})
    return rows


def _parse_geny_market_rows(html: str, identity: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Parse les deux rapports probables Geny sans confondre cote et pourcentage d'enjeux."""
    soup = BeautifulSoup(html, 'html.parser')
    header_text = ' '.join(soup.get_text(' ', strip=True).split())
    times = re.findall(r'\b(\d{1,2}h\d{2})\b', header_text)
    times = list(dict.fromkeys(times))[:2]
    rows: List[Dict[str, Any]] = []
    for tr in soup.find_all('tr'):
        cells = [' '.join(td.get_text(' ', strip=True).split()) for td in tr.find_all(['th', 'td'])]
        if len(cells) < 6:
            continue
        match = re.match(r'^0*(\d{1,2})$', cells[0])
        if not match:
            continue
        number = int(match.group(1))
        name = cells[2] if len(cells) > 2 else ''
        numeric = []
        for cell in cells[5:]:
            token = cell.replace(',', '.')
            if re.fullmatch(r'\d+(?:\.\d+)?', token):
                numeric.append(float(token))
        if len(numeric) < 2:
            rows.append({'numero': number, 'nom': name, 'market_data': {'status': 'UNPROVEN', 'source': 'GENY_COTES', 'reason': 'Deux rapports probables non identifiés'}})
            continue
        ref_time = times[0] if len(times) > 0 else None
        last_time = times[1] if len(times) > 1 else None
        rows.append({
            'numero': number,
            'nom': name,
            'cote_reference': numeric[0],
            'cote_derniere': numeric[1],
            'market_data': {
                'reference_quote': {'value': numeric[0], 'display_time': ref_time, 'source': 'GENY_COTES', 'kind': 'REFERENCE', 'status': 'OBSERVED' if ref_time else 'OBSERVED_UNTIMESTAMPED'},
                'last_pre_race_quote': {'value': numeric[1], 'display_time': last_time, 'source': 'GENY_COTES', 'kind': 'LAST_PRE_RACE', 'status': 'OBSERVED' if last_time else 'OBSERVED_UNTIMESTAMPED'},
                'sov_snapshots': [{'value': numeric[0], 'display_time': ref_time, 'source': 'GENY_COTES', 'kind': 'REFERENCE'}, {'value': numeric[1], 'display_time': last_time, 'source': 'GENY_COTES', 'kind': 'LAST_PRE_RACE'}],
                'cote_reference': numeric[0],
                'cote_avant_course': numeric[1],
                'cote_15m': numeric[1],
                'cote_finale': numeric[1],
                'delta_cote': numeric[0] - numeric[1],
                'fluctuation_relative': (numeric[0] - numeric[1]) / numeric[0] if numeric[0] else None,
                'sov_v2_input_status': 'READY_TWO_POINTS',
                'source_policy': 'GENY_COTES_TWO_PROBABLE_REPORTS',
            }
        })
    return rows


def _identity_evidence(html: str, identity: Dict[str, Any], source_url: str = '') -> Dict[str, Any]:
    text = BeautifulSoup(html, 'html.parser').get_text(' ', strip=True)
    normalized_text = re.sub(r'\s+', ' ', text).strip()
    date_iso = str(identity.get('date', ''))
    date_pmu = date_iso.replace('-', '')
    date_parts = date_iso.split('-')
    date_fr = '/'.join((date_parts[2], date_parts[1], date_parts[0])) if len(date_parts) == 3 else ''
    reunion = int(identity.get('reunion', 0) or 0)
    course = int(identity.get('numero_course', 0) or 0)
    source_url = str(source_url or '')
    url_rc_match = bool(
        re.search(rf'/R\s*0*{reunion}/C\s*0*{course}(?:[/?#]|$)', source_url, re.IGNORECASE)
        or re.search(rf'R\s*0*{reunion}C\s*0*{course}(?:[^0-9]|$)', source_url, re.IGNORECASE)
    )
    url_course_match = bool(re.search(rf'/courses/{re.escape(date_iso)}/[^/]+/{course}(?:[/?#]|$)', source_url, re.IGNORECASE))
    url_date_match = bool(date_iso and (date_iso in source_url or date_pmu in source_url or date_fr in source_url))
    date_match = any(token and token in normalized_text for token in (date_iso, date_pmu, date_fr)) or url_date_match
    rc_match = bool(re.search(rf'\bR\s*0*{reunion}\s*C\s*0*{course}\b', normalized_text, re.IGNORECASE))
    explicit_match = bool(re.search(rf'R[ée]union\s*0*{reunion}\s+(?:Course|C)\s*0*{course}\b', normalized_text, re.IGNORECASE))
    title_text = re.sub(r'\s+', ' ', BeautifulSoup(html, 'html.parser').get_text(' ', strip=True))
    title_match = bool(re.search(rf'\bR\s*0*{reunion}\b[^\n]{{0,180}}\bC\s*0*{course}\b', str(BeautifulSoup(html, 'html.parser').title or ''), re.IGNORECASE))
    if url_rc_match or url_course_match:
        rc_match = True
    if title_match:
        explicit_match = True
    return {
        'date_observee': date_match,
        'reunion_course_observe': rc_match or explicit_match,
        'identity_verified': bool(date_match and (rc_match or explicit_match)),
        'url_date_observee': url_date_match,
        'url_course_observee': url_rc_match or url_course_match,
        'reason': '' if date_match and (rc_match or explicit_match) else 'Date/réunion/course non démontrées dans la page',
    }


def _numbers_from_text(text: str) -> List[int]:
    found = []
    for token in re.findall(r'(?<!\d)(\d{1,2})(?!\d)', text or ''):
        number = int(token)
        if 1 <= number <= 99 and number not in found:
            found.append(number)
    return found


def _extract_canalturf_top5(soup: BeautifulSoup) -> List[int]:
    numbers: List[int] = []
    for heading in soup.find_all(['h3', 'h4', 'strong']):
        label = heading.get_text(' ', strip=True).lower()
        if not any(word in label for word in ('base', 'chance', 'outsider', 'pronostic')):
            continue
        node = heading
        for _ in range(4):
            node = node.find_next()
            if node is None:
                break
            values = _numbers_from_text(node.get_text(' ', strip=True))
            for value in values:
                if value not in numbers:
                    numbers.append(value)
                if len(numbers) >= 5:
                    return numbers[:5]
    return numbers[:5]


def _extract_zone_top5(soup: BeautifulSoup, identity: Dict[str, Any]) -> List[int]:
    reunion = int(identity.get('reunion', 0) or 0)
    course = int(identity.get('numero_course', 0) or 0)
    text = soup.get_text('\n', strip=True)
    for row in soup.find_all('tr'):
        row_text = ' '.join(row.get_text(' ', strip=True).split())
        if re.search(r'Zone[- ]Turf\.fr', row_text, re.IGNORECASE):
            values = []
            for cell in row.find_all(['td', 'th']):
                match = re.fullmatch(r'\s*0*(\d{1,2})\s*', cell.get_text(' ', strip=True))
                if match:
                    number = int(match.group(1))
                    if 1 <= number <= 99 and number not in values:
                        values.append(number)
            if len(values) >= 5:
                return values[:5]
    marker = re.search(rf'R\s*0*{reunion}\s+Course\s+N[°º]?\s*0*{course}\b', text, re.IGNORECASE)
    segment = text[marker.start():] if marker else text
    match = re.search(r'(?<!\d)(\d{1,2})\s*-\s*(\d{1,2})\s*-\s*(\d{1,2})\s*-\s*(\d{1,2})\s*-\s*(\d{1,2})(?!\d)', segment)
    if not match:
        return []
    return [int(value) for value in match.groups()]


def _extract_structured_top5(html: str, source: str = '', identity: Dict[str, Any] | None = None) -> Dict[str, Any]:
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text('\n', strip=True)
    identity = identity or {}
    source = str(source or '').upper()
    if source == 'CANALTURF':
        numbers = _extract_canalturf_top5(soup)
    elif source == "ZONE_TURF":
        numbers = _extract_zone_top5(soup, identity)
    elif source == "EQUIDIA":
        numbers = _parse_equidia_top5(soup)
    elif source == "FREQUENCE_TURF":
        parsed = _parse_frequence_top5(html)
        return parsed
    elif source == "TURFOO":
        parsed = _parse_turfoo_top5(html)
        return parsed
    elif source == "RTL":
        parsed = _parse_rtl_top5(html)
        return parsed
    else:
        numbers = []
    if not numbers and re.search(r'\b(?:top\s*5|top5|bases?|outsiders?|belles? chances?|sélection)\b', text, re.IGNORECASE):
        rows = _parse_visible_rows(html)
        numbers = [row['numero'] for row in rows[:5]]
    if len(numbers) < 5:
        return {'status': 'UNPROVEN', 'top5': [{'numero': n} for n in numbers], 'reason': 'Bloc de sélection trouvé mais moins de cinq numéros identifiés'}
    return {'status': 'OBSERVED', 'top5': [{'numero': n} for n in numbers[:5]], 'reason': ''}


def _requirements_evidence(candidate: Dict[str, Any], result: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Attribue un statut de preuve par groupe sans extrapoler depuis le HTML."""
    evidence = []
    rows_count = int(result.get('partants_extraits', 0) or 0)
    top5_status = result.get('top5_status')
    for requirement in candidate.get('data_requirements', []) or []:
        rid = requirement.get('requirement_id')
        if rid == 'press_top5_consensus' and top5_status == 'OBSERVED':
            status, reason = 'OBSERVED', ''
        elif rid == 'participants_and_market' and rows_count > 0:
            status, reason = 'PARTIAL', 'Lignes numérotées parsées; champs historiques/cotes non garantis'
        elif rid == 'identity_programme' and result.get('identity_evidence', {}).get('identity_verified'):
            status, reason = 'PARTIAL', 'Identité prouvée; programme détaillé non parsé par cet adaptateur'
        else:
            status, reason = 'UNPROVEN', 'Groupe déclaré dans le plan mais extraction spécialisée non démontrée'
        evidence.append({'requirement_id': rid, 'status': status, 'reason': reason, 'fields': requirement.get('fields', []), 'consumers': requirement.get('consumers', [])})
    return evidence


def sonder_source(candidate: Dict[str, Any]) -> Dict[str, Any]:
    """Sonde une source avec redirections, nettoyage publicitaire et preuve d'identité."""
    started = datetime.utcnow().isoformat() + 'Z'
    safe_candidate = dict(candidate)
    safe_candidate['url'] = re.sub(r'(api_key=)[^&]+', r'\\1REDACTED', str(candidate.get('url', '')))
    result = {
        **safe_candidate,
        'statut': 'ERREUR',
        'http_status': None,
        'content_bytes': 0,
        'partants_extraits': 0,
        'timestamp': started,
        'warnings': [],
    }
    fetched = fetcher_source(candidate)
    for key in ('statut', 'http_status', 'content_bytes', 'url_finale', 'redirects', 'data_status', 'block_reason', 'fetch_meta', 'message'):
        if key in fetched:
            result[key] = fetched[key]
    result['warnings'].extend(fetched.get('warnings', []))
    if fetched.get('statut') == 'BLOCKED':
        result['top5_status'] = 'UNPROVEN'
        result['top5'] = []
        return result
    html = fetched.get('html')
    if fetched.get('statut') != 'OK' or not html:
        return result
    identity = _identity_evidence(html, candidate.get('identity', {}), candidate.get('url', '')) if candidate.get('identity') else {'identity_verified': False, 'reason': 'Identifiants absents du registre'}
    resolution = candidate.get('resolution') or {}
    if not identity.get('identity_verified') and resolution.get('status') == 'RESOLVED' and resolution.get('method') in {'GENY_PROGRAM_INDEX', 'LETROT_DATE_INDEX', 'TURFOO_DATE_INDEX', 'ZONE_TURF_QUINTE_DATED', 'CANALTURF_DAILY_INDEX'}:
        identity = {**identity, 'identity_verified': True, 'resolution_verified': True, 'reason': 'Identité exacte prouvée par l’index spécialisé avant téléchargement de la page finale', 'resolution_evidence': resolution.get('evidence') or resolution.get('identity')}
    result['identity_evidence'] = identity
    if not identity.get('identity_verified'):
        result['warnings'].append('SOURCE_ACCESSIBLE_IDENTITE_UNPROVEN')
        result['data_status'] = 'UNPROVEN'
        result['top5_status'] = 'UNPROVEN'
        result['top5'] = []
        return result
    source_name = str(candidate.get('source', '')).upper()
    source_url = str(candidate.get('url', '')).lower()
    if source_name == 'GENY' and '/cotes' in source_url:
        rows = _parse_geny_market_rows(html, candidate.get('identity', {}))
    elif source_name == 'GENY':
        rows = _parse_geny_program_rows(html, source_name)
    elif source_name == 'CANALTURF':
        rows = _parse_canalturf_rows(html, source_name)
    elif source_name == 'LETROT':
        rows = _parse_table_rows(html, 'table', source_name)
    elif source_name == 'CANALTURF':
        rows = _parse_table_rows(html, '#TablePartants', source_name)
    else:
        rows = _parse_visible_rows(html)
    result['partants_extraits'] = len(rows)
    result['partants'] = rows
    top5 = _extract_structured_top5(html, candidate.get('source', ''), candidate.get('identity', {})) if candidate.get('top5_required') else {'status': 'NOT_REQUIRED', 'top5': [], 'reason': ''}
    result['top5_status'] = top5['status']
    result['top5'] = top5['top5']
    if source_name == 'GENY' and candidate.get('market_url'):
        market_candidate = {**candidate, 'url': candidate['market_url'], 'top5_required': False}
        market_fetch = fetcher_source(market_candidate)
        result['market_url'] = candidate['market_url']
        result['market_fetch_status'] = market_fetch.get('statut')
        result['market_http_status'] = market_fetch.get('http_status')
        if market_fetch.get('statut') == 'OK' and market_fetch.get('html'):
            market_rows = _parse_geny_market_rows(market_fetch['html'], candidate.get('identity', {}))
            result['market_rows'] = market_rows
            result['market_data_status'] = 'OBSERVED' if market_rows else 'UNPROVEN'
            if market_rows:
                if rows:
                    rows = _merge_rows_by_number(rows, market_rows)
                    result['partants'] = rows
                    result['partants_extraits'] = len(rows)
                    result['market_rows_merged_into_program'] = True
                else:
                    result['partants'] = market_rows
                    result['partants_extraits'] = len(market_rows)
                    rows = market_rows
                    result['market_rows_used_as_partants_fallback'] = True
        else:
            result['market_rows'] = []
            result['market_data_status'] = 'UNPROVEN'
    observed_field_counts: Dict[str, int] = {}
    for row in rows:
        for field in _PARTICIPANT_FIELDS:
            if _observed_value(_field_value(row, field)):
                observed_field_counts[field] = observed_field_counts.get(field, 0) + 1
    result['observed_fields_count'] = sum(observed_field_counts.values())
    result['observed_fields_by_name'] = observed_field_counts
    if top5.get('reason'):
        result['warnings'].append(top5['reason'])
    result['data_status'] = 'OBSERVED' if rows or result.get('market_data_status') == 'OBSERVED' or top5['status'] == 'OBSERVED' else 'UNPROVEN'
    if not rows and top5['status'] != 'OBSERVED':
        result['warnings'].append('SOURCE_ACCESSIBLE_NON_STRUCTUREE')
    result['requirements_evidence'] = _requirements_evidence(candidate, result)
    return result


def consolider_top5_presse(attempts: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Consolide uniquement les Top5 dont l’extraction est OBSERVED."""
    by_number: Dict[str, Dict[str, Any]] = {}
    observed_sources = []
    for attempt in attempts:
        if attempt.get('top5_status') != 'OBSERVED':
            continue
        source = str(attempt.get('source', 'UNKNOWN'))
        observed_sources.append(source)
        for row in attempt.get('top5', []) or []:
            try:
                number = int(row.get('numero'))
            except (TypeError, ValueError):
                continue
            item = by_number.setdefault(str(number), {'numero': number, 'sources': [], 'rangs': []})
            if source not in item['sources']:
                item['sources'].append(source)
            if row.get('rang') is not None:
                item['rangs'].append({'source': source, 'rang': row.get('rang')})
    citations = {}
    for number, item in by_number.items():
        distinct = len(item['sources'])
        citations[number] = {
            'numero': item['numero'],
            'sources': item['sources'],
            'distinct_source_count': distinct,
            'mentions': distinct,
            'in_any_top5': distinct >= 1,
            'cited_ge_3': distinct >= 3,
            'rangs': item['rangs'],
        }
    return {
        'status': 'OBSERVED' if observed_sources else 'UNPROVEN',
        'observed_sources': sorted(set(observed_sources)),
        'observed_source_count': len(set(observed_sources)),
        'top5_by_number': citations,
        'policy': 'Aucune non-citation déduite d’une source UNPROVEN; seules les extractions OBSERVED comptent',
    }


def appliquer_preuves_presse_partants(partants: List[Dict[str, Any]], press_consensus: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Injecte les preuves presse observées dans raw_data sans activer de signal silencieux."""
    top5_by_number = press_consensus.get('top5_by_number', {}) if isinstance(press_consensus, dict) else {}
    consensus_status = press_consensus.get('status', 'UNPROVEN') if isinstance(press_consensus, dict) else 'UNPROVEN'
    for partant in partants or []:
        try:
            number = int(partant.get('numero'))
        except (TypeError, ValueError):
            number = None
        evidence = top5_by_number.get(str(number), {}) if number is not None else {}
        sources = list(evidence.get('sources', []) or [])
        distinct = len(sources)
        cote = partant.get('cote')
        try:
            cote_value = float(cote) if cote not in (None, '', 'NC') else None
        except (TypeError, ValueError):
            cote_value = None
        t3_t4 = cote_value is not None and 15 < cote_value <= 300
        in_top5 = bool(evidence.get('in_any_top5'))
        cited_ge_3 = bool(evidence.get('cited_ge_3'))
        raw = dict(partant.get('raw_data', {}) or {})
        raw.update({
            'press_top5_sources': sources,
            'press_distinct_sources': distinct,
            'press_mentions': distinct,
            'press_in_any_top5': in_top5,
            'press_cited_ge_3': cited_ge_3,
            'press_consensus_status': consensus_status,
            'consensus_outsider': bool(t3_t4 and (cited_ge_3 or in_top5)) if consensus_status == 'OBSERVED' else None,
        })
        partant['raw_data'] = raw
        quality = dict(partant.get('data_quality', {}) or {})
        quality['press_top5'] = 'OBSERVED' if consensus_status == 'OBSERVED' and evidence else 'UNPROVEN'
        partant['data_quality'] = quality
        field_sources = dict(partant.get('field_sources', {}) or {})
        field_sources['press_top5'] = sources or 'NONE'
        partant['field_sources'] = field_sources
    return partants


def appliquer_preuves_marche_partants(partants: List[Dict[str, Any]], rapport_collecte: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Fusionne PMU et Geny sans remplacer une observation prouvée par une cote finale non horodatée."""
    attempts = (rapport_collecte or {}).get('source_attempts', []) or []
    geny_rows = {}
    for attempt in attempts:
        if str(attempt.get('source', '')).upper() != 'GENY':
            continue
        for row in attempt.get('partants', []) or []:
            if row.get('market_data', {}).get('sov_v2_input_status') == 'READY_TWO_POINTS':
                geny_rows[str(row.get('numero'))] = row
    for partant in partants or []:
        number = str(partant.get('numero'))
        existing = dict(partant.get('market_data', {}) or {})
        observations = list(existing.get('source_observations', []) or [])
        if existing:
            observations.append({'source': 'API_PMU', 'market_data': existing})
        geny = geny_rows.get(number)
        if geny:
            geny_market = dict(geny.get('market_data', {}) or {})
            observations.append({'source': 'GENY_COTES', 'market_data': geny_market})
            selected = existing if existing.get('sov_v2_input_status') == 'READY_TWO_POINTS' else geny_market
            selected = dict(selected)
            selected['source_observations'] = observations
            selected['selected_source'] = 'API_PMU' if selected is existing or existing.get('sov_v2_input_status') == 'READY_TWO_POINTS' else 'GENY_COTES'
            ref_a = existing.get('cote_reference')
            ref_b = geny_market.get('cote_reference')
            last_a = existing.get('cote_avant_course')
            last_b = geny_market.get('cote_avant_course')
            selected['cross_source_comparison'] = {
                'reference_difference': (ref_a - ref_b) if isinstance(ref_a, (int, float)) and isinstance(ref_b, (int, float)) else None,
                'last_pre_race_difference': (last_a - last_b) if isinstance(last_a, (int, float)) and isinstance(last_b, (int, float)) else None,
                'status': 'OBSERVED' if ref_a is not None and ref_b is not None else 'UNPROVEN',
            }
            partant['market_data'] = selected
            if selected.get('cote_reference') is not None:
                partant['cote'] = selected.get('cote_reference')
            raw = dict(partant.get('raw_data', {}) or {})
            raw['market_data'] = selected
            partant['raw_data'] = raw
            quality = dict(partant.get('data_quality', {}) or {})
            quality['cote_matin_ou_reference'] = 'OBSERVED'
            quality['cote_avant_course'] = 'OBSERVED'
            partant['data_quality'] = quality
    return partants


_PARTICIPANT_FIELDS = [
    'numero', 'nom', 'cote_matin', 'cote_avant_course', 'cote_15min',
    'sov_snapshots', 'valeur_pmu', 'driver_jockey', 'entraineur', 'ecurie',
    'proprietaire', 'age', 'sexe', 'poids_actuel_kg', 'numero_corde',
    'numero_autostart', 'recul_m', 'rk_brute', 'deferrage',
    'deferrage_4_pieds', 'deferrage_4_pieds_premiere', 'oeilleres',
    'premieres_oeilleres', 'changement_ferrure', 'changement_driver',
    'changement_entraineur', 'commentaire_derniere_course',
    'rangs_6_dernieres', 'rangs_4_dernieres', 'nb_partants_4_dernieres',
    'rangs_relatifs_4', 'rangs_3_dernieres', 'gains_totaux_eur',
    'nb_courses_total', 'victoires_total', 'places_total', 'repos',
    'allocations_last3', 'categories_allocations_6', 'ee_categories_6',
    'ee_scores_6', 'macro_groupe', 'historique_terrain_perf',
    'historique_distances_perf', 'historique_parcours_exact',
    'nb_courses_hippodrome', 'profil_hippodrome_similaire', 'style_mpa',
    'rythme_projete', 'rythme_effectif', 'positions_mi_course_5',
    'position_mi_course_historique', 'sens_corde_officiel',
    'sens_rotation_historique', 'jockey_windows', 'trainer_windows',
    'driver_classement_national', 'driver_classement_hebdomadaire',
    'driver_classement_12m', 'taux_victoires', 'taux_place', 'feu_equidia',
    'bio_rythme_saisonnier', 'chrono_200m', 'chrono_1km', 'rk_array',
    'rk_incident_flag', 'rk_ref_tiers', 'delai_j', 'nb_courses_30j',
    'iff_seuil_surmenage', 'h2h_avg', 'h2h_scores', 'taux_top5_tandem',
    'coeff_nb_tandem', 'coeff_temps_tandem', 'nb_courses_ensemble',
    'synergie_jch', 'harville_correlation_matrix', 'score_sim',
    'press_distinct_sources', 'press_sources', 'consensus_outsider',
    'ssfo_signals', 'gamma_signals', 'ghost_signals',
    'supra_omission_candidate', 'supra_retrait_candidate',
]


def _observed_value(value: Any) -> bool:
    if value is None or value == '' or value is False:
        return value is False
    if isinstance(value, str) and value.strip().upper() in {'NC', 'UNPROVEN', 'NONE', 'NULL'}:
        return False
    if isinstance(value, (list, dict, tuple, set)):
        return len(value) > 0
    return True


def _coverage_field_policy(course_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    context = course_context or {}
    discipline = str(context.get('discipline') or '').upper()
    type_depart = str(context.get('type_depart') or '').upper()
    est_handicap = bool(context.get('est_handicap'))
    core = {
        'numero', 'nom', 'driver_jockey', 'entraineur', 'proprietaire', 'age', 'sexe',
        'cote_matin', 'cote_avant_course', 'cote_15min', 'sov_snapshots', 'valeur_pmu',
        'deferrage', 'oeilleres', 'gains_totaux_eur',
        'nb_courses_total', 'taux_victoires', 'taux_place', 'repos',
        'rangs_6_dernieres', 'rangs_4_dernieres', 'rangs_3_dernieres',
        'synergie_jch',
    }
    reasons = {}
    conditional_contract_fields = {
        'changement_driver': 'conditional_equipment_changes',
        'consensus_outsider': 'conditional_declarations_and_qualitative',
        'places_total': 'conditional_career_value_rates',
        'press_distinct_sources': 'conditional_declarations_and_qualitative',
        'press_sources': 'conditional_declarations_and_qualitative',
        'victoires_total': 'conditional_career_value_rates',
    }
    for field in _PARTICIPANT_FIELDS:
        if field in core:
            reasons[field] = 'CORE_PUBLIC_EXPECTED'
        elif field in conditional_contract_fields:
            reasons[field] = f"{conditional_contract_fields[field].upper()}_CONDITIONAL_NOT_BLOCKING"
        else:
            reasons[field] = 'CONDITIONAL_OR_SPECIALIZED_NOT_EXPECTED_BY_DEFAULT'
    if 'TROT' in discipline and 'AUTOSTART' in type_depart:
        core.add('numero_autostart')
        reasons['numero_autostart'] = 'TROT_AUTOSTART_NUMBER_DECLARED_BY_PROGRAMME'
    elif 'TROT' in discipline and est_handicap:
        core.add('recul_m')
        reasons['recul_m'] = 'TROT_HANDICAP_RECUL_DECLARED_BY_PROGRAMME'
    elif 'PLAT' in discipline or 'OBSTACLE' in discipline:
        core.update({'poids_actuel_kg', 'numero_corde'})
        reasons['poids_actuel_kg'] = 'GALOP_WEIGHT_DECLARED_BY_PROGRAMME'
        reasons['numero_corde'] = 'GALOP_STALL_DECLARED_BY_PROGRAMME'
    return {'required_fields': sorted(core), 'excluded_fields': sorted(set(_PARTICIPANT_FIELDS) - core), 'reasons': reasons, 'policy_version': 'PUBLIC_EXPECTED_FIELDS_V2'}


def _field_value(partant: Dict[str, Any], field: str) -> Any:
    market = partant.get('market_data', {}) if isinstance(partant.get('market_data'), dict) else {}
    raw = partant.get('raw_data', {}) if isinstance(partant.get('raw_data'), dict) else {}
    aliases = {
        'numero': ('numero', 'numPmu'),
        'nom': ('nom',),
        'cote_matin': ('cote_matin', 'cote_reference'),
        'cote_avant_course': ('cote_avant_course', 'cote_derniere'),
        'cote_15min': ('cote_15min', 'cote_finale'),
        'sov_snapshots': ('sov_snapshots',),
        'poids_actuel_kg': ('poids_actuel_kg', 'poids'),
        'numero_corde': ('numero_corde', 'corde', 'placeCorde'),
        'numero_autostart': ('numero_autostart', 'autostart'),
        'rk_brute': ('rk_brute', 'rk'),
        'driver_jockey': ('driver_jockey', 'driver', 'jockey'),
        'deferrage': ('deferrage', 'deferre'),
        'gains_totaux_eur': ('gains_totaux_eur', 'gains'),
        'nb_courses_total': ('nb_courses_total', 'nb_courses', 'nombreCourses', 'nbCourses'),
        'victoires_total': ('victoires_total', 'nombreVictoires'),
        'places_total': ('places_total', 'nombrePlaces'),
        'taux_victoires': ('taux_victoires', 'taux_victoire', 'tauxVictoire'),
        'taux_place': ('taux_place', 'tauxPlace', 'taux_place_percent'),
        'press_sources': ('press_sources', 'press_top5_sources'),
        'changement_driver': ('changement_driver', 'driverChange'),
    }
    nested_sources = [raw.get('api_pmu'), raw.get('turf_bzh')]
    if field in {'rangs_6_dernieres', 'rangs_4_dernieres', 'rangs_3_dernieres'}:
        for source in (partant, raw, *nested_sources):
            if not isinstance(source, dict):
                continue
            music = source.get('musique')
            if music:
                ranks = [int(value) for value in re.findall(r'(?<![0-9(])(\d{1,2})[a-zA-Z]', str(music))]
                if ranks:
                    return ranks[:6] if field == 'rangs_6_dernieres' else ranks[:4] if field == 'rangs_4_dernieres' else ranks[:3]
    if field == 'gains_totaux_eur':
        for source in (partant, raw, *nested_sources):
            if not isinstance(source, dict):
                continue
            gains = source.get('gainsParticipant')
            if isinstance(gains, dict) and _observed_value(gains.get('gainsCarriere')):
                return gains.get('gainsCarriere')
    for key in aliases.get(field, (field,)):
        for source in (partant, market, raw, *nested_sources):
            if isinstance(source, dict) and _observed_value(source.get(key)):
                return source.get(key)
    quality = partant.get('data_quality', {}) if isinstance(partant.get('data_quality'), dict) else {}
    status = str(quality.get(field, '')).upper()
    return True if status.startswith('OBSERVED') else None


def consolider_tableau_donnees(partants: List[Dict[str, Any]], attempts: List[Dict[str, Any]],
                               base_sources: Optional[List[Dict[str, Any]]] = None,
                               course_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Construit une ligne unique par partant et conserve les observations par source."""
    base_sources = base_sources or []
    coverage_policy = _coverage_field_policy(course_context) if course_context is not None else {'required_fields': list(_PARTICIPANT_FIELDS), 'excluded_fields': [], 'reasons': {}, 'policy_version': 'LEGACY_ALL_FIELDS'}
    required_fields = coverage_policy['required_fields']
    by_number: Dict[str, Dict[str, Any]] = {}
    source_rows: Dict[str, List[Tuple[str, Dict[str, Any]]]] = {}
    for attempt in attempts:
        source = str(attempt.get('source', 'UNKNOWN'))
        for row in attempt.get('partants', []) or []:
            number = row.get('numero', row.get('numPmu'))
            if number is None:
                continue
            source_rows.setdefault(str(number), []).append((source, row))
    base_source_names = [str(row.get('source')) for row in base_sources if str(row.get('statut', '')).upper() == 'OK']
    for partant in partants or []:
        number = partant.get('numero', partant.get('numPmu'))
        if number is None:
            continue
        number_key = str(number)
        observations = list(source_rows.get(number_key, []))
        observations.append(('BASE_MERGED', partant))
        fields: Dict[str, Dict[str, Any]] = {}
        observed_cells = 0
        for field in _PARTICIPANT_FIELDS:
            expected = field in required_fields
            value = _field_value(partant, field)
            # La ligne de base peut être pauvre lorsque l’API PMU est
            # indisponible. On récupère alors la première valeur prouvée dans
            # les tentatives spécialisées, sans créer de valeur par défaut.
            if not _observed_value(value):
                for source, row in observations:
                    candidate_value = _field_value(row, field)
                    if _observed_value(candidate_value):
                        value = candidate_value
                        break
            sources = []
            if _observed_value(value):
                for source, row in observations:
                    if _observed_value(_field_value(row, field)) and source not in sources:
                        sources.append(source)
                if not sources:
                    sources = base_source_names or ['BASE_MERGED']
                if expected:
                    observed_cells += 1
            fields[field] = {'value': value if _observed_value(value) else None, 'status': 'OBSERVED' if _observed_value(value) else ('NOT_EXPECTED_PUBLICLY' if not expected else 'NC'), 'sources': sources, 'coverage_expected': expected, 'coverage_reason': coverage_policy['reasons'].get(field, '')}
        by_number[number_key] = {
            'numero': number,
            'nom': partant.get('nom', ''),
            'fields': fields,
            'sources_observees': sorted({source for source, _ in observations if source != 'BASE_MERGED'} | set(base_source_names)),
            'observed_fields': observed_cells,
            'expected_fields': len(required_fields),
            'excluded_fields_count': len(coverage_policy['excluded_fields']),
            'coverage_rate': observed_cells / len(required_fields) if required_fields else 0.0,
        }
    rows = list(by_number.values())
    total_cells = len(rows) * len(required_fields)
    observed_cells = sum(row['observed_fields'] for row in rows)
    field_coverage: Dict[str, Dict[str, Any]] = {}
    for field in required_fields:
        observed_numbers = []
        missing_numbers = []
        for row in rows:
            cell = (row.get('fields') or {}).get(field, {})
            if isinstance(cell, dict) and cell.get('status') == 'OBSERVED':
                observed_numbers.append(row.get('numero'))
            else:
                missing_numbers.append(row.get('numero'))
        expected_count = len(rows)
        observed_count = len(observed_numbers)
        field_coverage[field] = {
            'observed': observed_count,
            'expected': expected_count,
            'coverage_percent': round(100.0 * observed_count / expected_count, 2) if expected_count else 0.0,
            'observed_numbers': observed_numbers,
            'missing_numbers': missing_numbers,
        }
    return {
        'status': 'CALCULATED' if rows else 'UNPROVEN',
        'partants_attendus': len(partants or []),
        'partants_consolides': len(rows),
        'tous_partants_couverts': len(rows) == len(partants or []) and bool(rows),
        'fields_per_partant': len(_PARTICIPANT_FIELDS),
        'coverage_required_fields': required_fields,
        'coverage_excluded_fields': coverage_policy['excluded_fields'],
        'coverage_policy': coverage_policy,
        'observed_cells': observed_cells,
        'expected_cells': total_cells,
        'coverage_rate': observed_cells / total_cells if total_cells else 0.0,
        'coverage_percent': round(100.0 * observed_cells / total_cells, 2) if total_cells else 0.0,
        'field_coverage': field_coverage,
        'missing_required_fields': [field for field, detail in field_coverage.items() if detail['observed'] < detail['expected']],
        'rows': rows,
        'policy': 'UN_OBSERVATION_PAR_CHAMP_ET_PAR_PARTANT; NC/UNPROVEN_EXPLICITE',
    }


def appliquer_tableau_consolide_aux_partants(partants: List[Dict[str, Any]], tableau: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Hydrate les partants avec les valeurs OBSERVED du tableau consolidé.

    Le tableau n'est pas seulement un rapport : ses cellules prouvées deviennent
    les entrées du moteur. Une valeur déjà observée dans la ligne de base n'est
    jamais remplacée par une autre source; les nouvelles valeurs sont ajoutées
    dans raw_data avec leurs sources pour l'audit.
    """
    rows = {str(row.get('numero')): row for row in (tableau or {}).get('rows', []) if row.get('numero') is not None}
    target_aliases = {
        'cote_matin': 'cote', 'valeur_pmu': 'valeur_pmu', 'driver_jockey': 'driver_jockey',
        'poids_actuel_kg': 'poids', 'numero_corde': 'numero_corde',
        'numero_autostart': 'numero_autostart', 'deferrage': 'deferrage',
    }
    current_aliases = {
        'cote_matin': ('cote_matin', 'cote'),
        'poids_actuel_kg': ('poids_actuel_kg', 'poids'),
        'driver_jockey': ('driver_jockey', 'driver', 'jockey'),
        'valeur_pmu': ('valeur_pmu', 'valeurPmu', 'valeurPMU'),
    }
    hydrated = []
    for partant in partants or []:
        if not isinstance(partant, dict):
            hydrated.append(partant)
            continue
        number = partant.get('numero', partant.get('numPmu'))
        row = rows.get(str(number))
        if not row:
            hydrated.append(partant)
            continue
        raw = dict(partant.get('raw_data', {}) or {})
        field_sources = dict(partant.get('field_sources', {}) or {})
        data_quality = dict(partant.get('data_quality', {}) or {})
        consolidated_evidence = dict(partant.get('consolidated_field_evidence', {}) or {})
        for field, cell in (row.get('fields', {}) or {}).items():
            if not isinstance(cell, dict) or cell.get('status') != 'OBSERVED':
                continue
            value = cell.get('value')
            if value in (None, '', 'NC', 'UNPROVEN'):
                continue
            sources = list(cell.get('sources', []) or [])
            current = _field_value(partant, field)
            if not _observed_value(current):
                for alias in current_aliases.get(field, (field,)):
                    candidate_current = partant.get(alias)
                    if _observed_value(candidate_current):
                        current = candidate_current
                        break
            if not _observed_value(current):
                target = target_aliases.get(field, field)
                partant[target] = value
                if field == 'cote_matin' and not _observed_value(partant.get('cote')):
                    partant['cote'] = value
            raw.setdefault(field, value)
            if sources:
                field_sources.setdefault(field, sources[0])
            data_quality[field] = 'OBSERVED'
            consolidated_evidence[field] = {
                'value': value, 'status': 'OBSERVED', 'sources': sources,
                'coverage_expected': cell.get('coverage_expected', True),
                'coverage_reason': cell.get('coverage_reason', ''),
            }
        raw['consolidated_field_evidence'] = consolidated_evidence
        partant['raw_data'] = raw
        partant['field_sources'] = field_sources
        partant['data_quality'] = data_quality
        partant['consolidated_field_evidence'] = consolidated_evidence
        hydrated.append(partant)
    return hydrated


_SOURCE_OBSERVATION_STATUSES = {'OK', 'OBSERVED', 'ARRIVAL_OBSERVED', 'OFFICIAL_CONSENSUS_2_SOURCES', 'OFFICIAL_CONSENSUS_3_SOURCES'}


def normaliser_nom_source(source: Any) -> str:
    """Normalise un identifiant de source pour tous les contrôles de preuve."""
    return str(source or '').strip().upper().replace('.', '_')


def source_effectivement_exploitable(item: Dict[str, Any]) -> bool:
    """Retourne vrai uniquement si la source apporte une observation exploitable.

    Un statut HTTP ou applicatif `OK` ne constitue pas, à lui seul, une preuve.
    Il faut au moins une extraction de partant, un Top 5 observé, un ordre observé
    ou un compteur de champs observés explicitement journalisé.
    """
    if not isinstance(item, dict):
        return False
    status = str(item.get('statut', item.get('status', ''))).upper()
    if status not in _SOURCE_OBSERVATION_STATUSES:
        return False
    partants_extraits = item.get('partants_extraits', 0) or 0
    try:
        partants_extraits = int(partants_extraits)
    except (TypeError, ValueError):
        partants_extraits = 0
    partants = item.get('partants')
    observed_fields = item.get('observed_fields_count', item.get('fields_observed_count', 0)) or 0
    try:
        observed_fields = int(observed_fields)
    except (TypeError, ValueError):
        observed_fields = 0
    return bool(
        partants_extraits > 0
        or (isinstance(partants, (list, tuple, dict)) and len(partants) > 0)
        or str(item.get('top5_status', '')).upper() == 'OBSERVED'
        or bool(item.get('order_observee'))
        or observed_fields > 0
        or bool(item.get('field_observations'))
        or bool(item.get('observations'))
    )


def calculer_sources_effectives(rapport_collecte: Dict[str, Any]) -> List[str]:
    """Retourne les sources ayant effectivement fourni une preuve exploitable.

    Le même contrat est utilisé par le garde multisource, les règles RAH et
    l’export afin d’éviter tout décompte divergent.
    """
    items = list(rapport_collecte.get('sources_consultees', []) or [])
    items.extend(list(rapport_collecte.get('source_attempts', []) or []))
    return sorted({normaliser_nom_source(item.get('source')) for item in items if source_effectivement_exploitable(item) and item.get('source')})


def evaluer_garde_multisource(rapport_collecte: Dict[str, Any], tableau: Dict[str, Any]) -> Dict[str, Any]:
    """Bloque la suite en production sous trois sources ou sous 80 % de couverture."""
    effective_sources = calculer_sources_effectives(rapport_collecte)
    source_count = len(effective_sources)
    coverage_percent = float(tableau.get('coverage_percent', 0.0) or 0.0)
    partants_ok = bool(tableau.get('tous_partants_couverts'))
    source_count_ok = source_count >= 3
    coverage_ok = coverage_percent >= 80.0
    bypass = os.getenv('VANTAGE_PRIORITY_SOURCES_ENABLED', '1') == '0'
    if bypass:
        return {
            'status': 'BYPASS_OFFLINE_TEST', 'blocking': False,
            'minimum_sources': 3, 'effective_source_count': source_count,
            'effective_sources': effective_sources, 'coverage_percent': coverage_percent,
            'coverage_threshold_percent': 80.0, 'all_partants_required': True,
            'all_partants_couverture': partants_ok,
            'reason': 'VANTAGE_PRIORITY_SOURCES_ENABLED=0 — mode test hors ligne explicite',
        }
    reasons = []
    if not source_count_ok:
        reasons.append('MULTISOURCE_MIN_3_NOT_REACHED')
    if not partants_ok:
        reasons.append('CONSOLIDATED_TABLE_INCOMPLETE_PARTANTS')
    if not coverage_ok:
        reasons.append('DATA_COVERAGE_BELOW_80_PERCENT')
    field_coverage = tableau.get('field_coverage', {}) or {}
    missing_required_fields = [
        {'field': field, **detail}
        for field, detail in field_coverage.items()
        if detail.get('observed', 0) < detail.get('expected', 0)
    ]
    missing_required_fields.sort(key=lambda item: (item.get('coverage_percent', 0.0), item.get('field', '')))
    return {
        'status': 'PASS' if not reasons else 'BLOCKED', 'blocking': bool(reasons),
        'minimum_sources': 3, 'effective_source_count': source_count,
        'effective_sources': effective_sources, 'coverage_percent': coverage_percent,
        'coverage_threshold_percent': 80.0, 'all_partants_required': True,
        'all_partants_couverture': partants_ok, 'reasons': reasons,
        'coverage_required_fields': tableau.get('coverage_required_fields', []),
        'missing_required_fields': missing_required_fields,
        'policy': 'COLLECTE_SIMULTANEE_TOUTES_SOURCES_AVANT_PIPELINE',
    }


def enrichir_rapport_sources(ids: Dict[str, Any], rapport_collecte: Dict[str, Any],
                             partants: Optional[List[Dict[str, Any]]] = None,
                             course_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Consulte et journalise les sources du guide dans leur ordre normatif."""
    attempts = []
    priority_registry = construire_registre_sources(
        ids['date'], ids['reunion'], ids['numero_course'],
        discipline=str(ids.get('discipline') or ''), hippodrome=str(ids.get('hippodrome') or '')
    )
    # La collecte prioritaire est active par défaut. Elle peut être désactivée
    # uniquement pour les tests hors ligne, jamais silencieusement en production.
    if os.getenv('VANTAGE_PRIORITY_SOURCES_ENABLED', '1') == '1':
        def _collect_priority_candidate(candidate: Dict[str, Any]) -> Dict[str, Any]:
            enriched_candidate = {**candidate, 'source': candidate['source']}
            if candidate.get('adapter_method') in {'CANALTURF_DAILY_INDEX', 'ZONE_TURF_PROGRAM_INDEX', 'ZONE_TURF_QUINTE_DATED', 'GENY_PROGRAM_INDEX', 'LETROT_DATE_INDEX', 'FREQUENCE_TURF_ARTICLE_INDEX', 'FRANCE_GALOP_DISCIPLINE_GATE', 'TURFOO_DATE_INDEX', 'RTL_COURSES_INDEX'}:
                resolution = resoudre_candidat(enriched_candidate)
                enriched_candidate['resolution'] = resolution
                if resolution.get('status') == 'UNAVAILABLE_SCHEDULED_BREAK':
                    return {**enriched_candidate, 'statut': 'UNAVAILABLE_SCHEDULED_BREAK', 'data_status': 'UNPROVEN', 'top5_status': 'UNPROVEN', 'availability_window': resolution.get('availability_window'), 'warnings': [resolution.get('reason', 'Pause éditoriale déclarée')]}
                if resolution.get('status') != 'RESOLVED':
                    return {**enriched_candidate, 'statut': 'UNPROVEN', 'data_status': 'UNPROVEN', 'top5_status': 'UNPROVEN', 'warnings': [resolution.get('reason', 'Résolution exacte non prouvée')]}
                enriched_candidate['url'] = resolution['url']
                if resolution.get('market_url'):
                    enriched_candidate['market_url'] = resolution['market_url']
            return sonder_source(enriched_candidate)

        # Toutes les sources prioritaires sont sondées dans la même fenêtre
        # d’exécution; chaque résultat reste ensuite ordonné par rang pour l’audit.
        with ThreadPoolExecutor(max_workers=min(11, max(1, len(priority_registry)))) as executor:
            futures = [executor.submit(_collect_priority_candidate, candidate) for candidate in priority_registry]
            attempts.extend(future.result() for future in as_completed(futures))
        attempts.sort(key=lambda item: int(item.get('rank', 999) or 999))
    for candidate in construire_sources_candidates(ids):
        if candidate['source'] in {'turf.bzh_html', 'API_PMU', 'API_PMU_PARTICIPANTS'}:
            continue
        if any(item.get('source') == candidate['source'] for item in attempts):
            continue
        attempts.append(sonder_source(candidate))
    rapport_collecte = dict(rapport_collecte or {})
    rapport_collecte.setdefault('sources_prioritaires', priority_registry)
    rapport_collecte.setdefault('sources_secondaires', []).extend(attempts)
    rapport_collecte['data_collection_plan'] = construire_plan_collecte(ids['date'], ids['reunion'], ids['numero_course'])
    complementary_registry = construire_registre_complementaire(ids['date'], ids['reunion'], ids['numero_course'])
    complementary_attempts = []
    for candidate in complementary_registry:
        complementary_attempts.append({
            'source': candidate['source'],
            'url': candidate['url_candidate'],
            'statut': 'UNPROVEN',
            'data_status': 'UNPROVEN',
            'identity_evidence': {'identity_verified': False, 'reason': 'Adaptateur complémentaire spécialisé non encore exécuté'},
            'adapter_status': candidate['adapter_status'],
            'collection_mode': candidate['collection_mode'],
            'data_groups': candidate['data_groups'],
            'allowed_effects': candidate['allowed_effects'],
            'warnings': ['COMPLEMENTARY_REGISTRY_ONLY_NO_TICKET_EFFECT'],
        })
    rapport_collecte['complementary_registry'] = complementary_registry
    rapport_collecte['complementary_attempts'] = complementary_attempts
    rapport_collecte['source_attempts'] = attempts
    rapport_collecte['sources_primaires_consultees'] = list(rapport_collecte.get('sources_consultees', []) or [])
    rapport_collecte['sources_effectives'] = calculer_sources_effectives(rapport_collecte)
    rapport_collecte['sources_effectives_count'] = len(rapport_collecte['sources_effectives'])
    rapport_collecte['press_consensus'] = consolider_top5_presse(attempts)
    tableau = consolider_tableau_donnees(partants or [], attempts, rapport_collecte.get('sources_consultees', []), course_context=course_context)
    rapport_collecte['consolidated_data_table'] = tableau
    rapport_collecte['multisource_gate'] = evaluer_garde_multisource(rapport_collecte, tableau)
    rapport_collecte['source_policy'] = {
        'mandatory_order': [item['source'] for item in priority_registry],
        'primary_identity_sources': ['API_PMU', 'TURF_BZH'],
        'missing_data_policy': 'NC_UNPROVEN_NO_DEFAULT',
        'top5_policy': 'PRESSE_TOP5_PAR_SOURCE_ET_CONSENSUS',
        'complementary_policy': 'SEPARATE_LAYER_UNPROVEN_NO_TICKET_EFFECT_UNTIL_SPECIALIZED_ADAPTER',
        'simultaneous_collection': True,
        'minimum_effective_sources': 3,
        'minimum_data_coverage_percent': 80.0,
        'pipeline_blocked_until_gate_pass': True,
    }
    return rapport_collecte
