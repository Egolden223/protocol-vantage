#!/usr/bin/env python3
"""Qualifie un export historique réel pour la calibration GRU.

Le script ne fabrique aucune donnée et ne calcule aucune magnitude. Il prépare
un rapport de contrat : courses complètes éligibles ou exclusions documentées.
Formats acceptés : JSON liste d'enregistrements, JSON objet contenant records ou
races, et CSV aplati avec une ligne par partant.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


def _json(value: Any, default: Any = None) -> Any:
    if isinstance(value, (dict, list)):
        return value
    if value in (None, ''):
        return default
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def _num(value: Any) -> Optional[float]:
    try:
        if value in (None, '', 'NC', 'UNPROVEN'):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _truth(value: Any) -> bool:
    return value is True or str(value).strip().lower() in {'true', '1', 'yes', 'oui'}


def _load_json(path: Path) -> List[Dict[str, Any]]:
    payload = json.loads(path.read_text(encoding='utf-8'))
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        for key in ('records', 'races', 'courses', 'data'):
            if isinstance(payload.get(key), list):
                return [item for item in payload[key] if isinstance(item, dict)]
        return [payload]
    return []


def _load_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    grouped: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        race_id = str(row.get('race_id') or row.get('id_course') or row.get('course_id') or '').strip()
        if not race_id:
            continue
        race = grouped.setdefault(race_id, {
            'race_id': race_id,
            'date': row.get('date') or row.get('date_course'),
            'decision_timestamp': row.get('decision_timestamp') or row.get('timestamp_decision'),
            'declared_starters': row.get('declared_starters') or row.get('nb_partants'),
            'all_starters_complete': _truth(row.get('all_starters_complete')),
            'official_top5': _json(row.get('official_top5'), None),
            'partants': [],
        })
        partant = {
            'numero': row.get('numero') or row.get('program_number') or row.get('no'),
            'base_score': row.get('base_score') or row.get('baseline_score'),
            'official_rank': row.get('official_rank') or row.get('finish_position') or row.get('position'),
            'candidate_features': _json(row.get('candidate_features'), {}) or {},
            'feature_timestamps': _json(row.get('feature_timestamps'), {}) or {},
        }
        race['partants'].append(partant)
    return list(grouped.values())


def _top5_from_ranks(partants: List[Dict[str, Any]]) -> Optional[List[str]]:
    ranked = []
    for row in partants:
        rank = _num(row.get('official_rank'))
        if rank is not None and 1 <= rank <= 5:
            ranked.append((rank, str(row.get('numero'))))
    ranked.sort()
    values = [number for _, number in ranked]
    return values if len(values) == 5 and len(set(values)) == 5 else None


def _qualify(race: Dict[str, Any]) -> Dict[str, Any]:
    reasons: List[str] = []
    partants = race.get('partants')
    if not isinstance(partants, list) or len(partants) < 8:
        reasons.append('MINIMUM_8_STARTERS_NOT_MET')
    declared = _num(race.get('declared_starters'))
    if declared is None:
        reasons.append('DECLARED_STARTERS_MISSING')
    elif int(declared) != len(partants or []):
        reasons.append('STARTER_DENOMINATOR_MISMATCH')
    if race.get('all_starters_complete') is not True:
        reasons.append('ALL_STARTERS_NOT_EXPLICITLY_CONFIRMED')
    if not race.get('race_id') or not race.get('date'):
        reasons.append('RACE_ID_OR_DATE_MISSING')
    official_top5 = race.get('official_top5') or _top5_from_ranks(partants or [])
    if not isinstance(official_top5, list) or len(official_top5) != 5 or len(set(str(x) for x in official_top5)) != 5:
        reasons.append('OFFICIAL_TOP5_MISSING_OR_INVALID')
    for row in partants or []:
        if _num(row.get('base_score')) is None:
            reasons.append('BASE_SCORE_MISSING')
            break
        if _num(row.get('official_rank')) is None:
            reasons.append('OFFICIAL_RANK_MISSING')
            break
        if row.get('numero') in (None, ''):
            reasons.append('STARTER_NUMBER_MISSING')
            break
    race['official_top5'] = [str(x) for x in official_top5] if isinstance(official_top5, list) else official_top5
    race['all_starters_complete'] = not any(reason in reasons for reason in ('MINIMUM_8_STARTERS_NOT_MET', 'DECLARED_STARTERS_MISSING', 'STARTER_DENOMINATOR_MISMATCH', 'ALL_STARTERS_NOT_EXPLICITLY_CONFIRMED', 'BASE_SCORE_MISSING', 'OFFICIAL_RANK_MISSING', 'STARTER_NUMBER_MISSING'))
    return {'eligible': not reasons, 'reasons': reasons, 'race': race}


def qualify(records: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    qualified = [_qualify(record) for record in records if isinstance(record, dict)]
    reason_counts = Counter(reason for item in qualified for reason in item['reasons'])
    eligible = [item['race'] for item in qualified if item['eligible']]
    return {
        'schema': 'VANTAGE_GRU_DATA_QUALIFICATION_REPORT_V1',
        'status': 'READY_FOR_CALIBRATION' if eligible else 'NO_ELIGIBLE_RACES',
        'activation': 'NEVER_AUTOMATIC',
        'source_records': len(qualified),
        'eligible_complete_records': len(eligible),
        'ineligible_records': len(qualified) - len(eligible),
        'ineligible_reason_counts': dict(sorted(reason_counts.items())),
        'records': [item['race'] for item in qualified],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description='Qualifie un export réel pour la calibration GRU.')
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    records = _load_json(args.input) if args.input.suffix.lower() == '.json' else _load_csv(args.input)
    report = qualify(records)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({key: report[key] for key in ('status', 'source_records', 'eligible_complete_records', 'ineligible_records', 'ineligible_reason_counts')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
