"""Politique de placement GMO-V issue des restrictions STAB-03bis."""
from __future__ import annotations

from typing import Any, Dict, List

from engine.models import Course, Partant


def _raw(partant: Partant, key: str, default=None):
    return (getattr(partant, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def politique_stab_ticket(partant: Partant, course: Course) -> Dict[str, Any]:
    module = next((m for m in getattr(partant, 'modules_results', []) if m.nom == 'STAB' and m.actif), None)
    flags = set(getattr(module, 'flags', []) if module else [])
    critique = 'STAB_DQ_SERIE_CRITIQUE' in flags or 'KILL_LIST_M25_EQUIVALENT' in flags
    stab_score = _num(_raw(partant, 'stab_score'))
    if stab_score is None and module is not None:
        stab_score = _num((getattr(module, 'details', {}) or {}).get('stab_score'))
    pch_norm = _num(_raw(partant, 'pch_norm'))
    if pch_norm is None and getattr(partant, 'pch_final', None) is not None:
        pch_norm = max(0.0, min(1.0, float(partant.pch_final) / 220.0))
    if not critique:
        positions = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'R1', 'R2']
        if stab_score is not None and stab_score <= -80:
            positions = ['P6', 'R1', 'R2']
        if pch_norm is not None and pch_norm < .30:
            positions = [position for position in positions if position not in {'P1', 'P2', 'P3'}]
        return {'active': False, 'eligible': True, 'positions_autorisees': positions, 'flags': sorted(flags), 'stab_score': stab_score, 'pch_norm': pch_norm, 'rah15_pch_gate': pch_norm is None or pch_norm >= .30}

    tocard = _num(partant.tocard_score, 0.0) or 0.0
    signature = str(getattr(getattr(course, 'signature_msp', None), 'value', getattr(course, 'signature_msp', '')) or '').upper()
    iic = _num(_raw(partant, 'iic_global', _raw(partant, 'iic', partant.icp_count)), 0.0) or 0.0
    chaos_p5p6 = signature.endswith('CHAOS') and tocard >= .35 and iic >= 8.5
    b07 = 'STAB_DQ_SERIE_ATTENUATION_B07' in flags or bool(_raw(partant, 'b07_strict_top3_post_dq'))
    changement = 'STAB_DQ_SERIE_CHANGEMENT_ECURIES' in flags or bool(_raw(partant, 'changement_entraineur_30j')) and bool(_raw(partant, 'dq_anterieurs_changement'))
    if b07:
        positions = ['P4', 'P5', 'P6', 'R1', 'R2']
        mode = 'B07_P4_AUTORISE'
    elif changement:
        positions = ['P3', 'P4', 'P5', 'P6', 'R1', 'R2']
        mode = 'CHANGEMENT_ECURIES_P3_P4_AUTORISES'
    elif chaos_p5p6:
        positions = ['P5', 'P6', 'R1', 'R2']
        mode = 'CHAOS_P5_P6_R1_R2'
    elif tocard >= .20:
        positions = ['R1', 'R2']
        mode = 'RESERVE_R1_R2'
    else:
        positions = []
        mode = 'EXCLUSION_TICKET'
    if stab_score is not None and stab_score <= -80:
        positions = [position for position in positions if position in {'P6', 'R1', 'R2'}]
    if pch_norm is not None and pch_norm < .30:
        positions = [position for position in positions if position not in {'P1', 'P2', 'P3'}]
    return {
        'active': True,
        'eligible': bool(positions),
        'positions_autorisees': positions,
        'flags': sorted(flags),
        'mode': mode,
        'tocard_score': tocard,
        'iic': iic,
        'signature': signature,
        'stab_score': stab_score,
        'pch_norm': pch_norm,
        'rah15_pch_gate': pch_norm is None or pch_norm >= .30,
        'rah16_stab_critique_gate': stab_score is None or stab_score > -80,
        'b07': b07,
        'changement_ecuries': changement,
    }


def position_autorisee(partant: Partant, course: Course, position: str) -> bool:
    return position in politique_stab_ticket(partant, course).get('positions_autorisees', [])
