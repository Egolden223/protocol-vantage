"""Règles P2 de validation finale : calibration, concentration et dominance."""
from __future__ import annotations

from collections import Counter
from typing import Any, Dict

from engine.models import Course


def _num(value):
    try:
        return float(value) if value not in (None, '', 'NC', 'UNPROVEN') else None
    except (TypeError, ValueError):
        return None


def evaluer_rah162(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    raw = getattr(course, 'raw_data', {}) or {}
    band = raw.get('calibration_band')
    ticket = ticket_report.get('ticket_final', {}) or {}
    if not isinstance(band, dict):
        return {'rule': 'RAH-162', 'status': 'UNPROVEN', 'reason': 'Bande de calibration externe absente', 'ticket_size': len(ticket)}
    observed_profile = raw.get('profil_course')
    expected = band.get(observed_profile, band.get('global'))
    if not isinstance(expected, dict):
        return {'rule': 'RAH-162', 'status': 'UNPROVEN', 'reason': 'Segment de calibration absent', 'profil_course': observed_profile}
    expected_size = expected.get('ticket_size')
    ecart = None if expected_size is None else len(ticket) - float(expected_size)
    return {'rule': 'RAH-162', 'status': 'CALCULATED', 'profil_course': observed_profile, 'ticket_size': len(ticket), 'calibration_reference': expected, 'ecart_ticket_size': ecart, 'ecart_significatif': abs(ecart) > 1 if ecart is not None else None}


def evaluer_rah187(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    raw = getattr(course, 'raw_data', {}) or {}
    sct, tdi = raw.get('SCT'), raw.get('TDI')
    if sct in (None, '', 'NC', 'UNPROVEN') or tdi in (None, '', 'NC', 'UNPROVEN'):
        return {'rule': 'RAH-187', 'status': 'UNPROVEN', 'reason': 'SCT/TDI non fournis par le calculateur normatif'}
    return {'rule': 'RAH-187', 'status': 'CALCULATED', 'SCT': sct, 'TDI': tdi, 'concentration_alert': bool(raw.get('SCT_alert') or raw.get('TDI_alert'))}


def evaluer_rah193(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = {}
    ticket = ticket_report.get('ticket_final', {}) or {}
    for position, item in ticket.items():
        partant = next((p for p in course.partants if p.numero == item.get('numero')), None)
        signals = [float(getattr(s, 'valeur', 0) or 0) for s in getattr(partant, 'signaux', []) if getattr(s, 'actif', False) and not getattr(s, 'flag_manquant', False)] if partant else []
        total = sum(max(0.0, x) for x in signals)
        max_share = max((max(0.0, x) for x in signals), default=None)
        rows[position] = {'numero': item.get('numero'), 'status': 'CALCULATED' if total > 0 else 'UNPROVEN', 'max_factor_share': max_share / total if total > 0 else None, 'dominance_alert': max_share / total > .50 if total > 0 else None}
    return {'rule': 'RAH-193', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'threshold': .50}


def _ticket_rows(course: Course, ticket_report: Dict[str, Any]):
    rows = []
    for position, item in (ticket_report.get('ticket_final', {}) or {}).items():
        partant = next((p for p in course.partants if p.numero == item.get('numero')), None)
        if partant is not None:
            rows.append((position, partant))
    return rows


def _specialiste_evidence(partant) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    active_codes = {str(s.code).upper() for s in getattr(partant, 'signaux', []) if getattr(s, 'actif', False) and str(getattr(s, 'niveau_fallback', 'STRICT')).upper() in {'STRICT', 'DEGRADE'} and not getattr(s, 'flag_manquant', False)}
    gate = bool(active_codes.intersection({'B04', 'B05', 'B19'}))
    other_count = len(active_codes - {'B04', 'B05', 'B19'})
    ordre = _num(getattr(partant, 'ordre_score', None))
    icp = _num(raw.get('icp_global', getattr(partant, 'icp_count', None)))
    complete = ordre is not None and icp is not None
    qualified = gate and other_count >= 2 and ordre is not None and ordre >= .35 and icp is not None and icp >= 1
    return {'qualified': qualified, 'status': 'CALCULATED' if complete else 'UNPROVEN', 'gate_signal': sorted(active_codes.intersection({'B04', 'B05', 'B19'})), 'other_signal_count': other_count, 'ordre_score': ordre, 'icp': icp, 'criteria': 'B04/B05/B19 actif + 2 autres signaux + ORDRE>=0.35 + ICP>=1'}


def _tocard_evidence(partant) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    cote = _num(getattr(partant, 'cote', None))
    score = _num(getattr(partant, 'tocard_score', None))
    icp = _num(raw.get('icp_global', getattr(partant, 'icp_count', None)))
    ordre = _num(getattr(partant, 'ordre_score', None))
    qualified = (cote is not None and cote >= 25) or (score is not None and score >= .25) or (icp is not None and icp <= 2 and ordre is not None and ordre >= .30)
    return {'qualified': qualified, 'status': 'CALCULATED' if cote is not None and score is not None and icp is not None and ordre is not None else 'UNPROVEN', 'cote': cote, 'tocard_score': score, 'icp': icp, 'ordre_score': ordre, 'criteria': 'cote>=25 OU tocard_score>=0.25 OU ICP<=2 et ORDRE>=0.30'}


def evaluer_rah03(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = [{'position': position, 'numero': partant.numero, **_specialiste_evidence(partant)} for position, partant in _ticket_rows(course, ticket_report) if position in {'P3', 'P4', 'P5'}]
    status = 'PASS' if any(row['qualified'] for row in rows) else 'UNPROVEN' if any(row['status'] == 'UNPROVEN' for row in rows) else 'FAIL'
    return {'rule': 'RAH-03', 'status': status, 'scope': 'P3-P5', 'specialistes': rows, 'minimum': 1}


def evaluer_rah04(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = [{'position': position, 'numero': partant.numero, **_tocard_evidence(partant)} for position, partant in _ticket_rows(course, ticket_report) if position in {'P5', 'P6', 'R1', 'R2'}]
    status = 'PASS' if any(row['qualified'] for row in rows) else 'UNPROVEN' if any(row['status'] == 'UNPROVEN' for row in rows) else 'FAIL'
    return {'rule': 'RAH-04', 'status': status, 'scope': 'P5-P6/R1-R2', 'tocards': rows, 'minimum': 1}


def evaluer_rah05(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = [{'position': position, 'numero': partant.numero, 'proprietaire': (getattr(partant, 'raw_data', {}) or {}).get('proprietaire', ''), 'status': 'CALCULATED' if (getattr(partant, 'raw_data', {}) or {}).get('proprietaire') else 'UNPROVEN'} for position, partant in _ticket_rows(course, ticket_report) if position in {'P1', 'P2'}]
    owners = [row['proprietaire'] for row in rows if row['proprietaire']]
    duplicate = len(owners) == 2 and owners[0] == owners[1]
    return {'rule': 'RAH-05', 'status': 'FAIL' if duplicate else 'PASS' if len(owners) == 2 else 'UNPROVEN', 'scope': 'P1-P2', 'rows': rows, 'duplicate_owner': duplicate}


def evaluer_rah06(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = [{'position': position, 'numero': partant.numero, 'entraineur': getattr(partant, 'entraineur', ''), 'status': 'CALCULATED' if getattr(partant, 'entraineur', '') else 'UNPROVEN'} for position, partant in _ticket_rows(course, ticket_report) if position in {'P1', 'P2'}]
    trainers = [row['entraineur'] for row in rows if row['entraineur']]
    duplicate = len(trainers) == 2 and trainers[0] == trainers[1]
    signature = getattr(getattr(course, 'signature_msp', None), 'value', str(getattr(course, 'signature_msp', 'STANDARD'))).upper()
    p2 = next((partant for position, partant in _ticket_rows(course, ticket_report) if position == 'P2'), None)
    supra = _num((getattr(p2, 'raw_data', {}) or {}).get('signal_supra_individuel')) if p2 else None
    exception = duplicate and signature == 'CHAOS' and supra is not None and supra >= 2
    passed = not duplicate or exception
    return {'rule': 'RAH-06', 'status': 'PASS' if passed and len(trainers) == 2 else 'FAIL' if duplicate else 'UNPROVEN', 'scope': 'P1-P2', 'rows': rows, 'duplicate_trainer': duplicate, 'exception_rah262': exception, 'exception_evidence': {'signature': signature, 'signal_supra_individuel_p2': supra, 'minimum': 2}}


def evaluer_rah_structure(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    return {'RAH-03': evaluer_rah03(course, ticket_report), 'RAH-04': evaluer_rah04(course, ticket_report), 'RAH-05': evaluer_rah05(course, ticket_report), 'RAH-06': evaluer_rah06(course, ticket_report)}


def _category_ticket(partant):
    raw = getattr(partant, 'raw_data', {}) or {}
    value = raw.get('categorie_ticket', raw.get('classification_ticket', raw.get('profil_category')))
    if value not in (None, '', 'NC'):
        return str(value).upper().replace('-', '_').replace('É', 'E')
    profil = getattr(partant, 'profil_ado', None)
    return str(getattr(profil, 'value', profil) or '').upper().replace('-', '_') or None


def evaluer_rah01(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = _ticket_rows(course, ticket_report)
    p1 = next((partant for position, partant in rows if position == 'P1'), None)
    category = _category_ticket(p1) if p1 else None
    sans_pilier = bool((ticket_report or {}).get('sans_pilier') or (getattr(course, 'derived_metrics', {}) or {}).get('sans_pilier'))
    if p1 is None or category is None:
        return {'rule': 'RAH-01', 'status': 'UNPROVEN', 'position': 'P1', 'category': category, 'sans_pilier': sans_pilier}
    passed = category == 'PILIER' or sans_pilier
    return {'rule': 'RAH-01', 'status': 'PASS' if passed else 'FAIL', 'position': 'P1', 'category': category, 'sans_pilier': sans_pilier}


def evaluer_rah02(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = []
    for position, partant in _ticket_rows(course, ticket_report):
        if position in {'P2', 'P3'}:
            category = _category_ticket(partant)
            rows.append({'position': position, 'numero': partant.numero, 'category': category, 'status': 'CALCULATED' if category else 'UNPROVEN', 'minimum': ['REGULIER', 'DEMI_FAVORI']})
    if not rows or any(row['status'] == 'UNPROVEN' for row in rows):
        status = 'UNPROVEN'
    else:
        status = 'PASS' if all(row['category'] in {'REGULIER', 'DEMI_FAVORI'} for row in rows) else 'FAIL'
    return {'rule': 'RAH-02', 'status': status, 'positions': rows, 'minimum_categories': ['REGULIER', 'DEMI_FAVORI']}


def evaluer_rah09(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    from modules.gmov import tranche_cote
    signature = str(getattr(getattr(course, 'signature_msp', None), 'value', getattr(course, 'signature_msp', '')) or '').upper()
    if signature != 'LOCK':
        return {'rule': 'RAH-09', 'status': 'NOT_APPLICABLE', 'signature': signature, 'minimum_t1_t3': 4}
    selected = [(position, partant) for position, partant in _ticket_rows(course, ticket_report) if position in {'P1', 'P2', 'P3', 'P4', 'P5', 'P6'}]
    if len(selected) < 6:
        return {'rule': 'RAH-09', 'status': 'UNPROVEN', 'signature': signature, 'selected_count': len(selected), 'minimum_t1_t3': 4}
    tranches = [{'position': position, 'numero': partant.numero, 'tranche': tranche_cote(partant)} for position, partant in selected]
    count = sum(row['tranche'] in {'T1', 'T2', 'T3'} for row in tranches)
    return {'rule': 'RAH-09', 'status': 'PASS' if count >= 4 else 'FAIL', 'signature': signature, 't1_t3_count_p1_p6': count, 'minimum_t1_t3': 4, 'positions': tranches}


def evaluer_rah131(course: Course) -> Dict[str, Any]:
    hippo = str(getattr(course, 'hippodrome', '') or '').upper().replace('É', 'E')
    if hippo != 'CHANTILLY':
        return {'rule': 'RAH-131', 'status': 'NOT_APPLICABLE', 'applicable': False}
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        if course.distance < 1600:
            topology = raw.get('ligne_droite')
            expected = {'corde18': 4.8, 'corde1': -2.0}
        elif course.distance == 1600:
            topology = raw.get('virage_1600')
            expected = {'corde6': 4.8}
        else:
            topology = None
            expected = {}
        if course.distance < 1600 and topology is None or course.distance == 1600 and topology is None:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'reason': 'Configuration ligne droite/virage absente', 'tier': 'C', 'magnitude_factor': .40}
        else:
            rows[str(partant.numero)] = {'status': 'CALCULATED', 'applicable': bool(topology), 'tier': 'C', 'magnitude_factor': .40, 'expected_contributions': expected, 'prudence_flag': 'GRU_TIER_C_PRUDENCE'}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-131', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'source_confidence': 'TIER_C', 'required_flag': 'GRU_TIER_C_PRUDENCE'}


def evaluer_rah88(course: Course) -> Dict[str, Any]:
    hippo = str(getattr(course, 'hippodrome', '') or '').upper().replace('É', 'E')
    discipline = str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')) or '').upper()
    applicable = hippo == 'COMPIEGNE' and discipline in {'PLAT', 'HAIES'}
    if not applicable:
        return {'rule': 'RAH-88', 'status': 'NOT_APPLICABLE', 'applicable': False, 'reason': 'Compiègne Plat/Haies uniquement'}
    meta = getattr(course, 'collecte_meta', {}) or {}
    direction = meta.get('sens_corde_officiel', meta.get('sens_rotation_course', meta.get('sens_hippodrome')))
    source = meta.get('sens_corde_source', meta.get('programme_officiel_source'))
    if direction in (None, '', 'NC') or not source:
        return {'rule': 'RAH-88', 'status': 'UNPROVEN', 'applicable': True, 'direction': direction, 'source': source, 'flag': 'COMPIEGNE_CORDE_A_CONFIRMER'}
    return {'rule': 'RAH-88', 'status': 'CALCULATED', 'applicable': True, 'direction': str(direction).upper(), 'source': source, 'conflict_resolved': True}


def evaluer_rah124_129(course: Course) -> Dict[str, Any]:
    codes = {'RAH-124-GRU-DIST-1': 'RAH-124', 'RAH-125-GRU-DIST-2': 'RAH-125', 'RAH-126-GRU-DIST-3': 'RAH-126', 'RAH-127-GRU-DIST-4': 'RAH-127', 'RAH-127-GRU-DIST-4-PSF': 'RAH-127', 'RAH-128-GRU-VOLTE-1': 'RAH-128', 'RAH-132-GRU-TERRAIN-1': 'RAH-132', 'RAH-133-GRU-TERRAIN-2': 'RAH-133', 'RAH-134-GRU-ETRANGER': 'RAH-134', 'RAH-134-GRU-ETRANGER-DECOUVERTE': 'RAH-134', 'RAH-138-GRU-B12-LOCAL': 'RAH-138', 'RAH-139-GRU-AUTEUIL-DEBUTANT': 'RAH-139', 'RAH-139-GRU-AUTEUIL-SPECIALISTE': 'RAH-139', 'RAH-139-GRU-AUTEUIL-CHUTE': 'RAH-139', 'RAH-139-GRU-AUTEUIL-BOUE': 'RAH-139', 'RAH-139-GRU-AUTEUIL-AGE': 'RAH-139', 'RAH-140-GRU-COMPIEGNE-MENEUR': 'RAH-140', 'RAH-140-GRU-COMPIEGNE-ATTENTISTE': 'RAH-140', 'RAH-140-GRU-COMPIEGNE-SOUPLE': 'RAH-140', 'RAH-140-GRU-COMPIEGNE-BOUE': 'RAH-140', 'RAH-141-GRU-VINCENNES-D4': 'RAH-141'}
    rows = {code: {'status': 'NOT_TRIGGERED', 'rules': []} for code in {'RAH-124', 'RAH-125', 'RAH-126', 'RAH-127', 'RAH-128', 'RAH-129', 'RAH-132', 'RAH-133', 'RAH-134', 'RAH-138', 'RAH-139', 'RAH-140', 'RAH-141'}}
    for rule in getattr(course, 'gru_regles', []) or []:
        parent = codes.get(getattr(rule, 'code', ''), getattr(rule, 'code', ''))
        if parent in rows:
            rows[parent]['status'] = 'CALCULATED'
            rows[parent]['rules'].append({'code': rule.code, 'contribution': rule.pch_contribution, 'description': rule.description})
    for partant in getattr(course, 'partants', []) or []:
        module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'MODULE_RECUL'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rah129 = details.get('rah129') if isinstance(details.get('rah129'), dict) else None
        if rah129 is not None:
            rows['RAH-129']['status'] = 'CALCULATED' if rah129.get('status') in {'APPLIED', 'NOT_TRIGGERED'} else 'UNPROVEN'
            rows['RAH-129'].setdefault('partants', {})[str(partant.numero)] = rah129
        elif module is not None and getattr(module, 'actif', False):
            rows['RAH-129'].setdefault('partants', {})[str(partant.numero)] = {'status': 'UNPROVEN', 'reason': 'Détails RAH-129 absents'}
    return {'rule': 'RAH-124_129', 'status': 'CALCULATED' if all(row['status'] in {'CALCULATED', 'NOT_TRIGGERED'} for row in rows.values()) else 'UNPROVEN', 'rules': rows, 'no_proxy': True}


def evaluer_rah121(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in getattr(course, 'partants', []) or []:
        module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'CRE_v2'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        if details.get('mode') == 'CRE_PROXY_v3':
            delta = _num(details.get('delta_rk_moyen'))
            coherent = details.get('tendance_coherente')
            level = 5 if delta is not None and delta >= .40 else 4 if delta is not None and delta >= .20 else 3 if delta is not None and delta >= -.15 else 2 if delta is not None and delta >= -.40 else 1 if delta is not None else None
            rows[str(partant.numero)] = {'status': 'CALCULATED', 'mode': 'CRE_PROXY_v3', 'delta_rk_pondere': delta, 'weight_delta_rk_12': .40, 'weight_delta_rk_23': .60, 'tendance_coherente': coherent, 'reduction_incoherence': .70 if coherent is False and delta is not None and delta > 0 else 1.0, 'niveau_5': level, 'score': getattr(module, 'score', None)}
        elif details.get('mode') == 'CRE_v2':
            rows[str(partant.numero)] = {'status': 'NOT_APPLICABLE', 'mode': 'CRE_v2', 'reason': 'Chrono CRE direct disponible; proxy non requis'}
        elif 'CRE_DESACTIVE' in set(getattr(module, 'flags', []) if module is not None else []):
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'mode': 'DESACTIVE', 'reason': 'RK/chrono insuffisants'}
        else:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'reason': 'CRE_v3 absent'}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-121', 'status': 'CALCULATED' if statuses and all(s in {'CALCULATED', 'NOT_APPLICABLE'} for s in statuses) else 'UNPROVEN', 'partants': rows, 'formula': '0.40*delta_rk_12+0.60*delta_rk_23', 'incoherence_factor': .70}


def evaluer_rah120(course: Course) -> Dict[str, Any]:
    field_size = _num(getattr(course, 'nb_partants', None)) or float(len(getattr(course, 'partants', []) or []))
    ift = _num(getattr(course, 'ift_moyen_champ', None))
    vm = _num(getattr(course, 'nb_valeur_morte_champ', None))
    media = _num(getattr(course, 'overbet_media_count', None))
    kills = _num(getattr(course, 'kill_list_count', None))
    conditions = {'ift_ge_75': ift is not None and ift >= 75, 'valeur_morte_le_3': vm is not None and vm <= 3, 'overbet_media_le_1': media is not None and media <= 1, 'kill_list_ratio_le_015': kills is not None and field_size > 0 and kills / field_size <= .15}
    reliable = all(conditions.values())
    rows = {}
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        individual_block = raw.get('overbet_surcote') is True or raw.get('m30_paradoxe_favori') is True
        rows[str(partant.numero)] = {'status': 'CALCULATED', 'harville_mult': 1.0, 'individual_block': individual_block, 'reason': 'RAH120_INDIVIDUAL' if individual_block else 'RAH120_FIELD_UNRELIABLE' if not reliable else 'RAH120_RELIABLE'}
    return {'rule': 'RAH-120', 'status': 'CALCULATED' if reliable else 'UNPROVEN', 'harville_fiable': reliable, 'harville_mult_default': 1.0 if not reliable else None, 'conditions': conditions, 'field_size': field_size, 'partants': rows, 'neutral_if_unproven': True}


def evaluer_rah137(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in getattr(course, 'partants', []) or []:
        module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'PDQ'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rah137 = details.get('rah137') if isinstance(details.get('rah137'), dict) else None
        rows[str(partant.numero)] = {'status': 'CALCULATED' if rah137 is not None else 'UNPROVEN', 'rah137': rah137, 'pdq_contribution': details.get('contribution')}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-137', 'status': 'CALCULATED' if statuses and all(s == 'CALCULATED' for s in statuses) else 'UNPROVEN', 'partants': rows, 'standard_factor': .50, 'rah137_factor': .40}


def evaluer_rah136(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        inedit = raw.get('premiere_course') is True or raw.get('cheval_inedit') is True or raw.get('nb_courses_total') == 0
        pdq = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'PDQ'), None)
        pente = raw.get('pente_details') or {}
        b47_active = any(getattr(s, 'code', '') == 'B47' and getattr(s, 'actif', False) for s in getattr(partant, 'signaux', []))
        top = raw.get('entraineur_top_strict') is True
        rows[str(partant.numero)] = {'status': 'CALCULATED' if inedit else 'NOT_APPLICABLE', 'inedit': inedit, 'pdq_neutralise': bool(inedit and pdq and pdq.details.get('rah136_inedit')), 'pente_neutralisee': bool(inedit and pente.get('flag') == 'RAH136_NOEUF_PENTE_NEUTRALISEE'), 'b47_actif_observe': b47_active, 'b47_neutralisation_requise': inedit, 'entraineur_top_strict': top, 'bonus_top_strict': 6 if inedit and top else 0, 'requalification_factor': .50 if raw.get('cheval_requalifie') is True else 1.0}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-136', 'status': 'CALCULATED' if statuses and all(s in {'CALCULATED', 'NOT_APPLICABLE'} for s in statuses) else 'UNPROVEN', 'partants': rows, 'noeuf_neutralises': ['PDQ', 'B47', 'PENTE'], 'requalification_factor': .50}


def evaluer_rah148(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    supra = (ticket_report.get('etapes', {}) or {}).get('etape_11_supra') or ticket_report.get('supra')
    if not isinstance(supra, dict):
        return {'rule': 'RAH-148', 'status': 'UNPROVEN', 'reason': 'Rapport SUPRA absent'}
    phase7 = (supra.get('phases') or {}).get('phase7_rah238') or {}
    prudence = _num(phase7.get('facteurs_prudence_actifs'))
    plafond = _num(phase7.get('plafond_modifications_rah216'))
    if prudence is None or plafond is None:
        return {'rule': 'RAH-148', 'status': 'UNPROVEN', 'reason': 'Facteurs de prudence ou plafond absents'}
    expected = max(0, 3 - int(prudence))
    return {'rule': 'RAH-148', 'status': 'CALCULATED' if int(plafond) == expected and plafond >= 0 else 'FAIL', 'facteurs_prudence_actifs': int(prudence), 'plafond_observe': int(plafond), 'plafond_attendu': expected, 'jamais_neutralisation_totale': bool(phase7.get('jamais_neutralisation_totale', True))}


def evaluer_rah149(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    supra = (ticket_report.get('etapes', {}) or {}).get('etape_11_supra') or ticket_report.get('supra')
    if not isinstance(supra, dict):
        return {'rule': 'RAH-149', 'status': 'UNPROVEN', 'reason': 'Rapport SUPRA absent'}
    applied = supra.get('modifications_appliquees', []) or []
    blocked = supra.get('modifications_bloquees', []) or []
    total = len(applied) + len(blocked)
    convergences = [len(mod.get('familles_convergentes', []) or []) >= 2 for mod in applied + blocked]
    status = 'CALCULATED' if total <= 3 and all(convergences) else 'FAIL'
    return {'rule': 'RAH-149', 'status': status, 'total_modifications': total, 'maximum': 3, 'convergence_2_familles': convergences, 'maximum_ok': total <= 3}


def evaluer_rah147(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    supra = (ticket_report.get('etapes', {}) or {}).get('etape_11_supra') or ticket_report.get('supra')
    if not isinstance(supra, dict):
        return {'rule': 'RAH-147', 'status': 'UNPROVEN', 'reason': 'Rapport SUPRA absent', 'publication_allowed': False}
    applied = supra.get('modifications_appliquees', []) or []
    blocked = supra.get('modifications_bloquees', []) or []
    rows = []
    valid = True
    for mod in applied + blocked:
        confidence = _num(mod.get('supra_confiance'))
        expected = 'APPLIED' if mod in applied else 'BLOCKED'
        row = {'numero': mod.get('numero'), 'status': expected, 'supra_confiance': confidence, 'threshold': .50}
        if confidence is None or (expected == 'APPLIED' and confidence < .50) or (expected == 'BLOCKED' and confidence >= .50):
            valid = False
        rows.append(row)
    status = 'CALCULATED' if valid else 'UNPROVEN'
    return {'rule': 'RAH-147', 'status': status, 'modifications': rows, 'individual_threshold': .50, 'no_global_confidence_proxy': True}


def evaluer_rah142(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    supra = (ticket_report.get('etapes', {}) or {}).get('etape_11_supra') or ticket_report.get('supra')
    if not isinstance(supra, dict):
        return {'rule': 'RAH-142', 'status': 'UNPROVEN', 'reason': 'Rapport SUPRA absent', 'publication_allowed': False}
    phases = supra.get('phases') or {}
    expected = ['phase1_anomalies', 'phase2_coherence', 'phase2_rah146', 'phase3_marche', 'phase4_presse_divergence', 'phase5_modules_diff', 'phase6_contraintes', 'phase7_rah238']
    present = [phase for phase in expected if phase in phases]
    order_ok = list(phases.keys())[:len(expected)] == expected if len(phases) >= len(expected) else False
    max_ok = int(supra.get('nb_modifications', 0) or 0) <= 3
    status = 'CALCULATED' if len(present) == len(expected) and order_ok and max_ok else 'UNPROVEN'
    return {'rule': 'RAH-142', 'status': status, 'phases_expected': expected, 'phases_present': present, 'order_ok': order_ok, 'executed_before_gmov': True, 'max_modifications_ok': max_ok, 'publication_allowed': status == 'CALCULATED'}


def evaluer_rah97_99(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    ticket = getattr(course, 'ticket', {}) or {}
    if not ticket:
        ticket = ticket_report.get('ticket_final', {}) or {}
    entries = []
    for position, item in ticket.items():
        if isinstance(item, dict):
            numero = item.get('numero')
            category = str(item.get('categorie', item.get('category', '')) or '').upper()
            entries.append({'position': position, 'numero': numero, 'category': category, 'style': item.get('style')})
    categories = [row['category'] for row in entries]
    priority = ['PILIER', 'DEMI_FAVORI', 'REGULIER', 'SPECIALISTE', 'TOCARD']
    observed_priority = [priority.index(cat) for cat in categories if cat in priority]
    r97 = {'rule': 'RAH-97', 'status': 'CALCULATED' if entries and len(observed_priority) == len(entries) else 'UNPROVEN', 'category_order': priority, 'observed_categories': categories, 'priority_observed': observed_priority}
    numbers = {row['numero'] for row in entries if row['numero'] is not None}
    styles = {row['style'] for row in entries if row['style']}
    tocard_count = sum(1 for row in entries if row['category'] == 'TOCARD')
    p1_p3 = [row for row in entries if str(row['position']) in {'P1', 'P2', 'P3'}]
    kill_violation = any(bool((next((p for p in getattr(course, 'partants', []) or [] if p.numero == row['numero']), None) or Partant(0, '')).raw_data.get('kill_list')) for row in p1_p3)
    r98 = {'rule': 'RAH-98', 'status': 'CALCULATED' if len(numbers) == 8 and tocard_count >= 1 and len(styles) >= 2 and not kill_violation else 'UNPROVEN', 'ticket_size': len(numbers), 'tocard_count': tocard_count, 'style_count': len(styles), 'kill_violation_p1_p3': kill_violation, 'minimums': {'ticket': 8, 'tocard': 1, 'styles': 2}}
    borda_rows = []
    for row in entries:
        partant = next((p for p in getattr(course, 'partants', []) or [] if p.numero == row['numero']), None)
        raw = getattr(partant, 'raw_data', {}) or {} if partant else {}
        borda = raw.get('borda_score', raw.get('borda_final'))
        borda_rows.append({'position': row['position'], 'numero': row['numero'], 'borda_score': borda, 'status': 'CALCULATED' if _num(borda) is not None else 'UNPROVEN'})
    r99 = {'rule': 'RAH-99', 'status': 'CALCULATED' if borda_rows and all(row['status'] == 'CALCULATED' for row in borda_rows) else 'UNPROVEN', 'criteria_weights': {'ordre': 2.0, 'pch_norm': 1.5, 'tocard': 1.0, 'csf': 1.0, 'cote_inverse': .5, 'style_rythme': .5, 'icp': .3, 'dernier_rang_inverse': .3}, 'rows': borda_rows}
    return {'RAH-97': r97, 'RAH-98': r98, 'RAH-99': r99}


def evaluer_rah243_245_253_254_260_261_263_264_265(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = {}
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        numero = str(partant.numero)
        anciennete = _num(raw.get('jours_depuis_derniere_course', raw.get('absence_jours')))
        nb_courses = _num(raw.get('nb_courses_total', raw.get('nb_courses')))
        s243 = 'CALCULATED' if anciennete is not None and nb_courses is not None else 'UNPROVEN'
        r243 = {'status': s243, 'jours_absence': anciennete, 'nb_courses': nb_courses, 'excessive': s243 == 'CALCULATED' and anciennete > 548 and nb_courses > 10, 'tier': 'RETROGRADE' if s243 == 'CALCULATED' and anciennete > 548 and nb_courses > 10 else 'STANDARD'}
        victoires = _num(raw.get('serie_victoires', raw.get('victoires_consecutives')))
        allocation = _num(raw.get('allocation_categorie', raw.get('allocation_course')))
        reference = _num(raw.get('allocation_reference', raw.get('allocation_precedente')))
        s245 = 'CALCULATED' if victoires is not None and allocation is not None and reference is not None else 'UNPROVEN'
        active245 = s245 == 'CALCULATED' and victoires >= 3 and allocation > 1.3 * reference
        r245 = {'status': s245, 'serie_victoires': victoires, 'allocation': allocation, 'allocation_reference': reference, 'montee_non_confirmee': active245, 'malus_pch': -6 if active245 else 0}
        cote = _num(getattr(partant, 'cote', None))
        f6 = raw.get('famille_6_opportuniste_tactique', raw.get('f6_candidat_observe'))
        s247 = 'CALCULATED' if cote is not None and f6 is not None else 'UNPROVEN'
        r247 = {'status': s247, 'cote': cote, 'f6_observe': f6, 'applicable': s247 == 'CALCULATED' and cote > 30, 'ls_final_contribution': 0, 'ticket_effect': False}
        sample_rows = {}
        for name in ('SF', 'CSF', 'PDQ', 'TANDEM'):
            sample = _num(raw.get('sample_' + name.lower(), raw.get('nb_courses_' + name.lower())))
            signal = raw.get(name.lower() + '_score')
            if sample is not None or signal is not None:
                sample_rows[name] = {'status': 'CALCULATED' if sample is not None else 'UNPROVEN', 'sample': sample, 'weight_factor': .70 if name in {'SF', 'CSF', 'PDQ'} and sample is not None and sample < 8 else 1.0, 'tandem_cap': 5 if name == 'TANDEM' and sample is not None and sample < 8 else None}
        r253 = {'status': 'CALCULATED' if sample_rows and all(x['status'] == 'CALCULATED' for x in sample_rows.values()) else ('UNPROVEN' if sample_rows else 'NOT_APPLICABLE'), 'samples': sample_rows, 'threshold': 8}
        vals = raw.get('d22_conditions')
        conditions = [bool(x) for x in vals[:4]] if isinstance(vals, (list, tuple)) and len(vals) >= 4 else [raw.get(k) for k in ('d22_a', 'd22_b', 'd22_c', 'd22_d')]
        s254 = 'CALCULATED' if all(isinstance(x, bool) for x in conditions) else 'UNPROVEN'
        r254 = {'status': s254, 'conditions': conditions, 'conditions_true': sum(x is True for x in conditions), 'strict': s254 == 'CALCULATED' and sum(x is True for x in conditions) >= 2, 'minimum_simultaneous': 2}
        style = str(raw.get('style_mpa', '') or '').upper()
        rythme = str(raw.get('rythme_projete', '') or '').upper()
        s260 = 'CALCULATED' if style and rythme else 'UNPROVEN'
        r260 = {'status': s260, 'style': style or None, 'rythme': rythme or None, 'malus_mpa_champ': -10 if s260 == 'CALCULATED' and 'ATTENTISTE' in style and rythme in {'LENT', 'TRES_LENT', 'TRÈS_LENT'} else 0}
        incident = raw.get('incident_concurrent_documente', raw.get('incident_documente'))
        drift = _num(raw.get('drift'))
        s261 = 'CALCULATED' if drift is not None or incident is not None else 'UNPROVEN'
        r261 = {'status': s261, 'drift_observe': drift, 'incident_documente': incident, 'drift_neutralise': incident is True, 'drift_effectif': 0 if incident is True else drift}
        atypique = raw.get('decouverte_hippodrome_atypique', raw.get('premiere_course_hippodrome_atypique'))
        european = raw.get('performance_european_pattern', raw.get('european_pattern'))
        d09bis = raw.get('d09bis_capture', raw.get('deferrage_4_pieds_premiere', raw.get('deferrage_ponctuel')))
        d09 = raw.get('d09_active', raw.get('d09_bonus'))
        r263 = {'status': 'CALCULATED' if atypique is not None else 'UNPROVEN', 'decouverte_atypique': atypique, 'malus_pch': -3 if atypique is True else 0}
        r264 = {'status': 'CALCULATED' if european is not None else 'UNPROVEN', 'european_pattern': european, 'sri_taux': 'PLEIN' if european is True else 'NON_APPLICABLE'}
        b_d09 = _num(d09) if d09 not in (None, True, False) else (3 if d09 is True else 0)
        b_d09bis = 3 if d09bis is True else 0
        r265 = {'status': 'CALCULATED' if d09bis is not None or d09 is not None else 'UNPROVEN', 'd09bis': d09bis, 'd09': d09, 'bonus_d09bis': b_d09bis, 'bonus_d09': b_d09, 'bonus_max_non_cumule': max(b_d09bis, b_d09)}
        rows[numero] = {'RAH-243': r243, 'RAH-245': r245, 'RAH-247': r247, 'RAH-253': r253, 'RAH-254': r254, 'RAH-260': r260, 'RAH-261': r261, 'RAH-263': r263, 'RAH-264': r264, 'RAH-265': r265}
    return {code: {numero: row[code] for numero, row in rows.items()} for code in ('RAH-243', 'RAH-245', 'RAH-247', 'RAH-253', 'RAH-254', 'RAH-260', 'RAH-261', 'RAH-263', 'RAH-264', 'RAH-265')}


def evaluer_rah282_287(course: Course) -> Dict[str, Any]:
    discipline = str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')) or '').upper()
    applicable = discipline in {'TROT_ATTELE', 'TROT_MONTE'} and bool(getattr(course, 'handicap', False) or (getattr(course, 'raw_data', {}) or {}).get('handicap'))
    recul_values = [(_num((getattr(p, 'raw_data', {}) or {}).get('recul_m')), p.numero) for p in getattr(course, 'partants', []) or []]
    observed = applicable and any(value is not None and value > 0 for value, _ in recul_values)
    return {'RAH-282': {'status': 'CALCULATED' if observed else 'NOT_APPLICABLE' if not applicable else 'UNPROVEN', 'recul_observe': [numero for value, numero in recul_values if value is not None and value > 0], 'contribution_pch': 0, 'flag': 'RENDRE_LA_DISTANCE_NEUTRE' if observed else None, 'no_bonus_no_malus': True}, 'RAH-287': {'status': 'NOT_APPLICABLE', 'reason': 'Version bonus/malus alternative non retenue par la clarification RAH-282', 'contribution_pch': 0, 'implemented': False}}


def evaluer_rah85_89(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    known = {'VINCENNES', 'LONGCHAMP', 'CHANTILLY', 'AUTEUIL', 'SAINT-CLOUD', 'DEAUVILLE', 'ENGHIEN', 'MAISONS-LAFFITTE', 'CAGNES-SUR-MER', 'LYON-PARILLY', 'TOULOUSE', 'BORDEAUX', 'MARSEILLE-BORELY', 'NANTES', 'STRASBOURG', 'COMPIEGNE', 'FONTAINEBLEAU', 'CRAON', 'CABOURG', 'LAVAL', 'VICHY', 'CLAIREFONTAINE'}
    hippo = str(getattr(course, 'hippodrome', '') or '').upper().replace('É', 'E')
    rows = {code: [] for code in ('RAH-85', 'RAH-86', 'RAH-89')}
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        ligne_droite = raw.get('ligne_droite') is True
        profil = raw.get('profil_corde_ligne_droite', raw.get('corde_profil'))
        rows['RAH-85'].append({'numero': partant.numero, 'status': 'CALCULATED' if not (getattr(course, 'distance', 0) < 1600 and ligne_droite) or profil is not None else 'UNPROVEN', 'applicable': getattr(course, 'distance', 0) < 1600 and ligne_droite, 'profil': profil})
        spec_v = raw.get('specialiste_vincennes')
        spec_e = raw.get('specialiste_enghien')
        transfert = raw.get('b04_d07_transfert')
        rows['RAH-86'].append({'numero': partant.numero, 'status': 'FAIL' if transfert is True else 'CALCULATED' if spec_v is not None or spec_e is not None else 'UNPROVEN', 'specialiste_vincennes': spec_v, 'specialiste_enghien': spec_e, 'transfert_interdit': True})
        sens = raw.get('sens_corde_officiel', raw.get('sens_rotation_course', raw.get('sens_hippodrome')))
        rows['RAH-89'].append({'numero': partant.numero, 'status': 'CALCULATED' if sens is not None else 'UNPROVEN', 'sens_corde': sens})
    unknown = hippo not in known
    r87 = {'rule': 'RAH-87', 'status': 'FAIL' if unknown else 'CALCULATED', 'hippodrome': hippo, 'gru_known': not unknown, 'ift_penalty': -3 if unknown else 0, 'flag': 'GRU_INCONNU' if unknown else None}
    return {
        'RAH-85': {'rule': 'RAH-85', 'status': 'CALCULATED' if rows['RAH-85'] and all(row['status'] == 'CALCULATED' for row in rows['RAH-85']) else 'UNPROVEN', 'partants': rows['RAH-85']},
        'RAH-86': {'rule': 'RAH-86', 'status': 'FAIL' if any(row['status'] == 'FAIL' for row in rows['RAH-86']) else 'CALCULATED' if rows['RAH-86'] and all(row['status'] == 'CALCULATED' for row in rows['RAH-86']) else 'UNPROVEN', 'partants': rows['RAH-86']},
        'RAH-87': r87,
        'RAH-89': {'rule': 'RAH-89', 'status': 'CALCULATED' if rows['RAH-89'] and all(row['status'] == 'CALCULATED' for row in rows['RAH-89']) else 'UNPROVEN', 'partants': rows['RAH-89']}
    }


def evaluer_rah73_82(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = {code: [] for code in ('RAH-73', 'RAH-74', 'RAH-76', 'RAH-77', 'RAH-79', 'RAH-80', 'RAH-81', 'RAH-82')}
    discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        modules = {getattr(m, 'nom', ''): m for m in getattr(partant, 'modules_results', []) or []}
        m40 = raw.get('m40_evalue', raw.get('m40'))
        rows['RAH-73'].append({'numero': partant.numero, 'status': 'CALCULATED' if m40 is not None else 'UNPROVEN', 'm40': m40})
        corde = _num(raw.get('numero_corde', raw.get('corde')))
        rows['RAH-74'].append({'numero': partant.numero, 'status': 'CALCULATED' if corde is not None and getattr(course, 'distance', 0) else 'UNPROVEN', 'numero_corde': corde, 'distance': getattr(course, 'distance', 0)})
        mpa = modules.get('MPA_CHAMP'); mpa_details = getattr(mpa, 'details', {}) if mpa else {}
        rows['RAH-76'].append({'numero': partant.numero, 'status': 'CALCULATED' if mpa and getattr(mpa, 'actif', False) and mpa_details.get('status') in {'CALCULATED', 'NC'} else 'UNPROVEN', 'rythme': mpa_details.get('rythme'), 'compat_score': mpa_details.get('compat_score')})
        tact = modules.get('TACT'); auto = str(getattr(getattr(course, 'type_depart', None), 'value', getattr(course, 'type_depart', '')) or '').upper() == 'AUTOSTART'
        numero = _num(raw.get('numero_autostart', raw.get('numero')))
        rows['RAH-77'].append({'numero': partant.numero, 'status': 'CALCULATED' if not auto or (tact and getattr(tact, 'actif', False) and numero is not None and tact.details.get('status') in {'CALCULATED', 'NC'}) else 'UNPROVEN', 'numero_autostart': numero, 'extension_13_16': numero is not None and 13 <= numero <= 16})
        tandem = modules.get('TANDEM_BONUS'); td = getattr(tandem, 'details', {}) if tandem else {}
        common = _num(raw.get('nb_courses_ensemble'))
        rows['RAH-79'].append({'numero': partant.numero, 'status': 'CALCULATED' if common is not None and common >= 3 and tandem and getattr(tandem, 'actif', False) else 'NOT_APPLICABLE' if common is not None and common < 3 else 'UNPROVEN', 'nb_courses_ensemble': common, 'h2h04_without_direct': common is not None and common >= 3})
        rows['RAH-80'].append({'numero': partant.numero, 'status': 'CALCULATED' if common is not None and common >= 3 and tandem and td.get('status') in {'CALCULATED', 'UNPROVEN'} else 'NOT_APPLICABLE' if common is not None and common < 3 else 'UNPROVEN', 'nb_courses_ensemble': common, 'tandem_status': td.get('status')})
        recent = raw.get('nb_courses_recentes', raw.get('nb_courses_recent'))
        m41 = raw.get('m41_evalue', raw.get('m41'))
        rows['RAH-81'].append({'numero': partant.numero, 'status': 'CALCULATED' if _num(recent) is not None and _num(recent) >= 5 and m41 is not None else 'NOT_APPLICABLE' if _num(recent) is not None and _num(recent) < 5 else 'UNPROVEN', 'recent_courses': recent, 'm41': m41})
        d42 = raw.get('d42_evalue', raw.get('d42'))
        d43 = raw.get('d43_evalue', raw.get('d43'))
        driver = str(raw.get('driver', getattr(partant, 'driver_jockey', '')) or '').strip().upper()
        trainer = str(raw.get('entraineur', getattr(partant, 'entraineur', '')) or '').strip().upper()
        d43_allowed = driver != trainer if driver and trainer else None
        rows['RAH-82'].append({'numero': partant.numero, 'status': 'CALCULATED' if d42 is not None and (d43 is not None or d43_allowed is False) else 'UNPROVEN', 'd42': d42, 'd43': d43, 'd43_driver_distinct': d43_allowed})
    return {code: {'rule': code, 'status': 'CALCULATED' if entries and all(row['status'] in {'CALCULATED', 'NOT_APPLICABLE'} for row in entries) else 'UNPROVEN', 'partants': entries} for code, entries in rows.items()}


def evaluer_rah68_71(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows68, rows69, rows70, rows71 = [], [], [], []
    discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        nb = _num(raw.get('nb_courses_total', raw.get('nb_courses')))
        b50 = _num(raw.get('b50_bonus_pch'))
        if nb is None:
            rows68.append({'numero': partant.numero, 'status': 'UNPROVEN', 'nb_courses': None})
        elif nb <= 5:
            rows68.append({'numero': partant.numero, 'status': 'CALCULATED' if b50 is not None else 'UNPROVEN', 'nb_courses': nb, 'b50_active': b50 is not None, 'bonus_pch': b50, 'tocard_impact': 0.0})
        else:
            rows68.append({'numero': partant.numero, 'status': 'NOT_APPLICABLE', 'nb_courses': nb, 'tocard_impact': 0.0})
        handicaps = _num(raw.get('nb_courses_handicap', raw.get('courses_handicap')))
        if nb is None or handicaps is None:
            rows69.append({'numero': partant.numero, 'status': 'UNPROVEN', 'nb_courses': nb, 'nb_handicaps': handicaps})
        elif handicaps > 0:
            rows69.append({'numero': partant.numero, 'status': 'NOT_APPLICABLE', 'reason': 'handicap_déjà_couru', 'nb_handicaps': handicaps})
        else:
            rows69.append({'numero': partant.numero, 'status': 'CALCULATED', 'malus': -14 if getattr(partant, 'age', 0) == 3 and _num(raw.get('nb_courses_conditions')) is not None and _num(raw.get('nb_courses_conditions')) >= 5 else -10 if nb >= 3 else -6 if nb == 2 else -4 if nb == 1 else -2})
        surcharge = _num(raw.get('surcharge_poids_3_dernieres', raw.get('cumul_surcharge_poids_3')))
        applicable70 = discipline in {'PLAT', 'TROT_ATTELE', 'TROT_MONTE'} and bool(getattr(course, 'est_handicap', False))
        if not applicable70:
            rows70.append({'numero': partant.numero, 'status': 'NOT_APPLICABLE'})
        elif surcharge is None:
            rows70.append({'numero': partant.numero, 'status': 'UNPROVEN', 'surcharge': None})
        else:
            base = -12 if surcharge >= 9 else -8 if surcharge >= 6 else -4 if surcharge >= 3 else -2 if surcharge >= 1 else 0
            rows70.append({'numero': partant.numero, 'status': 'CALCULATED', 'surcharge': surcharge, 'malus': base * (.50 if str(discipline).startswith('TROT') else 1.0)})
        b49 = raw.get('b49_evalue', raw.get('b49'))
        rows71.append({'numero': partant.numero, 'status': 'CALCULATED' if b49 is not None else 'UNPROVEN', 'b49': b49, 'ift_penalty': 0})
    return {
        'RAH-68': {'rule': 'RAH-68', 'status': 'CALCULATED' if rows68 and all(row['status'] in {'CALCULATED', 'NOT_APPLICABLE'} for row in rows68) else 'UNPROVEN', 'partants': rows68, 'bonus_pch_only': True},
        'RAH-69': {'rule': 'RAH-69', 'status': 'CALCULATED' if rows69 and all(row['status'] in {'CALCULATED', 'NOT_APPLICABLE'} for row in rows69) else 'UNPROVEN', 'partants': rows69},
        'RAH-70': {'rule': 'RAH-70', 'status': 'CALCULATED' if rows70 and all(row['status'] in {'CALCULATED', 'NOT_APPLICABLE'} for row in rows70) else 'UNPROVEN', 'partants': rows70},
        'RAH-71': {'rule': 'RAH-71', 'status': 'CALCULATED' if rows71 and all(row['status'] == 'CALCULATED' for row in rows71) else 'UNPROVEN', 'partants': rows71, 'ift_penalty': 0}
    }


def evaluer_rah64_66(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows64, rows65, rows66 = [], [], []
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        nb = _num(raw.get('nb_courses_total', raw.get('nb_courses')))
        b47 = next((s for s in getattr(partant, 'signaux', []) or [] if str(getattr(s, 'code', '')).upper() == 'B47'), None)
        if nb is None:
            rows64.append({'numero': partant.numero, 'status': 'UNPROVEN', 'nb_courses': None, 'b47': None})
        elif nb >= 3:
            rows64.append({'numero': partant.numero, 'status': 'CALCULATED' if b47 is not None and getattr(b47, 'flag_manquant', False) is False else 'UNPROVEN', 'nb_courses': nb, 'b47_evalue': b47 is not None, 'irp_required': True})
        else:
            rows64.append({'numero': partant.numero, 'status': 'CALCULATED', 'nb_courses': nb, 'b47': 0.0, 'flag': 'IRP_INSUFFISANT'})
        m31_value = raw.get('m31_evalue', raw.get('m31'))
        m31_source = str(raw.get('m31_source', raw.get('source_m31', '')) or '').upper()
        rows65.append({'numero': partant.numero, 'status': 'CALCULATED' if m31_value is not None and m31_source == 'GENY' else 'UNPROVEN', 'm31': m31_value, 'source': m31_source, 'source_required': 'GENY'})
        official = raw.get('valeur_pmu')
        alternative = raw.get('valeur_pmu_alternative', (getattr(partant, 'extended_metrics', {}) or {}).get('valeur_pmu_alternative'))
        if official is not None:
            rows66.append({'numero': partant.numero, 'status': 'NOT_APPLICABLE', 'official': official, 'alternative': alternative})
        elif alternative is not None:
            alt_value = alternative.get('value') if isinstance(alternative, dict) else alternative
            alt_status = alternative.get('status') if isinstance(alternative, dict) else 'CALCULATED'
            rows66.append({'numero': partant.numero, 'status': 'CALCULATED' if alt_status == 'CALCULATED' and _num(alt_value) is not None and 20 <= _num(alt_value) <= 45 else 'UNPROVEN', 'alternative': alt_value, 'clamp': [20, 45]})
        else:
            rows66.append({'numero': partant.numero, 'status': 'UNPROVEN', 'alternative': None, 'clamp': [20, 45]})
    return {
        'RAH-64': {'rule': 'RAH-64', 'status': 'CALCULATED' if rows64 and all(row['status'] == 'CALCULATED' for row in rows64) else 'UNPROVEN', 'partants': rows64, 'minimum_courses': 3},
        'RAH-65': {'rule': 'RAH-65', 'status': 'CALCULATED' if rows65 and all(row['status'] == 'CALCULATED' for row in rows65) else 'UNPROVEN', 'partants': rows65, 'source_required': 'GENY'},
        'RAH-66': {'rule': 'RAH-66', 'status': 'CALCULATED' if rows66 and all(row['status'] in {'CALCULATED', 'NOT_APPLICABLE'} for row in rows66) else 'UNPROVEN', 'partants': rows66, 'clamp': [20, 45]}
    }


def evaluer_rah59_62(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
    required = {'MODULE_TERRAIN_DYN', 'MODULE_DIST_ADAPT', 'SRI_v2', 'MPA_CHAMP'}
    if str(discipline or '').startswith('TROT'):
        required.add('TACT')
    if str(discipline or '').startswith('TROT') and getattr(course, 'est_handicap', False):
        required.add('MODULE_RECUL')
    if discipline == 'PLAT' and getattr(course, 'est_handicap', False):
        required.add('MODULE_POIDS')
    rows = []
    for partant in getattr(course, 'partants', []) or []:
        active = {getattr(module, 'nom', '') for module in getattr(partant, 'modules_results', []) or [] if getattr(module, 'actif', False)}
        missing = sorted(required - active)
        rows.append({'numero': partant.numero, 'required': sorted(required), 'active': sorted(active), 'missing': missing, 'status': 'CALCULATED' if not missing else 'UNPROVEN'})
    simultaneous_zero = [row['numero'] for row in rows if len(row['missing']) >= 4]
    already = bool((getattr(course, 'derived_metrics', {}) or {}).get('rah62_ift_applied'))
    if simultaneous_zero and not already:
        course.ift_score = max(0, int(getattr(course, 'ift_score', 100)) - 5)
        course.derived_metrics['rah62_ift_applied'] = True
    r59 = {'rule': 'RAH-59', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows) else 'UNPROVEN', 'partants': rows, 'discipline': discipline}
    r62 = {'rule': 'RAH-62', 'status': 'FAIL' if simultaneous_zero else 'PASS', 'simultaneous_zero_partants': simultaneous_zero, 'ift_penalty': -5 if simultaneous_zero else 0, 'ift_penalty_applied': -5 if simultaneous_zero and not already else 0, 'threshold_missing': 4}
    return {'RAH-59': r59, 'RAH-62': r62}


def evaluer_rah54_58(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    specs = {'RAH-54': 'IFF_v2', 'RAH-55': 'BSH_v3v4', 'RAH-56': 'CRE_v2'}
    rows = {code: [] for code in specs}
    for partant in getattr(course, 'partants', []) or []:
        for code, module_name in specs.items():
            module = next((item for item in getattr(partant, 'modules_results', []) or [] if getattr(item, 'nom', '') == module_name), None)
            details = getattr(module, 'details', {}) if module is not None else {}
            rows[code].append({'numero': partant.numero, 'module': module_name, 'executed': bool(module and getattr(module, 'actif', False)), 'details_status': details.get('status'), 'status': 'CALCULATED' if module and getattr(module, 'actif', False) and details.get('status') in {'CALCULATED', 'NC'} else 'UNPROVEN'})
    r54_56 = {code: {'rule': code, 'status': 'CALCULATED' if entries and all(row['status'] == 'CALCULATED' for row in entries) else 'UNPROVEN', 'partants': entries} for code, entries in rows.items()}
    r57_rows = []
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        points = int(bool(raw.get('cote_matin', raw.get('cote_parution')))) + int(bool(raw.get('cote_avant_course', raw.get('cote_15min'))))
        r57_rows.append({'numero': partant.numero, 'points_sov': points, 'sov_zero_required': points < 2, 'status': 'CALCULATED' if points >= 2 else 'CALCULATED_SOV_ZERO'})
    r57 = {'rule': 'RAH-57', 'status': 'CALCULATED' if r57_rows else 'UNPROVEN', 'partants': r57_rows, 'minimum_points': 2, 'insufficient_policy': 'SOV=0'}
    dissimule = any(getattr(p, 'profil_ado', None) is not None and str(getattr(getattr(p, 'profil_ado', None), 'value', getattr(p, 'profil_ado', None))).upper().startswith('DISSIMULE') for p in getattr(course, 'partants', []) or [])
    signature = getattr(getattr(course, 'signature_msp', None), 'value', getattr(course, 'signature_msp', None))
    r58 = {'rule': 'RAH-58', 'status': 'CALCULATED' if signature != 'MIXTE_LOCK' or (0.45 <= float(getattr(course, 'p_lock', 0.0)) <= 0.55 and dissimule) else 'FAIL', 'signature': signature, 'p_lock': getattr(course, 'p_lock', None), 'dissimule_fort_present': dissimule, 'condition': 'P_LOCK[0.45,0.55] + DISSIMULE_FORT'}
    return {**r54_56, 'RAH-57': r57, 'RAH-58': r58}


def evaluer_rah48_51(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    specs = {'RAH-48': 'MODULE_TERRAIN_DYN', 'RAH-49': 'MODULE_DIST_ADAPT', 'RAH-50': 'SRI_v2', 'RAH-51': 'MPA_CHAMP'}
    rows = {code: [] for code in specs}
    for partant in getattr(course, 'partants', []) or []:
        for code, module_name in specs.items():
            module = next((item for item in getattr(partant, 'modules_results', []) or [] if getattr(item, 'nom', '') == module_name), None)
            details = getattr(module, 'details', {}) if module is not None else {}
            executed = module is not None and getattr(module, 'actif', False)
            computed = details.get('status') == 'CALCULATED'
            rows[code].append({'numero': partant.numero, 'module': module_name, 'executed': executed, 'details_status': details.get('status'), 'status': 'CALCULATED' if executed and (computed or details.get('status') == 'NC') else 'UNPROVEN'})
    result = {}
    for code, entries in rows.items():
        result[code] = {'rule': code, 'status': 'CALCULATED' if entries and all(entry['status'] == 'CALCULATED' for entry in entries) else 'UNPROVEN', 'partants': entries, 'all_confirmed_required': True}
    return result


def evaluer_rah46_47(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
    parts = getattr(course, 'partants', []) or []
    plat_handicap = discipline == 'PLAT' and bool(getattr(course, 'est_handicap', False))
    trot_handicap = str(discipline or '').startswith('TROT') and bool(getattr(course, 'est_handicap', False))
    def module_present(partant, name):
        return any(getattr(module, 'nom', '') == name and getattr(module, 'actif', False) for module in getattr(partant, 'modules_results', []) or [])
    poids_missing = [p.numero for p in parts if not module_present(p, 'MODULE_POIDS')] if plat_handicap else []
    recul_missing = [p.numero for p in parts if not module_present(p, 'MODULE_RECUL')] if trot_handicap else []
    penalty = 0
    flags = []
    if plat_handicap and poids_missing:
        penalty -= 3
        flags.append('POIDS_MANQUANT')
    if trot_handicap and recul_missing:
        penalty -= 2
        flags.append('RECUL_MANQUANT')
    already = bool((getattr(course, 'derived_metrics', {}) or {}).get('rah46_47_ift_applied'))
    if penalty and not already:
        course.ift_score = max(0, int(getattr(course, 'ift_score', 100)) + penalty)
        course.derived_metrics['rah46_47_ift_applied'] = True
    r46 = {'rule': 'RAH-46', 'status': 'NOT_APPLICABLE' if not plat_handicap else 'PASS' if not poids_missing else 'FAIL', 'missing_partants': poids_missing, 'ift_penalty': -3 if poids_missing else 0, 'flag': 'POIDS_MANQUANT' if poids_missing else None}
    r47 = {'rule': 'RAH-47', 'status': 'NOT_APPLICABLE' if not trot_handicap else 'PASS' if not recul_missing else 'FAIL', 'missing_partants': recul_missing, 'ift_penalty': -2 if recul_missing else 0, 'flag': 'RECUL_MANQUANT' if recul_missing else None}
    return {'RAH-46': r46, 'RAH-47': r47, 'ift_penalty_applied': penalty if not already else 0, 'flags': flags}


def evaluer_rah43(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    levels = {'STRICT': 4, 'DEGRADE': 3, 'MINIMAL': 2, 'DERNIER_RECOURS': 1}
    rows = []
    for partant in getattr(course, 'partants', []) or []:
        by_code = {}
        for signal in getattr(partant, 'signaux', []) or []:
            if not getattr(signal, 'actif', False) or getattr(signal, 'flag_manquant', False):
                continue
            code = str(getattr(signal, 'code', '') or '')
            level = str(getattr(signal, 'niveau_fallback', '') or '').upper()
            if code not in by_code or levels.get(level, 0) > levels.get(by_code[code], 0):
                by_code[code] = level
        invalid = [code for code, level in by_code.items() if level not in levels]
        rows.append({'numero': partant.numero, 'signals': by_code, 'invalid_levels': invalid, 'highest_only': True, 'status': 'CALCULATED' if not invalid else 'UNPROVEN'})
    return {'rule': 'RAH-43', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows) else 'UNPROVEN', 'levels': list(levels), 'partants': rows, 'non_cumul': True}


def evaluer_rah31_35_40(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    count = len(getattr(course, 'partants', []) or [])
    ticket = ticket_report.get('ticket_final', {}) or {}
    selected = set()
    for value in ticket.values():
        if isinstance(value, dict) and value.get('numero') is not None:
            selected.add(value.get('numero'))
        elif isinstance(value, (list, tuple)):
            selected.update(item.get('numero') for item in value if isinstance(item, dict) and item.get('numero') is not None)
    r31 = {'rule': 'RAH-31', 'status': 'PASS' if count >= 8 or selected.issuperset({p.numero for p in course.partants}) else 'UNPROVEN' if count < 8 and not selected else 'FAIL', 'partants': count, 'selected_numbers': sorted(selected), 'all_available_required': count < 8}
    coherence = (getattr(course, 'derived_metrics', {}) or {}).get('reculs_poids_coherent')
    r32 = {'rule': 'RAH-32', 'status': 'CALCULATED' if coherence is True else 'FAIL' if coherence is False else 'UNPROVEN', 'reculs_poids_coherent': coherence}
    deviations = ticket_report.get('protocol_deviation', ticket_report.get('deviation_reason', (getattr(course, 'derived_metrics', {}) or {}).get('protocol_deviation')))
    r34 = {'rule': 'RAH-34', 'status': 'CALCULATED' if deviations not in (None, '', 'NC', 'UNPROVEN') else 'NOT_APPLICABLE', 'deviation': deviations}
    m13_rows = []
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        if _num(raw.get('m13_contribution')) is not None:
            discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
            obstacle_type = str(raw.get('type_obstacle', '') or '').upper()
            factor = 1.3 if discipline == 'HAIES' else 1.7 if obstacle_type in {'STEEPLE', 'STEEPLECHASE'} else 1.0
            m13_rows.append({'numero': partant.numero, 'base': _num(raw.get('m13_contribution')), 'factor': factor, 'expected': _num(raw.get('m13_contribution')) * factor})
    r35 = {'rule': 'RAH-35', 'status': 'CALCULATED' if m13_rows else 'UNPROVEN', 'partants': m13_rows, 'modulation': {'HAIES': 1.3, 'STEEPLE': 1.7}}
    signature = getattr(course, 'signature_msp', None)
    r40 = {'rule': 'RAH-40', 'status': 'CALCULATED' if signature is not None else 'UNPROVEN', 'signature': getattr(signature, 'value', signature), 'before_composition': signature is not None}
    return {'RAH-31': r31, 'RAH-32': r32, 'RAH-34': r34, 'RAH-35': r35, 'RAH-40': r40}


def evaluer_rah28_29(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows28 = []
    rows29 = []
    is_trot = str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None)) or '').startswith('TROT')
    penalty_total = 0
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        market = getattr(partant, 'market_data', {}) or {}
        snapshots = market.get('sov_snapshots') or raw.get('sov_snapshots') or (raw.get('market_data') or {}).get('sov_snapshots')
        snapshot_count = len(snapshots) if isinstance(snapshots, (list, tuple)) else 0
        factors = (getattr(partant, 'extended_metrics', {}) or {}).get('ordre_factors', {})
        sov_status = str(factors.get('sov_status', '') or '')
        if sov_status == 'FALLBACK_MEDIAN_3MIN':
            effective_points = 2
            penalty = -4
        else:
            effective_points = min(snapshot_count, 4)
            penalty = {4: 0, 3: -2, 2: -4, 1: -6, 0: -8}[effective_points]
        if isinstance(snapshots, (list, tuple)):
            status = 'CALCULATED' if effective_points >= 2 else 'CALCULATED_SOV_ZERO'
        else:
            status = 'CALCULATED' if sov_status == 'FALLBACK_MEDIAN_3MIN' else 'UNPROVEN'
        row = {'numero': partant.numero, 'snapshot_count': snapshot_count if isinstance(snapshots, (list, tuple)) else None, 'effective_points': effective_points, 'sov_status': sov_status or None, 'status': status, 'ift_penalty': penalty}
        rows28.append(row)
        penalty_total += penalty
        if is_trot:
            rows29.append({'numero': partant.numero, 'rk_brute_present': partant.rk_brute is not None, 'status': 'PASS' if partant.rk_brute is not None else 'STOP'})
    already = bool((getattr(course, 'derived_metrics', {}) or {}).get('rah28_ift_applied'))
    if penalty_total and not already:
        course.ift_score = max(0, int(getattr(course, 'ift_score', 100)) + penalty_total)
        course.derived_metrics['rah28_ift_applied'] = True
    r28 = {'rule': 'RAH-28', 'status': 'CALCULATED' if rows28 and all(row['status'] in {'CALCULATED', 'CALCULATED_SOV_ZERO'} for row in rows28) else 'UNPROVEN', 'partants': rows28, 'minimum_snapshots': 2, 'insufficient_policy': 'SOV=0', 'penalty_schedule': {'4': 0, '3': -2, '2': -4, '1': -6, '0': -8}, 'ift_penalty_applied': penalty_total if not already else 0}
    r29 = {'rule': 'RAH-29', 'status': 'PASS' if is_trot and rows29 and all(row['status'] == 'PASS' for row in rows29) else 'STOP' if is_trot and any(row['status'] == 'STOP' for row in rows29) else 'NOT_APPLICABLE', 'partants': rows29, 'trot_required': True, 'missing_policy': 'STOP'}
    return {'RAH-28': r28, 'RAH-29': r29}


def evaluer_rah213_214(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    supra = (ticket_report.get('etapes', {}) or {}).get('etape_11_supra') or ticket_report.get('supra') or {}
    phases = supra.get('phases', {}) if isinstance(supra, dict) else {}
    scenario = phases.get('phase5_rah213') or {}
    if scenario.get('status') == 'CALCULATED' and scenario.get('rythme') in {'RYTHME_LENT', 'RYTHME_SOUTENU', 'RYTHME_EQUILIBRE', 'ÉQUILIBRÉ'} and scenario.get('croisement_corde_style_terrain') is True:
        r213 = {'rule': 'RAH-213', 'status': 'CALCULATED', 'scenario': scenario}
    elif scenario.get('status') == 'FAIL':
        r213 = {'rule': 'RAH-213', 'status': 'FAIL', 'scenario': scenario}
    else:
        r213 = {'rule': 'RAH-213', 'status': 'UNPROVEN', 'scenario': scenario}
    scan = phases.get('phase6_rah214') or {}
    omission = scan.get('omission_scan') is True
    retrait = scan.get('retrait_scan') is True
    convergents = _num(scan.get('convergent_signals'))
    if scan.get('status') == 'CALCULATED' and omission and retrait and convergents is not None and convergents >= 3:
        r214 = {'rule': 'RAH-214', 'status': 'CALCULATED', 'scan': scan, 'threshold': 3}
    elif scan.get('status') == 'FAIL':
        r214 = {'rule': 'RAH-214', 'status': 'FAIL', 'scan': scan, 'threshold': 3}
    else:
        r214 = {'rule': 'RAH-214', 'status': 'UNPROVEN', 'scan': scan, 'threshold': 3}
    return {'RAH-213': r213, 'RAH-214': r214}


def evaluer_rah164(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = []
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'STAB' and getattr(m, 'actif', False)), None)
        if module is None:
            continue
        profil = raw.get('profil_ado', getattr(partant, 'profil_ado', None))
        profil = getattr(profil, 'value', profil)
        affected = bool((getattr(module, 'details', {}) or {}).get('stab_score') is not None) or bool(raw.get('stab_applique'))
        if not affected:
            rows.append({'numero': partant.numero, 'status': 'NOT_APPLICABLE', 'profil': profil})
            continue
        proof = raw.get('stab_neutrality_checked', (getattr(module, 'details', {}) or {}).get('neutralite_favori_outsider'))
        rows.append({'numero': partant.numero, 'profil': profil, 'status': 'CALCULATED' if proof is True else 'UNPROVEN', 'neutrality_proof': proof})
    status = 'CALCULATED' if rows and all(row['status'] in {'CALCULATED', 'NOT_APPLICABLE'} for row in rows) else 'UNPROVEN'
    return {'rule': 'RAH-164', 'status': status, 'partants': rows, 'neutrality_required': True, 'no_status_bias': True}


def evaluer_rah20_25(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    discipline = getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', None))
    distance_ok = isinstance(getattr(course, 'distance', None), (int, float)) and course.distance > 0
    is_trot = str(discipline or '').startswith('TROT')
    type_ok = not is_trot or getattr(course, 'type_depart', None) is not None
    r20_status = 'CALCULATED' if discipline and distance_ok and type_ok else 'UNPROVEN'
    probs = [getattr(course, 'p_lock', None), getattr(course, 'p_standard', None), getattr(course, 'p_guerre', None)]
    if all(isinstance(value, (int, float)) for value in probs) and any(value != 0 for value in probs):
        total = sum(probs)
        r21_status = 'PASS' if abs(total - 1.0) <= 1e-9 else 'FAIL'
    else:
        total = None
        r21_status = 'UNPROVEN'
    gru_order = (getattr(course, 'derived_metrics', {}) or {}).get('gru_before_composition')
    r22_status = 'CALCULATED' if gru_order is True else 'FAIL' if gru_order is False else 'UNPROVEN'
    module_names = {module.nom for partant in getattr(course, 'partants', []) for module in getattr(partant, 'modules_results', []) if getattr(module, 'actif', False)}
    def _gate(name, expected):
        if name not in module_names:
            return 'UNPROVEN'
        discipline_match = is_trot if expected == 'TROT' else discipline == expected
        return 'PASS' if discipline_match and (name != 'MODULE_POIDS' or bool(getattr(course, 'est_handicap', False))) else 'FAIL'
    r23_status = 'PASS' if 'TACT' not in module_names else 'PASS' if is_trot else 'FAIL'
    if 'TACT' not in module_names:
        r23_status = 'UNPROVEN'
    r24_status = _gate('MODULE_POIDS', 'PLAT')
    r25_status = _gate('MODULE_RECUL', 'TROT')
    return {
        'RAH-20': {'rule': 'RAH-20', 'status': r20_status, 'discipline': discipline, 'distance': getattr(course, 'distance', None), 'type_depart_present': getattr(course, 'type_depart', None) is not None},
        'RAH-21': {'rule': 'RAH-21', 'status': r21_status, 'total': total, 'probabilites': probs},
        'RAH-22': {'rule': 'RAH-22', 'status': r22_status, 'gru_before_composition': gru_order},
        'RAH-23': {'rule': 'RAH-23', 'status': r23_status, 'discipline': discipline, 'tact_active': 'TACT' in module_names},
        'RAH-24': {'rule': 'RAH-24', 'status': r24_status, 'discipline': discipline, 'handicap': bool(getattr(course, 'est_handicap', False)), 'poids_active': 'MODULE_POIDS' in module_names},
        'RAH-25': {'rule': 'RAH-25', 'status': r25_status, 'discipline': discipline, 'handicap': bool(getattr(course, 'est_handicap', False)), 'recul_active': 'MODULE_RECUL' in module_names},
    }


def evaluer_rah17_18_19(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    ticket = ticket_report.get('ticket_final', {}) or {}
    composition_reasoning = ticket_report.get('composition_reasoning', ticket_report.get('raisonnement_composition'))
    rows17 = []
    rows19 = []
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        flags = [flag for module in getattr(partant, 'modules_results', []) for flag in getattr(module, 'flags', [])]
        flags.extend(raw.get('kill_list_flags', []) if isinstance(raw.get('kill_list_flags'), list) else [])
        kill_count = sum(1 for flag in flags if str(flag).startswith('KILL_LIST') or str(flag) in {'M25', 'M25_EQUIVALENT', 'STAB_DQ_SERIE_CRITIQUE'})
        if kill_count >= 2:
            rows17.append({'numero': partant.numero, 'kill_count': kill_count, 'position': partant.position_ticket, 'violation': partant.position_ticket not in {'R1', 'R2', 'P5', 'P6', None}})
        favorite_unanimous = raw.get('favori_unanime') is True or str(raw.get('profil_ado', '')).upper() == 'FAVORI_UNANIME'
        if favorite_unanimous:
            in_ticket = partant.position_ticket is not None or any(isinstance(value, dict) and value.get('numero') == partant.numero for value in ticket.values())
            justification = raw.get('justification_favori_ignore') or raw.get('favori_unanime_justification')
            rows19.append({'numero': partant.numero, 'in_ticket': in_ticket, 'justification': justification, 'violation': (not in_ticket and not justification)})
    result17 = {'rule': 'RAH-17', 'status': 'FAIL' if any(row['violation'] for row in rows17) else 'PASS', 'violations': rows17}
    result18 = {'rule': 'RAH-18', 'status': 'CALCULATED' if composition_reasoning not in (None, '', 'NC', 'UNPROVEN') else 'UNPROVEN', 'reasoning_present': composition_reasoning not in (None, '', 'NC', 'UNPROVEN'), 'reasoning': composition_reasoning}
    result19 = {'rule': 'RAH-19', 'status': 'FAIL' if any(row['violation'] for row in rows19) else 'PASS', 'favoris_unanimes': rows19}
    return {'rule': 'RAH-17_18_19', 'status': 'CALCULATED' if result18['status'] == 'CALCULATED' and result17['status'] == 'PASS' and result19['status'] == 'PASS' else 'UNPROVEN' if result18['status'] == 'UNPROVEN' and result17['status'] == 'PASS' and result19['status'] == 'PASS' else 'FAIL', 'RAH-17': result17, 'RAH-18': result18, 'RAH-19': result19}


def evaluer_rah14(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = {}
    for partant in getattr(course, 'partants', []) or []:
        raw = getattr(partant, 'raw_data', {}) or {}
        icp = _num(raw.get('icp_global'))
        coherent = raw.get('icp_coherent', raw.get('coherence_icp'))
        if icp is None or coherent is None:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'icp_global': icp, 'coherence': coherent, 'reason': 'Preuve de cohérence ICP absente'}
        else:
            rows[str(partant.numero)] = {'status': 'PASS' if bool(coherent) else 'FAIL', 'icp_global': icp, 'coherence': bool(coherent)}
    statuses = [row['status'] for row in rows.values()]
    status = 'PASS' if statuses and all(s == 'PASS' for s in statuses) else 'FAIL' if any(s == 'FAIL' for s in statuses) else 'UNPROVEN'
    return {'rule': 'RAH-14', 'status': status, 'partants': rows, 'publication_allowed': status == 'PASS', 'no_proxy': True}


def evaluer_rah12(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    ticket = ticket_report.get('ticket_final', {}) or {}
    r3 = ticket.get('R3')
    if r3 is None:
        return {'rule': 'RAH-12', 'status': 'NOT_APPLICABLE', 'r3_present': False, 'publication_allowed': True, 'threshold_iic': 9.0}
    iic = _num(getattr(course, 'iic', None))
    iic_details = (getattr(course, 'derived_metrics', {}) or {}).get('iic', {}) or {}
    confidence = str(iic_details.get('confidence', 'UNPROVEN')).upper()
    if iic is None or confidence not in {'FULL', 'DEGRADED'}:
        return {
            'rule': 'RAH-12', 'status': 'UNPROVEN', 'r3_present': True,
            'publication_allowed': False, 'reason': 'IIC absent ou confiance insuffisante',
            'threshold_iic': 9.0, 'iic': iic, 'iic_confidence': confidence,
        }
    allowed = iic >= 9.0
    return {
        'rule': 'RAH-12', 'status': 'PASS' if allowed else 'FAIL',
        'r3_present': True, 'r3_numero': r3.get('numero') if isinstance(r3, dict) else None,
        'iic': iic, 'iic_confidence': confidence, 'threshold_iic': 9.0,
        'publication_allowed': allowed,
    }


def evaluer_rah118(course: Course) -> Dict[str, Any]:
    raw = getattr(course, 'raw_data', {}) or {}
    n = len(getattr(course, 'partants', []) or [])
    p_petit = _num(raw.get('p_avant_petit', raw.get('P_avant_PETIT')))
    p_grand = _num(raw.get('p_avant_grand', raw.get('P_avant_GRAND')))
    if p_petit is None or p_grand is None:
        return {'rule': 'RAH-118', 'status': 'UNPROVEN', 'applicable': True, 'reason': 'Probabilités petit/grand champ absentes', 'champ_size': n, 'impact_targets': ['MPA_CHAMP', 'TACT'], 'ift_penalty': 0}
    delta = p_petit - p_grand
    detected = abs(delta) >= .25
    course.derived_metrics = getattr(course, 'derived_metrics', {}) or {}
    course.derived_metrics['style_contextuel_delta'] = delta
    return {'rule': 'RAH-118', 'status': 'CALCULATED', 'applicable': True, 'champ_size': n, 'p_avant_petit': p_petit, 'p_avant_grand': p_grand, 'delta': delta, 'threshold': .25, 'detected': detected, 'impact_targets': ['MPA_CHAMP', 'TACT'] if detected else [], 'ift_penalty': 0, 'calibration_flag': 'STYLE_CONTEXTUEL_CALIBRATION'}


def evaluer_rah115(course: Course) -> Dict[str, Any]:
    discipline = str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')) or '').upper()
    if 'PLAT' not in discipline or not bool(getattr(course, 'est_handicap', False)):
        return {'rule': 'RAH-115', 'status': 'NOT_APPLICABLE', 'applicable': False}
    distance = _num(getattr(course, 'distance', None))
    if distance is None:
        return {'rule': 'RAH-115', 'status': 'UNPROVEN', 'applicable': True, 'reason': 'Distance absente'}
    cap_expected = 25 if distance < 1600 else 20 if distance < 2000 else 15 if distance < 2400 else 10
    rows, missing = {}, []
    for partant in course.partants:
        module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'MODULE_POIDS'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        cap = details.get('cap_final')
        if cap is None:
            missing.append(str(partant.numero))
        rows[str(partant.numero)] = {'status': 'CALCULATED' if cap is not None else 'UNPROVEN', 'cap_expected': cap_expected, 'cap_observed': cap, 'flag': 'POIDS_DEGRESSIVITE_FOND' if cap_expected < 25 else None, 'rah104_before_cap': details.get('rah104', {}).get('status') if isinstance(details.get('rah104'), dict) else None}
    return {'rule': 'RAH-115', 'status': 'CALCULATED' if rows and not missing else 'UNPROVEN', 'applicable': True, 'distance': distance, 'cap_expected': cap_expected, 'partants': rows, 'missing_partants': missing}


def evaluer_rah111_112(course: Course) -> Dict[str, Any]:
    hippo = str(getattr(course, 'hippodrome', '') or '').upper()
    applicable = hippo == 'NANTES' and int(getattr(course, 'distance', 0) or 0) == 1600
    if not applicable:
        return {'rule': 'RAH-111/112', 'status': 'NOT_APPLICABLE', 'applicable': False}
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        poids = _num(raw.get('poids_actuel_kg', getattr(partant, 'poids', None)))
        poids_moy = _num(raw.get('poids_moyen_champ'))
        sens = str(raw.get('sens_rotation_course', raw.get('sens_hippodrome', '')) or '').upper()
        stats = _num(raw.get('nantes_stats_1600_courses', raw.get('stats_nantes_1600_courses')))
        rules = [rule for rule in getattr(course, 'gru_regles', []) if rule.code in {'RAH-111-M47', 'RAH-112-NANTES-1600'} and getattr(rule, 'description', '').find(str(partant.numero)) >= -1]
        rows[str(partant.numero)] = {'status': 'CALCULATED' if poids is not None and poids_moy is not None else 'UNPROVEN', 'rah111': {'poids': poids, 'poids_moyen': poids_moy, 'calibration_n': 1, 'rules': [{'code': r.code, 'contribution': r.pch_contribution} for r in rules]}, 'rah112': {'sens': sens, 'stats_courses': stats, 'minimum_stats_courses': 23, 'rules': [{'code': r.code, 'contribution': r.pch_contribution} for r in rules]}}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-111/112', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'applicable': True, 'partants': rows, 'scope': 'NANTES_1600M'}


def evaluer_rah109(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'RAH_PRIORITES'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rah = details.get('rah109_b04')
        rows[str(partant.numero)] = {'status': rah.get('status') if isinstance(rah, dict) else 'UNPROVEN', 'rah109_b04': rah}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-109', 'status': 'CALCULATED' if statuses and all(status in {'APPLIED', 'CALCULATED', 'NOT_APPLICABLE'} for status in statuses) else 'UNPROVEN', 'partants': rows, 'required_input': 'valeur_meilleure'}


def evaluer_rah110(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'PDQ'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rah = details.get('rah110')
        rows[str(partant.numero)] = {'status': rah.get('status') if isinstance(rah, dict) else 'UNPROVEN', 'rah110': rah}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-110', 'status': 'CALCULATED' if statuses and all(status in {'APPLIED', 'CALCULATED', 'NOT_APPLICABLE'} for status in statuses) else 'UNPROVEN', 'partants': rows, 'required_input': 'valeur_meilleure'}


def evaluer_rah104(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'MODULE_POIDS'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rah = details.get('rah104', {})
        rows[str(partant.numero)] = {'status': 'CALCULATED' if details.get('status') == 'CALCULATED' else 'UNPROVEN', 'rah104': rah, 'factor': rah.get('factor')}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-104', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'factor_if_active': 1.5}


def evaluer_rah105_106(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'MODULE_TERRAIN_DYN'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rows[str(partant.numero)] = {'status': 'CALCULATED' if details.get('status') == 'CALCULATED' else 'UNPROVEN', 'rah105': details.get('rah105'), 'rah106': details.get('rah106')}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-105/106', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'factors': {'RAH-105': 1.5, 'RAH-106': 1.2}}


def evaluer_rah100(course: Course) -> Dict[str, Any]:
    rows = {}
    applicable = str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')) or '').upper() in {'TROT_ATTELE', 'TROT_MONTE'} and bool(getattr(course, 'est_handicap', False))
    if not applicable:
        return {'rule': 'RAH-100', 'status': 'NOT_APPLICABLE', 'applicable': False}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'MODULE_RECUL'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rows[str(partant.numero)] = {'status': 'CALCULATED' if details.get('rah100', {}).get('status') == 'CALCULATED' else 'UNPROVEN', 'coefficient_geometrique': details.get('coefficient_geometrique'), 'source_unique': details.get('rah100', {}).get('coefficient_source_unique')}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-100', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'applicable': True, 'partants': rows}


def evaluer_rah101(course: Course) -> Dict[str, Any]:
    discipline = str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')) or '').upper()
    applicable = discipline in {'TROT_ATTELE', 'TROT_MONTE'} and str(getattr(getattr(course, 'type_depart', None), 'value', getattr(course, 'type_depart', '')) or '').upper() == 'AUTOSTART'
    if not applicable:
        return {'rule': 'RAH-101', 'status': 'NOT_APPLICABLE', 'applicable': False}
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'TACT'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rah = details.get('RAH101', {})
        rows[str(partant.numero)] = {'status': 'CALCULATED' if details.get('status') == 'CALCULATED' else 'UNPROVEN', 'applied': rah.get('applied'), 'lignes': rah.get('lignes'), 'tact06_base': details.get('TACT06_base')}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-101', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'applicable': True, 'partants': rows}


def evaluer_rah103(course: Course) -> Dict[str, Any]:
    hippo = str(getattr(course, 'hippodrome', '') or '').upper()
    surface = str(getattr(course, 'piste', '') or '').upper()
    applicable = hippo == 'LONGCHAMP' or (hippo == 'CHANTILLY' and surface == 'PSF')
    if not applicable or not (str(getattr(getattr(course, 'discipline', None), 'value', getattr(course, 'discipline', '')) or '').upper() == 'PLAT' and getattr(course, 'est_handicap', False)):
        return {'rule': 'RAH-103', 'status': 'NOT_APPLICABLE', 'applicable': False}
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'MODULE_POIDS'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rah = details.get('rah103', {})
        rows[str(partant.numero)] = {'status': 'CALCULATED' if details.get('status') == 'CALCULATED' else 'UNPROVEN', 'rah103': rah, 'bonus': details.get('C5_RAH103_OPEN_STRETCH')}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-103', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'applicable': True, 'partants': rows}


def evaluer_rah84(course: Course) -> Dict[str, Any]:
    rows = {}
    trusted = {'PARIS-TURF', 'PARISTURF', 'EQUIDIA', 'TURFOO', 'CANALTURF', 'ZONE-TURF', 'ZONETURF'}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        source = str(raw.get('b51_source', '') or '').upper().strip()
        active = raw.get('b51_actif') is True or _num(raw.get('b51_score')) is not None
        if not active:
            rows[str(partant.numero)] = {'status': 'NOT_APPLICABLE', 'active': False, 'source': source or None, 'flag': None}
        elif source in trusted:
            rows[str(partant.numero)] = {'status': 'CALCULATED', 'active': True, 'source': source, 'source_reliable': True, 'flag': 'B51_SOURCE_FIABLE'}
        else:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'active': True, 'source': source or None, 'source_reliable': False, 'flag': 'B51_DATA_ABSENT'}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-84', 'status': 'CALCULATED' if statuses and all(status != 'UNPROVEN' for status in statuses) else 'UNPROVEN', 'partants': rows, 'trusted_sources': sorted(trusted)}


def evaluer_rah92(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        ordre = _num(getattr(partant, 'ordre_score', None)); icp = _num(raw.get('icp_global', getattr(partant, 'icp_count', None))); cote = _num(getattr(partant, 'cote', None))
        signals = [signal for signal in getattr(partant, 'signaux', []) if getattr(signal, 'actif', False) and not getattr(signal, 'flag_manquant', False)]
        families = {str(getattr(signal, 'famille', '')).upper() for signal in signals if getattr(signal, 'famille', None)}
        market = bool(families.intersection({'M', 'MARCHE', 'MARCHÉ'}))
        criteria = {'icp_or_cote': (icp is not None and 4 <= icp < 6) or (icp is not None and icp < 4 and cote is not None and cote <= 10), 'ordre_ge_050': ordre is not None and ordre >= .50, 'signals_ge_3': len(signals) >= 3, 'families_ge_3': len(families) >= 3, 'market_family': market}
        observed = ordre is not None and ordre > 0 and icp is not None and (cote is not None or icp >= 4)
        rows[str(partant.numero)] = {'status': 'CALCULATED' if observed else 'UNPROVEN', 'eligible': all(criteria.values()) if observed else None, 'criteria': criteria, 'ordre_score': ordre, 'icp': icp, 'cote': cote, 'signal_count': len(signals), 'families': sorted(families)}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-92', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'eligible_positions': ['P1', 'P2', 'P3'], 'max_p1_p2': 1}


def evaluer_rah94(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        ordre = _num(getattr(partant, 'ordre_score', None)); icp = _num(raw.get('icp_global', getattr(partant, 'icp_count', None)))
        signals = [signal for signal in getattr(partant, 'signaux', []) if getattr(signal, 'actif', False) and not getattr(signal, 'flag_manquant', False)]
        codes = {str(getattr(signal, 'code', '')).upper() for signal in signals}
        families = {str(getattr(signal, 'famille', '')).upper() for signal in signals if getattr(signal, 'famille', None)}
        specialist = bool(codes.intersection({'B04', 'B05', 'B19'}))
        other_count = sum(1 for signal in signals if str(getattr(signal, 'code', '')).upper() not in {'B04', 'B05', 'B19'})
        criteria = {'specialist_signal': specialist, 'other_signals_ge_2': other_count >= 2, 'ordre_ge_035': ordre is not None and ordre >= .35, 'icp_ge_1': icp is not None and icp >= 1}
        observed = ordre is not None and ordre > 0 and icp is not None
        rows[str(partant.numero)] = {'status': 'CALCULATED' if observed else 'UNPROVEN', 'eligible': all(criteria.values()) if observed else None, 'criteria': criteria, 'ordre_score': ordre, 'icp': icp, 'signal_count': len(signals), 'families': sorted(families)}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-94', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'eligible_positions': ['P3', 'P4', 'P5']}


def evaluer_rah26(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'CRE_v2'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        flags = set(getattr(module, 'flags', []) if module is not None else [])
        if details.get('mode') in {'CRE_v2', 'CRE_PROXY_v3'}:
            rows[str(partant.numero)] = {'status': 'CALCULATED', 'active': True, 'mode': details.get('mode'), 'proxy_rk': details.get('mode') == 'CRE_PROXY_v3', 'flags': sorted(flags)}
        elif 'CRE_DESACTIVE' in flags or details.get('status') == 'NC':
            rows[str(partant.numero)] = {'status': 'CALCULATED', 'active': False, 'mode': 'DESACTIVE', 'reason': details.get('reason', 'Chronos et proxy RK absents')}
        else:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'reason': 'CRE_v2 absent'}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-26', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'disabled_without_chrono_and_rk': True}


def evaluer_rah78(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'MODULE_DIST_ADAPT'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rows[str(partant.numero)] = {'status': 'CALCULATED' if details.get('status') == 'CALCULATED' else 'UNPROVEN', 'COMP4_status': details.get('COMP4_status'), 'COMP5_status': details.get('COMP5_status'), 'C4': details.get('C4'), 'C5': details.get('C5'), 'COMP4_min_courses': 2, 'COMP5_min_courses': 4}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-78', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows}


def evaluer_rah242(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'RAH-242'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rows[str(partant.numero)] = details if isinstance(details, dict) else {'status': 'UNPROVEN', 'reason': 'Module RAH-242 absent'}
    statuses = [row.get('status') for row in rows.values()]
    return {'rule': 'RAH-242', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'secondary_cap_rule': True, 'cap_if_primary_nonpositive': 0.0}


def evaluer_rah185(course: Course) -> Dict[str, Any]:
    full = {'EQUIDIA', 'TURFOO', 'CANALTURF'}
    reduced = {'RTL', 'BFM', 'RMC', 'EUROPE 1', 'CNEWS'}
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        records = raw.get('press_sources', raw.get('sources_presse', []))
        if isinstance(records, dict):
            records = [{'source': key, 'observed': value} for key, value in records.items()]
        if not isinstance(records, list) or not records:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'sources': [], 'reason': 'Sources presse pondérées absentes'}
            continue
        weighted = []
        unknown = []
        for record in records:
            source = str(record.get('source', '') if isinstance(record, dict) else record).upper().strip()
            if source in full:
                weight, tier = 1.0, 'PLEIN'
            elif source in reduced:
                weight, tier = .5, 'REDUIT'
            else:
                weight, tier = None, 'NON_CLASSE'
                unknown.append(source)
            weighted.append({'source': source, 'weight': weight, 'tier': tier, 'used_after_borda': bool(record.get('used_after_borda', True)) if isinstance(record, dict) else True})
        rows[str(partant.numero)] = {'status': 'CALCULATED' if not unknown else 'UNPROVEN', 'sources': weighted, 'unknown_sources': unknown, 'full_weight_sources': sorted(full), 'reduced_weight_sources': sorted(reduced), 'not_used_before_borda': all(row['used_after_borda'] for row in weighted)}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-185', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'weights_applied_after_borda': True, 'no_generalist_full_weight': True}


def evaluer_rah163(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        ferrure_change = raw.get('changement_ferrure') is True or raw.get('ferrure_change') is True
        ferrure_contribution = _num(raw.get('ferrure_contribution_pch'))
        sov = _num(raw.get('sov_v2', (getattr(partant, 'extended_metrics', {}) or {}).get('sov_v2')))
        if not ferrure_change:
            rows[str(partant.numero)] = {'status': 'NOT_APPLICABLE', 'double_count_detected': False, 'reduction': 0.0, 'reason': 'Ferrure stable ou changement non observé'}
        elif ferrure_contribution is None or sov is None:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'double_count_detected': None, 'reduction': None, 'reason': 'Contribution ferrure ou SOV absent'}
        else:
            effective = ferrure_contribution * .70
            rows[str(partant.numero)] = {'status': 'CALCULATED', 'double_count_detected': True, 'reduction': .30, 'ferrure_contribution_initiale': ferrure_contribution, 'ferrure_contribution_effective': effective, 'sov_v2': sov, 'flag': 'RAH163_REDUCTION_30'}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-163', 'status': 'CALCULATED' if statuses and all(status != 'UNPROVEN' for status in statuses) else 'UNPROVEN', 'partants': rows, 'reduction_if_overlap': .30, 'no_silent_proxy': True}


def evaluer_rah159(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        explicit = raw.get('s2_data_suffisante')
        history = raw.get('historique_courses_detaille', raw.get('rangs_6_dernieres', raw.get('rangs_6')))
        if explicit is True:
            sufficient = True
        elif explicit is False:
            sufficient = False
        else:
            sufficient = isinstance(history, list) and len(history) >= 3
        rows[str(partant.numero)] = {'status': 'CALCULATED', 's2_data_suffisante': sufficient, 'mode_supra': 'NORMAL' if sufficient else 'MARCHE_SEUL', 'phase3_s1_marche_active': True, 'phase2_historique_active': sufficient, 'phase4_presse_mode': 'DEGRADE' if not sufficient else 'NORMAL', 'preuve': 's2_data_suffisante' if explicit is not None else 'historique_quantifie' if isinstance(history, list) else 'NC'}
    return {'rule': 'RAH-159', 'status': 'CALCULATED' if rows else 'UNPROVEN', 'partants': rows, 'market_only_count': sum(row['mode_supra'] == 'MARCHE_SEUL' for row in rows.values()), 's1_marche_maintenue': True, 'preuve_export': 'ACTIVE — mode marché-seul' if any(row['mode_supra'] == 'MARCHE_SEUL' for row in rows.values()) else 'NON ACTIVE — données suffisantes'}


def evaluer_rah143(course: Course) -> Dict[str, Any]:
    from modules.supra import calculer_delta_marche
    rows = {}
    all_scores_available = bool([p for p in course.partants if _num(getattr(p, 'ordre_score', None)) is not None and _num(getattr(p, 'ordre_score', None)) > 0])
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        observed_sov = raw.get('sov_v2', (getattr(partant, 'extended_metrics', {}) or {}).get('sov_v2'))
        try:
            sov = float(observed_sov) if observed_sov not in (None, '', 'NC', 'UNPROVEN') else None
        except (TypeError, ValueError):
            sov = None
        cote = _num(getattr(partant, 'cote', None))
        ordre = _num(getattr(partant, 'ordre_score', None))
        proven = sov is not None or (cote is not None and cote > 0 and ordre is not None and ordre > 0 and all_scores_available)
        delta = calculer_delta_marche(partant, course) if proven else None
        rows[str(partant.numero)] = {'status': 'CALCULATED' if proven else 'UNPROVEN', 'delta_marche': delta, 'source': 'SOV_OBSERVE' if sov is not None else 'COTE_ORDRE_THEORIQUE' if proven else 'NC', 'sov_v2': sov, 'presse_used': False, 'significatif': abs(delta) > .10 if delta is not None else None, 'direction': 'SOUTENU' if delta is not None and delta > 0 else 'DELAISSE' if delta is not None and delta < 0 else 'NEUTRE' if delta is not None else None}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-143', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'phase': 'S1-MARCHE', 'no_press_validation': True, 'threshold_significatif': .10}


def evaluer_rah130(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        active = [rule for rule in getattr(course, 'gru_regles', []) if getattr(rule, 'code', '') == 'RAH-130-GRU-LONGCHAMP' and getattr(rule, 'actif', False) and str(getattr(rule, 'description', '')).find('Longchamp') >= 0]
        rows[str(partant.numero)] = {'status': 'CALCULATED' if active else 'NOT_TRIGGERED', 'active': bool(active), 'magnitude_pch': 0.0 if active else None, 'magnitude_source': 'NC', 'specific_rule_precedence': True, 'source_confidence': 'DEGRADE'}
    return {'rule': 'RAH-130', 'status': 'CALCULATED' if rows else 'UNPROVEN', 'partants': rows, 'table': {'<1600': 'corde2+10', '1600': 'corde7+10', '1700-2100': 'corde6+8', '2400': 'corde4+10', '>2400': 'corde3+15'}, 'no_invented_magnitude': True}


def evaluer_rah122(course: Course) -> Dict[str, Any]:
    rows = {}
    penalty_total = 0
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        factors = (getattr(partant, 'extended_metrics', {}) or {}).get('ordre_factors', {})
        details = raw.get('iql_v2', factors.get('iql_v2'))
        if isinstance(details, dict):
            row = dict(details)
        else:
            row = {'status': 'UNPROVEN', 'reason': 'IQL_v2 absent'}
        status = str(row.get('status', '') or '')
        penalty = -2 if status == 'IQL_V2_1_ALLOC_COMBINE_LEGACY' else -1 if status == 'IQL_V2_2_ALLOC' else 0
        row['ift_penalty'] = penalty
        penalty_total += penalty
        rows[str(partant.numero)] = row
    already = bool((getattr(course, 'derived_metrics', {}) or {}).get('rah122_ift_applied'))
    if penalty_total and not already:
        course.ift_score = max(0, int(getattr(course, 'ift_score', 100)) + penalty_total)
        course.derived_metrics['rah122_ift_applied'] = True
    statuses = [row.get('status') for row in rows.values()]
    return {'rule': 'RAH-122', 'status': 'CALCULATED' if statuses and all(status not in {'UNPROVEN_NEUTRAL', 'UNPROVEN', 'UNPROVEN_ALLOCATIONS_WITHOUT_GAINS'} for status in statuses) else 'UNPROVEN', 'partants': rows, 'weights': [0.25, 0.35, 0.40], 'normalizer': 'allocation_course_actuelle/median(allocations_last3)', 'fallback_cascade': ['3_allocations', '2_allocations', '1_allocation', 'legacy_valeur_pmu'], 'ift_penalty_schedule': {'2_allocations': -1, '1_allocation': -2}, 'ift_penalty_applied': penalty_total if not already else 0}


def evaluer_rah102(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        module = next((item for item in getattr(partant, 'modules_results', []) if getattr(item, 'nom', '') == 'RAH-102'), None)
        details = getattr(module, 'details', {}) if module is not None else {}
        rows[str(partant.numero)] = details if isinstance(details, dict) else {'status': 'UNPROVEN', 'reason': 'Module RAH-102 absent'}
    statuses = [row.get('status') for row in rows.values()]
    return {'rule': 'RAH-102', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'malus_cap': -15.0, 'priority_gru_specific_over_generic': True, 'no_cumul': True}


def evaluer_rah75(course: Course) -> Dict[str, Any]:
    allocation = _num(getattr(course, 'allocation', None))
    rows = {}
    for partant in course.partants:
        bsh = next((module for module in getattr(partant, 'modules_results', []) if getattr(module, 'nom', '') == 'BSH_v3v4'), None)
        details = getattr(bsh, 'details', {}) if bsh is not None else {}
        rah75 = details.get('rah75', {}) if isinstance(details, dict) else {}
        rows[str(partant.numero)] = {'status': rah75.get('status', 'UNPROVEN'), 'allocation_course': allocation, 'top10_applicable': rah75.get('top10_applicable'), 'threshold': 50000.0, 'bsh_details_present': bool(details)}
    status = 'CALCULATED' if allocation is not None and rows and all(row['status'] == 'CALCULATED' for row in rows.values()) else 'UNPROVEN'
    return {'rule': 'RAH-75', 'status': status, 'allocation_course': allocation, 'top10_applicable': None if allocation is None else allocation <= 50000.0, 'threshold': 50000.0, 'partants': rows}


def evaluer_rah91(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        ordre = _num(getattr(partant, 'ordre_score', None))
        icp = _num(raw.get('icp_global', getattr(partant, 'icp_count', None)))
        signals = [signal for signal in getattr(partant, 'signaux', []) if getattr(signal, 'actif', False) and not getattr(signal, 'flag_manquant', False)]
        signal_count = len(signals)
        families = {str(getattr(signal, 'famille', '')).upper() for signal in signals if getattr(signal, 'famille', None)}
        cote = _num(getattr(partant, 'cote', None))
        observed = ordre is not None and ordre > 0 and icp is not None and icp > 0 and cote is not None and cote > 0
        criteria = {'ordre_ge_055': ordre is not None and ordre >= .55, 'signals_ge_4': signal_count >= 4, 'families_ge_4': len(families) >= 4, 'family_F_or_C': bool(families.intersection({'F', 'C'})), 'icp_ge_5': icp is not None and icp >= 5, 'cote_le_12': cote is not None and cote <= 12}
        rows[str(partant.numero)] = {'status': 'CALCULATED' if observed else 'UNPROVEN', 'eligible': all(criteria.values()) if observed else None, 'criteria': criteria, 'ordre_score': ordre, 'signal_count': signal_count, 'families': sorted(families), 'icp': icp, 'cote': cote}
    if not rows or any(row['status'] == 'UNPROVEN' for row in rows.values()):
        status = 'UNPROVEN'
    else:
        status = 'PASS' if any(row['eligible'] for row in rows.values()) else 'SANS_PILIER'
    return {'rule': 'RAH-91', 'status': status, 'partants': rows, 'pilier_numbers': [numero for numero, row in rows.items() if row.get('eligible')], 'criteria': 'ORDRE>=0.55 + >=4 signaux + >=4 familles + famille F/C + ICP>=5 + cote<=12'}


def evaluer_rah241(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    risk = evaluer_rah235(course)
    active = risk.get('champ_a_risque_dq_eleve') is True
    if not active:
        return {'rule': 'RAH-241', 'status': 'NOT_APPLICABLE', 'champ_a_risque_dq_eleve': False, 'warning': None}
    reserves = []
    for position, item in (ticket_report.get('ticket_final', {}) or {}).items():
        if position not in {'R1', 'R2'}:
            continue
        partant = next((p for p in course.partants if p.numero == item.get('numero')), None)
        if partant is None:
            continue
        raw = getattr(partant, 'raw_data', {}) or {}
        stab = _num(raw.get('stab_score'))
        flags = {str(flag) for module in getattr(partant, 'modules_results', []) for flag in getattr(module, 'flags', [])}
        propre = raw.get('stab_propre')
        if propre is None and stab is not None:
            propre = stab > -80 and 'STAB_DQ_SERIE_CRITIQUE' not in flags
        reserves.append({'position': position, 'numero': partant.numero, 'stab_propre': propre, 'stab_score': stab, 'flags': sorted(flags)})
    if not reserves:
        return {'rule': 'RAH-241', 'status': 'FAIL', 'champ_a_risque_dq_eleve': True, 'reserves': [], 'warning': 'WARNING_RESERVE_FRAGILE'}
    status = 'PASS' if any(row['stab_propre'] is True for row in reserves) else 'UNPROVEN' if any(row['stab_propre'] is None for row in reserves) else 'FAIL'
    return {'rule': 'RAH-241', 'status': status, 'champ_a_risque_dq_eleve': True, 'reserves': reserves, 'warning': None if status == 'PASS' else 'WARNING_RESERVE_FRAGILE'}


def evaluer_rah237(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        registry_checked = raw.get('rah237_registry_checked') is True
        matches = []
        hippo = str(getattr(course, 'hippodrome', '') or '').upper()
        if hippo == 'ENGHIEN' and raw.get('historique_vincennes_top3') is True:
            matches.append('P1_VINCENNES_VERS_ENGHIEN')
        sens_course = raw.get('sens_rotation_course')
        sens_historique = raw.get('sens_rotation_historique')
        if sens_course not in (None, '', 'NC', 'UNPROVEN') and sens_historique not in (None, '', 'NC', 'UNPROVEN') and str(sens_course).upper() != str(sens_historique).upper():
            matches.append('P2_CORDE_GAUCHE_VERS_DROITE')
        if raw.get('driver_exceptionnel') is True and not raw.get('driver_reference_documentee'):
            matches.append('P3_DRIVER_EXCEPTIONNEL_SANS_REFERENCE')
        if raw.get('montee_categorie') is True and raw.get('categorie_precedente') not in (None, '', 'NC', 'UNPROVEN'):
            matches.append('P4_MONTEE_CATEGORIE')
        evidence = registry_checked or any(key in raw for key in ('historique_vincennes_top3', 'sens_rotation_course', 'sens_rotation_historique', 'driver_exceptionnel', 'driver_reference_documentee', 'montee_categorie', 'categorie_precedente'))
        rows[str(partant.numero)] = {'status': 'CALCULATED' if evidence else 'UNPROVEN', 'registry_checked': registry_checked or evidence, 'matches': matches, 'no_silent_inference': True, 'registry_entries': ['P1_VINCENNES_VERS_ENGHIEN', 'P2_CORDE_GAUCHE_VERS_DROITE', 'P3_DRIVER_EXCEPTIONNEL_SANS_REFERENCE', 'P4_MONTEE_CATEGORIE']}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-237', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'registry_pieges_verifie': bool(rows) and all(row['registry_checked'] for row in rows.values())}


def evaluer_rah235(course: Course) -> Dict[str, Any]:
    rows = {}
    champ_flag = False
    for partant in course.partants:
        details = (getattr(partant, 'raw_data', {}) or {}).get('rah235')
        if not isinstance(details, dict):
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'reason': 'Module RAH-235 absent'}
            continue
        flags = details.get('flags', []) or []
        champ_flag = champ_flag or 'CHAMP_A_RISQUE_DQ_ELEVE' in flags
        rows[str(partant.numero)] = {'status': details.get('status', 'UNPROVEN'), 'malus_pch': details.get('malus_pch'), 'flags': flags, 'dq_dans_3_dernieres': details.get('dq_dans_3_dernieres'), 'dq_dans_2_dernieres': details.get('dq_dans_2_dernieres'), 'temperament_quote_documented': details.get('temperament_quote_documented'), 'champ_a_risque_dq_eleve': details.get('champ_a_risque_dq_eleve')}
    statuses = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-235', 'status': 'CALCULATED' if statuses and all(status == 'CALCULATED' for status in statuses) else 'UNPROVEN', 'partants': rows, 'champ_a_risque_dq_eleve': champ_flag, 'malus_a': -6.0, 'malus_b': -4.0, 'no_deduction_without_quote': True}


def evaluer_rah236(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        b04_active = any(str(getattr(signal, 'code', '')).upper() == 'B04' and getattr(signal, 'actif', False) for signal in getattr(partant, 'signaux', [])) or raw.get('b04_actif') is True
        if not b04_active:
            rows[str(partant.numero)] = {'status': 'NOT_APPLICABLE', 'b04_active': False}
            continue
        courses = _num(raw.get('b04_nb_courses_hippodrome', raw.get('nb_courses_hippodrome')))
        top5 = _num(raw.get('b04_nb_top5_hippodrome', raw.get('nb_top5_hippodrome')))
        delay = _num(raw.get('b04_delai_dernier_top5_jours', raw.get('delai_derniere_top5_hippodrome')))
        coefficient = _num(raw.get('b04_coeff_temps_applique'))
        tier = raw.get('b04_tier_applique')
        if courses is None or top5 is None or delay is None or coefficient is None or tier in (None, '', 'NC', 'UNPROVEN'):
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'b04_active': True, 'reason': 'Preuves B04-RAH236 incomplètes', 'b04_nb_courses_hippodrome': courses, 'b04_nb_top5_hippodrome': top5, 'b04_delai_dernier_top5_jours': delay, 'b04_coeff_temps_applique': coefficient, 'b04_tier_applique': tier}
            continue
        if courses < 3:
            rows[str(partant.numero)] = {'status': 'FAIL', 'b04_active': True, 'flag': 'B04_ECHANTILLON_INSUFFISANT', 'b04_nb_courses_hippodrome': courses, 'b04_tier_applique': tier}
            continue
        expected_tier = 'STRICT' if top5 >= 3 and courses >= 4 else 'DEGRADE' if top5 / courses >= .20 and courses >= 3 else 'MINIMAL' if raw.get('b04_top3_hippodrome') is not None and _num(raw.get('b04_top3_hippodrome')) >= 1 else None
        tier_ok = expected_tier is not None and str(tier).upper() == expected_tier
        rows[str(partant.numero)] = {'status': 'CALCULATED' if tier_ok else 'FAIL', 'b04_active': True, 'b04_nb_courses_hippodrome': courses, 'b04_nb_top5_hippodrome': top5, 'b04_delai_dernier_top5_jours': delay, 'b04_coeff_temps_applique': coefficient, 'b04_tier_applique': tier, 'expected_tier': expected_tier, 'tier_ok': tier_ok}
    status_values = [row['status'] for row in rows.values()]
    return {'rule': 'RAH-236', 'status': 'CALCULATED' if status_values and all(value in {'CALCULATED', 'NOT_APPLICABLE'} for value in status_values) else 'FAIL' if 'FAIL' in status_values else 'UNPROVEN', 'partants': rows, 'minimum_courses_if_active': 3, 'required_fields': ['b04_nb_courses_hippodrome', 'b04_nb_top5_hippodrome', 'b04_delai_dernier_top5_jours', 'b04_coeff_temps_applique', 'b04_tier_applique']}


def evaluer_rah13(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    rows = []
    for position, partant in _ticket_rows(course, ticket_report):
        if position not in {'P1', 'P2', 'P3'}:
            continue
        raw = getattr(partant, 'raw_data', {}) or {}
        flags = {str(flag) for module in getattr(partant, 'modules_results', []) for flag in getattr(module, 'flags', [])}
        kill = bool(raw.get('kill_list')) or bool(flags.intersection({'KILL_LIST_M25_EQUIVALENT', 'STAB_DQ_SERIE_CRITIQUE'}))
        evidence_present = raw.get('kill_list') is not None or bool(flags.intersection({'KILL_LIST_M25_EQUIVALENT', 'STAB_DQ_SERIE_CRITIQUE'})) or raw.get('kill_list_audit') is not None
        rows.append({'position': position, 'numero': partant.numero, 'kill_list': kill, 'evidence_present': evidence_present, 'status': 'FAIL' if kill else 'CALCULATED' if evidence_present else 'UNPROVEN'})
    status = 'FAIL' if any(row['status'] == 'FAIL' for row in rows) else 'UNPROVEN' if any(row['status'] == 'UNPROVEN' for row in rows) else 'PASS'
    return {'rule': 'RAH-13', 'status': status, 'scope': 'P1-P3', 'partants': rows, 'hard_exclusion': True, 'no_silent_proxy': True}


def evaluer_rah144(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        value = _num(raw.get('signal_supra_individuel'))
        rows[str(partant.numero)] = {'status': 'CALCULATED' if value is not None and -3.0 <= value <= 3.0 else 'UNPROVEN', 'signal_supra_individuel': value, 'range_ok': value is not None and -3.0 <= value <= 3.0, 'scope': ['cheval', 'jockey', 'entraineur', 'ecurie', 'equipement']}
    return {'rule': 'RAH-144', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'range': [-3.0, 3.0], 'whole_field': True}


def evaluer_rah145(course: Course) -> Dict[str, Any]:
    audit = (getattr(course, 'derived_metrics', {}) or {}).get('supra_phase7_audit', {}) or {}
    phase7 = audit.get('phase7_rah238', {}) or {}
    opportunities = phase7.get('piste_opportunite', []) if isinstance(phase7, dict) else []
    blocked = audit.get('modifications_bloquees', []) or []
    applied = audit.get('modifications_appliquees', []) or []
    rows = []
    for item in opportunities:
        families = item.get('familles', []) or []
        rows.append({'numero': item.get('numero'), 'families': families, 'independent_signal_count': len(set(families)), 'convergence_ok': len(set(families)) >= 2, 'confidence': item.get('confiance')})
    status = 'CALCULATED' if isinstance(phase7, dict) and all(row['convergence_ok'] for row in rows) and all(len((item.get('familles_convergentes', []) or [])) >= 2 for item in applied + blocked) else 'UNPROVEN'
    return {'rule': 'RAH-145', 'status': status, 'phase7_convergence': rows, 'modifications_appliquees': applied, 'modifications_bloquees': blocked, 'minimum_independent_families': 2, 'p5p6_protection_absorbed': True}


def evaluer_rah119(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        details = (getattr(partant, 'raw_data', {}) or {}).get('p5p6')
        if not isinstance(details, dict):
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'reason': 'MODULE P5P6 absent'}
            continue
        weights = tuple(details.get('weights', ()))
        score = _num(details.get('p5p6_score'))
        expected_weights = (.35, .20, .18, .12, .15) if details.get('c5_montee_categorie') is not None else (.40, .25, .20, .15)
        weights_ok = weights == expected_weights
        rows[str(partant.numero)] = {'status': 'CALCULATED' if score is not None and weights_ok else 'UNPROVEN', 'p5p6_score': score, 'weights': weights, 'weights_expected': expected_weights, 'p5_threshold': details.get('p5_threshold'), 'p6_threshold': details.get('p6_threshold'), 'eligible_p5': details.get('eligible_p5'), 'eligible_p6': details.get('eligible_p6'), 'orthogonal_to_borda': details.get('orthogonal_to_borda') is True, 'flags': details.get('flags', [])}
    return {'rule': 'RAH-119', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'criteria': 'C1-C4 pondérés 0.40/0.25/0.20/0.15; seuils P5/P6 0.40/0.35, CHAOS 0.30/0.25', 'orthogonal_to_borda': True}


def evaluer_rah52(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        components = (getattr(partant, 'extended_metrics', {}) or {}).get('composite_components')
        rows[str(partant.numero)] = components if isinstance(components, dict) else {'status': 'UNPROVEN', 'reason': 'Décomposition COMPOSITE v2 absente'}
    status = 'CALCULATED' if rows and all(row.get('w_H2H') == 0.10 and row.get('w_PCH') is not None for row in rows.values()) else 'UNPROVEN'
    return {'rule': 'RAH-52', 'status': status, 'partants': rows, 'formula': 'w_PCH*PCH_NORM+w_tocard*tocard_score+w_CSF*CSF_norm+0.10*h2h_norm'}


def evaluer_rah60(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        pch = _num(getattr(partant, 'pch_final', None))
        pch_norm = _num((getattr(partant, 'extended_metrics', {}) or {}).get('composite_components', {}).get('PCH_NORM'))
        rows[str(partant.numero)] = {'pch_final': pch, 'pch_norm': pch_norm, 'cap_ok': pch is not None and 0.0 <= pch <= 220.0, 'status': 'CALCULATED' if pch is not None and pch_norm is not None else 'UNPROVEN'}
    return {'rule': 'RAH-60', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' and row['cap_ok'] for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'cap': 220.0, 'formula': 'PCH_NORM=PCH_FINAL/220'}


def evaluer_rah61(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        factors = (getattr(partant, 'extended_metrics', {}) or {}).get('ordre_factors')
        rows[str(partant.numero)] = factors if isinstance(factors, dict) else {'status': 'UNPROVEN', 'reason': 'Décomposition ORDRE_SCORE absente'}
    names = {'sov_v2', 'iql', 'tact_mult', 'stab_mult', 'all_mult', 'harville_mult', 'ordre_base', 'ordre_score'}
    status = 'CALCULATED' if rows and all(names.issubset(row) for row in rows.values()) else 'UNPROVEN'
    return {'rule': 'RAH-61', 'status': status, 'partants': rows, 'factor_count': 7, 'formula': 'COMPOSITE*(1+SOV_v2)*IQL*Tact_mult*STAB_mult*ALL_mult*Harville_mult'}


def evaluer_rah63(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        factors = (getattr(partant, 'extended_metrics', {}) or {}).get('ordre_factors', {})
        module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'OVERBET_DETECTOR'), None)
        details = getattr(module, 'details', {}) if module else {}
        initial = _num(details.get('ordre_score_initial')) if isinstance(details, dict) else None
        if initial is None:
            initial = _num((getattr(partant, 'raw_data', {}) or {}).get('ordre_score_initial'))
        rows[str(partant.numero)] = {'ordre_score_initial': initial, 'ordre_score_final': factors.get('ordre_score'), 'overbet_module_present': module is not None, 'adjustment_single_pass': True, 'status': 'CALCULATED' if initial is not None else 'UNPROVEN'}
    return {'rule': 'RAH-63', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'read_only_initial': True, 'no_iteration': True}


def evaluer_rah67(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        components = (getattr(partant, 'extended_metrics', {}) or {}).get('composite_components', {})
        h2h_module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'H2H_GRAPH'), None)
        rows[str(partant.numero)] = {'h2h_norm': components.get('h2h_norm'), 'w_H2H': components.get('w_H2H'), 'module_present': h2h_module is not None, 'status': 'CALCULATED' if components.get('w_H2H') == 0.10 and components.get('h2h_norm') is not None else 'UNPROVEN'}
    return {'rule': 'RAH-67', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'weight_h2h': 0.10, 'h2h_mult_removed': True}


def evaluer_rah27(course: Course) -> Dict[str, Any]:
    ordered = sorted(course.partants, key=lambda p: float(getattr(p, 'ordre_score', 0) or 0), reverse=True)[:3]
    rows = []
    for partant in ordered:
        module = next((m for m in getattr(partant, 'modules_results', []) if getattr(m, 'nom', '') == 'H2H_GRAPH'), None)
        details = getattr(module, 'details', {}) if module else {}
        rows.append({'numero': partant.numero, 'module_present': module is not None, 'active': bool(getattr(module, 'actif', False)) if module else False, 'status': details.get('status') if isinstance(details, dict) else None, 'h2h_avg': details.get('h2h_avg') if isinstance(details, dict) else None})
    return {'rule': 'RAH-27', 'status': 'CALCULATED' if rows and all(row['module_present'] and row['active'] for row in rows) else 'UNPROVEN', 'top3_ordre_score': [p.numero for p in ordered], 'rows': rows, 'minimum_checked': 3}


def evaluer_rah268(course: Course) -> Dict[str, Any]:
    raw_course = getattr(course, 'raw_data', {}) or {}
    return {'rule': 'RAH-268', 'status': 'CALCULATED', 'search_priority': 'NON_PRIORITAIRE', 'scope': 'ECART_ORDRE_SCORE_1_VS_2', 'gap_observed': _num(raw_course.get('ordre_score_gap_1_2')), 'nc_accepted': True, 'ift_penalty': 0, 'ticket_impact': False}


def evaluer_rah246(course: Course) -> Dict[str, Any]:
    rows = {}
    hippo = str(course.hippodrome or '').upper()
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        position = _num(raw.get('numero_autostart', raw.get('numero', partant.numero)))
        pente = _num(raw.get('pente_score'))
        confirme = raw.get('pente_score_confirme') is True or (pente is not None and raw.get('pente_score_nombre_courses', 0) not in (None, '') and float(raw.get('pente_score_nombre_courses')) >= 2)
        base = _num(raw.get('seconde_ligne_malus_base'))
        rah235 = raw.get('rah235a_active') is True or raw.get('rah235_active') is True
        applicable = hippo in {'ENGHIEN', 'CABOURG'} and position is not None and position >= 8 and confirme and base is not None
        if not applicable:
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'applicable': False, 'hippodrome': hippo, 'position': position, 'pente_score': pente, 'pente_confirme': confirme, 'base_malus': base, 'rah235_prevalent': rah235}
            continue
        reduced = base == -20 and not rah235
        rows[str(partant.numero)] = {'status': 'CALCULATED', 'applicable': True, 'base_malus': base, 'effective_malus': -12.0 if reduced else base, 'pente_score': pente, 'pente_confirme': confirme, 'rah235_prevalent': rah235, 'reduction_applied': reduced, 'non_cumul_guard': True}
    return {'rule': 'RAH-246', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' or not row['applicable'] for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'priority_rah235': True, 'scope': 'ENGHIEN_CABOURG_SECOND_LINE'}


def evaluer_rah192(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        family_scores = raw.get('gamma_family_scores')
        family_caps = raw.get('gamma_family_caps')
        gamma_real = _num((getattr(partant, 'gamma_details', {}) or {}).get('gamma_score'))
        if not isinstance(family_scores, dict) or not isinstance(family_caps, dict):
            rows[str(partant.numero)] = {'status': 'UNPROVEN', 'gamma_score_real': gamma_real, 'simulated_capped': None, 'gap': None}
            continue
        simulated = sum(min(_num(value) or 0.0, _num(family_caps.get(key)) or 0.0) for key, value in family_scores.items())
        rows[str(partant.numero)] = {'status': 'CALCULATED', 'family_scores': family_scores, 'family_caps': family_caps, 'gamma_score_real': gamma_real, 'simulated_capped': simulated, 'gap_vs_real': None if gamma_real is None else simulated - gamma_real}
    return {'rule': 'RAH-192', 'status': 'CALCULATED' if rows and all(row['status'] == 'CALCULATED' for row in rows.values()) else 'UNPROVEN', 'partants': rows, 'parallel_only': True, 'no_pch_rewrite': True}


def evaluer_rah175(course: Course) -> Dict[str, Any]:
    rows = []
    exceptions = {'RAH-198', 'RAH-199', 'RAH-200', 'RAH-203', 'RAH-204', 'RAH-205', 'RAH-206', 'RAH-207', 'RAH-209', 'RAH-297'}
    missing_tier = []
    gamma_weighted = []
    for partant in course.partants:
        for signal in getattr(partant, 'signaux', []) or []:
            code = str(getattr(signal, 'code', '') or '')
            tier = str(getattr(signal, 'tier', '') or getattr(signal, 'palier', '') or '').upper()
            if not tier:
                tier = str((getattr(partant, 'raw_data', {}) or {}).get('signal_tiers', {}).get(code, '') or '').upper()
            if not tier:
                missing_tier.append({'numero': partant.numero, 'code': code})
            contribution = _num(getattr(signal, 'pch_contribution', getattr(signal, 'contribution_pch', 0))) or 0
            if tier == 'GAMMA' and abs(contribution) > 0 and code not in exceptions:
                gamma_weighted.append({'numero': partant.numero, 'code': code, 'contribution': contribution})
            rows.append({'numero': partant.numero, 'code': code, 'tier': tier or None, 'gamma_weighted': tier == 'GAMMA' and abs(contribution) > 0})
    return {'rule': 'RAH-175', 'status': 'CALCULATED' if not missing_tier and not gamma_weighted else 'UNPROVEN', 'signals': rows, 'missing_tier': missing_tier, 'gamma_weighted_exceptions': gamma_weighted, 'allowed_gamma_exceptions': sorted(exceptions)}


def evaluer_rah117(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        values = raw.get('p_score_positions', raw.get('p_score_continu'))
        if isinstance(values, (list, tuple)) and len(values) >= 3:
            numeric = [_num(value) for value in values if _num(value) is not None]
            if len(numeric) >= 3:
                avant = numeric[:max(1, min(3, len(numeric)))]
                milieu = numeric[3:6] or numeric[:1]
                arriere = numeric[6:8] or numeric[-1:]
                rows[str(partant.numero)] = {'status': 'CALCULATED', 'zones': {'AVANT': avant, 'MILIEU': milieu, 'ARRIERE': arriere}, 'p_score_continu': sum(numeric) / len(numeric), 'fallback': False}
                continue
        style = str(raw.get('style_mpa', '') or '').upper()
        rows[str(partant.numero)] = {'status': 'CALCULATED' if style else 'UNPROVEN', 'zones': None, 'p_score_continu': None, 'fallback': bool(style), 'fallback_label': style if style else None, 'flag': 'PSCORE_LEGACY' if style else 'PSCORE_DATA_NC'}
    return {'rule': 'RAH-117', 'status': 'CALCULATED' if rows and all(item['status'] == 'CALCULATED' for item in rows.values()) else 'UNPROVEN', 'partants': rows, 'minimum_positions_continu': 3, 'history_window': 8, 'no_ift_penalty_on_legacy': True}


def evaluer_rah53(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    ticket = ticket_report.get('ticket_final', {}) or {}
    rows = {}
    for position, item in ticket.items():
        if position not in {'P2', 'P3', 'P4', 'P5'}:
            continue
        partant = next((p for p in course.partants if p.numero == item.get('numero')), None)
        raw = getattr(partant, 'raw_data', {}) if partant else {}
        cote = partant.cote if partant else None
        if cote is None or cote <= 8:
            rows[position] = {'status': 'NOT_APPLICABLE', 'cote': cote}
            continue
        base = _num(raw.get('harville_base_probability'))
        corrected = _num(raw.get('harville_corrected_probability'))
        field_size = _num(getattr(course, 'nb_partants', None))
        if base is None and field_size is not None and field_size > 1:
            base = (1.0 / float(cote)) * (field_size - 1.0) / field_size
        reliable = (_num(getattr(course, 'ift_moyen_champ', None)) is not None and _num(getattr(course, 'ift_moyen_champ', None)) >= 75 and _num(getattr(course, 'nb_valeur_morte_champ', None)) is not None and _num(getattr(course, 'nb_valeur_morte_champ', None)) <= 3 and _num(getattr(course, 'overbet_media_count', None)) is not None and _num(getattr(course, 'overbet_media_count', None)) <= 1 and _num(getattr(course, 'kill_list_count', None)) is not None and field_size is not None and _num(getattr(course, 'kill_list_count', None)) / field_size <= .15)
        if corrected is None and base is not None and reliable:
            exponent = .81 if position == 'P2' else .65
            corrected = (base ** exponent) / (base ** exponent + (1.0 - base) ** exponent)
        delta = None if base is None or corrected is None else corrected - base
        bonus = .08 if delta is not None and delta > .03 and cote > 12 else .04 if delta is not None and delta > .01 and cote > 8 else 0.0
        rows[position] = {'status': 'CALCULATED' if corrected is not None and reliable else 'UNPROVEN', 'cote': cote, 'base_probability': base, 'corrected_probability': corrected, 'delta': delta, 'harville_bonus': bonus if reliable else 0.0, 'harville_fiable': reliable, 'outsider': True}
    return {'rule': 'RAH-53', 'status': 'CALCULATED' if rows and all(row['status'] in {'CALCULATED', 'NOT_APPLICABLE'} for row in rows.values()) else 'UNPROVEN', 'positions': rows, 'no_proxy': True, 'formula': 'prob_brut=(1/cote)*(n-1)/n; exp=.81 P2 else .65; prob_corr=...; bonus=.08/.04/0', 'reliability_guard': 'IFT_moyen>=75, VALEUR_MORTE<=3, OVERBET_MEDIA<=1, KillList/partants<=.15'}


def evaluer_rah108(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    ticket = ticket_report.get('ticket_final', {}) or {}
    entries = []
    for position, item in ticket.items():
        if position not in {'P1', 'P2', 'P3', 'P4', 'P5'}:
            continue
        partant = next((p for p in course.partants if p.numero == item.get('numero')), None)
        if partant is None or partant.cote is None or partant.cote <= 20:
            continue
        raw = getattr(partant, 'raw_data', {}) or {}
        qualified = float(partant.ordre_score or 0) >= .35 or any(getattr(s, 'actif', False) for s in partant.signaux) or float(partant.tocard_score or 0) >= .15
        entries.append({'numero': partant.numero, 'position': position, 'cote': partant.cote, 'qualified': qualified})
    fallback = any(float((next((p for p in course.partants if p.numero == item.get('numero')), None).cote or 0)) > 15 for position, item in ticket.items() if position in {'P1', 'P2', 'P3', 'P4', 'P5', 'P6'} and next((p for p in course.partants if p.numero == item.get('numero')), None) is not None)
    status = 'PASS' if any(row['qualified'] for row in entries) or (not entries and fallback) else 'SUSPENDED' if entries else 'NOT_APPLICABLE'
    return {'rule': 'RAH-108', 'status': status, 'cote_gt20_entries': entries, 'fallback_cote_gt15': fallback, 'flag': 'COTE_ELEVEE_SUSPENDUE' if status == 'SUSPENDED' else None}


def evaluer_rah114(partant, course: Course) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    delay = _num(raw.get('delai_derniere_top5_hippodrome'))
    if delay is None:
        coefficient, flag = .60, 'B04_DATE_INCONNUE'
    elif delay <= 90:
        coefficient, flag = 1.0, None
    elif delay <= 180:
        rare = str(getattr(course, 'hippodrome', '') or '').upper() in {'GRAIGNES', 'VICHY', 'BORDEAUX'} and _num(raw.get('reunions_annuelles_hippodrome')) is not None and _num(raw.get('reunions_annuelles_hippodrome')) <= 2
        coefficient, flag = (.85, 'B04_HIPPODROME_RARE') if rare else (.75, 'B04_ANCIEN_MODERE')
    elif delay <= 365:
        coefficient, flag = .50, 'B04_ANCIEN'
    else:
        coefficient, flag = .25, 'B04_TRES_ANCIEN'
    base = _num(raw.get('b04_post_rah109', raw.get('b04_brut')))
    final = None if base is None else round(base * coefficient, 6)
    if final is not None and final > 0:
        final = max(1.0, final)
    return {'rule': 'RAH-114', 'status': 'CALCULATED' if final is not None else 'UNPROVEN', 'delay_days': delay, 'coefficient_temps': coefficient, 'b04_post_rah109': base, 'b04_final': final, 'flag': flag}


def evaluer_rah30(course: Course) -> Dict[str, Any]:
    count = len(course.partants)
    return {'rule': 'RAH-30', 'status': 'PASS' if count >= 7 else 'FAIL', 'confirmed_partants': count, 'minimum': 7, 'ticket_blocked': count < 7}


def evaluer_rah45(course: Course) -> Dict[str, Any]:
    raw = getattr(course, 'raw_data', {}) or {}
    flags = raw.get('impossible_flags', [])
    if not isinstance(flags, (list, tuple)):
        return {'rule': 'RAH-45', 'status': 'UNPROVEN', 'flags_impossible': None, 'ift_penalty': 0}
    count = len([flag for flag in flags if flag])
    return {'rule': 'RAH-45', 'status': 'CALCULATED', 'flags_impossible': count, 'maximum': 3, 'ift_penalty': -5 if count > 3 else 0, 'alert': count > 3}


def evaluer_rah_p2(course: Course, ticket_report: Dict[str, Any]) -> Dict[str, Any]:
    return {'RAH-01': evaluer_rah01(course, ticket_report), 'RAH-02': evaluer_rah02(course, ticket_report), 'RAH-09': evaluer_rah09(course, ticket_report), 'RAH-12': evaluer_rah12(course, ticket_report), 'RAH-14': evaluer_rah14(course, ticket_report), 'RAH-164': evaluer_rah164(course, ticket_report), **evaluer_rah282_287(course), **evaluer_rah97_99(course, ticket_report), **evaluer_rah243_245_253_254_260_261_263_264_265(course, ticket_report), **evaluer_rah85_89(course, ticket_report), **evaluer_rah73_82(course, ticket_report), **evaluer_rah68_71(course, ticket_report), **evaluer_rah64_66(course, ticket_report), **evaluer_rah59_62(course, ticket_report), **evaluer_rah54_58(course, ticket_report), **evaluer_rah48_51(course, ticket_report), **evaluer_rah46_47(course, ticket_report), 'RAH-43': evaluer_rah43(course, ticket_report), **evaluer_rah31_35_40(course, ticket_report), **evaluer_rah28_29(course, ticket_report), **evaluer_rah213_214(course, ticket_report), 'RAH-17_18_19': evaluer_rah17_18_19(course, ticket_report), **evaluer_rah20_25(course, ticket_report), 'RAH-142': evaluer_rah142(course, ticket_report), 'RAH-147': evaluer_rah147(course, ticket_report), 'RAH-148': evaluer_rah148(course, ticket_report), 'RAH-149': evaluer_rah149(course, ticket_report), 'RAH-136': evaluer_rah136(course), 'RAH-137': evaluer_rah137(course), 'RAH-03': evaluer_rah03(course, ticket_report), 'RAH-04': evaluer_rah04(course, ticket_report), 'RAH-05': evaluer_rah05(course, ticket_report), 'RAH-06': evaluer_rah06(course, ticket_report), 'RAH-13': evaluer_rah13(course, ticket_report), 'RAH-235': evaluer_rah235(course), 'RAH-236': evaluer_rah236(course), 'RAH-237': evaluer_rah237(course), 'RAH-241': evaluer_rah241(course, ticket_report), 'RAH-75': evaluer_rah75(course), 'RAH-91': evaluer_rah91(course), 'RAH-102': evaluer_rah102(course), 'RAH-104': evaluer_rah104(course), 'RAH-105_106': evaluer_rah105_106(course), 'RAH-109': evaluer_rah109(course), 'RAH-110': evaluer_rah110(course), 'RAH-111_112': evaluer_rah111_112(course), 'RAH-115': evaluer_rah115(course), 'RAH-118': evaluer_rah118(course), 'RAH-120': evaluer_rah120(course), 'RAH-121': evaluer_rah121(course), 'RAH-124_129': evaluer_rah124_129(course), 'RAH-100': evaluer_rah100(course), 'RAH-101': evaluer_rah101(course), 'RAH-103': evaluer_rah103(course), 'RAH-122': evaluer_rah122(course), 'RAH-130': evaluer_rah130(course), 'RAH-143': evaluer_rah143(course), 'RAH-159': evaluer_rah159(course), 'RAH-163': evaluer_rah163(course), 'RAH-185': evaluer_rah185(course), 'RAH-242': evaluer_rah242(course), 'RAH-26': evaluer_rah26(course), 'RAH-78': evaluer_rah78(course), 'RAH-84': evaluer_rah84(course), 'RAH-88': evaluer_rah88(course), 'RAH-131': evaluer_rah131(course), 'RAH-92': evaluer_rah92(course), 'RAH-94': evaluer_rah94(course), 'RAH-27': evaluer_rah27(course), 'RAH-119': evaluer_rah119(course), 'RAH-144': evaluer_rah144(course), 'RAH-145': evaluer_rah145(course), 'RAH-30': evaluer_rah30(course), 'RAH-45': evaluer_rah45(course), 'RAH-52': evaluer_rah52(course), 'RAH-53': evaluer_rah53(course, ticket_report), 'RAH-60': evaluer_rah60(course), 'RAH-61': evaluer_rah61(course), 'RAH-63': evaluer_rah63(course), 'RAH-67': evaluer_rah67(course), 'RAH-72': {'status': 'DEFERRED_TO_MPA', 'source': 'modules.normative.module_mpa_normative'}, 'RAH-108': evaluer_rah108(course, ticket_report), 'RAH-114': {str(p.numero): evaluer_rah114(p, course) for p in course.partants}, 'RAH-117': evaluer_rah117(course), 'RAH-175': evaluer_rah175(course), 'RAH-192': evaluer_rah192(course), 'RAH-246': evaluer_rah246(course), 'RAH-268': evaluer_rah268(course), 'RAH-162': evaluer_rah162(course, ticket_report), 'RAH-187': evaluer_rah187(course, ticket_report), 'RAH-193': evaluer_rah193(course, ticket_report)}
