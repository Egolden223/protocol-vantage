"""Implémentations déterministes des modules Vantage explicitement spécifiés."""
from __future__ import annotations

from statistics import mean
from typing import Any, Dict, List

from engine.models import Course, Partant, ModuleResult, Discipline


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def _clamp(lo: float, hi: float, value: float) -> float:
    return max(lo, min(hi, value))


def _nc(result: ModuleResult, flag: str, reason: str) -> ModuleResult:
    result.score = 0.0
    result.flags.append(flag)
    result.details = {'status': 'NC', 'reason': reason}
    return result


def module_stab_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='STAB', actif=True)
    dq_h = _num(_raw(partant, 'dq_freq_12m'))
    n_h = _num(_raw(partant, 'nb_courses_12m'))
    dq_d = _num(_raw(partant, 'dq_driver_12m'))
    n_d = _num(_raw(partant, 'nb_courses_driver'))
    incidents = _raw(partant, 'incidents_30j', []) or []
    pattern = str(_raw(partant, 'pattern_incidents', '') or '').upper()
    ferrure = _num(_raw(partant, 'ferrure_changes'))
    equip = _num(_raw(partant, 'equip_changes'))
    if all(x is None for x in (dq_h, n_h, dq_d, n_d, ferrure, equip)) and not incidents and not pattern:
        return _nc(result, 'STAB_DATA_NC', 'Données DQ/incidents/équipement absentes')

    s1 = 0
    if dq_h is not None and n_h is not None:
        taux = dq_h / max(n_h, 1)
        s1 = -20 if taux > .20 else -15 if taux > .15 else -10 if taux > .10 else -5 if taux > .05 else 0
    s2 = 0
    if dq_d is not None and n_d is not None:
        taux = dq_d / max(n_d, 1)
        s2 = -15 if taux > .15 else -12 if taux > .10 else -8 if taux > .05 else 0
    nb_incidents = len(incidents)
    s3 = 0 if nb_incidents == 0 else -8 if nb_incidents == 1 else -12 if nb_incidents == 2 else -20
    s3 += {'STABLE': 0, 'VARIABLE': -3, 'CHANGEANTE': -8, 'SERIES': -15}.get(pattern, 0)

    # STAB-03bis : 3+ DQ/A dans les 5 dernières courses tentées, sur 12 mois.
    dq_series_5 = _num(_raw(partant, 'dq_consecutifs_5_tentees', _raw(partant, 'dq_series_5')))
    dq_series_12m = _num(_raw(partant, 'dq_series_12m', dq_h))
    stab_dq_serie_critique = pattern == 'SERIES' and dq_series_5 is not None and dq_series_5 >= 3 and dq_series_12m is not None and dq_series_12m >= 3

    s4 = 0
    if ferrure is not None:
        s4 += 0 if ferrure == 0 else -5 if ferrure == 1 else -12
        if str(_raw(partant, 'deferrage', '')).upper() == 'AUCUN' and ferrure > 0:
            s4 -= 3
    if equip is not None:
        s4 += 0 if equip == 0 else -5 if equip < 3 else -10
    # STAB-06 : risque d’allure du favori trot. Non-cumul si STAB-01 > 15%.
    s6 = 0
    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    cote = _num(partant.cote)
    cotes_champ = sorted([_num(p.cote) for p in course.partants if _num(p.cote) is not None and _num(p.cote) > 0])
    rang_cote = cotes_champ.index(cote) + 1 if cote is not None and cote in cotes_champ else None
    if discipline in {'TROT_ATTELE', 'TROT_MONTE'} and dq_h is not None and dq_h >= 1 and (cote is not None and (cote <= 6 or rang_cote in {1, 2})):
        if not (dq_h / max(n_h or 1, 1) > .15):
            s6 = -5

    score = _clamp(-100, 0, s1 + s2 + s3 + s4 + s6)
    contribution = max(-20, score)
    result.score = contribution
    result.details = {
        'status': 'CALCULATED', 's1_dq_cheval': s1, 's2_dq_driver': s2,
        's3_incidents': s3, 's4_equipement': s4, 's6_favori_risque_allure': s6,
        'stab_score': score, 'pch_contribution': contribution,
        'dq_series_5_tentees': dq_series_5, 'dq_series_12m': dq_series_12m,
        'rang_cote_champ': rang_cote,
        'kill_list': stab_dq_serie_critique,
        'restrictions_ticket': ['P5', 'P6'] if stab_dq_serie_critique else [],
    }
    if stab_dq_serie_critique:
        result.flags.extend(['STAB_DQ_SERIE_CRITIQUE', 'KILL_LIST_M25_EQUIVALENT', 'EXCLUSION_P1_P4'])
        if _num(_raw(partant, 'b07_strict_top3_post_dq')):
            result.flags.append('STAB_DQ_SERIE_ATTENUATION_B07')
        if _raw(partant, 'changement_entraineur_30j') and _raw(partant, 'dq_anterieurs_changement'):
            result.flags.append('STAB_DQ_SERIE_CHANGEMENT_ECURIES')
    rah233_active = s6 == -5 and discipline in {'TROT_ATTELE', 'TROT_MONTE'}
    if s6 < 0:
        result.flags.append('STAB_FAVORI_RISQUE_ALLURE')
    if rah233_active:
        result.flags.append('RAH233_STAB06_NON_CUMUL_STAB01')
    result.details['rah233'] = {'status': 'CALCULATED' if rah233_active else 'NOT_TRIGGERED', 'malus': -5 if rah233_active else 0, 'non_cumul_stab01': True, 'conditions': {'trot': discipline in {'TROT_ATTELE', 'TROT_MONTE'}, 'dq_12m': dq_h, 'cote': cote, 'rang_cote': rang_cote}}
    return result


def module_tact_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='TACT', actif=False)
    if course.discipline not in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE):
        return result
    result.actif = True
    numero = _num(_raw(partant, 'numero_autostart', _raw(partant, 'numero')))
    if numero is None:
        return _nc(result, 'TACT_DATA_NC', 'Numéro autostart absent')
    style = str(_raw(partant, 'style_mpa', '') or '').upper()
    if 'MENEUR' in style:
        t1 = 12 if numero <= 3 else 8 if numero <= 8 else -6 if numero <= 12 else -12 if numero <= 16 else -8
        wagon_penalty = -2 if len(course.partants) > 12 else 0
    elif 'ATTENT' in style:
        t1 = 8 if numero <= 3 else 5 if numero <= 8 else -4 if numero <= 12 else -8 if numero <= 16 else -3
        wagon_penalty = 0
    else:
        t1 = 0
        wagon_penalty = 0
    t2 = 0
    if str(_raw(partant, 'position_montee', '')).upper() == '1ERE_LIGNE':
        t2 += 10
    elif str(_raw(partant, 'position_montee', '')).upper() == 'EXT_SIMPLE':
        t2 -= 5
    elif str(_raw(partant, 'position_montee', '')).upper() == 'EXT_2ND':
        t2 -= 8
    attelage_pos = _num(_raw(partant, 'attelage_pos'))
    if attelage_pos == 1:
        t2 += 5
    elif attelage_pos == 2:
        t2 += 0
    hist_dos = _raw(partant, 'hist_dos_attelage2', _raw(partant, 'historique_attelage2', [])) or []
    if isinstance(hist_dos, dict):
        hist_dos = [hist_dos]
    hist_top5 = sum(1 for row in hist_dos if isinstance(row, dict) and _num(row.get('rang')) is not None and _num(row.get('rang')) <= 5)
    hist_total = len([row for row in hist_dos if isinstance(row, dict)])
    if hist_total:
        t2 += (hist_top5 / hist_total) * 8
    chrono = _num(_raw(partant, 'chrono_1km'))
    ratio = _num(_raw(partant, 'ratio_final'))
    t3 = 8 if chrono is not None and chrono < 62 else 4 if chrono is not None and chrono < 65 else 0
    if ratio is not None and 'MENEUR' in style and ratio > 1.05:
        t3 += 3
    if ratio is not None and 'ATTENT' in style and ratio < .95:
        t3 += 8
    hist_montee = _raw(partant, 'hist_montee_rangs', _raw(partant, 'historique_montee', [])) or []
    hist_montee = [_num(x) for x in hist_montee]
    hist_montee = [x for x in hist_montee if x is not None]
    if hist_montee and 'MENEUR' in style and mean(hist_montee) <= 3:
        t3 += 10
    if hist_montee and 'ATTENT' in style and mean(hist_montee) >= 8:
        t3 += 8
    t4 = -10 if _raw(partant, 'changement_driver') else 0
    t4 += -5 if _raw(partant, 'changement_entraineur') else 0
    t4 += -8 if _raw(partant, 'changement_attelage') else 0
    t4 += -3 if _raw(partant, 'changement_ferrure') else 0
    t5 = -6 if course.hippodrome.upper() == 'VINCENNES' and str(course.piste).upper() == 'GRANDE_PISTE' and numero == 9 and bool(_raw(partant, 'premiere_ligne', _raw(partant, 'position_montee', '') == '1ERE_LIGNE')) else 0
    hippo = course.hippodrome.upper()
    lignes = {'VINCENNES': 9, 'ENGHIEN': 8, 'CAGNES-SUR-MER': 8, 'CAEN': 7, 'CABOURG': 7, 'GRAIGNES': 7}
    t6_base = -4 if numero > lignes.get(hippo, 8) and hippo in {'CAEN', 'CABOURG', 'GRAIGNES'} else 0
    rah279 = -4 if hippo == 'CABOURG' and numero >= 8 else 0
    t6 = t6_base + rah279
    raw_score = t1 + wagon_penalty + t2 + t3 + t4 + t5 + t6
    if str(getattr(course, 'type_depart', '')).upper().endswith('VOLTE'):
        raw_score *= .8
    result.score = _clamp(-50, 50, raw_score)
    result.details = {'status': 'CALCULATED', 'T1': t1, 'T2': t2, 'T3': t3, 'T4': t4, 'T5': t5, 'T6': t6, 'TACT06_base': t6_base, 'RAH101': {'status': 'CALCULATED', 'hippodrome': hippo, 'lignes': lignes.get(hippo, 8), 'applied': bool(t6_base)}, 'RAH279': rah279, 'tact_score': result.score}
    if rah279:
        result.flags.append('GRU_CABOURG_SECONDE_LIGNE')
    return result


def module_poids_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='MODULE_POIDS', actif=False)
    if course.discipline != Discipline.PLAT or not course.est_handicap:
        return result
    result.actif = True
    poids = _num(_raw(partant, 'poids_actuel_kg', partant.poids))
    poids_moy = _num(_raw(partant, 'poids_moyen_champ'))
    valeur = _num(_raw(partant, 'valeur_pmu', _raw(partant, 'valeur_pmu_alternative')))
    valeur_prev = _num(_raw(partant, 'valeur_precedente'))
    poids_prev = _num(_raw(partant, 'poids_precedent_kg'))
    poids_min = _num(_raw(partant, 'poids_min_champ'))
    poids_max = _num(_raw(partant, 'poids_max_champ'))
    if poids is None:
        return _nc(result, 'POIDS_MANQUANT', 'Poids actuel absent')
    c1 = 10 if 52 <= poids <= 56 else 5 if poids <= 58 else -8 if poids > 59 else 3
    c2 = 0 if poids_moy is None else 12 if poids - poids_moy < -4 else 6 if poids - poids_moy < -2 else -10 if poids - poids_moy > 4 else -5 if poids - poids_moy > 2 else 0
    c3 = 0
    if valeur is not None and valeur_prev is not None and poids_prev is not None:
        dv, dp = valeur - valeur_prev, poids - poids_prev
        c3 = 15 if dv > 0 and dp <= 1 else -3 if dv > 0 and dp > 3 else 8 if dv < 0 and dp < -1 else -5 if dv < 0 and dp > 0 else 0
    c4 = 8 if poids_max is not None and poids_min is not None and poids_max - poids_min > 8 and poids <= poids_min + 2 else 0
    c5 = 0
    hippo = course.hippodrome.upper()
    surface = str(_raw(partant, 'surface', getattr(course, 'piste', '')) or '').upper()
    open_stretch_applicable = hippo == 'LONGCHAMP' or (hippo == 'CHANTILLY' and surface == 'PSF')
    open_stretch_conditions = poids_moy is not None and valeur is not None and poids >= poids_moy + 2 and valeur >= (sum(_num(_raw(p, 'valeur_pmu', _raw(p, 'valeur_pmu_alternative'))) for p in course.partants if _num(_raw(p, 'valeur_pmu', _raw(p, 'valeur_pmu_alternative'))) is not None) / max(1, len([p for p in course.partants if _num(_raw(p, 'valeur_pmu', _raw(p, 'valeur_pmu_alternative'))) is not None])) + 3)
    if open_stretch_applicable and bool(_raw(partant, 'open_stretch')) and open_stretch_conditions:
        c5 = 2
    score = c1 + c2 + c3 + c4 + c5
    plat01_applied = bool(course.est_handicap) and course.distance < 1400 and poids <= 53
    if plat01_applied:
        score *= 1.30
    rah104_applied = hippo == 'CHANTILLY' and course.distance >= 2000 and bool(course.est_handicap) and poids_moy is not None and poids >= poids_moy + 2
    if rah104_applied:
        score *= 1.5
    cap = 25 if course.distance < 1600 else 20 if course.distance < 2000 else 15 if course.distance < 2400 else 10
    result.score = _clamp(-20, cap, score)
    result.details = {'status': 'CALCULATED', 'C1': c1, 'C2': c2, 'C3': c3, 'C4': c4, 'C5_RAH103_OPEN_STRETCH': c5, 'plat01': {'status': 'APPLIED' if plat01_applied else 'NOT_TRIGGERED', 'factor': 1.30 if plat01_applied else 1.0, 'conditions': {'handicap': bool(course.est_handicap), 'distance_lt_1400': course.distance < 1400, 'poids_le_53': poids <= 53}}, 'rah103': {'status': 'APPLIED' if c5 == 2 else 'NOT_TRIGGERED', 'open_stretch_applicable': open_stretch_applicable, 'conditions': open_stretch_conditions, 'bonus': c5}, 'rah104': {'status': 'APPLIED' if rah104_applied else 'NOT_TRIGGERED', 'factor': 1.5 if rah104_applied else 1.0, 'conditions': {'chantilly': hippo == 'CHANTILLY', 'distance_ge_2000': course.distance >= 2000, 'handicap': bool(course.est_handicap), 'top_weight': poids_moy is not None and poids >= poids_moy + 2}}, 'cap_final': cap}
    if cap < 25:
        result.flags.append('POIDS_DEGRESSIVITE_FOND')
    return result


def module_recul_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='MODULE_RECUL', actif=False)
    if course.discipline not in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE) or not course.est_handicap:
        return result
    result.actif = True
    recul = _num(_raw(partant, 'recul_m'))
    rk_cheval = _num(_raw(partant, 'rk_sec'))
    rk_median = _num(_raw(partant, 'rk_champ_median_sec'))
    if recul is None:
        return _nc(result, 'RECUL_MANQUANT', 'Recul absent')
    c1 = {0: 15, 25: 5, 50: -5, 75: -15}.get(int(recul), 0)
    c2 = 0
    if rk_cheval is not None and rk_median is not None and recul > 0:
        superiority = rk_median - rk_cheval
        c2 = _clamp(0, 12, superiority * 25 / recul) if superiority > 0 else _clamp(-8, 0, superiority * 5)
    hist = _raw(partant, 'reculs_historiques', []) or []
    ranks = [x[1] for x in hist if isinstance(x, (list, tuple)) and len(x) > 1 and abs(float(x[0]) - recul) <= 12]
    c3 = 8 if ranks and mean(ranks) <= 3 else 4 if ranks and mean(ranks) <= 5 else -8 if ranks and mean(ranks) >= 7 else 0
    coeffs = {'VINCENNES': .8, 'ENGHIEN': .8, 'MARSEILLE-BORÉLY': .8, 'BORDEAUX': .8, 'LYON-PARILLY': .8, 'CAEN': 1.3, 'CABOURG': 1.3, 'GRAIGNES': 1.3}
    coeff = coeffs.get(course.hippodrome.upper(), 1.0)
    raw_course = getattr(course, 'raw_data', {}) or {}
    multi_echelons = bool(raw_course.get('echelons_multiples') or raw_course.get('nb_echelons', 1) and float(raw_course.get('nb_echelons', 1)) >= 2)
    tangent = bool(_raw(partant, 'tangent_premier_echelon')) and multi_echelons and recul == 0
    rah174_bonus = 8.0 if tangent else 0.0
    rah129_position = str(_raw(partant, 'position_echelon', _raw(partant, 'echelon_position', '')) or '').upper().replace('-', '_')
    cote_partant = _num(getattr(partant, 'cote', None))
    rah129_bonus = 0.0
    if (rah129_position in {'TANGENT_POSITIF', 'PREMIER_TANGENT', 'PREMIER_SANS_RECUL'} or tangent) and recul == 0:
        rah129_bonus = 2.0 if cote_partant is not None and cote_partant < 4 else 5.0
    elif rah129_position in {'MOINS_RICHE_2E', 'DEUXIEME_MOINS_RICHE', '2E_MOINS_RICHE'} or recul == 25:
        rah129_bonus = -6.0
    elif rah129_position in {'MOINS_RICHE_3E', 'TROISIEME_MOINS_RICHE', '3E_MOINS_RICHE'} or recul == 50:
        rah129_bonus = -10.0
    base_score = _clamp(-20, 20, c1 + c2 + c3 + rah174_bonus + rah129_bonus) * coeff
    recul_factor_rah129 = .70 if recul == 50 else 1.0
    rah138_angers = course.hippodrome.upper() == 'ANGERS' and recul == 50
    recul_factor = .65 if rah138_angers else recul_factor_rah129
    result.score = base_score * recul_factor
    result.details = {'status': 'CALCULATED', 'C1': c1, 'C2': c2, 'C3': c3, 'coefficient_geometrique': coeff, 'rah100': {'status': 'CALCULATED', 'coefficient_source_unique': True, 'coefficient': coeff}, 'rah174': {'status': 'APPLIED' if tangent else 'NOT_TRIGGERED', 'bonus': rah174_bonus, 'multi_echelons': multi_echelons, 'tangent_premier_echelon': bool(_raw(partant, 'tangent_premier_echelon')), 'anti_double_count_module_recul': True}, 'rah129': {'status': 'APPLIED' if rah129_bonus else 'NOT_TRIGGERED', 'position_echelon': rah129_position or None, 'bonus_malus': rah129_bonus, 'recul_50m_factor': recul_factor_rah129, 'cote': cote_partant}, 'rah138': {'status': 'APPLIED' if rah138_angers else 'NOT_TRIGGERED', 'angers': course.hippodrome.upper() == 'ANGERS', 'recul_50m_factor': .65 if rah138_angers else None}}
    return result


def _records(value):
    """Normalise une historique hétérogène sans fabriquer de lignes."""
    if isinstance(value, dict):
        return list(value.values())
    return value if isinstance(value, list) else []


def _discipline_module(name: str, active: bool) -> ModuleResult:
    return ModuleResult(nom=name, actif=active)


def _record_value(row, *keys):
    if isinstance(row, dict):
        for key in keys:
            if key in row and row[key] not in (None, '', 'NC', 'UNPROVEN'):
                return row[key]
    return None


def module_plat01_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('PLAT-01', course.discipline == Discipline.PLAT)
    if not result.actif:
        return result
    poids = _num(_raw(partant, 'poids_actuel_kg', partant.poids))
    distance = _num(course.distance)
    conditions = poids is not None and distance is not None and poids <= 53 and distance < 1400
    if poids is None or distance is None:
        return _nc(result, 'PLAT01_DATA_NC', 'Poids ou distance absent')
    if not conditions:
        result.details = {'status': 'CALCULATED', 'conditions': False, 'bonus_pch': 0.0, 'module_poids_factor': 1.0}
        return result
    if course.est_handicap:
        # L’effet multiplicatif est appliqué dans MODULE_POIDS; ce module expose la preuve sans double comptage.
        result.details = {'status': 'CALCULATED', 'conditions': True, 'bonus_pch': 0.0, 'module_poids_factor': 1.30, 'effect_delegated_to': 'MODULE_POIDS'}
    else:
        result.score = 6.0
        result.details = {'status': 'CALCULATED', 'conditions': True, 'bonus_pch': 6.0, 'module_poids_factor': 1.0}
    return result


def module_plat02_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('PLAT-02', course.discipline == Discipline.PLAT)
    if not result.actif:
        return result
    hist = _records(_raw(partant, 'historique_distances_perf', []))
    rows = []
    for row in hist:
        if isinstance(row, (list, tuple)) and len(row) >= 2:
            distance, rank = row[0], row[1]
        else:
            distance, rank = _record_value(row, 'distance', 'distance_m'), _record_value(row, 'rang', 'rank', 'place')
        d, r = _num(distance), _num(rank)
        if d is not None and r is not None and d >= 2400:
            rows.append({'distance': d, 'rang': r})
    top3 = [row for row in rows if row['rang'] <= 3]
    result.score = 10.0 if len(top3) >= 2 else 0.0
    result.details = {'status': 'CALCULATED' if hist else 'NC', 'top3_fond': len(top3), 'conditions': len(top3) >= 2, 'threshold': 2}
    if not hist:
        result.flags.append('PLAT02_DATA_NC')
    return result


def module_plat03_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('PLAT-03', course.discipline == Discipline.PLAT)
    if not result.actif:
        return result
    corde = _num(_raw(partant, 'numero_corde', _raw(partant, 'corde')))
    field_size = _num(_raw(partant, 'nb_partants_4_dernieres', course.nb_partants))
    hist = _records(_raw(partant, 'historique_corde_perf', _raw(partant, 'historique_parcours_exact', [])))
    outer_top5 = False
    for row in hist:
        if isinstance(row, dict):
            c, r = _num(_record_value(row, 'corde', 'numero_corde')), _num(_record_value(row, 'rang', 'rank', 'place'))
            outer = row.get('corde_exterieure', c is not None and c >= 14)
            outer_top5 = outer_top5 or bool(outer) and r is not None and r <= 5
    if corde is None or field_size is None:
        return _nc(result, 'PLAT03_DATA_NC', 'Corde ou taille du champ absente')
    active = corde >= 14 and field_size >= 16 and outer_top5
    result.score = 8.0 if active else 0.0
    result.details = {'status': 'CALCULATED' if hist else 'UNPROVEN', 'numero_corde': corde, 'nb_partants': field_size, 'historique_top5_corde_exterieure': outer_top5, 'conditions': active}
    if not hist:
        result.flags.append('PLAT03_HISTORY_UNPROVEN')
    return result


def module_plat04_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('PLAT-04', course.discipline == Discipline.PLAT)
    if not result.actif:
        return result
    hist = _records(_raw(partant, 'position_mi_course_historique', _raw(partant, 'positions_mi_course_5', [])))
    qualifying = 0
    observed = 0
    for row in hist[-5:]:
        if isinstance(row, (list, tuple)) and len(row) >= 2:
            mid, final = row[0], row[1]
        else:
            mid, final = _record_value(row, 'position_mi_course', 'mi_course', 'mid_position'), _record_value(row, 'rang_final', 'rang', 'rank', 'place')
        mid, final = _num(mid), _num(final)
        if mid is not None and final is not None:
            observed += 1
            qualifying += int(mid > 8 and final <= 3)
    result.score = 10.0 if qualifying >= 2 else 0.0
    result.details = {'status': 'CALCULATED' if observed else 'NC', 'observed_last5': observed, 'qualifying_finisher': qualifying, 'conditions': qualifying >= 2}
    if not observed:
        result.flags.append('PLAT04_DATA_NC')
    return result


def module_trot01_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('TROT-01', course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE))
    if not result.actif:
        return result
    rk_values = [_num(x) for x in _records(_raw(partant, 'rk_array', _raw(partant, 'rk_historique', [])))[-5:]]
    rk_values = [x for x in rk_values if x is not None]
    current = _num(getattr(partant, 'rk_brute', None), _num(_raw(partant, 'rk_brute')))
    stable = len(rk_values) >= 5 and max(rk_values) - min(rk_values) <= 1.0
    in_top3 = current is not None and current <= 3
    result.score = 8.0 if stable and in_top3 else 0.0
    result.details = {'status': 'CALCULATED' if rk_values and current is not None else 'NC', 'rk_last5': rk_values, 'rk_stable_pm_05': stable, 'rk_current_top3': in_top3, 'conditions': stable and in_top3}
    if not (rk_values and current is not None):
        result.flags.append('TROT01_DATA_NC')
    return result


def module_trot02_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('TROT-02', course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE))
    if not result.actif:
        return result
    hist = [_num(x) if not isinstance(x, dict) else _num(_record_value(x, 'position_mi_course', 'mi_course', 'mid_position')) for x in _records(_raw(partant, 'positions_mi_course_historique', _raw(partant, 'positions_mi_course_5', [])))[-6:]]
    hist = [x for x in hist if x is not None]
    qualifying = sum(x <= 3 for x in hist)
    active = len(hist) >= 6 and qualifying / 6 >= 0.5
    result.score = 10.0 if active else 0.0
    result.details = {'status': 'CALCULATED' if hist else 'NC', 'positions_last6': hist, 'nb_top3_mi_course': qualifying, 'conditions': active}
    if not hist:
        result.flags.append('TROT02_DATA_NC')
    return result


def module_trot03_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('TROT-03', course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE))
    if not result.actif:
        return result
    depart = str(getattr(getattr(course, 'type_depart', None), 'value', getattr(course, 'type_depart', '')) or _raw(partant, 'type_depart', '')).upper()
    if 'AUTOSTART' in depart:
        result.details = {'status': 'NOT_APPLICABLE', 'reason': 'Départ autostart; TACT couvre ce cas'}
        return result
    hist = _records(_raw(partant, 'historique_depart_volte', _raw(partant, 'volte_top5_historique', [])))
    top5 = 0
    observed = 0
    for row in hist:
        rank = _num(row if not isinstance(row, dict) else _record_value(row, 'rang', 'rank', 'place'))
        if rank is not None:
            observed += 1
            top5 += int(rank <= 5)
    result.score = 8.0 if top5 >= 4 else 0.0
    result.details = {'status': 'CALCULATED' if observed else 'NC', 'top5_depart_volte': top5, 'courses_observees': observed, 'conditions': top5 >= 4}
    if not observed:
        result.flags.append('TROT03_DATA_NC')
    return result


def module_trot04_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('TROT-04', course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE))
    if not result.actif:
        return result
    depart = str(getattr(getattr(course, 'type_depart', None), 'value', getattr(course, 'type_depart', '')) or _raw(partant, 'type_depart', '')).upper()
    numero = _num(_raw(partant, 'numero_autostart', _raw(partant, 'numero')))
    autorise = _raw(partant, 'gru_bonus_corde_specifique', _raw(partant, 'gru_bonus_corde_autostart'))
    if 'AUTOSTART' not in depart or numero is None:
        return _nc(result, 'TROT04_DATA_NC', 'Type de départ ou numéro autostart absent')
    if autorise is None:
        return _nc(result, 'TROT04_GRU_UNPROVEN', 'Autorisation GRU de la corde intérieure absente')
    active = numero <= 3 and autorise is True
    result.score = 5.0 if active else 0.0
    result.details = {'status': 'CALCULATED', 'numero_autostart': numero, 'gru_bonus_corde_specifique': bool(autorise), 'conditions': active}
    return result


def module_obs01_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('OBS-01', course.discipline in (Discipline.OBSTACLE, Discipline.HAIES))
    if not result.actif:
        return result
    hist = _records(_raw(partant, 'historique_obstacle', []))
    nb = _num(_raw(partant, 'nb_courses_obstacle'))
    if nb is None and hist:
        nb = float(len(hist))
    chutes = _num(_raw(partant, 'nb_chutes_obstacle', _raw(partant, 'chutes_obstacle')))
    if nb is None or chutes is None:
        return _nc(result, 'OBS01_DATA_NC', 'Courses obstacle ou chutes absentes')
    result.score = 10.0 if nb >= 8 and chutes == 0 else 6.0 if nb >= 5 and chutes == 0 else 0.0
    result.details = {'status': 'CALCULATED', 'nb_courses_obstacle': nb, 'nb_chutes_obstacle': chutes, 'strict': nb >= 8 and chutes == 0, 'degrade': 5 <= nb < 8 and chutes == 0}
    return result


def module_obs02_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('OBS-02', course.discipline in (Discipline.OBSTACLE, Discipline.HAIES))
    if not result.actif:
        return result
    current_type = str(_raw(partant, 'type_obstacle_course', _raw(partant, 'type_obstacle', _raw(partant, 'type_course_obstacle', '')))).upper()
    hist = _records(_raw(partant, 'historique_obstacle', []))
    top5 = sum(1 for row in hist if isinstance(row, dict) and str(_record_value(row, 'type_obstacle', 'type', 'discipline_obstacle') or '').upper() == current_type and (_num(_record_value(row, 'rang', 'rank', 'place')) or 99) <= 5)
    if not current_type or not hist:
        return _nc(result, 'OBS02_DATA_NC', 'Type d’obstacle ou historique absent')
    result.score = 10.0 if top5 >= 3 else 0.0
    result.details = {'status': 'CALCULATED', 'type_obstacle': current_type, 'top5_meme_type': top5, 'conditions': top5 >= 3}
    return result


def module_obs03_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('OBS-03', course.discipline in (Discipline.OBSTACLE, Discipline.HAIES))
    if not result.actif:
        return result
    hist = _records(_raw(partant, 'historique_obstacle', []))[-5:]
    if not hist:
        return _nc(result, 'OBS03_DATA_NC', 'Historique des fautes obstacle absent')
    faults = []
    for row in hist:
        if isinstance(row, dict):
            value = _record_value(row, 'faute', 'fautes', 'faults', 'nb_fautes')
        else:
            value = None
        if value not in (None, '', 'NC', 'UNPROVEN'):
            faults.append(value)
    if len(faults) < len(hist):
        return _nc(result, 'OBS03_DATA_UNPROVEN', 'Fautes non documentées sur toutes les cinq dernières courses')
    numeric = [_num(x) for x in faults]
    minor = sum(1 for x in faults if str(x).upper() in {'MINEURE', 'TOUCHE', '1'})
    if all(x is not None for x in numeric):
        total_faults = sum(x for x in numeric)
        minor = int(total_faults == 1)
    result.score = 8.0 if minor == 0 and sum(x or 0 for x in numeric) == 0 else 4.0 if minor == 1 else 0.0
    result.details = {'status': 'CALCULATED', 'fautes_5_dernieres': faults, 'zero_faute': result.score == 8.0, 'une_faute_mineure': result.score == 4.0}
    return result


def module_obs04_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('OBS-04', course.discipline in (Discipline.OBSTACLE, Discipline.HAIES))
    if not result.actif:
        return result
    recent = _raw(partant, 'chute_derniere_course_obstacle')
    if recent is None:
        hist = _records(_raw(partant, 'historique_obstacle', []))
        recent = _record_value(hist[-1], 'chute', 'chute_obstacle') if hist else None
    if recent is None:
        return _nc(result, 'OBS04_DATA_NC', 'Résultat de la dernière course obstacle absent')
    result.score = -15.0 if bool(recent) else 0.0
    result.details = {'status': 'CALCULATED', 'chute_derniere_course_obstacle': bool(recent), 'malus': result.score, 'cumulable_m13': True}
    return result


def module_obs05_normative(partant: Partant, course: Course) -> ModuleResult:
    result = _discipline_module('OBS-05', course.discipline in (Discipline.OBSTACLE, Discipline.HAIES))
    if not result.actif:
        return result
    distance = _num(course.distance)
    hist = _records(_raw(partant, 'historique_obstacle', []))
    if distance is None or not hist:
        return _nc(result, 'OBS05_DATA_NC', 'Distance ou historique obstacle absent')
    top3 = 0
    for row in hist:
        d = _num(_record_value(row, 'distance', 'distance_m'))
        r = _num(_record_value(row, 'rang', 'rank', 'place'))
        if d is not None and r is not None and abs(d - distance) <= 300 and r <= 3:
            top3 += 1
    result.score = 8.0 if top3 >= 2 else 0.0
    result.details = {'status': 'CALCULATED', 'top3_distance_±300m': top3, 'distance_course': distance, 'conditions': top3 >= 2}
    return result


def module_terrain_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='MODULE_TERRAIN_DYN', actif=True)
    penetro = _num(getattr(course, 'penetrometre', None), _num(_raw(partant, 'penetrometre_actuel')))
    hist = _raw(partant, 'historique_terrain_perf', []) or []
    if penetro is None and not hist:
        return _nc(result, 'PENETROMETRE_MANQUANT', 'Pénétromètre ou historique terrain absent')
    perfs = [float(r) for p, r in hist if abs(float(p) - penetro) < 1.0] if penetro is not None else []
    c1 = 15 if perfs and mean(perfs) <= 2 else 8 if perfs and mean(perfs) <= 4 else 2 if perfs and mean(perfs) <= 6 else -12 if perfs and mean(perfs) >= 8 else 0
    style = str(_raw(partant, 'style_mpa', '')).upper()
    terrain = str(course.terrain or '').upper()
    c2 = 0
    if terrain in {'LOURD', 'TRÈS_LOURD', 'TRES_LOURD'}:
        c2 = 8 if course.distance >= 2000 and 'ATTENT' in style else -6 if course.distance < 1600 and 'MENEUR' in style else -3 if 'MENEUR' in style else 0
    elif terrain in {'LÉGER', 'TRES_LEGER', 'TRÈS_LÉGER'}:
        c2 = 8 if course.distance < 1600 and 'MENEUR' in style else -4 if 'ATTENT' in style and course.distance < 1400 else 0
    corde = _num(_raw(partant, 'numero_corde'))
    c3 = -5 if terrain in {'LOURD', 'TRÈS_LOURD', 'TRES_LOURD'} and corde is not None and corde <= 4 else 3 if terrain in {'LÉGER', 'TRES_LEGER', 'TRÈS_LÉGER'} and corde is not None and corde <= 4 else 0
    m03 = next((_num(getattr(signal, 'valeur', None)) for signal in getattr(partant, 'signaux', []) if str(getattr(signal, 'code', '')).upper() == 'M03' and getattr(signal, 'actif', False)), None)
    b17 = next((_num(getattr(signal, 'valeur', None)) for signal in getattr(partant, 'signaux', []) if str(getattr(signal, 'code', '')).upper() == 'B17' and getattr(signal, 'actif', False)), None)
    rah105_applied = course.hippodrome.upper() == 'SAINT-CLOUD' and penetro is not None and penetro >= 4.0 and m03 is not None
    rah106_applied = course.hippodrome.upper() == 'SAINT-CLOUD' and penetro is not None and penetro >= 4.0 and b17 is not None
    amplification = (m03 * .5 if rah105_applied else 0.0) + (b17 * .2 if rah106_applied else 0.0)
    result.score = _clamp(-15, 15, c1 + c2 + c3 + amplification)
    result.details = {'status': 'CALCULATED', 'C1': c1, 'C2': c2, 'C3': c3, 'perfs_utilisees': len(perfs), 'rah105': {'status': 'APPLIED' if rah105_applied else 'NOT_TRIGGERED', 'factor': 1.5 if rah105_applied else 1.0, 'm03_observe': m03}, 'rah106': {'status': 'APPLIED' if rah106_applied else 'NOT_TRIGGERED', 'factor': 1.2 if rah106_applied else 1.0, 'b17_observe': b17}}
    return result


def module_dist_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='MODULE_DIST_ADAPT', actif=True)
    hist = _raw(partant, 'historique_distances_perf', []) or []
    current = course.distance
    exact = [(d, r) for d, r in hist if abs(float(d) - current) <= 50]
    c1 = 15 if len(exact) >= 3 and mean(r for _, r in exact) <= 2 else 8 if len(exact) >= 3 and mean(r for _, r in exact) <= 4 else -10 if len(exact) >= 3 and mean(r for _, r in exact) >= 7 else 5 if len(exact) == 1 and exact[0][1] <= 3 else -4 if len(exact) == 1 and exact[0][1] >= 7 else 0
    distances = [float(d) for d, _ in hist[-6:]]
    c2 = 0
    if distances:
        delta = current - mean(distances)
        c2 = -12 if abs(delta) > 400 else -6 if abs(delta) > 200 else 3 if abs(delta) <= 100 else 0
    large = [(d, r) for d, r in hist if abs(float(d) - current) <= 200]
    c3 = 0 if exact else 5 if large and mean(r for _, r in large) <= 3 else -5 if large and mean(r for _, r in large) >= 7 else 0
    parcours = _raw(partant, 'historique_parcours_exact', []) or []
    c4 = 0
    c5 = 0
    if len(parcours) >= 2:
        auto = _num(_raw(partant, 'numero_autostart'))
        autos = [_num(x.get('numero_autostart')) for x in parcours if isinstance(x, dict)]
        ranks = [_num(x.get('rang')) for x in parcours if isinstance(x, dict)]
        if auto is not None and autos and auto < min(x for x in autos if x is not None): c4 += 5
        if len(ranks) >= 3 and _num(_raw(partant, 'rang_attendu')) is not None and _num(_raw(partant, 'rang_attendu')) < min(ranks[-3:]): c4 += 4
    if len(parcours) >= 4:
        ranks = [_num(x.get('rang')) for x in parcours if isinstance(x, dict) and _num(x.get('rang')) is not None]
        if len(ranks) >= 4 and ranks[-1] < mean(ranks[-4:-1]): c5 = 5
    if not hist:
        return _nc(result, 'DISTANCE_HISTORIQUE_MANQUANT', 'Historique distance absent')
    result.score = _clamp(-15, 15, c1 + c2 + c3 + c4 + c5)
    result.details = {'status': 'CALCULATED', 'C1': c1, 'C2': c2, 'C3': c3, 'C4': c4, 'C5': c5, 'exact_count': len(exact), 'COMP4_status': 'CALCULATED' if len(parcours) >= 2 else 'UNPROVEN', 'COMP5_status': 'CALCULATED' if len(parcours) >= 4 else 'UNPROVEN', 'COMP4_min_courses': 2, 'COMP5_min_courses': 4}
    return result


def module_mpa_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='MPA_CHAMP', actif=True)
    rythme = str(_raw(partant, 'rythme_projete', '') or '').upper()
    style = str(_raw(partant, 'style_mpa', '') or '').upper()
    if not rythme or not style:
        return _nc(result, 'MPA_DATA_NC', 'Style MPA ou rythme projeté absent')
    matrix = {
        'MENEUR_FORT': {'LENT': 15, 'CONTRÔLÉ': 10, 'MODÉRÉ': 0, 'RAPIDE': -12, 'TRÈS_RAPIDE': -18},
        'MENEUR_MODÉRÉ': {'LENT': 12, 'CONTRÔLÉ': 8, 'MODÉRÉ': 3, 'RAPIDE': -7, 'TRÈS_RAPIDE': -11},
        'ATTENTISTE': {'LENT': -10, 'CONTRÔLÉ': -3, 'MODÉRÉ': 5, 'RAPIDE': 10, 'TRÈS_RAPIDE': 18},
        'CHASSEUR': {'LENT': 2, 'CONTRÔLÉ': 4, 'MODÉRÉ': 3, 'RAPIDE': 8, 'TRÈS_RAPIDE': 15},
        'POLYVALENT': {'LENT': 3, 'CONTRÔLÉ': 3, 'MODÉRÉ': 3, 'RAPIDE': 4, 'TRÈS_RAPIDE': 5},
    }
    key = 'MENEUR_FORT' if style == 'MENEUR_FORT' else 'MENEUR_MODÉRÉ' if style.startswith('MENEUR') else style
    compat = matrix.get(key, {}).get(rythme)
    if compat is None:
        return _nc(result, 'MPA_STYLE_RYTHME_NC', 'Style ou rythme non présent dans la matrice')
    position_hist = _raw(partant, 'positions_mi_course_5', _raw(partant, 'position_mi_course_historique'))
    if isinstance(position_hist, (list, tuple)):
        position_count = len([x for x in position_hist[:5] if _num(x) is not None and _num(x) <= 2])
    else:
        position_count = _num(_raw(partant, 'nb_positions_mi_course_top2_5'))
    taux_victoires = _num(_raw(partant, 'taux_victoires', _raw(partant, 'taux_victoires_carriere')))
    nb_courses = _num(_raw(partant, 'nb_courses', _raw(partant, 'courses_total')))
    vrai_cheval_train = key.startswith('MENEUR') and position_count is not None and position_count >= 5 and taux_victoires is not None and taux_victoires > .30 and nb_courses is not None and nb_courses > 5
    jeune_guard = nb_courses is not None and nb_courses <= 5
    rah113_applied = vrai_cheval_train and not jeune_guard and rythme in {'RAPIDE', 'TRES_RAPIDE'} and compat < 0
    compat_effective = compat * .50 if rah113_applied else compat
    impact = .65 if course.distance >= 2400 else .80 if course.distance >= 1800 else .90 if course.distance >= 1400 else 1.0
    result.score = _clamp(-20, 20, compat_effective * impact)
    hippodrome = str(getattr(course, 'hippodrome', '') or '').upper()
    rah72_active = hippodrome == 'COMPIEGNE' and float(course.distance or 0) >= 1800 and key.startswith('ATTENTISTE')
    if rah72_active:
        result.score = _clamp(-20, 20, result.score + 8.0)
        result.flags.append('RAH72_COMPIEGNE_ATTENTISTE')
    result.details = {'status': 'CALCULATED', 'style': key, 'rythme': rythme, 'compat_score': compat, 'compat_score_effective': compat_effective, 'impact_distance': impact, 'rah72': {'status': 'APPLIED' if rah72_active else 'NOT_TRIGGERED', 'bonus_pch': 8.0 if rah72_active else 0.0, 'hippodrome': hippodrome, 'distance': course.distance}, 'rah113': {'status': 'APPLIED' if rah113_applied else 'NOT_TRIGGERED', 'position_mi_course_top2_count': position_count, 'taux_victoires': taux_victoires, 'nb_courses': nb_courses, 'vrai_cheval_train': vrai_cheval_train, 'jeune_guard': jeune_guard}}
    if rah113_applied:
        result.flags.append('RAH113_VRAI_CHEVAL_TRAIN')
    return result


def module_h2h_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='H2H_GRAPH', actif=True)
    avg = _num(_raw(partant, 'h2h_avg'))
    if avg is None:
        scores = [_num(x) for x in (_raw(partant, 'h2h_scores', []) or [])]
        scores = [x for x in scores if x is not None]
        avg = mean(scores) if scores else None
    if avg is None:
        return _nc(result, 'H2H_DATA_NC', 'Confrontations directes absentes')
    result.score = _clamp(-15, 15, avg)
    result.details = {'status': 'CALCULATED', 'h2h_avg': avg, 'h2h_norm': _clamp(-1, 1, avg / 15)}
    return result


def module_overbet_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='OVERBET_DETECTOR', actif=True)
    order_initial = _num(_raw(partant, 'ordre_score_initial'))
    cote_15 = _num(_raw(partant, 'cote_15min', partant.cote))
    if order_initial is None or cote_15 is None or order_initial <= 0 or cote_15 <= 0:
        return _nc(result, 'OVERBET_DEFERRED', 'ORDRE_SCORE initial ou cote 15min absent ; module différé')
    cote_theorique = 1 / (order_initial * .80)
    ecart = (cote_theorique - cote_15) / cote_theorique
    base_score = -12 if ecart >= .15 and order_initial < .50 else 6 if ecart <= -.15 else 0
    sov_v2 = _num(_raw(partant, 'sov_v2'))
    victoires_10 = _num(_raw(partant, 'victoires_10', _raw(partant, 'wins_last_10')))
    top5_10 = _num(_raw(partant, 'top5_10', _raw(partant, 'top5_rate_10')))
    icp_pondere = _num(_raw(partant, 'icp_pondere', _raw(partant, 'icp_global', partant.icp_count)))
    montee_non_confirmee = bool(_raw(partant, 'montee_categorie_non_confirmee'))
    absence_reference = bool(_raw(partant, 'absence_reference_piste'))
    m30_active = bool(_raw(partant, 'm30_paradoxe_favori'))
    media_condition = (icp_pondere is not None and icp_pondere >= 3.0 and order_initial > .50 and (
        (victoires_10 is not None and victoires_10 == 0 and top5_10 is not None and top5_10 >= .60)
        or montee_non_confirmee or absence_reference
    ))
    rah251_applied = bool(media_condition and not m30_active and base_score >= 0)
    if rah251_applied:
        base_score = -6
    icp_global = _num(_raw(partant, 'icp_global', _raw(partant, 'icp_pondere', partant.icp_count)))
    rah294 = base_score < 0 and sov_v2 is not None and sov_v2 > 0 and icp_global is not None and icp_global >= 3 and cote_15 <= 5
    result.score = base_score * .80 if rah294 else base_score
    result.details = {
        'status': 'CALCULATED', 'ordre_score_initial': order_initial, 'cote_theorique': cote_theorique,
        'cote_15min': cote_15, 'ecart': ecart, 'rah294_attenuation': rah294,
        'sov_v2': sov_v2, 'icp_global': icp_global,
        'rah251': {
            'status': 'APPLIED' if rah251_applied else 'INACTIVE' if media_condition and m30_active else 'NOT_TRIGGERED',
            'icp_pondere': icp_pondere, 'ordre_score_gt_050': order_initial > .50,
            'victoires_10': victoires_10, 'top5_10': top5_10,
            'montee_categorie_non_confirmee': montee_non_confirmee,
            'absence_reference_piste': absence_reference,
            'm30_paradoxe_favori': m30_active,
            'non_cumul_m30': m30_active,
        },
    }
    if rah251_applied:
        result.flags.append('RAH251_OVERBET_MEDIA_CLASSE')
    elif media_condition and m30_active:
        result.flags.append('RAH251_NON_CUMUL_M30')
    if result.score < 0: result.flags.append('OVERBET_SURCOTE')
    if rah294: result.flags.append('OVERBET_FAVORI_PRESSE_ATTENUE')
    if result.score > 0: result.flags.append('OVERBET_SOUSCOTE')
    return result


def module_iff_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='IFF_v2', actif=True)
    delay = _num(_raw(partant, 'delai_j'))
    opt_min = _num(_raw(partant, 'iff_opt_min'))
    opt_max = _num(_raw(partant, 'iff_opt_max'))
    courses_30j = _num(_raw(partant, 'nb_courses_30j'))
    seuil = _num(_raw(partant, 'iff_seuil_surmenage'))
    commentaire = str(_raw(partant, 'commentaire_derniere_course', '') or '').lower()
    feu = str(_raw(partant, 'feu_equidia', '') or '').upper()
    icp = _num(_raw(partant, 'icp_pondere'), 0.0)
    if delay is None and not commentaire and not feu and courses_30j is None:
        return _nc(result, 'IFF_DATA_NC', 'Délai, commentaire, surmenage et feu Equidia absents')
    flags = []
    iff_fenetre = 0
    if delay is None:
        flags.append('DELAI_MANQUANT')
    elif opt_min is not None and opt_max is not None:
        if opt_min <= delay <= opt_max:
            iff_fenetre = 8
        elif delay < opt_min:
            iff_fenetre = -5
        elif delay <= opt_max * 1.5:
            iff_fenetre = 3
        elif delay <= opt_max * 2.5:
            iff_fenetre = 0
        else:
            iff_fenetre = -3
    iff_surmenage = 0
    if courses_30j is not None and seuil is not None and courses_30j > seuil:
        iff_surmenage = -8 * (courses_30j - seuil)
    positif_fort = ('mieux que ne l’indique le classement', 'mieux que ne l indique le classement', 'bonne fin de course', 'a fini très fort', 'aurait pu faire mieux', 'aurait pu faire mieux avec de l’espace', 'aurait pu faire mieux avec de l espace')
    positif_leger = ('bloqué', 'bloque', 'sans avoir ses aises', 'gêné', 'gene', 'n’a pas eu le passage', "n'a pas eu le passage", 'a manqué d’espace', 'a manque d espace')
    negatif_leger = ('a longtemps été au galop', 'a longtemps ete au galop', 'a fauté', 'a faute')
    negatif_fort = ("n'a jamais été en course", "n'a jamais ete en course", 'éprouver des difficultés', 'eprouver des difficultes', "n'était pas à l'aise", "n'etait pas a l'aise")
    engagement_fort = ('visé de longue date', 'vise de longue date', 'ciblé depuis plusieurs mois', 'cible depuis plusieurs mois', 'travaille pour cette course', 'préparé spécifiquement', 'prepare specifiquement')
    non_objectif = ('pas un objectif', 'pas la cible', 'course de passage', "n'est pas prêt", "n'est pas au mieux", 'mis là pour l’occuper', "mis la pour l'occuper")
    excuse_externe = ('perdu une ferrure', 'perdu un fer en course', 'pris dans un accident', 'heurté par un autre cheval', 'probleme au depart', "n'a pas pris l'autostart", 'problèmes mécaniques', 'problemes mecaniques')
    comment_raw = 6 if any(x in commentaire for x in positif_fort) else 5 if any(x in commentaire for x in positif_leger) else -6 if any(x in commentaire for x in negatif_leger) else -4 if any(x in commentaire for x in negatif_fort) else 8 if any(x in commentaire for x in engagement_fort) else -8 if any(x in commentaire for x in non_objectif) else 7 if any(x in commentaire for x in excuse_externe) and _num(_raw(partant, 'ee_score')) is not None and _num(_raw(partant, 'ee_score')) >= .65 else 5 if any(x in commentaire for x in excuse_externe) else 0
    high_comment = any(x in commentaire for x in engagement_fort + non_objectif) or (any(x in commentaire for x in excuse_externe) and _num(_raw(partant, 'ee_score')) is not None and _num(_raw(partant, 'ee_score')) >= .65)
    iff_comment = _clamp(-8 if high_comment else -6, 8 if high_comment else 6, comment_raw)
    if not commentaire:
        flags.append('COMMENTAIRE_ABSENT')
    iff_feu = {'VERT': 2, 'ORANGE': -4, 'ROUGE': -8}.get(feu, 0)
    if feu == 'VERT' and iff_comment >= 4:
        iff_feu = 0
        flags.append('FEU_VERT_NON_CUMUL_IFF_COMMENTAIRE')
    if feu == 'ORANGE': flags.append('FEU_ORANGE')
    if feu == 'ROUGE': flags.append('FEU_ROUGE')
    absence_silencieuse = -1 if delay is not None and delay > 60 and courses_30j in (None, 0) and icp < 2 and str(getattr(course.discipline, 'value', course.discipline)).upper() in {'TROT_ATTELE', 'TROT_MONTE', 'PLAT'} else 0
    iff_tendance_brute = _num(_raw(partant, 'iff_tendance_rangs_brute', _raw(partant, 'iff_tendance_component')))
    iff_tendance_effective = iff_tendance_brute
    pente = _num(_raw(partant, 'pente_score'))
    if iff_tendance_brute is not None and pente is not None and pente >= .07 and str(_raw(partant, 'pente_classification', '')) != 'PS_STABLE':
        iff_tendance_effective = iff_tendance_brute * .50
        flags.append('FORME_ATTENUEE_IFF')
    iff_tendance_delta = (iff_tendance_effective - iff_tendance_brute) if iff_tendance_brute is not None else 0.0
    if delay is None:
        score = 0.0
        flags.append('IFF_FALLBACK_DELAI_ABSENT')
    else:
        cap_haut = 18 if commentaire or feu in {'VERT', 'ORANGE', 'ROUGE'} else 15
        score = _clamp(-20, cap_haut, iff_fenetre + iff_surmenage + iff_comment + absence_silencieuse + iff_feu + iff_tendance_delta)
    result.score = score
    result.details = {'status': 'CALCULATED', 'IFF_fenetre': iff_fenetre, 'IFF_surmenage': iff_surmenage, 'IFF_commentaire': iff_comment, 'IFF_commentaire_brut': comment_raw, 'IFF_absence_silencieuse': absence_silencieuse, 'IFF_feu_equidia': iff_feu, 'IFF_cap_haut': 18 if commentaire or feu in {'VERT', 'ORANGE', 'ROUGE'} else 15, 'IFF_tendance_brute': iff_tendance_brute, 'IFF_tendance_effective': iff_tendance_effective, 'RAH152_forme_attenuee': iff_tendance_brute is not None and iff_tendance_effective != iff_tendance_brute, 'flags': flags}
    result.flags.extend(flags)
    return result


def module_nrc_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='NRC', actif=True)
    valeur = _num(_raw(partant, 'valeur_pmu'))
    valeurs = [_num(_raw(p, 'valeur_pmu')) for p in course.partants]
    valeurs = [x for x in valeurs if x is not None]
    if valeur is None or not valeurs:
        return _nc(result, 'VALEUR_MANQUANTE', 'Valeur PMU absente pour le cheval ou le champ')
    delta = valeur - sum(valeurs) / len(valeurs)
    score = 8 if delta > 5 else 4 if delta >= 2 else 0 if delta >= -2 else -4 if delta >= -5 else -8
    result.score = score
    result.details = {'status': 'CALCULATED', 'valeur_pmu': valeur, 'valeur_moy_champ': sum(valeurs) / len(valeurs), 'delta': delta}
    return result


def _bilan_fenetre(raw: Dict[str, Any], key: str, windows: Dict[int, float], baseline: float, cap: tuple[float, float], course_key: str) -> ModuleResult:
    result = ModuleResult(nom=key, actif=True)
    data = raw.get(course_key, {}) or {}
    if not data:
        return _nc(result, f'{key}_DATA_NC', f'Fenêtres {key} absentes')
    score = 0.0
    details = {}
    for days, weight in windows.items():
        item = data.get(str(days), data.get(days, {})) or {}
        races = _num(item.get('races'))
        wins = _num(item.get('wins'))
        if races is None or wins is None:
            continue
        taux = wins / max(races, 1)
        contribution_global = max(0, (taux - baseline) * 100) * weight * 0.60
        taux_hippo = _num(item.get('taux_hippodrome', item.get('taux_ctx_hippodrome')))
        taux_distance = _num(item.get('taux_distance', item.get('taux_ctx_distance')))
        taux_ctx = (taux_hippo + taux_distance) / 2.0 if taux_hippo is not None and taux_distance is not None else None
        contribution_ctx = max(0, (taux_ctx - baseline * .85) * 100) * weight * .40 if taux_ctx is not None else 0.0
        contribution = contribution_global + contribution_ctx
        score += contribution
        details[str(days)] = {'taux': taux, 'contribution_global': contribution_global, 'taux_hippodrome': taux_hippo, 'taux_distance': taux_distance, 'taux_contextuel': taux_ctx, 'contribution_contextuelle': contribution_ctx, 'contribution': contribution}
    if not details:
        return _nc(result, f'{key}_WINDOWS_NC', 'Aucune fenêtre exploitable')
    result.score = _clamp(cap[0], cap[1], score)
    result.details = {'status': 'CALCULATED', 'windows': details, 'baseline': baseline}
    return result


def module_bsh_normative(partant: Partant, course: Course) -> ModuleResult:
    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    windows = {'TROT_ATTELE': {7: 3.5, 14: 2.5, 30: 1.0}, 'TROT_MONTE': {7: 3.5, 14: 2.5, 30: 1.0}, 'PLAT': {14: 3.0, 28: 2.0, 45: 1.0}, 'OBSTACLE': {14: 2.0, 28: 3.0, 45: 1.5}}.get(discipline, {})
    baseline = {'TROT_ATTELE': .14, 'TROT_MONTE': .14, 'PLAT': .12, 'OBSTACLE': .10}.get(discipline, .12)
    result = _bilan_fenetre(partant.raw_data or {}, 'BSH_v3v4', windows, baseline, (-5, 20), 'jockey_windows')
    allocation = _num(getattr(course, 'allocation', None))
    raw = getattr(partant, 'raw_data', {}) or {}
    jockey_rank = _num(raw.get('classement_national_jockey', raw.get('jockey_rang_national')))
    taux_top1_20j = _num(raw.get('taux_top1_20j_jockey', raw.get('taux_victoires_20j_jockey')))
    bsh_v4_applied = allocation is not None and allocation <= 50000.0 and jockey_rank is not None and jockey_rank <= 10 and taux_top1_20j is not None and taux_top1_20j > .20
    bsh_v4_bonus = 6.0 if bsh_v4_applied else 0.0
    if result.details.get('status') == 'CALCULATED':
        result.score = _clamp(-5, 20, float(result.score or 0.0) + bsh_v4_bonus)
        result.details['bsh_v4_bonus'] = bsh_v4_bonus
        result.details['impact_pch'] = result.score
    result.details.setdefault('rah75', {})
    result.details['rah75'] = {'status': 'APPLIED' if bsh_v4_applied else 'CALCULATED' if allocation is not None else 'UNPROVEN', 'allocation_course': allocation, 'top10_applicable': None if allocation is None else allocation <= 50000.0, 'classement_national_jockey': jockey_rank, 'taux_top1_20j_jockey': taux_top1_20j, 'bonus': bsh_v4_bonus, 'threshold': 50000.0, 'rule': 'allocation_course<=50k ET jockey Top10 ET taux_top1_20j>20%'}
    return result


def module_bsc_normative(partant: Partant, course: Course) -> ModuleResult:
    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    windows = {'TROT_ATTELE': {15: 3.0, 30: 1.5}, 'TROT_MONTE': {15: 3.0, 30: 1.5}, 'PLAT': {15: 3.0, 30: 2.0, 60: .5}, 'OBSTACLE': {15: 2.0, 30: 3.0, 60: 1.5}}.get(discipline, {})
    baseline = {'TROT_ATTELE': .12, 'TROT_MONTE': .12, 'PLAT': .10, 'OBSTACLE': .08}.get(discipline, .10)
    result = _bilan_fenetre(partant.raw_data or {}, 'BSC_v3', windows, baseline, (-3, 15), 'trainer_windows')
    if result.details.get('status') == 'CALCULATED':
        for detail in result.details.get('windows', {}).values():
            detail['formula'] = 'max(0,(taux-baseline)*100)*poids*0.60'
    return result


def module_cre_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='CRE_v2', actif=True)
    chrono = _num(_raw(partant, 'chrono_200m'))
    terrain_coeff = {'TRÈS_LÉGER': 1.08, 'TRES_LEGER': 1.08, 'LÉGER': 1.04, 'STANDARD': 1.0, 'LOURD': .95, 'TRÈS_LOURD': .88, 'TRES_LOURD': .88}.get(str(course.terrain or 'STANDARD').upper(), 1.0)
    champ = [_num(_raw(p, 'chrono_200m')) for p in course.partants]
    champ = [x for x in champ if x is not None]
    if chrono is not None and champ:
        superiority = (sum(champ) / len(champ) - chrono) * terrain_coeff
        score = 18 if superiority > .8 else 12 if superiority > .5 else 6 if superiority > .2 else 0 if superiority >= -.2 else -6 if superiority >= -.5 else -12
        result.score = _clamp(-12, 18, score)
        result.details = {'status': 'CALCULATED', 'mode': 'CRE_v2', 'superiority': superiority, 'terrain_coeff': terrain_coeff}
        return result
    rk = _raw(partant, 'rk_array', []) or []
    incidents = _raw(partant, 'rk_incident_flag', []) or []
    if str(getattr(course.discipline, 'value', course.discipline)).upper().startswith('TROT') and len(rk) >= 3:
        usable = [float(x) for x, incident in zip(rk[-3:], incidents[-3:] or [False] * 3) if not incident]
        if len(usable) < 3:
            return _nc(result, 'CRE_PROXY_INCIDENTS_EXCLUS', 'Les trois RK sont associés à des incidents')
        d12, d23 = usable[1] - usable[0], usable[2] - usable[1]
        delta = .40 * d12 + .60 * d23
        coherent = (d12 > 0 and d23 > 0) or (d12 < 0 and d23 < 0)
        score = 14 if delta >= .60 and coherent else 10 if delta >= .40 else 6 if delta >= .20 else 0 if delta >= -.15 else -4 if delta >= -.40 else -10 if coherent else -6
        if not coherent and delta > 0:
            score *= .70
        result.score = _clamp(-12, 18, score)
        result.flags.append('CRE_PROXY_v3')
        result.details = {'status': 'CALCULATED', 'mode': 'CRE_PROXY_v3', 'delta_rk_moyen': delta, 'tendance_coherente': coherent}
        return result
    return _nc(result, 'CRE_DESACTIVE', 'Chronos et proxy RK insuffisants')


def module_forme_lineaire_normative(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='FORME_LINEAIRE', actif=True)
    raw = getattr(partant, 'raw_data', {}) or {}
    rangs = raw.get('rangs_6_dernieres', raw.get('rangs_6', [])) or []
    if not rangs:
        return _nc(result, 'FORME_LINEAIRE_NC', 'Historique des six dernières courses absent')
    points = {1: 3.00, 2: 2.00, 3: 1.00, 4: .75, 5: .60, 6: .45, 7: .30, 8: .15}
    recence = [1.00, .80, .60, .40, .20, .10]
    categories = raw.get('categories_allocations_6', raw.get('categories_courses_6', [])) or []
    cat_coeff = {'GROUPE_LISTED': 1.40, 'QUINTE_CLASSE1': 1.20, 'CLASSE2_3': 1.00, 'RECLAMER_INFERIEURE': .80}
    ee_categories = raw.get('ee_categories_6', []) or []
    macro = str(raw.get('macro_groupe', 'PISCINE_GENERIQUE')).upper()
    macro_coeff = {'SOCLE': .50, 'MOTEUR': .75, 'PISCINE_GENERIQUE': .85, 'DETONATEUR': 1.00}.get(macro, .85)
    total = 0.0
    details = []
    for idx, rang in enumerate(rangs[:6]):
        try:
            rang_i = int(rang)
        except (TypeError, ValueError):
            continue
        base = points.get(rang_i, 0.0)
        cat = str(categories[idx]).upper() if idx < len(categories) else 'RECLAMER_INFERIEURE'
        coeff = cat_coeff.get(cat, 1.0)
        neutralized = False
        if idx < len(ee_categories) and ee_categories[idx] in {'A', 'B', 'C'} and _num(raw.get('ee_scores_6', [None] * len(rangs))[idx] if idx < len(raw.get('ee_scores_6', [])) else None, 0) >= .65:
            base = 1.0 if ee_categories[idx] == 'A' else 0.0
            neutralized = True
        contribution = base * recence[idx] * coeff
        total += contribution
        details.append({'rang': rang_i, 'base': base, 'recence': recence[idx], 'categorie': cat, 'coeff_categorie': coeff, 'neutralized': neutralized, 'contribution': contribution})
    score = min(20.0, total * macro_coeff * 2.0)
    result.score = score
    result.details = {'status': 'CALCULATED', 'forme_brute': total, 'coeff_macro_groupe': macro_coeff, 'forme_lineaire_pch': score, 'courses_utilisees': len(details), 'details': details}
    if len(details) < 6:
        result.flags.append('FORME_LINEAIRE_PARTIELLE')
    if len(details) == 1:
        result.flags.append('FORME_LINEAIRE_INSUFFISANTE')
    result.flags.append('FORME_LINEAIRE_V2')
    return result
