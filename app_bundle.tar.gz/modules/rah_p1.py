"""Règles P1 liées à la classification et à la publication du ticket."""
from __future__ import annotations

from typing import Any, Dict, List

from engine.models import Course, Partant


def _raw(partant: Partant, key: str, default=None):
    return (getattr(partant, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC', 'UNPROVEN') else default
    except (TypeError, ValueError):
        return default


def _ordre_normalise(partant: Partant) -> float | None:
    raw = _num(_raw(partant, 'ordre_score_normalise'))
    if raw is not None:
        return max(0.0, min(1.0, raw))
    value = _num(partant.ordre_score)
    if value is None:
        return None
    return value / 100.0 if value > 1.0 else value


def evaluer_rah96(partant: Partant) -> Dict[str, Any]:
    """RAH-96 : score de proximité de fallback, sans remplacer les catégories actives."""
    ordre = _ordre_normalise(partant)
    actifs = len([s for s in getattr(partant, 'signaux', []) if getattr(s, 'actif', False)])
    familles = len(set(getattr(partant, 'familles_actives', []) or []))
    icp = _num(_raw(partant, 'icp_global', partant.icp_count))
    if ordre is None or icp is None:
        return {'rule': 'RAH-96', 'status': 'UNPROVEN', 'score_proximite': None, 'inputs': {'ordre': ordre, 'nb_signaux': actifs, 'nb_familles': familles, 'icp': icp}}
    score = ordre * .40 + min(1.0, actifs / 2.0) * .30 + min(1.0, familles / 2.0) * .20 + min(1.0, icp / 2.0) * .10
    return {'rule': 'RAH-96', 'status': 'CALCULATED', 'score_proximite': score, 'inputs': {'ordre': ordre, 'nb_signaux': actifs, 'nb_familles': familles, 'icp': icp}, 'fallback_only': True}


def evaluer_rah93(partant: Partant) -> Dict[str, Any]:
    ordre = _ordre_normalise(partant)
    signaux = len([s for s in getattr(partant, 'signaux', []) if getattr(s, 'actif', False)])
    familles = len(set(getattr(partant, 'familles_actives', []) or []))
    icp = _num(_raw(partant, 'icp_global', partant.icp_count))
    style = _raw(partant, 'style_mpa')
    conditions = {'ordre_ge_040': ordre is not None and ordre >= .40, 'signaux_ge_3': signaux >= 3, 'familles_ge_2': familles >= 2, 'icp_ge_2': icp is not None and icp >= 2}
    active = all(conditions.values())
    return {'rule': 'RAH-93', 'status': 'CALCULATED' if ordre is not None and icp is not None else 'UNPROVEN', 'active': active, 'eligible_positions': ['P2', 'P3', 'P4'] if active else [], 'style': style, 'conditions': conditions, 'max_same_style_p1_p4': 2}


def evaluer_rah95(partant: Partant) -> Dict[str, Any]:
    """RAH-95 : conditions TOCARD et positions admissibles."""
    cote = _num(partant.cote)
    tocard = _num(partant.tocard_score, 0.0)
    icp = _num(_raw(partant, 'icp_global', partant.icp_count))
    ordre = _ordre_normalise(partant)
    conditions = {
        'cote_ge_25': cote is not None and cote >= 25,
        'tocard_score_ge_025': tocard is not None and tocard >= .25,
        'icp_le_2_ordre_ge_030': icp is not None and icp <= 2 and ordre is not None and ordre >= .30,
    }
    active = any(conditions.values())
    return {
        'rule': 'RAH-95',
        'status': 'CALCULATED' if cote is not None or ordre is not None else 'UNPROVEN',
        'active': active,
        'eligible_positions': ['P5', 'P6', 'R1', 'R2'] if active else [],
        'conditions': conditions,
        'inputs': {'cote': cote, 'tocard_score': tocard, 'icp_global': icp, 'ordre_score_normalise': ordre},
        'flag': 'TOCARD_ELIGIBLE_RAH95' if active else 'TOCARD_RAH95_NON_ACTIVE',
    }


def evaluer_rah98(ticket: List[Partant], course: Course) -> Dict[str, Any]:
    selected = list(ticket)
    tocards = [p for p in selected if evaluer_rah95(p).get('active')]
    styles = [str(_raw(p, 'style_mpa', '') or '').upper() for p in selected]
    style_counts = {style: styles.count(style) for style in set(styles) if style}
    kill_p1_p3 = [p.numero for p in selected if p.position_ticket in {'P1', 'P2', 'P3'} and any(flag in {'KILL_LIST_M25_EQUIVALENT', 'STAB_DQ_SERIE_CRITIQUE'} for module in getattr(p, 'modules_results', []) for flag in module.flags)]
    size_expected = min(8, len(course.partants))
    constraints = {'size_ok': len(selected) == size_expected, 'at_least_one_tocard': bool(tocards) if size_expected >= 8 else True, 'style_max_3': max(style_counts.values(), default=0) <= 3, 'no_kill_list_p1_p3': not kill_p1_p3}
    return {'rule': 'RAH-98', 'status': 'CALCULATED', 'complement_used': len(selected) > 0, 'constraints': constraints, 'style_counts': style_counts, 'tocard_numbers': [p.numero for p in tocards], 'kill_list_p1_p3': kill_p1_p3, 'publication_allowed': all(constraints.values())}


def verifier_rah36_41(ticket: List[Partant], course: Course) -> Dict[str, Any]:
    """Vérifie la structure 6+2, la prudence P1/P2 et la règle de publication."""
    expected_size = len(course.partants) if len(course.partants) < 8 else 8
    size_ok = len(ticket) == expected_size
    violations = []
    p1_p2 = [p for p in ticket if p.position_ticket in {'P1', 'P2'}]
    for partant in p1_p2:
        cote = _num(partant.cote)
        if cote is not None and cote > 25:
            raw = getattr(partant, 'raw_data', {}) or {}
            exception = bool(raw.get('rah41_exception_documented') or raw.get('rah266_eligible') or raw.get('rah230_alpha_replacement'))
            if not exception:
                violations.append({'numero': partant.numero, 'raison': 'RAH41_COTE_P1_P2_SANS_EXCEPTION', 'cote': cote})
    rah41_ok = not violations
    return {
        'RAH-36': {'status': 'PASS' if size_ok else 'FAIL', 'expected_size': expected_size, 'actual_size': len(ticket), 'structure': '6_TITULAIRES_2_RESERVES' if expected_size == 8 else 'TOUS_PARTANTS_CONFIRME'},
        'RAH-41': {'status': 'PASS' if rah41_ok else 'FAIL', 'violations': violations},
        'RAH-42': {'status': 'PENDING_FINAL_VALIDATION', 'requires': ['RAH-36', 'RAH-41', 'RAH-90', 'RAH-07/168', 'RAH-259', 'RAH-11']},
    }


def evaluer_rah165(course: Course) -> Dict[str, Any]:
    """RAH-165 : GMO-V analytique, sans promesse de simulation non prouvée."""
    observed = []
    missing = []
    branch_counts = []
    residuals = []
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        value = _num(raw.get('p_top5'))
        if value is None:
            missing.append(partant.numero)
        else:
            observed.append(partant.numero)
        branches = raw.get('gmov_branches')
        if isinstance(branches, (list, tuple)):
            branch_counts.append(len(branches))
        residual = _num(raw.get('gmov_mass_residuelle'))
        if residual is not None:
            residuals.append(residual)
    all_probs = len(observed) == len(course.partants) and bool(course.partants)
    branches_ok = not branch_counts or min(branch_counts) >= 3
    residual_ok = not residuals or max(residuals) <= .15
    status = 'CALCULATED' if all_probs and branches_ok and residual_ok else 'UNPROVEN'
    return {
        'rule': 'RAH-165',
        'status': status,
        'mode': 'ANALYTIC',
        'probabilities_observed_for': observed,
        'missing_probability_partants': missing,
        'branch_count_min': min(branch_counts) if branch_counts else None,
        'mass_residuelle_max': max(residuals) if residuals else None,
        'branch_requirement': '>=3 par position; extension à 4 si masse résiduelle >15%',
        'simulation_claim': False,
    }


def finaliser_rah42(audit: Dict[str, Any]) -> Dict[str, Any]:
    required = ('RAH-36', 'RAH-41', 'RAH-90', 'RAH-07/168', 'RAH-259', 'RAH-11')
    statuses = {key: (audit.get(key) or {}).get('status') for key in required}
    ok = all(value == 'PASS' for value in statuses.values())
    return {'rule': 'RAH-42', 'status': 'PASS' if ok else 'FAIL', 'dependencies': statuses, 'publication_allowed': ok}
