"""GMO-V — Pool Élargi, sélection jointe et habillage P1–R2.

Les étiquettes P1–R2 sont appliquées après la sélection et n'influencent pas
le gain marginal. Les données non prouvées ne sont jamais converties en
éligibilité automatique.
"""
from __future__ import annotations

from typing import Any, Dict, List, Tuple

from engine.models import Course, Partant, ProfilADO
from modules.gmov_policy import politique_stab_ticket, position_autorisee
from modules.rah_p1 import evaluer_rah93, evaluer_rah95, evaluer_rah96, evaluer_rah98, verifier_rah36_41, finaliser_rah42, evaluer_rah165


QUOTAS_SIGNATURE = {
    'LOCK': {'T1': (2, 4), 'T2': (1, 2), 'T3': (1, 2), 'T4': (1, 2)},
    'STANDARD': {'T1': (2, 3), 'T2': (1, 2), 'T3': (2, 3), 'T4': (1, 1)},
    'MIXTE_LOCK': {'T1': (2, 3), 'T2': (1, 2), 'T3': (1, 3), 'T4': (1, 2)},
    'CHAOS': {'T1': (1, 2), 'T2': (1, 2), 'T3': (2, 3), 'T4': (1, 2)},
}


def tranche_cote(partant: Partant) -> str:
    cote = partant.cote
    if cote is None or cote <= 0:
        return 'NC'
    if cote < 9:
        return 'T1'
    if cote <= 15:
        return 'T2'
    if cote <= 50:
        return 'T3'
    if cote <= 300:
        return 'T4'
    return 'HORS_CHAMP'


def _raw(partant: Partant, key: str, default=None):
    return (getattr(partant, 'raw_data', {}) or {}).get(key, default)


def _p_top5(partant: Partant) -> Tuple[float, Dict[str, Any]]:
    raw = _raw(partant, 'p_top5')
    if raw is not None:
        try:
            value = max(0.0, min(1.0, float(raw)))
            return value, {'status': 'OBSERVED', 'source': _raw(partant, 'p_top5_source', 'raw_data'), 'proxy': False}
        except (TypeError, ValueError):
            pass
    # Fallback conservé uniquement pour permettre une sélection technique.
    # Il est explicitement marqué comme proxy et interdit la certification
    # pleine du ticket tant qu’aucune P(Top5) n’est observée.
    try:
        raw_order = float(partant.ordre_score)
        normalized = raw_order if 0.0 <= raw_order <= 1.0 else raw_order / 100.0
    except (TypeError, ValueError):
        normalized = 0.0
    return max(0.0, min(1.0, normalized)), {'status': 'PROXY_ORDER_SCORE', 'source': 'ordre_score', 'proxy': True, 'reason': 'P(Top5) absente'}


def calculer_potential_score(partant: Partant, course: Course) -> float:
    """POTENTIAL_SCORE RAH-266/17.10k pour T3/T4."""
    tranche = tranche_cote(partant)
    if tranche not in {'T3', 'T4'}:
        return 0.0
    score_sim = min(1.0, max(0.0, float(_raw(partant, 'score_sim', 0.0) or 0.0) / .70))
    tocard_norm = min(1.0, max(0.0, partant.tocard_score / .35))
    d46 = 1.0 if bool(_raw(partant, 'consensus_outsider')) else 0.0
    d_convergence = 1.0 if len(getattr(partant, 'ghost_details', {}).get('flags', [])) >= 3 else 0.0
    potential = .40 * score_sim + .30 * tocard_norm + .15 * d46 + .15 * d_convergence
    return max(0.0, min(1.0, potential))


def _correlation(partant: Partant, ticket_actuel: List[Partant]) -> float:
    if not ticket_actuel:
        return 0.0
    values = []
    for other in ticket_actuel:
        corr = 0.0
        if _raw(partant, 'style_mpa') and _raw(partant, 'style_mpa') == _raw(other, 'style_mpa'):
            corr = max(corr, .8)
        if partant.ecurie and partant.ecurie == other.ecurie:
            corr = max(corr, .8)
        if set(partant.familles_actives) & set(other.familles_actives):
            corr = max(corr, .5)
        if _raw(partant, 'profil_tactique') and _raw(partant, 'profil_tactique') == _raw(other, 'profil_tactique'):
            corr = max(corr, .7)
        values.append(corr)
    return max(values, default=0.0)


def calculer_gain_hybride(partant: Partant, ticket_actuel: List[Partant], course: Course) -> float:
    """ΔF = .55×couverture jointe + .45×P_boost selon RAH-17.10k."""
    ptop5, ptop5_evidence = _p_top5(partant)
    corr = _correlation(partant, ticket_actuel)
    couverture = ptop5 * (1.0 - corr)
    potential = calculer_potential_score(partant, course)
    pboost = ptop5
    if tranche_cote(partant) in {'T3', 'T4'} and potential >= .40:
        pboost = ptop5 * (1.0 + .30 * potential)
    gain = .55 * couverture + .45 * pboost
    partant.extended_metrics.setdefault('gmov_evidence', {})['p_top5'] = ptop5_evidence
    partant.extended_metrics['gmov_evidence']['coverage'] = {'status': 'HEURISTIC_PROXY', 'formula': 'p_top5*(1-correlation)', 'proxy': True, 'reason': 'P(Top5 subset) jointe non observée'}

    # RAH-259 : intégrer la conformité des tranches dans la boucle, jamais
    # comme correction après sélection.
    signature = course.signature_msp.value if course.signature_msp else 'STANDARD'
    quotas = QUOTAS_SIGNATURE.get(signature, QUOTAS_SIGNATURE['STANDARD'])
    tranche = tranche_cote(partant)
    tranche_count = sum(1 for item in ticket_actuel if tranche_cote(item) == tranche)
    if tranche in quotas and any(tranche_cote(item) == tranche for item in course.partants):
        minimum, maximum = quotas[tranche]
        if tranche_count < minimum:
            gain *= 1.15
        elif tranche_count >= maximum:
            gain *= 0.85

    # IRON_GATE BETA : pénalité marginale pour un score élevé sans deux
    # familles de signaux indépendantes.
    if partant.ordre_score >= 50 and len(getattr(partant, 'familles_actives', []) or []) < 2:
        gain *= 0.85
    return gain


def _t4_eligible(partant: Partant, course: Course) -> Tuple[bool, str]:
    if tranche_cote(partant) != 'T4':
        return True, ''
    signature = course.signature_msp.value if course.signature_msp else 'STANDARD'
    ghost_flags = set(getattr(partant, 'ghost_details', {}).get('flags', []))
    ssfo = float(getattr(partant, 'ssfo_details', {}).get('bonus_ssfo_final', 0.0) or 0.0)
    longshots = getattr(partant, 'longshots_details', {}) or {}
    ls_final = longshots.get('LS_FINAL')
    alpha = bool(longshots.get('rah266_f2_alpha_eligible')) or (longshots.get('gouvernance') == 'F2_ALPHA' and ls_final is not None and float(ls_final) >= .50)
    conditions = [
        signature == 'CHAOS',
        bool(ghost_flags & {'D01', 'D07', 'D12', 'D24', 'D41', 'D43'}),
        alpha,
        partant.tocard_score >= .30,
        ssfo >= 8,
    ]
    reason = {'signature_chaos': conditions[0], 'ghost_fort': conditions[1], 'ls_f2_alpha_ge_050': conditions[2], 'rah266_f2_alpha_eligible': longshots.get('rah266_f2_alpha_eligible', False), 'tocard_ge_030': conditions[3], 'ssfo_ge_8': conditions[4], 'ls_final': ls_final, 'ssfo': ssfo}
    if partant.cote is not None and partant.cote <= 100:
        eligible = any(conditions)
        return eligible, 'RAH-266_T4a:' + str(reason)
    eligible = sum(bool(x) for x in conditions) >= 2 or (ssfo >= 10)
    return eligible, 'RAH-266_T4b:' + str(reason)


def verifier_contraintes_ticket(partant: Partant, ticket_actuel: List[Partant], course: Course) -> Tuple[bool, str]:
    tranche = tranche_cote(partant)
    if tranche in {'NC', 'HORS_CHAMP'}:
        return False, 'CONTRAINTE_TRANCHE: cote absente ou hors champ'
    stab_policy = politique_stab_ticket(partant, course)
    if stab_policy.get('active') and not stab_policy.get('eligible'):
        return False, f"CONTRAINTE_STAB_KILL_LIST: {stab_policy.get('mode', 'EXCLUSION_TICKET')}"
    eligible, reason = _t4_eligible(partant, course)
    if not eligible:
        return False, f'CONTRAINTE_T4: {reason}'
    signature = course.signature_msp.value if course.signature_msp else 'STANDARD'
    quotas = QUOTAS_SIGNATURE.get(signature, QUOTAS_SIGNATURE['STANDARD'])
    if sum(1 for p in ticket_actuel if tranche_cote(p) == tranche) >= quotas[tranche][1]:
        return False, f'CONTRAINTE_TRANCHE: plafond {tranche} atteint'
    if partant.ecurie and sum(1 for p in ticket_actuel if p.ecurie == partant.ecurie) >= 2:
        return False, f'CONTRAINTE_ECURIE: plafond pour {partant.ecurie}'
    icp = _raw(partant, 'icp_global', partant.icp_count)
    try:
        favori_unanime = float(icp or 0) >= 6
    except (TypeError, ValueError):
        favori_unanime = False
    if favori_unanime and sum(1 for p in ticket_actuel if float(_raw(p, 'icp_global', p.icp_count) or 0) >= 6) >= 2:
        return False, 'CONTRAINTE_RAH90: plafond de deux favoris ICP>=6'
    style = _raw(partant, 'style_mpa')
    max_style = 3 if signature == 'CHAOS' else 4
    if style and sum(1 for p in ticket_actuel if _raw(p, 'style_mpa') == style) >= max_style:
        return False, f'CONTRAINTE_STYLE: plafond pour {style}'
    if partant.cote > 30 and sum(1 for p in ticket_actuel if p.cote and p.cote > 30) >= 2:
        return False, 'CONTRAINTE_T4: maximum absolu de deux chevaux >30/1'
    return True, ''


def evaluer_rah167(partant: Partant, ticket: List[Partant]) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    matrix = raw.get('harville_correlation_matrix')
    if not isinstance(matrix, dict):
        return {'status': 'UNPROVEN', 'reason': 'Matrice Harville sourcée absente', 'proxy_fallback_interdit': True}
    correlations = []
    for other in ticket:
        if other.numero == partant.numero:
            continue
        value = matrix.get(str(other.numero), matrix.get(other.numero))
        try:
            correlations.append({'numero': other.numero, 'correlation': max(0.0, min(1.0, float(value)))})
        except (TypeError, ValueError):
            return {'status': 'UNPROVEN', 'reason': 'Corrélation Harville non numérique', 'proxy_fallback_interdit': True}
    return {'status': 'CALCULATED', 'correlations': correlations, 'mean_correlation': sum(x['correlation'] for x in correlations) / len(correlations) if correlations else 0.0, 'proxy_fallback_interdit': True}


def construire_pool_elargi(course: Course) -> Tuple[List[Partant], Dict[str, Any]]:
    pool = []
    details = []
    fallback_admission_numbers = []
    for partant in sorted(course.partants, key=lambda p: p.ordre_score, reverse=True):
        order_norm = max(0.0, min(1.0, partant.ordre_score / 100.0))
        ssfo = float(getattr(partant, 'ssfo_details', {}).get('bonus_ssfo_final', 0.0) or 0.0)
        p5p6_value = _raw(partant, 'p5p6', {}).get('p5p6_score') if isinstance(_raw(partant, 'p5p6', {}), dict) else None
        p5p6_value = float(p5p6_value) if p5p6_value not in (None, '', 'NC', 'UNPROVEN') else None
        criteria = {
            'ordre_score': order_norm >= .25,
            'tocard_score': partant.tocard_score >= .20,
            'p5p6_score': p5p6_value is not None and p5p6_value >= .30,
            'ssfo': ssfo >= 5,
            'supra_omission': bool(_raw(partant, 'supra_omission_candidate')),
            'consensus_outsider': bool(_raw(partant, 'consensus_outsider')),
        }
        if any(criteria.values()):
            pool.append(partant)
            details.append({'numero': partant.numero, 'criteria': criteria})
    if len(pool) < min(14, len(course.partants)):
        for partant in sorted(course.partants, key=lambda p: p.ordre_score, reverse=True):
            if partant not in pool:
                pool.append(partant)
                fallback_admission_numbers.append(partant.numero)
            if len(pool) >= min(14, len(course.partants)):
                break
    selected_pool = pool[:14]
    ssfo_missing = [p.numero for p in course.partants if not isinstance(getattr(p, 'ssfo_details', None), dict) or getattr(p, 'ssfo_details', {}).get('status') not in {'CALCULATED', 'ACTIVE'}]
    ssfo_eligible = [p.numero for p in course.partants if isinstance(getattr(p, 'ssfo_details', None), dict) and getattr(p, 'ssfo_details', {}).get('status') in {'CALCULATED', 'ACTIVE'} and float(getattr(p, 'ssfo_details', {}).get('bonus_ssfo_final', 0.0) or 0.0) >= 5]
    return selected_pool, {'pool_size': len(selected_pool), 'candidates': details, 'fallback_admission_numbers': fallback_admission_numbers, 'normative_eligibility_complete': not fallback_admission_numbers, 'rah272': {'status': 'CALCULATED' if not ssfo_missing else 'UNPROVEN', 'ssfo_eligible_numbers': ssfo_eligible, 'ssfo_missing_numbers': ssfo_missing, 'admit_bonus_ge_5': True}}


def _appliquer_rah156(course: Course, ticket: List[Partant], rapport: Dict[str, Any]) -> List[Partant]:
    """RAH-156 : ne pas doubler un TOCARD et un P5P6/R2 dans une plage de cote ±5/1."""
    p5p6 = [p for p in ticket if isinstance(_raw(p, 'p5p6', {}), dict) and (_raw(p, 'p5p6', {}).get('p5p6_score') or 0) >= .40]
    tocards = [p for p in ticket if p.tocard_score >= .20 and p not in p5p6]
    for tocard in tocards:
        if tocard.cote is None:
            continue
        redundant = [p for p in p5p6 if p.cote is not None and abs(float(p.cote) - float(tocard.cote)) <= 5]
        if not redundant:
            continue
        candidates = [p for p in course.partants if p not in ticket and not (p.tocard_score >= .20 and p.cote is not None and abs(float(p.cote) - float(tocard.cote)) <= 5)]
        replacement = max(candidates, key=lambda p: p.ordre_score, default=None)
        if replacement is not None:
            ticket.remove(tocard)
            ticket.append(replacement)
            rapport['contraintes_violees'].append({'numero': tocard.numero, 'raison': 'RAH156_TOCARD_REDONDANT_P5P6', 'remplace_par': replacement.numero})
        else:
            rapport['contraintes_violees'].append({'numero': tocard.numero, 'raison': 'RAH156_SUSPENDUE_AUCUN_REMPLACEMENT'})
    return ticket


def verifier_rah11_ordre_score(course: Course) -> Dict[str, Any]:
    """RAH-11 : aucun ticket ne peut être composé sans ORDRE_SCORE pour tout le champ."""
    numeros = [p.numero for p in course.partants]
    marker = (getattr(course, 'derived_metrics', {}) or {}).get('ordre_score_calculated_for', [])
    marker_set = {int(x) for x in marker if str(x).isdigit()}
    finite = []
    invalid = []
    for partant in course.partants:
        try:
            value = float(partant.ordre_score)
            if value != value or value in (float('inf'), float('-inf')):
                raise ValueError
            finite.append(partant.numero)
        except (TypeError, ValueError):
            invalid.append(partant.numero)
    explicit = set(numeros) == marker_set and bool(numeros)
    inferred = not invalid and len(finite) == len(numeros) and any(float(p.ordre_score) != 0.0 for p in course.partants)
    ok = bool(numeros) and not invalid and (explicit or inferred)
    return {
        'rule': 'RAH-11',
        'status': 'PASS' if ok else 'FAIL',
        'all_partants': len(numeros),
        'ordre_score_calculated': len(finite),
        'invalid_partants': invalid,
        'evidence_mode': 'SCORING_MARKER' if explicit else 'PRECOMPUTED_VALUES' if inferred else 'NONE',
        'calculated_for': sorted(marker_set),
        'raison': '' if ok else 'ORDRE_SCORE absent, invalide ou non calculé pour tout le champ',
    }


def _appliquer_rah230(course: Course, ticket: List[Partant], rapport: Dict[str, Any]) -> List[Partant]:
    """RAH-230 : seul un Longshot Famille 2 ALPHA peut modifier le ticket réel."""
    candidates = []
    for partant in course.partants:
        if partant in ticket:
            continue
        details = getattr(partant, 'longshots_details', {}) or {}
        ls_final = details.get('LS_FINAL')
        governance = details.get('gouvernance')
        try:
            alpha = governance == 'F2_ALPHA' and float(ls_final) >= .60
        except (TypeError, ValueError):
            alpha = False
        if alpha:
            candidates.append(partant)
    candidates.sort(key=lambda p: (float((getattr(p, 'longshots_details', {}) or {}).get('LS_FINAL') or 0.0), p.ordre_score), reverse=True)
    result = {
        'rule': 'RAH-230',
        'status': 'OBSERVATION' if not candidates else 'CANDIDAT_ALPHA',
        'candidate_count': len(candidates),
        'candidates': [{'numero': p.numero, 'nom': p.nom, 'LS_FINAL': (getattr(p, 'longshots_details', {}) or {}).get('LS_FINAL'), 'gouvernance': (getattr(p, 'longshots_details', {}) or {}).get('gouvernance')} for p in candidates],
        'ghost_only_families': ['F1', 'F3', 'F4', 'F5', 'F7', 'F8'],
        'f6_never_real_effect': True,
        'replacement': None,
    }
    if not candidates or not ticket:
        rapport['rah230'] = result
        return ticket
    target = next((p for p in ticket if p.position_ticket == 'R2'), None)
    target = target or next((p for p in ticket if p.position_ticket == 'P6'), None)
    target = target or min(ticket, key=lambda p: p.ordre_score)
    candidate = candidates[0]
    ticket_without = [p for p in ticket if p is not target]
    valid, reason = verifier_contraintes_ticket(candidate, ticket_without, course)
    result['target_priority'] = 'R2_then_P6'
    result['target_numero'] = target.numero
    result['candidate_numero'] = candidate.numero
    result['constraint_check'] = {'valid': valid, 'reason': reason}
    if valid:
        ticket = ticket_without + [candidate]
        result['status'] = 'APPLIED_REAL_REPLACEMENT'
        result['replacement'] = {'removed': target.numero, 'added': candidate.numero, 'reason': 'RAH230_F2_ALPHA_LS_GE_060'}
    else:
        result['status'] = 'ALPHA_BLOCKED_CONSTRAINT'
    rapport['rah230'] = result
    return ticket


def _appliquer_rah10(course: Course, ticket: List[Partant], rapport: Dict[str, Any]) -> List[Partant]:
    """RAH-10 : deux outsiders T5+ dans un ticket CHAOS."""
    signature = course.signature_msp.value if course.signature_msp else 'STANDARD'
    eligible = [p for p in course.partants if tranche_cote(p) in {'T3', 'T4'} and p not in ticket and _t4_eligible(p, course)[0]]
    count = sum(1 for p in ticket if tranche_cote(p) in {'T3', 'T4'})
    audit = {'rule': 'RAH-10', 'status': 'NOT_APPLICABLE' if signature != 'CHAOS' else 'PASS' if count >= 2 else 'SUSPENDED', 'signature': signature, 'outsiders_t5_plus': count, 'minimum': 2, 'replacements': []}
    if signature == 'CHAOS':
        while count < 2 and eligible and ticket:
            candidate = max(eligible, key=lambda p: p.ordre_score)
            removable = [p for p in ticket if tranche_cote(p) not in {'T3', 'T4'}]
            removable = removable or list(ticket)
            removed = min(removable, key=lambda p: p.ordre_score)
            ticket_without = [p for p in ticket if p is not removed]
            valid, reason = verifier_contraintes_ticket(candidate, ticket_without, course)
            if not valid:
                audit.setdefault('blocked', []).append({'numero': candidate.numero, 'reason': reason})
                eligible.remove(candidate)
                continue
            ticket = ticket_without + [candidate]
            eligible.remove(candidate)
            count += 1
            audit['replacements'].append({'removed': removed.numero, 'added': candidate.numero})
        audit['outsiders_t5_plus'] = count
        audit['status'] = 'PASS' if count >= 2 else 'SUSPENDED'
    rapport['rah10'] = audit
    return ticket


def _appliquer_rah178(course: Course, ticket: List[Partant], rapport: Dict[str, Any]) -> List[Partant]:
    """Garantit la couverture minimale des quatre tranches lorsque des candidats sont disponibles."""
    signature = course.signature_msp.value if course.signature_msp else 'STANDARD'
    quotas = QUOTAS_SIGNATURE.get(signature, QUOTAS_SIGNATURE['STANDARD'])
    for tranche, (minimum, maximum) in quotas.items():
        disponibles = [p for p in course.partants if tranche_cote(p) == tranche]
        while sum(1 for p in ticket if tranche_cote(p) == tranche) < minimum:
            candidats = [p for p in disponibles if p not in ticket]
            if not candidats:
                rapport['quotas_appliques'][tranche] = {'status': 'SUSPENDU', 'raison': 'Aucun candidat disponible', 'minimum': minimum, 'maximum': maximum}
                break
            candidats.sort(key=lambda p: p.ordre_score, reverse=True)
            ajout = None
            for candidate in candidats:
                ticket_sans = list(ticket)
                if len(ticket_sans) >= 8:
                    removables = [p for p in ticket_sans if tranche_cote(p) != tranche and sum(1 for q in ticket_sans if tranche_cote(q) == tranche_cote(p)) > quotas.get(tranche_cote(p), (0, 8))[0]]
                    removables = removables or ticket_sans
                    retire = min(removables, key=lambda p: p.ordre_score)
                    ticket_sans.remove(retire)
                ok, reason = verifier_contraintes_ticket(candidate, ticket_sans, course)
                if ok:
                    ajout = (candidate, ticket_sans)
                    break
            if ajout is None:
                rapport['quotas_appliques'][tranche] = {'status': 'SUSPENDU', 'raison': 'Candidat disponible mais contraintes dures incompatibles', 'minimum': minimum, 'maximum': maximum}
                break
            candidate, ticket_after = ajout
            removed = [p for p in ticket if p not in ticket_after]
            ticket = ticket_after
            ticket.append(candidate)
            rapport['iterations'].append({'regle': 'RAH-178', 'tranche': tranche, 'numero_ajoute': candidate.numero, 'numero_retire': removed[0].numero if removed else None})
        rapport['quotas_appliques'].setdefault(tranche, {'status': 'SATISFAIT', 'minimum': minimum, 'maximum': maximum})
        rapport['quotas_appliques'][tranche]['compte_final'] = sum(1 for p in ticket if tranche_cote(p) == tranche)
    return ticket


def _qualifie_rah267(partant: Partant) -> bool:
    actifs = len([s for s in getattr(partant, 'signaux', []) if s.actif])
    ssfo = float(getattr(partant, 'ssfo_details', {}).get('bonus_ssfo_final', 0.0) or 0.0)
    return bool(partant.tocard_score >= .15 or partant.ordre_score >= .30 or actifs >= 1 or ssfo >= 5)


def _appliquer_composition_rah267(course: Course, ticket: List[Partant], rapport: Dict[str, Any]) -> List[Partant]:
    """Applique les contraintes de composition au ticket final, avec remplacement traçable."""
    candidats = [p for p in course.partants if p not in ticket and _t4_eligible(p, course)[0]]
    m30_exclus = [p for p in ticket if bool(_raw(p, 'm30_paradoxe_favori')) and p.profil_ado == ProfilADO.FAVORI_UNANIME]
    for excluded in m30_exclus:
        replacement = max((p for p in candidats if _qualifie_rah267(p)), key=lambda p: p.ordre_score, default=None)
        if replacement is not None:
            ticket.remove(excluded)
            ticket.append(replacement)
            candidats.remove(replacement)
            rapport['contraintes_violees'].append({'numero': excluded.numero, 'raison': 'RAH267_M30_PARADOXE_FAVORI_EXCLUSION', 'remplace_par': replacement.numero})

    qualifying_high = [p for p in course.partants if p.cote is not None and p.cote > 20 and _qualifie_rah267(p)]
    if qualifying_high and not any(p in ticket and p.cote is not None and p.cote > 20 for p in ticket):
        replacement = max((p for p in candidats if p.cote is not None and p.cote > 20 and _qualifie_rah267(p)), key=lambda p: p.ordre_score, default=None)
        if replacement is not None and ticket:
            removed = min(ticket, key=lambda p: p.ordre_score)
            ticket.remove(removed)
            ticket.append(replacement)
            candidats.remove(replacement)
            rapport['contraintes_violeees' if False else 'contraintes_violees'].append({'numero': removed.numero, 'raison': 'RAH267_COTE_ELEVEE_OBLIGATOIRE', 'remplace_par': replacement.numero})
        elif replacement is None:
            rapport['contraintes_violees'].append({'raison': 'RAH267_COTE_ELEVEE_SUSPENDUE'})

    value_dead = [p for p in course.partants if p.cote is not None and p.cote > 25 and not [s for s in p.signaux if s.actif] and p.tocard_score < .20]
    if value_dead and not any(p in ticket for p in value_dead):
        replacement = max((p for p in value_dead if p not in ticket), key=lambda p: p.ordre_score, default=None)
        if replacement is not None and ticket:
            removed = min(ticket, key=lambda p: p.ordre_score)
            ticket.remove(removed)
            ticket.append(replacement)
            rapport['contraintes_violees'].append({'numero': removed.numero, 'raison': 'RAH267_VALEUR_MORTE_OBLIGATOIRE', 'remplace_par': replacement.numero})
    return ticket


def construire_ticket_gmov(course: Course) -> Dict[str, Any]:
    rapport: Dict[str, Any] = {
        'methode': 'GMO-V_POOL_ELARGI_GAIN_HYBRIDE',
        'signature': course.signature_msp.value if course.signature_msp else 'STANDARD',
        'pool_elargi': {}, 'quotas_appliques': {}, 'iterations': [], 'ticket_final': {}, 'contraintes_violees': [],
        'evidence_policy': 'PROXY_INTERDIT_A_LA_CERTIFICATION',
    }
    rah11 = verifier_rah11_ordre_score(course)
    rapport['hard_constraints'] = {'RAH-11': rah11}
    if rah11['status'] != 'PASS':
        rapport['contraintes_violees'].append({'raison': 'RAH11_ORDRE_SCORE_INCOMPLET', 'details': rah11})
        rapport['validation'] = {'selection_size_ok': False, 'quotas_ok': False, 'rah11_ok': False, 'rah90_ok': False, 'style_diversity_ok': False, 'hard_constraints_logged': True, 'certifiable': False}
        course.ticket = rapport
        return rapport
    for partant in course.partants:
        partant.extended_metrics['rah93'] = evaluer_rah93(partant)
        partant.extended_metrics['rah95'] = evaluer_rah95(partant)
        partant.extended_metrics['rah96'] = evaluer_rah96(partant)
    rapport['rah165'] = evaluer_rah165(course)
    rapport['rah96'] = {'status': 'CALCULATED', 'fallback_only': True, 'partants': {str(p.numero): p.extended_metrics['rah96'] for p in course.partants}}
    pool, pool_details = construire_pool_elargi(course)
    rapport['pool_elargi'] = pool_details
    ticket: List[Partant] = []
    for iteration in range(min(8, len(pool))):
        best = None
        best_gain = -1.0
        for candidate in pool:
            if candidate in ticket:
                continue
            valid, reason = verifier_contraintes_ticket(candidate, ticket, course)
            if not valid:
                rapport['contraintes_violees'].append({'iteration': iteration + 1, 'numero': candidate.numero, 'raison': reason})
                continue
            gain = calculer_gain_hybride(candidate, ticket, course)
            if gain > best_gain:
                best, best_gain = candidate, gain
        if best is None:
            break
        ticket.append(best)
        rapport['iterations'].append({'position_selection': iteration + 1, 'numero': best.numero, 'nom': best.nom, 'tranche': tranche_cote(best), 'gain_marginal': round(best_gain, 6), 'selection_mode': 'STRICT'})

    # RAH-36/42 : le ticket publié doit conserver huit positions sur un champ
    # suffisant. Si les contraintes strictes sont incompatibles entre elles
    # (par exemple tranche T4 non admissible et plafonds de tranches déjà atteints),
    # compléter avec des partants observés et tracer explicitement chaque relaxation.
    target_size = min(8, len(course.partants))
    if len(ticket) < target_size:
        for candidate in sorted(pool, key=lambda p: p.ordre_score, reverse=True):
            if candidate in ticket:
                continue
            policy = politique_stab_ticket(candidate, course)
            if policy.get('active') and not policy.get('eligible'):
                continue
            valid, reason = verifier_contraintes_ticket(candidate, ticket, course)
            rapport['contraintes_violees'].append({
                'iteration': len(ticket) + 1,
                'numero': candidate.numero,
                'raison': reason or 'SELECTION_STRICTE_NON_RETENUE',
                'relaxation': 'RAH-36_TICKET_SIZE_REQUIRED',
            })
            ticket.append(candidate)
            rapport['iterations'].append({
                'position_selection': len(ticket),
                'numero': candidate.numero,
                'nom': candidate.nom,
                'tranche': tranche_cote(candidate),
                'gain_marginal': round(calculer_gain_hybride(candidate, ticket[:-1], course), 6),
                'selection_mode': 'RELAXED_COMPLETION',
                'strict_constraints_valid': valid,
            })
            if len(ticket) >= target_size:
                break

    ticket = _appliquer_composition_rah267(course, ticket, rapport)
    ticket = _appliquer_rah10(course, ticket, rapport)
    ticket = _appliquer_rah178(course, ticket, rapport)
    ticket = _appliquer_rah156(course, ticket, rapport)
    ticket = _appliquer_rah230(course, ticket, rapport)
    positions = ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'R1', 'R2']
    remaining = sorted(ticket, key=lambda p: p.ordre_score, reverse=True)[:8]
    assigned = []
    for position in positions:
        eligible_here = [p for p in remaining if p not in assigned and position_autorisee(p, course, position)]
        if eligible_here:
            partant = max(eligible_here, key=lambda p: p.ordre_score)
        else:
            fallback = [p for p in remaining if p not in assigned and not politique_stab_ticket(p, course).get('active')]
            if not fallback and position in {'P5', 'P6', 'R1', 'R2'}:
                fallback = [p for p in remaining if p not in assigned and position_autorisee(p, course, position)]
            if not fallback:
                rapport['contraintes_violees'].append({'position': position, 'raison': 'POSITION_NON_REMPLIE_STAB_CONTRAINTE'})
                continue
            partant = max(fallback, key=lambda p: p.ordre_score)
            if not position_autorisee(partant, course, position):
                rapport['contraintes_violees'].append({'position': position, 'numero': partant.numero, 'raison': 'RELAXATION_POSITION_STAB_DOCUMENTEE'})
        assigned.append(partant)
        partant.position_ticket = position
        tranche = tranche_cote(partant)
        categorie = 'NC' if tranche == 'NC' else 'Favori' if tranche == 'T1' else 'Outsider' if tranche in {'T2', 'T3'} else 'Tocard'
        rah95_details = evaluer_rah95(partant)
        rapport.setdefault('rah95', {})[str(partant.numero)] = rah95_details
        rapport['ticket_final'][position] = {
            'numero': partant.numero,
            'nom': partant.nom,
            'cote': partant.cote,
            'tranche': tranche,
            'categorie': categorie,
            'ordre_score': round(partant.ordre_score, 6),
            'profil_ado': partant.profil_ado.value if partant.profil_ado else 'NC',
            'familles_actives': partant.familles_actives,
            'tocard_score': round(partant.tocard_score, 6),
            'ssfo_bonus': getattr(partant, 'ssfo_details', {}).get('bonus_ssfo_final', 0.0),
            'p5p6_score': _raw(partant, 'p5p6', {}).get('p5p6_score') if isinstance(_raw(partant, 'p5p6', {}), dict) else None,
            'p5_threshold': .40,
            'p6_threshold': .35,
            'stab_ticket_policy': politique_stab_ticket(partant, course),
        }

    reserve_rows = {pos: rapport['ticket_final'].get(pos) for pos in ('R1', 'R2')}
    reserve_scores = [row.get('p5p6_score') for row in reserve_rows.values() if isinstance(row, dict) and row.get('p5p6_score') is not None]
    rapport['rah155'] = {'status': 'CALCULATED' if len(ticket) == 8 and all(isinstance(row, dict) for row in reserve_rows.values()) else 'UNPROVEN', 'reserve_positions': reserve_rows, 'p5p6_scores': reserve_scores, 'dedicated_reserve_audit': True}
    rapport['rah167'] = {str(p.numero): evaluer_rah167(p, ticket) for p in ticket}
    rapport['rah_structure'] = verifier_rah36_41(ticket, course)
    rapport['rah98'] = evaluer_rah98(ticket, course)
    rah108_audit = (getattr(course, 'derived_metrics', {}) or {}).get('rah108') or {}
    rah83_components = {'favori_unanime': (getattr(course, 'derived_metrics', {}) or {}).get('favori_unanime'), 'cote_elevee': rah108_audit, 'valeur_morte_reserve': [p.numero for p in ticket if p.position_ticket in {'R1', 'R2'} and p.profil_ado == ProfilADO.VALEUR_MORTE]}
    rapport['rah83'] = {'rule': 'RAH-83', 'status': 'CALCULATED', 'components': rah83_components, 'precedence_over_raw_order': True}
    signature = course.signature_msp.value if course.signature_msp else 'STANDARD'
    quotas = QUOTAS_SIGNATURE.get(signature, QUOTAS_SIGNATURE['STANDARD'])
    for tranche, (min_q, max_q) in quotas.items():
        nb = sum(1 for p in ticket if tranche_cote(p) == tranche)
        satisfaisable = any(tranche_cote(p) == tranche for p in course.partants)
        rapport['quotas_appliques'][tranche] = {
            'nb': nb, 'min': min_q, 'max': max_q,
            'conforme': min_q <= nb <= max_q if satisfaisable else nb == 0,
            'satisfaisable': satisfaisable,
            'flag': '' if satisfaisable else f'TRANCHE_{tranche}_NON_SATISFAISABLE',
        }
    signature_norm = str(signature).upper()
    taille = len(getattr(course, 'partants', []) or [])
    taille_bucket = '8-11' if 8 <= taille <= 11 else '12-15' if 12 <= taille <= 15 else '16-20' if 16 <= taille <= 20 else 'HORS_TABLE'
    table_status = 'CALCULATED' if signature_norm in QUOTAS_SIGNATURE and taille_bucket != 'HORS_TABLE' else 'UNPROVEN'
    rapport['rah171'] = {'status': table_status, 'signature': signature_norm, 'taille_champ': taille, 'taille_bucket': taille_bucket, 'table_quotas': QUOTAS_SIGNATURE.get(signature_norm)}
    rapport['rah177'] = {'status': table_status, 'signature': signature_norm, 'quotas_adaptatifs': rapport['quotas_appliques'], 'minimum_par_tranche': 1, 'tranche_non_satisfaisable': [t for t, q in rapport['quotas_appliques'].items() if not q.get('satisfaisable', True)], 'jamais_force': True}
    proxy_partants = [p.numero for p in ticket if (getattr(p, 'extended_metrics', {}).get('gmov_evidence', {}).get('p_top5', {}).get('proxy') or getattr(p, 'extended_metrics', {}).get('gmov_evidence', {}).get('coverage', {}).get('proxy'))]
    rapport['gmov_evidence'] = {
        'p_top5_proxy_partants': proxy_partants,
        'p_top5_proxy_used': bool(proxy_partants),
        'coverage_formula_status': 'HEURISTIC_PROXY',
        'certification_blocked_by_proxy': bool(proxy_partants),
    }
    rapport['selection_size'] = len(ticket)
    rapport['ticket_certifiable_size'] = len(ticket) == 8 and not proxy_partants and not pool_details.get('fallback_admission_numbers')
    signature_upper = str(signature).upper()
    max_style = 3 if signature_upper == 'CHAOS' else 4
    style_counts = {}
    for partant in ticket:
        style = _raw(partant, 'style_mpa')
        if style:
            style_counts[style] = style_counts.get(style, 0) + 1
    favori_count = sum(1 for p in ticket if float(_raw(p, 'icp_global', p.icp_count) or 0) >= 6)
    style_ok = all(count <= max_style for count in style_counts.values())
    rah90_ok = favori_count <= 2
    quotas_ok = all(item.get('conforme', False) or not item.get('satisfaisable', True) for item in rapport['quotas_appliques'].values())
    rapport['hard_constraints'].update({
        'RAH-90': {'status': 'PASS' if rah90_ok else 'FAIL', 'favoris_icp_ge_6': favori_count, 'maximum': 2},
        'RAH-07/168': {'status': 'PASS' if style_ok else 'FAIL', 'style_counts': style_counts, 'maximum': max_style},
        'RAH-259': {'status': 'PASS' if quotas_ok else 'FAIL', 'quotas': rapport['quotas_appliques']},
        'RAH-166': {'status': 'PASS', 'enforced_in_selection_loop': True, 'iterations': len(rapport['iterations'])},
        'RAH-10': rapport.get('rah10', {'status': 'UNPROVEN'}),
    })
    rah10_ok = rapport['hard_constraints']['RAH-10']['status'] in {'PASS', 'NOT_APPLICABLE'}
    rah11_ok = rapport['hard_constraints']['RAH-11']['status'] == 'PASS'
    rah36_ok = rapport['rah_structure']['RAH-36']['status'] == 'PASS'
    rah41_ok = rapport['rah_structure']['RAH-41']['status'] == 'PASS'
    rah42_audit = finaliser_rah42({
        **rapport['hard_constraints'],
        'RAH-36': rapport['rah_structure']['RAH-36'],
        'RAH-41': rapport['rah_structure']['RAH-41'],
    })
    rapport['rah_structure']['RAH-42'] = rah42_audit
    rapport['validation'] = {
        'selection_size_ok': len(ticket) == 8,
        'quotas_ok': quotas_ok,
        'rah10_ok': rah10_ok,
        'rah11_ok': rah11_ok,
        'rah36_ok': rah36_ok,
        'rah41_ok': rah41_ok,
        'rah42_ok': rah42_audit['status'] == 'PASS',
        'rah230_status': rapport.get('rah230', {}).get('status', 'NO_CANDIDATE'),
        'rah90_ok': rah90_ok,
        'style_diversity_ok': style_ok,
        'hard_constraints_logged': True,
        'certifiable': len(ticket) == 8 and quotas_ok and rah90_ok and style_ok and rah10_ok and rah11_ok and rah36_ok and rah41_ok and rah42_audit['status'] == 'PASS' and not rapport['gmov_evidence']['certification_blocked_by_proxy'] and not rapport['pool_elargi'].get('fallback_admission_numbers'),
    }
    course.ticket = rapport
    return rapport
