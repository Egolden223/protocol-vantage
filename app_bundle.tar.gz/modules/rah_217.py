"""Audit de gouvernance RAH-217 pour les scores amont utilisés par SUPRA/GMO-V."""
from __future__ import annotations

from typing import Any, Dict

from engine.models import Course


def evaluer_rah217(course: Course, rapport_supra: Dict[str, Any] | None = None, rapport_gmov: Dict[str, Any] | None = None) -> Dict[str, Any]:
    required = {'PCH_FINAL': [], 'COMPOSITE': [], 'S1_MARCHE': [], 'S2_HISTORIQUE': [], 'GAMMA': []}
    for partant in course.partants:
        if getattr(partant, 'pch_final', None) is not None:
            required['PCH_FINAL'].append(partant.numero)
        if getattr(partant, 'composite', None) is not None:
            required['COMPOSITE'].append(partant.numero)
        raw = getattr(partant, 'raw_data', {}) or {}
        if raw.get('sov_v2') not in (None, '', 'NC', 'UNPROVEN') or (getattr(partant, 'extended_metrics', {}) or {}).get('sov_v2') is not None:
            required['S1_MARCHE'].append(partant.numero)
        if raw.get('score_sim') not in (None, '', 'NC', 'UNPROVEN') or (getattr(partant, 'extended_metrics', {}) or {}).get('score_sim') is not None:
            required['S2_HISTORIQUE'].append(partant.numero)
        if getattr(partant, 'gamma_details', None):
            required['GAMMA'].append(partant.numero)
    critical = ['PCH_FINAL', 'COMPOSITE']
    critical_ok = all(len(required[key]) == len(course.partants) for key in critical) if course.partants else False
    reviewed = bool(rapport_supra is not None and rapport_gmov is not None)
    return {
        'rule': 'RAH-217',
        'status': 'CALCULATED' if critical_ok and reviewed else 'UNPROVEN',
        'scores_amont': {key: {'observed_count': len(values), 'total': len(course.partants), 'partants': values} for key, values in required.items()},
        'relecture_critique_supra': reviewed,
        'relecture_critique_gmov': reviewed,
        'recalculation_silencieux': False,
        'missing_critical': [key for key in critical if len(required[key]) != len(course.partants)],
        'market_and_history_may_be_unproven': True,
    }
