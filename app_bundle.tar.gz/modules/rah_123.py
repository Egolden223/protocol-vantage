"""Gouvernance des garde-fous anti-surajustement RAH-123."""
from __future__ import annotations

from typing import Any, Dict

from engine.models import Course


def _num(value):
    try:
        return float(value) if value not in (None, '', 'NC', 'UNPROVEN') else None
    except (TypeError, ValueError):
        return None


def evaluer_rah123(course: Course) -> Dict[str, Any]:
    rows = {}
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        p5p6 = raw.get('p5p6', {}) if isinstance(raw.get('p5p6', {}), dict) else {}
        pente = (raw.get('pente_details', {}) or {}) if isinstance(raw.get('pente_details', {}), dict) else {}
        pscore_positions = raw.get('pscore_positions')
        style_delta = _num(raw.get('style_contextuel_delta'))
        iql_windows = raw.get('iql_windows')
        harville = raw.get('harville_details')
        observed = any(value is not None for value in (_num(p5p6.get('p5p6_score')), _num(pente.get('contribution_pch')), style_delta, _num(raw.get('iql_score'))))
        rows[str(partant.numero)] = {
            'p5p6_threshold': .40,
            'p5p6_guard': p5p6.get('p5_threshold', .40) == .40 or p5p6.get('p5p6_score') is None,
            'pente_clamp': pente.get('contribution_pch') is None or -10 <= float(pente.get('contribution_pch', 0)) <= 12,
            'p_score_fallback': isinstance(pscore_positions, (list, tuple)) and len(pscore_positions) >= 3 or raw.get('pscore_legacy') is True or pscore_positions is None,
            'style_contextuel_threshold': style_delta is None or abs(style_delta) >= .25,
            'iql_anti_zero': iql_windows is not None or raw.get('iql_score') is None,
            'harville_neutral': harville is None or float((harville or {}).get('penalty', 0) or 0) >= 0,
            'observed_inputs': observed,
        }
    status = 'CALCULATED' if rows and all(all(value for key, value in row.items() if key != 'observed_inputs') for row in rows.values()) else 'UNPROVEN'
    return {'rule': 'RAH-123', 'status': status, 'guards': rows, 'calibration_flags': ['PENTE_CALIBRATION_N_FAIBLE', 'P5P6_CALIBRATION_N_FAIBLE', 'STYLE_CONTEXTUEL_CALIBRATION'], 'no_retroactive_tuning': True}
