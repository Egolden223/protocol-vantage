"""Évaluation normative du Chasseur de Longshots F1–F8.

Les formules suivent la section 17.4 du protocole maître. Les composantes
incomplètes restent UNPROVEN et ne sont pas remplacées par une valeur neutre
interprétable comme une observation.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from engine.models import Course, Partant


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def _bounded(value) -> Optional[float]:
    value = _num(value)
    return None if value is None else max(0.0, min(1.0, value))


def _ratio_or_value(raw: Dict[str, Any], value_key: str, count_key: str, total_key: str):
    direct = _bounded(raw.get(value_key))
    if direct is not None:
        return direct
    count = _num(raw.get(count_key))
    total = _num(raw.get(total_key))
    if count is None or total is None or total <= 0:
        return None
    return max(0.0, min(1.0, count / total))


def _family(code: str, value: Optional[float], inputs: Dict[str, Any], formula: str, eligibility: bool) -> Dict[str, Any]:
    status = 'NOT_APPLICABLE' if not eligibility else 'CALCULATED' if value is not None else 'UNPROVEN'
    return {
        'code': code,
        'status': status,
        'value': None if value is None else round(max(0.0, min(1.0, value)), 6),
        'inputs': inputs,
        'formula': formula,
        'eligible': eligibility,
    }


def evaluer_longshots(partant: Partant, course: Course) -> Dict[str, Any]:
    raw = dict(getattr(partant, 'raw_data', {}) or {})
    cote = _num(partant.cote)
    eligible_cote = cote is not None and cote > 30

    absence = _num(raw.get('absence_jours', raw.get('repos')))
    gains = _num(raw.get('gains_totaux', raw.get('gains_totaux_eur')))
    plafond = _num(raw.get('plafond_elimination'))
    driver_elite = _bounded(raw.get('driver_top20'))
    if driver_elite is None:
        rank = _num(raw.get('driver_rang_national'))
        driver_elite = 1.0 if rank is not None and rank <= 20 else None
    top3_12m = _ratio_or_value(raw, 'top3_12m', 'nb_top3_12m', 'nb_courses_12m')
    entraineur_forme = raw.get('entraineur_en_forme') is True or raw.get('entraineur_forme') is True
    f1_eligible = eligible_cote and absence is not None and absence > 60 and gains is not None and plafond is not None and plafond > 0 and gains <= 0.80 * plafond and (driver_elite is not None or entraineur_forme) and top3_12m is not None and top3_12m > 0
    f1 = None if not f1_eligible or None in (absence, gains, plafond, driver_elite, top3_12m) or plafond <= 0 else (
        .25 * min(1.0, absence / 90.0) + .25 * max(0.0, min(1.0, 1.0 - gains / plafond)) + .25 * (driver_elite if driver_elite is not None else 1.0) + .25 * top3_12m
    )

    irp = _bounded(_num(raw.get('irp_ajuste', raw.get('irp')) / .70) if _num(raw.get('irp_ajuste', raw.get('irp'))) is not None else None)
    top3_5d = _ratio_or_value(raw, 'top3_5d', 'nb_top3_5d', 'nb_courses_5d')
    progression = _bounded(raw.get('progression_rang'))
    if progression is None:
        delta = _num(raw.get('progression_places_3courses'))
        progression = _bounded(delta / 3.0) if delta is not None else None
    changement_entraineur_flag = raw.get('changement_entraineur_90j') is True or raw.get('changement_entraineur_90j') == 1
    changement_entraineur = _bounded(raw.get('changement_entraineur_90j'))
    if changement_entraineur is None and changement_entraineur_flag:
        changement_entraineur = 1.0
    irp_raw = _num(raw.get('irp_ajuste', raw.get('irp')))
    progression_places = _num(raw.get('progression_places_3courses'))
    top3_5d_count = _num(raw.get('nb_top3_5d'))
    top3_5d_observed = top3_5d_count is not None and top3_5d_count >= 1 or (top3_5d_count is None and top3_5d is not None and top3_5d > 0)
    f2_eligible = eligible_cote and irp_raw is not None and irp_raw >= .40 and top3_5d_observed and (changement_entraineur_flag or (progression_places is not None and progression_places > 3))
    f2 = None if not f2_eligible or None in (irp, top3_5d, progression, changement_entraineur) else (.35 * irp + .25 * top3_5d + .25 * progression + .15 * changement_entraineur)

    rk_ref = _num(raw.get('rk_ref_tiers'))
    rk_cheval = _num(raw.get('rk_cheval'))
    driver_top10 = _bounded(raw.get('driver_top10'))
    if driver_top10 is None:
        rank = _num(raw.get('driver_rang_national'))
        driver_top10 = 1.0 if rank is not None and rank <= 10 else None
    place_4d = _ratio_or_value(raw, 'place_4d', 'nb_place_4d', 'nb_courses_4d')
    dq_12m = _num(raw.get('dq_freq_12m'))
    field_size = _num(getattr(course, 'nb_partants', None))
    best_third = raw.get('rk_meilleur_tiers') is True or (field_size is not None and rk_cheval is not None and rk_cheval > 0 and rk_cheval <= max(1.0, field_size / 3.0))
    f3_eligible = eligible_cote and best_third and None not in (rk_ref, rk_cheval, driver_top10, place_4d, dq_12m) and place_4d > 0 and dq_12m > 0
    f3 = None if not f3_eligible or None in (rk_ref, rk_cheval, driver_top10, place_4d, dq_12m) or rk_cheval <= 0 else (
        .30 * max(0.0, min(1.0, rk_ref / rk_cheval)) + .30 * driver_top10 + .20 * place_4d + .20 * (1.0 - min(1.0, dq_12m / 5.0))
    )

    alignement = _bounded(raw.get('alignement_style'))
    antecedent = _ratio_or_value(raw, 'antecedent_parcours', 'nb_top3_parcours', 'nb_courses_parcours')
    commentaire = _bounded(raw.get('commentaire_tactique_favorable'))
    if commentaire is None:
        commentaire = 1.0 if raw.get('commentaire_tactique') is True else None
    f4_eligible = eligible_cote and None not in (alignement, antecedent, commentaire)
    f4 = None if not f4_eligible else (.40 * alignement + .30 * antecedent + .30 * commentaire)

    icp_norm = _bounded(_num(raw.get('icp_pondere')))
    top3_3d = _ratio_or_value(raw, 'top3_3d', 'nb_top3_3d', 'nb_courses_3d')
    sov_positive = _bounded(raw.get('sov_v2_positif'))
    if sov_positive is None:
        sov_positive = 1.0 if raw.get('sov_v2') is not None and _num(raw.get('sov_v2')) > 0 else None
    icp_raw = _num(raw.get('icp_pondere'))
    f5_eligible = eligible_cote and icp_raw is not None and icp_raw <= 1.0 and top3_3d is not None and top3_3d > 0 and sov_positive is not None and sov_positive > 0
    f5 = None if not f5_eligible else (.35 * (1.0 - icp_norm) + .35 * top3_3d + .30 * sov_positive)

    style_attentiste = str(raw.get('style_mpa', '')).upper() == 'ATTENTISTE'
    f6_observe = style_attentiste and (str(getattr(course, 'signature_msp', '')).upper().endswith('CHAOS') or bool(raw.get('champ_risque_dq_eleve'))) and _num(course.distance) is not None and course.distance >= 2000

    top5_5d = _ratio_or_value(raw, 'top5_5d', 'nb_top5_5d', 'nb_courses_5d')
    f7_eligible = eligible_cote and None not in (gains, plafond, top5_5d) and plafond > 0 and gains < 0.60 * plafond and top5_5d >= .40
    f7 = None if not f7_eligible else (.5 * max(0.0, min(1.0, 1.0 - gains / plafond)) + .5 * top5_5d)

    exact_wins = _num(raw.get('victoires_parcours_exact'))
    exact_top3 = _num(raw.get('top3_parcours_exact'))
    exact_courses = _num(raw.get('courses_parcours_exact'))
    recent_exact = _num(raw.get('occurrence_parcours_exact_12m'))
    f8 = None if None in (exact_wins, exact_top3, exact_courses, recent_exact) or exact_courses <= 0 or recent_exact < 1 else max(0.0, min(1.0, (exact_wins + exact_top3) / exact_courses))

    families = {
        'F1': _family('F1', f1, {'absence_jours': absence, 'gains': gains, 'plafond': plafond, 'driver_elite': driver_elite, 'entraineur_en_forme': entraineur_forme, 'top3_12m': top3_12m}, '0.25*MIN(1,absence/90)+0.25*(1-gains/plafond)+0.25*driver_elite+0.25*top3_12m', f1_eligible),
        'F2': _family('F2', f2, {'irp_ajuste': irp, 'top3_5d': top3_5d, 'progression': progression, 'changement_entraineur': changement_entraineur, 'changement_entraineur_flag': changement_entraineur_flag, 'eligibility_irp_min': .40, 'eligibility_progression_places_min': 3}, '0.35*MIN(1,IRP/0.70)+0.25*Top3_5D+0.25*Progression+0.15*Changement_Entraineur', f2_eligible),
        'F3': _family('F3', f3, {'rk_ref': rk_ref, 'rk_cheval': rk_cheval, 'driver_top10': driver_top10, 'place_4d': place_4d, 'dq_12m': dq_12m, 'best_third': best_third}, '0.30*MIN(1,RK_ref/RK_cheval)+0.30*Driver_Top10+0.20*Place_4D+0.20*(1-MIN(1,DQ_12m/5))', f3_eligible),
        'F4': _family('F4', f4, {'alignement_style': alignement, 'antecedent_parcours': antecedent, 'commentaire_tactique': commentaire}, '0.40*Alignement_Style+0.30*Antecedent_Parcours+0.30*Commentaire_Tactique', f4_eligible),
        'F5': _family('F5', f5, {'icp_pondere': icp_norm, 'top3_3d': top3_3d, 'sov_v2_positif': sov_positive}, '0.35*(1-ICP_norm)+0.35*Top3_3D+0.30*SOV_v2_positif', f5_eligible),
        'F6': {'code': 'F6', 'status': 'OBSERVED' if f6_observe else 'INACTIVE', 'value': None, 'inputs': {'style_attentiste': style_attentiste}, 'formula': 'Observation seulement ; jamais de LS_FINAL', 'eligible': eligible_cote, 'f6_candidat_observe': f6_observe},
        'F7': _family('F7', f7, {'gains': gains, 'plafond': plafond, 'top5_5d': top5_5d}, '0.5*(1-gains/plafond)+0.5*Top5_5D', f7_eligible),
        'F8': _family('F8', f8, {'victoires': exact_wins, 'top3': exact_top3, 'courses': exact_courses, 'occurrence_12m': recent_exact}, '(Victoires+Top3)/Courses parcours exact', eligible_cote),
    }
    active_pairs = [(code, item['value']) for code, item in families.items() if code != 'F6' and item.get('status') == 'CALCULATED' and item.get('eligible') and item.get('value') is not None]
    active = [value for _, value in active_pairs]
    active_codes = [code for code, _ in active_pairs]
    ls_base = max(active) if active else None
    multiplier = 1.20 if len(active_codes) >= 3 else 1.10 if len(active_codes) >= 2 else 1.0
    ls_final = min(1.0, ls_base * multiplier) if ls_base is not None else None
    dominant_family = None
    if active_pairs:
        # En cas d’égalité, l’ALPHA n’est pas promu par défaut : F2 doit être
        # strictement dominante pour éviter une promotion opportuniste.
        max_value = max(value for _, value in active_pairs)
        top_codes = [code for code, value in active_pairs if value == max_value]
        dominant_family = top_codes[0] if len(top_codes) == 1 else None
    status = 'CALCULATED' if ls_final is not None else 'UNPROVEN'
    p_top5 = _num(raw.get('p_top5'))
    p_corrigee = None if p_top5 is None or ls_final is None or ls_final < .50 else p_top5 * (1.0 + min(.50, ls_final * .50))
    residual_mass = _num(raw.get('masse_residuelle'))
    supra = raw.get('supra_rah238') if isinstance(raw.get('supra_rah238'), dict) else {}
    risk_evaluated = raw.get('supra_piste_risque_evaluee', supra.get('piste_risque_evaluee'))
    risk_triggered = raw.get('supra_retrogradation_declenchee', supra.get('retrogradation_declenchee'))
    rah232_status = 'CALCULATED' if risk_evaluated is not None or risk_triggered is not None else 'UNPROVEN'
    alpha_candidate = dominant_family == 'F2' and ls_final is not None and ls_final >= .60
    rah266_f2_alpha_eligible = dominant_family == 'F2' and ls_final is not None and ls_final >= .50
    rah234_status = 'CALCULATED' if ls_final is not None and active_codes else 'UNPROVEN'
    return {
        'status': status,
        'eligible_cote': eligible_cote,
        'cote': cote,
        'families': families,
        'families_actives': active_codes,
        'LS_BASE': None if ls_base is None else round(ls_base, 6),
        'bonus_convergence': multiplier,
        'LS_FINAL': None if ls_final is None else round(ls_final, 6),
        'seuil_observe': ls_final is not None and ls_final >= .40,
        'seuil_candidat': ls_final is not None and ls_final >= .60,
        'seuil_prioritaire': ls_final is not None and ls_final >= .80,
        'gouvernance': 'F2_ALPHA' if alpha_candidate else 'BETA_FANTOME' if ls_final is not None and ls_final >= .60 else 'OBSERVATION',
        'famille_dominante': dominant_family,
        'direct_score_effect': False,
        'ticket_effect_policy': 'F2_ALPHA_ONLY_VIA_RAH230_OR_RAH266;_BETA_FANTOME_ONLY',
        'rah266_f2_alpha_eligible': rah266_f2_alpha_eligible,
        'rah231': {'status': 'CALCULATED' if p_corrigee is not None else 'UNPROVEN', 'p_top5_observee': p_top5, 'p_top5_corrigee_audit_only': p_corrigee, 'ticket_effect': False, 'residual_mass': residual_mass, 'residual_mass_ok': residual_mass is None or residual_mass <= .15},
        'rah229': {'status': status, 'LS_FINAL': None if ls_final is None else round(ls_final, 6), 'families_1_5': [code for code in active_codes if code in {'F1', 'F2', 'F3', 'F4', 'F5'}], 'f6_excluded': True},
        'rah232': {'status': rah232_status, 'piste_risque_evaluee': risk_evaluated, 'retrogradation_declenchee': risk_triggered, 'audit_post_course_only': True},
        'rah234': {'status': rah234_status, 'candidat_alpha': alpha_candidate, 'famille_dominante': dominant_family, 'replacement_eligible': alpha_candidate, 'f6_excluded': True},
        'rah239': {'status': 'CALCULATED' if ls_final is not None else 'UNPROVEN', 'family_2_alpha_only_for_real_replacement': True, 'gouvernance': 'F2_ALPHA' if alpha_candidate else 'BETA_FANTOME' if ls_final is not None and ls_final >= .60 else 'OBSERVATION', 'f6_excluded': True},
        'f6_candidat_observe': bool(families['F6'].get('f6_candidat_observe')),
        'formula_version': 'MASTER_17.4_F1_F8',
    }
