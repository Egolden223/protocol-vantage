"""Évaluateur normatif du MODULE P5P6 (RAH-150/155/257)."""
from __future__ import annotations

from typing import Any, Dict, Optional

from engine.models import Course, Partant, ModuleResult


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC', 'UNPROVEN') else default
    except (TypeError, ValueError):
        return default


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def evaluer_p5p6(partant: Partant, course: Course) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    flags = []
    strict_count = _num(raw.get('nb_signaux_strict', raw.get('strict_bonus_count')))
    d43 = bool(raw.get('d43_longshot') or 'D43' in getattr(partant, 'ghost_details', {}).get('flags', []))
    pente = _num(raw.get('rah244_pente_score_effective', raw.get('pente_score')))
    pente_brute = _num(raw.get('pente_score'))
    pente_forte_pch = pente_brute is not None and pente_brute >= .75
    c1_observed = _num(raw.get('p5p6_c1'))
    if c1_observed is not None:
        c1 = _clamp(c1_observed)
    elif d43:
        c1 = 1.0
        flags.append('C1_D43_LONGSHOT')
    elif strict_count is not None:
        c1 = 1.0 if strict_count >= 3 else _clamp(strict_count / 3.0)
    else:
        c1 = None
        flags.append('C1_UNPROVEN')

    cote = _num(partant.cote)
    c2_observed = _num(raw.get('p5p6_c2'))
    if c2_observed is not None:
        c2 = _clamp(c2_observed)
    elif cote is None:
        c2 = None
        flags.append('C2_COTE_NC')
    elif cote < 6:
        # RAH-150 : un favori ne reçoit pas le vieux C2=0.1 par défaut.
        if (strict_count is not None and strict_count >= 3) or d43 or (pente is not None and pente >= .75):
            c2 = .4
            flags.append('C2_RAH150_PALIER_FAVORI')
        else:
            c2 = None
            flags.append('C2_PALIER_CONDITIONNEL_UNPROVEN')
    else:
        c2 = None
        flags.append('C2_PALIERS_COTE_NON_OBSERVES')

    c3 = _num(raw.get('p5p6_c3'))
    if c3 is None:
        trajectory = _num(raw.get('trajectory_score'))
        c3 = _clamp(trajectory) if trajectory is not None else None
    if c3 is not None and pente_forte_pch:
        c3 = min(c3, .6)
        flags.append('C3_PLAFONNE_REDONDANCE')

    safety_count = _num(raw.get('safety_negative_count'))
    c4 = _num(raw.get('p5p6_c4'))
    if c4 is None and safety_count is not None:
        c4 = _clamp(1.0 - .5 * safety_count)
    elif c4 is None and raw.get('security_signals') is not None:
        c4 = 1.0 if not raw.get('security_signals') else 0.0
    elif c4 is None:
        c4 = None
        flags.append('C4_SECURITE_UNPROVEN')

    c5 = _num(raw.get('p5p6_c5', raw.get('montee_categorie_score')))
    if c5 is not None:
        c5 = _clamp(c5)
        weights = (.35, .20, .18, .12, .15)
        components = (c1, c2, c3, c4, c5)
        if any(value is None for value in components):
            score = None
            flags.append('P5P6_ENTREE_MANQUANTE')
        else:
            score = sum(value * weight for value, weight in zip(components, weights))
            flags.append('RAH257_REPONDERATION_C5')
    else:
        weights = (.40, .25, .20, .15)
        components = (c1, c2, c3, c4)
        if any(value is None for value in components):
            score = None
            flags.append('P5P6_ENTREE_MANQUANTE')
        else:
            score = sum(value * weight for value, weight in zip(components, weights))

    signature = getattr(getattr(course, 'signature_msp', None), 'value', str(getattr(course, 'signature_msp', 'STANDARD'))).upper()
    p5_threshold = .30 if signature == 'CHAOS' else .40
    p6_threshold = .25 if signature == 'CHAOS' else .35
    details = {
        'status': 'CALCULATED' if score is not None else 'UNPROVEN',
        'p5p6_score': score,
        'c1_signal_fort': c1,
        'c2_cote': c2,
        'c3_trajectoire': c3,
        'c4_securite': c4,
        'c5_montee_categorie': c5,
        'weights': weights,
        'p5_threshold': p5_threshold,
        'p6_threshold': p6_threshold,
        'eligible_p5': None if score is None else score >= p5_threshold,
        'eligible_p6': None if score is None else score >= p6_threshold,
        'orthogonal_to_borda': True,
        'signature_threshold_mode': 'CHAOS_ABAISSE' if signature == 'CHAOS' else 'STANDARD',
        'flags': flags,
    }
    raw['p5p6'] = details
    partant.raw_data = raw
    return details


def executer_p5p6(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='P5P6', actif=True)
    details = evaluer_p5p6(partant, course)
    result.score = 0.0
    result.details = details
    result.flags = details.get('flags', [])
    return result
