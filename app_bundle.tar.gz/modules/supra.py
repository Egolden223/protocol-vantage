"""
PROTOCOL VANTAGE — Module SUPRA (7 phases)
Audit transversal avec max 3 modifications.
Verrou SUPRA_CONFIANCE < 0.50 = blocage.
Règle de convergence: 2 familles de signaux indépendantes (RAH-215 §10.b).
"""
from typing import List, Dict, Any, Tuple, Optional
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.models import Course, Partant, ProfilADO, SignatureMSP
from modules.longshots_normative import evaluer_longshots
from engine.quality_governance import evaluer_rah270


def calculer_delta_marche(partant: Partant, course: Course) -> float:
    """
    S1-MARCHÉ: DELTA_MARCHÉ calculé depuis les cotes SOV.
    Mesure l'écart entre la cote actuelle et la cote théorique.
    """
    if partant.cote is None or partant.cote <= 0:
        return 0.0

    raw = getattr(partant, 'raw_data', {}) or {}
    observed_sov = raw.get('sov_v2', (partant.extended_metrics or {}).get('sov_v2'))
    if observed_sov not in (None, '', 'NC'):
        try:
            return float(observed_sov)
        except (TypeError, ValueError):
            pass

    # SOV théorique basé sur le scoring
    all_scores = [p.ordre_score for p in course.partants if p.ordre_score > 0]
    if not all_scores:
        return 0.0

    total_score = sum(all_scores)
    if total_score == 0:
        return 0.0

    prob_theorique = partant.ordre_score / total_score
    prob_marche = 1.0 / partant.cote if partant.cote > 0 else 0.0

    delta = prob_marche - prob_theorique
    return delta


def phase1_identification_anomalies(course: Course) -> List[Dict[str, Any]]:
    """
    Phase 1: Identification des anomalies de scoring.
    Détecte les écarts significatifs entre ORDRE_SCORE et position attendue.
    """
    anomalies = []
    partants_tries = sorted(course.partants, key=lambda p: p.ordre_score, reverse=True)

    for i, partant in enumerate(partants_tries):
        # Anomalie si cote basse mais score faible
        if partant.cote is not None and 0 < partant.cote < 8 and i > 4:
            anomalies.append({
                "type": "FAVORI_SCORE_FAIBLE",
                "partant": partant.nom,
                "numero": partant.numero,
                "cote": partant.cote,
                "rang_score": i + 1,
                "severite": "HAUTE"
            })
        # Anomalie si cote haute mais score élevé
        elif partant.cote is not None and partant.cote > 20 and i < 3:
            anomalies.append({
                "type": "OUTSIDER_SCORE_ELEVE",
                "partant": partant.nom,
                "numero": partant.numero,
                "cote": partant.cote,
                "rang_score": i + 1,
                "severite": "MOYENNE"
            })

    return anomalies


def evaluer_rah146(partant: Partant) -> Dict[str, Any]:
    """RAH-146 : SCORE_SIM et profil gagnant type de l’historique."""
    raw = getattr(partant, 'raw_data', {}) or {}
    try:
        score_sim = float(raw.get('score_sim')) if raw.get('score_sim') not in (None, '', 'NC', 'UNPROVEN') else None
    except (TypeError, ValueError):
        score_sim = None
    try:
        nb_courses = float(raw.get('nb_courses_sim', raw.get('nb_courses', raw.get('courses_total'))))
    except (TypeError, ValueError):
        nb_courses = None
    profile = {
        'position_mi_course': raw.get('position_mi_course_historique'),
        'ecart_moyen_arrivee': raw.get('ecart_moyen_arrivee'),
        'taux_favoris_dejoues': raw.get('taux_favoris_dejoues'),
    }
    status = 'CALCULATED' if score_sim is not None and nb_courses is not None and nb_courses >= 5 else 'UNPROVEN'
    return {'rule': 'RAH-146', 'status': status, 'score_sim': score_sim, 'seuil': .70, 'actif': status == 'CALCULATED' and score_sim >= .70, 'nb_courses': nb_courses, 'minimum_courses': 5, 'profil_gagnant_type': profile, 'source_required': 'historique quantifié'}


def phase2_verification_coherence(course: Course) -> List[Dict[str, Any]]:
    """
    Phase 2: Vérification de cohérence des modules.
    """
    incoherences = []

    for partant in course.partants:
        # Vérifier cohérence entre modules
        scores_modules = {m.nom: m.score for m in partant.modules_results if m.actif}

        # Si STAB négatif mais TERRAIN_DYN positif et forme positive
        stab = scores_modules.get("STAB", 0)
        terrain = scores_modules.get("MODULE_TERRAIN_DYN", 0)

        if stab < 0 and terrain > 5:
            incoherences.append({
                "type": "INCOHERENCE_STAB_TERRAIN",
                "partant": partant.nom,
                "numero": partant.numero,
                "stab": stab,
                "terrain": terrain
            })

    return incoherences


def phase3_signal_marche(course: Course) -> List[Dict[str, Any]]:
    """
    Phase 3: S1-MARCHÉ — DELTA_MARCHÉ.
    Utilise les cotes SOV déjà collectées.
    """
    signaux_marche = []

    for partant in course.partants:
        delta = calculer_delta_marche(partant, course)
        if abs(delta) > 0.10:  # Seuil de significativité
            signaux_marche.append({
                "type": "DELTA_MARCHE_SIGNIFICATIF",
                "partant": partant.nom,
                "numero": partant.numero,
                "delta": round(delta, 4),
                "direction": "SOUTENU" if delta > 0 else "DELAISSE",
                "magnitude": abs(delta)
            })

    return signaux_marche


def phase4_presse_divergence(course: Course) -> List[Dict[str, Any]]:
    """
    Phase 4: S3-PRESSE-DIVERGENCE (RAH-212).
    UNIQUEMENT comme détecteur de divergence.
    Jamais comme validation ou consensus direct.
    """
    divergences = []

    for partant in course.partants:
        # Détecter divergence entre consensus presse (ICP) et scoring
        partants_tries = sorted(course.partants, key=lambda p: p.ordre_score, reverse=True)
        rang_score = next(
            (i for i, p in enumerate(partants_tries) if p.numero == partant.numero),
            len(partants_tries)
        )

        raw = getattr(partant, 'raw_data', {}) or {}
        # RAH-212 : la divergence presse ne pénalise pas les outsiders.
        outsider = (partant.cote is not None and partant.cote > 12) or partant.tocard_score >= .20
        # Si ICP élevé mais rang score faible = divergence
        if partant.icp_count >= 4 and rang_score > 5 and not outsider:
            divergences.append({
                "type": "DIVERGENCE_PRESSE_SCORE",
                "partant": partant.nom,
                "numero": partant.numero,
                "icp": partant.icp_count,
                "rang_score": rang_score + 1,
                "note": "Détecteur de divergence uniquement - pas de validation directe"
            })
        elif partant.icp_count <= 1 and rang_score < 3:
            divergences.append({
                "type": "DIVERGENCE_SCORE_PRESSE",
                "partant": partant.nom,
                "numero": partant.numero,
                "icp": partant.icp_count,
                "rang_score": rang_score + 1,
                "note": "Cheval bien classé mais ignoré par la presse"
            })

    return divergences


def phase5_modules_differentiels(course: Course) -> List[Dict[str, Any]]:
    """
    Phase 5: Analyse des modules différentiels.
    """
    resultats = []

    for partant in course.partants:
        rythme = evaluer_rah270(partant)
        if rythme.get('status') == 'CALCULATED':
            resultats.append({
                'type': 'RAH270_DONNEE_RYTHME_CRITIQUE',
                'partant': partant.nom,
                'numero': partant.numero,
                'priority': rythme.get('priority'),
                'flag': rythme.get('flag'),
                'commentaire_rythme': rythme.get('commentaire_rythme'),
                'chrono_sectionnel': rythme.get('chrono_sectionnel'),
            })
        # Identifier les modules avec impact fort
        for module in partant.modules_results:
            if module.actif and abs(module.score) > 5:
                resultats.append({
                    "type": "MODULE_IMPACT_FORT",
                    "partant": partant.nom,
                    "numero": partant.numero,
                    "module": module.nom,
                    "score": module.score,
                    "direction": "POSITIF" if module.score > 0 else "NEGATIF"
                })

    return resultats


def phase6_verification_contraintes(course: Course) -> List[Dict[str, Any]]:
    """
    Phase 6: Vérification des contraintes dures.
    """
    violations = []

    for partant in course.partants:
        # RAH-90: Contrainte de cote maximale en P1-P5
        if partant.cote is not None and partant.cote > 20 and partant.position_ticket in ("P1", "P2", "P3", "P4", "P5"):
            # Vérifier qu'il y a justification
            nb_signaux = len([s for s in partant.signaux if s.actif])
            if nb_signaux < 3:
                violations.append({
                    "type": "CONTRAINTE_COTE_ELEVEE",
                    "partant": partant.nom,
                    "numero": partant.numero,
                    "cote": partant.cote,
                    "position": partant.position_ticket,
                    "nb_signaux": nb_signaux
                })

    return violations


def phase7_synthese_decision(
    anomalies: List,
    incoherences: List,
    signaux_marche: List,
    divergences: List,
    modules_diff: List,
    contraintes: List,
    course: Course
) -> List[Dict[str, Any]]:
    """
    Phase 7: Synthèse et décision de modifications.
    Max 3 modifications, chacune avec convergence 2 familles.
    """
    modifications_proposees = []

    # Collecter tous les signaux par partant
    signaux_par_partant = {}
    for item in anomalies + signaux_marche + divergences:
        num = item.get("numero")
        if num not in signaux_par_partant:
            signaux_par_partant[num] = {"familles": set(), "signaux": []}
        signaux_par_partant[num]["signaux"].append(item)

        # Classifier la famille du signal
        if item["type"].startswith("DELTA_MARCHE"):
            signaux_par_partant[num]["familles"].add("M")
        elif item["type"].startswith("DIVERGENCE"):
            signaux_par_partant[num]["familles"].add("C")
        elif item["type"].startswith("FAVORI") or item["type"].startswith("OUTSIDER"):
            signaux_par_partant[num]["familles"].add("F")

    # Les modules forts sont une famille indépendante uniquement lorsqu’ils
    # portent une preuve calculée, jamais lorsqu’ils sont UNPROVEN/NC.
    for item in modules_diff:
        partant = next((p for p in course.partants if p.numero == item.get('numero')), None)
        if partant and item.get('score') is not None:
            num = item['numero']
            signaux_par_partant.setdefault(num, {'familles': set(), 'signaux': []})
            signaux_par_partant[num]['familles'].add('MODULE')
            signaux_par_partant[num]['signaux'].append(item)

    # Proposer des modifications (max 3)
    for num, data in signaux_par_partant.items():
        if len(modifications_proposees) >= 3:
            break

        # Verrou de convergence: 2 familles indépendantes (RAH-215 §10.b)
        if len(data["familles"]) >= 2:
            partant = next((p for p in course.partants if p.numero == num), None)
            if partant:
                modifications_proposees.append({
                    "partant": partant.nom,
                    "numero": num,
                    "familles_convergentes": list(data["familles"]),
                    "nb_signaux": len(data["signaux"]),
                    "action": "RECLASSER" if len(data["signaux"]) >= 2 else "SURVEILLER",
                    "confiance": min(0.8, len(data["signaux"]) * 0.2)
                })

    return modifications_proposees


def evaluer_rah238(course: Course, modifications: List[Dict[str, Any]]) -> Dict[str, Any]:
    opportunites = [
        {'numero': item.get('numero'), 'familles': item.get('familles_convergentes', []), 'confiance': item.get('confiance', 0.0)}
        for item in modifications if len(item.get('familles_convergentes', [])) >= 2 and item.get('confiance', 0.0) >= .50
    ]
    risques = []
    for partant in course.partants:
        raw = getattr(partant, 'raw_data', {}) or {}
        facts = []
        if raw.get('rah235_fact') in {'A', 'B', 'C'}:
            facts.append('RAH-235')
        if bool(raw.get('rah237_trap_confirmed')):
            facts.append('RAH-237')
        if bool(raw.get('stab_critical')) or bool(raw.get('stab_score') is not None and float(raw.get('stab_score')) <= -80):
            facts.append('STAB_CRITIQUE')
        if bool(raw.get('rah244_rentree_sans_preparation')) and partant.cote is not None and partant.cote <= 6 and bool(raw.get('top2_champ')) and float(raw.get('confiance_intrinseque', 0) or 0) >= .65:
            facts.append('RAH-244b')
        confidence = float(raw.get('confiance_intrinseque', 0) or 0)
        if len(facts) == 1 and confidence >= .65:
            risques.append({'numero': partant.numero, 'signal_unique': facts[0], 'confiance_intrinseque': confidence, 'action': 'DEGRADER'})
    prudence = 0
    prudence_details = {}
    for p in course.partants:
        raw = getattr(p, 'raw_data', {}) or {}
        factors = raw.get('supra_prudence_factors')
        if isinstance(factors, dict):
            active = [key for key, value in factors.items() if value is True]
        elif isinstance(factors, (list, tuple, set)):
            active = list(factors)
        else:
            active = ['supra_prudence_factor'] if bool(raw.get('supra_prudence_factor')) else []
        if active:
            prudence += len(active)
            prudence_details[str(p.numero)] = active
    max_modifications = max(0, 3 - prudence)
    return {'rule': 'RAH-238', 'status': 'CALCULATED', 'piste_opportunite': opportunites, 'piste_risque': risques, 'registre_pieges_verifie': True, 'facteurs_prudence_actifs': prudence, 'facteurs_prudence_details': prudence_details, 'plafond_modifications_rah216': max_modifications, 'jamais_neutralisation_totale': True, 'verdict': 'CORRECTION' if risques else 'VALIDATION'}


def calculer_supra_confiance(modification: Dict[str, Any]) -> float:
    """
    Calcul SUPRA_CONFIANCE pour une modification.
    Si < 0.50 → blocage de cette modification.
    """
    base = 0.30
    bonus_familles = len(modification.get("familles_convergentes", [])) * 0.15
    bonus_signaux = min(0.20, modification.get("nb_signaux", 0) * 0.05)
    return min(1.0, base + bonus_familles + bonus_signaux)


def executer_supra(course: Course) -> Dict[str, Any]:
    """
    Exécution complète du module SUPRA (7 phases).
    Retourne le rapport SUPRA avec les modifications appliquées.
    """
    rapport = {
        "phases": {},
        "modifications_appliquees": [],
        "modifications_bloquees": [],
        "nb_modifications": 0
    }

    # Phase 1
    anomalies = phase1_identification_anomalies(course)
    rapport["phases"]["phase1_anomalies"] = anomalies

    # Phase 2
    incoherences = phase2_verification_coherence(course)
    rapport["phases"]["phase2_coherence"] = incoherences
    rapport["phases"]["phase2_rah146"] = {str(p.numero): evaluer_rah146(p) for p in course.partants}

    # Phase 3
    signaux_marche = phase3_signal_marche(course)
    rapport["phases"]["phase3_marche"] = signaux_marche

    # Phase 4
    divergences = phase4_presse_divergence(course)
    rapport["phases"]["phase4_presse_divergence"] = divergences
    presse_missing = []
    presse_rows = []
    for p in course.partants:
        raw = getattr(p, 'raw_data', {}) or {}
        sources = raw.get('press_sources', raw.get('press_top5_sources'))
        source_count = len(sources) if isinstance(sources, (list, tuple, set, dict)) else sources
        row_status = 'CALCULATED' if isinstance(source_count, (int, float)) and source_count >= 3 else 'UNPROVEN'
        presse_rows.append({'numero': p.numero, 'sources_count': source_count, 'status': row_status, 'detector_only': True})
        if row_status == 'UNPROVEN':
            presse_missing.append(p.numero)
    rapport['rah212'] = {'rule': 'RAH-212', 'status': 'CALCULATED' if not presse_missing else 'UNPROVEN', 'rows': presse_rows, 'divergences': divergences, 'outsider_neutralized': True, 'validation_directe_interdite': True}

    # Phase 5
    modules_diff = phase5_modules_differentiels(course)
    rapport["phases"]["phase5_modules_diff"] = modules_diff
    # RAH-213 : le scénario doit être fourni explicitement et croisé avec les facteurs de course.
    rythme_data = (getattr(course, 'derived_metrics', {}) or {}).get('supra_phase5_scenario')
    rapport["phases"]["phase5_rah213"] = rythme_data if isinstance(rythme_data, dict) else {'status': 'UNPROVEN', 'reason': 'Scénario rythme/croisement absent'}
    # Phase 6 — scan négligés + Chasseur de Longshots
    # Le document maître exige que Longshots soit exécuté dans SUPRA Phase 6,
    # jamais comme une étape autonome avant SUPRA.
    rapport['phases']['phase6_longshots'] = chasseur_longshots(course)
    contraintes = phase6_verification_contraintes(course)
    rapport["phases"]["phase6_contraintes"] = contraintes
    # RAH-214 : scan omission ET retrait, avec seuil de trois signaux convergents.
    scan_data = (getattr(course, 'derived_metrics', {}) or {}).get('supra_phase6_scan')
    rapport["phases"]["phase6_rah214"] = scan_data if isinstance(scan_data, dict) else {'status': 'UNPROVEN', 'reason': 'Scan bidirectionnel absent'}


    # Phase 7: Synthèse
    modifications = phase7_synthese_decision(
        anomalies, incoherences, signaux_marche,
        divergences, modules_diff, contraintes, course
    )
    rapport['phases']['phase7_rah238'] = evaluer_rah238(course, modifications)

    # Appliquer les modifications (max 3, avec verrou confiance)
    for modif in modifications[:3]:
        confiance = calculer_supra_confiance(modif)
        modif["supra_confiance"] = confiance

        if confiance >= 0.50:
            rapport["modifications_appliquees"].append(modif)
            rapport["nb_modifications"] += 1

            # APPLIQUER la modification au classement
            num = modif["numero"]
            partant = next((p for p in course.partants if p.numero == num), None)
            if partant and modif["action"] == "RECLASSER":
                # Bonus SUPRA au score du partant (proportionnel à la confiance)
                bonus_supra = confiance * 15.0  # Bonus significatif
                partant.pch_final += bonus_supra
                partant.composite += bonus_supra * 0.8
                partant.ordre_score = partant.composite * partant.produit_mult_ecrete
                modif["bonus_applique"] = bonus_supra
                modif["nouveau_ordre_score"] = partant.ordre_score
        else:
            modif["raison_blocage"] = f"SUPRA_CONFIANCE={confiance:.2f} < 0.50"
            rapport["modifications_bloquees"].append(modif)

    rapport['rah215'] = {'rule': 'RAH-215', 'status': 'CALCULATED' if modifications and all(len(m.get('familles_convergentes', [])) >= 2 and float(m.get('supra_confiance', 0) or 0) >= .50 for m in modifications) else 'UNPROVEN', 'modifications': [{'numero': m.get('numero'), 'familles': m.get('familles_convergentes', []), 'supra_confiance': m.get('supra_confiance')} for m in modifications], 'minimum_familles': 2, 'threshold_confidence': .50}
    course.supra_modifications = rapport["nb_modifications"]
    course.supra_details = rapport["modifications_appliquees"]

    return rapport


# =============================================================================
# CHASSEUR DE LONGSHOTS (8 familles)
# =============================================================================

def chasseur_longshots(course: Course) -> Dict[str, Any]:
    """Exécute les formules normatives Longshots F1–F8.

    F6 reste une observation gouvernée et n’entre jamais dans LS_FINAL. Les
    familles incomplètes restent UNPROVEN ; aucun palier heuristique n’est
    attribué à partir de signaux voisins.
    """
    rapport = {
        'version': 'MASTER_17.4_F1_F8',
        'candidats': [],
        'familles_actives': [],
        'observations_f6': [],
        'partants': {},
        'rah228': {'rule': 'RAH-228', 'status': 'CALCULATED', 'eligible_count': 0, 'missing_ls_final': [], 'f6_observation_only': True},
    }
    for partant in course.partants:
        details = evaluer_longshots(partant, course)
        partant.longshots_details = details
        ls_final = details.get('LS_FINAL')
        if ls_final is not None:
            # LS_FINAL est un indicateur Longshots gouverné, pas un signal D
            # et ne doit jamais réécrire tocard_score/ORDRE_SCORE. Son effet
            # réel est limité à F2_ALPHA via RAH-230/RAH-266 ; les autres
            # familles restent en ticket fantôme ou observation.
            details['direct_score_effect'] = False
        active = details.get('familles_actives', [])
        rapport['familles_actives'] = sorted(set(rapport['familles_actives']) | set(active))
        if details.get('eligible_cote'):
            rapport['rah228']['eligible_count'] += 1
            if details.get('LS_FINAL') is None:
                rapport['rah228']['status'] = 'UNPROVEN'
                rapport['rah228']['missing_ls_final'].append(partant.numero)
        rapport['partants'][str(partant.numero)] = details
        rapport['partants'][str(partant.numero)]['rah228'] = {
            'status': 'CALCULATED' if details.get('LS_FINAL') is not None else 'UNPROVEN' if details.get('eligible_cote') else 'NOT_APPLICABLE',
            'families_f1_f5': {code: (details.get('families', {}).get(code, {}) or {}).get('status') for code in ('F1', 'F2', 'F3', 'F4', 'F5')},
            'f6_observation_only': True,
        }
        if details.get('f6_candidat_observe'):
            rapport['observations_f6'].append({'numero': partant.numero, 'nom': partant.nom, 'flag': 'f6_candidat_observe'})
        if details.get('seuil_candidat'):
            rapport['candidats'].append({
                'numero': partant.numero,
                'nom': partant.nom,
                'cote': partant.cote,
                'LS_FINAL': ls_final,
                'LS_BASE': details.get('LS_BASE'),
                'familles': active,
                'gouvernance': details.get('gouvernance'),
                'profil': 'DISSIMULE_FORT' if ls_final >= .80 else 'DISSIMULE_LEGER',
            })
    return rapport
