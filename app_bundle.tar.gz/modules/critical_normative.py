"""Calculateurs normatifs SRI_v2, CSF et PDQ."""
from __future__ import annotations

from typing import Any, Dict, List, Tuple

from engine.models import Course, Discipline, ModuleResult, Partant


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def _clamp(lo: float, hi: float, value: float) -> float:
    return max(lo, min(hi, value))


def evaluer_sri_v2(partant: Partant, course: Course) -> Dict[str, Any]:
    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    valeur = _num(_raw(partant, 'valeur_pmu', _raw(partant, 'valeur_pmu_alternative')))
    gains = _num(_raw(partant, 'gains_totaux_eur', _raw(partant, 'gains_totaux')))
    nb_courses = _num(_raw(partant, 'nb_courses', _raw(partant, 'courses_total')))
    niveau = _num(_raw(partant, 'niveau_max', 0.0), 0.0)
    age = _num(partant.age)
    if valeur is None:
        return {'status': 'UNPROVEN', 'sri_v2': None, 'flags': ['VALEUR_PMU_MANQUANTE'], 'reason': 'Valeur PMU nécessaire absente'}
    gain_course = gains / max(nb_courses or 1, 1) if gains is not None else 0.0
    flags: List[str] = []
    if gains is None:
        flags.append('GAINS_MANQUANTS')
    if discipline.startswith('TROT'):
        base = valeur * 1.5 + gain_course / 200 + niveau * 8
        if age is None:
            age_mult = 1.0
            flags.append('AGE_MANQUANT')
        elif 6 <= age <= 9:
            age_mult = 1.05
        elif 4 <= age <= 5:
            age_mult = .95
        elif age > 10:
            age_mult = .88
        else:
            age_mult = .80
    elif discipline == 'PLAT':
        base = valeur * 1.3 + gain_course / 300 + niveau * 12
        if age is None:
            age_mult = 1.0
            flags.append('AGE_MANQUANT')
        elif 3 <= age <= 5:
            age_mult = 1.0
        elif age == 6:
            age_mult = .97
        elif 7 <= age <= 8:
            age_mult = .90
        else:
            age_mult = .83
    elif discipline in {'OBSTACLE', 'HAIES'}:
        base = valeur * 1.4 + gain_course / 150 + niveau * 10
        if age is None:
            age_mult = 1.0
            flags.append('AGE_MANQUANT')
        elif 6 <= age <= 10:
            age_mult = 1.05
        elif 4 <= age <= 5:
            age_mult = .90
        elif age > 11:
            age_mult = .85
        else:
            age_mult = .78
    else:
        base = valeur * 1.2 + gain_course / 250 + niveau * 10
        age_mult = 1.0
        flags.append('DISCIPLINE_INCONNUE')
    sri = _clamp(0, 120, base * age_mult)
    if _raw(partant, 'sri_hors_pattern_europeen'):
        flags.append('SRI_HORS_PATTERN_EUROPEEN')
    return {'status': 'CALCULATED', 'sri_v2': sri, 'sri_base': base, 'gain_par_course': gain_course, 'niveau_max': niveau, 'age_mult': age_mult, 'flags': flags}


def executer_sri_v2(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='SRI_v2', actif=True)
    details = evaluer_sri_v2(partant, course)
    result.details = details
    result.flags = details.get('flags', [])
    # Le document maître inclut SRI_v2 dans PCH_FINAL. La valeur reste
    # entièrement décomposée dans details, mais sa contribution numérique doit
    # être propagée au score du module.
    result.score = float(details.get('sri_v2') or 0.0) if details.get('status') == 'CALCULATED' else 0.0
    result.details['impact_pch'] = result.score
    return result


SF_DEFS: Dict[str, Tuple[str, float]] = {
    'SF-01': ('F_PERF', 4), 'SF-02': ('F_PERF', 3), 'SF-03': ('F_PERF', 4), 'SF-04b': ('F_PERF', 5), 'SF-05': ('F_PERF', 4), 'SF-06': ('F_PERF', 3),
    'SF-07': ('F_PHYS', 3), 'SF-08': ('F_PHYS', 3), 'SF-09': ('F_PHYS', 2), 'SF-10': ('F_PHYS', 4),
    'SF-11': ('F_COND', 3), 'SF-12': ('F_COND', 4), 'SF-13': ('F_COND', 2), 'SF-14': ('F_COND', 3), 'SF-15': ('F_COND', 5), 'SF-16': ('F_COND', 4),
    'SF-17': ('F_MARKET', 2), 'SF-18': ('F_MARKET', 4), 'SF-19': ('F_MARKET', 4), 'SF-20': ('F_MARKET', 3),
    'SF-21': ('F_CONTEXT', 4), 'SF-22': ('F_CONTEXT', 3), 'SF-23': ('F_CONTEXT', 2), 'SF-24': ('F_CONTEXT', 4),
}


def _module_score(partant: Partant, name: str) -> float | None:
    for module in getattr(partant, 'modules_results', []):
        if module.nom == name and module.actif:
            return float(module.score)
    return None


def evaluer_csf(partant: Partant, course: Course) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    cote = _num(partant.cote)
    age = _num(partant.age)
    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    active: Dict[str, Dict[str, Any]] = {}
    def add(code: str, condition: bool | None):
        family, points = SF_DEFS[code]
        if condition is True:
            active[code] = {'family': family, 'points': points, 'status': 'ACTIVE'}
        elif condition is None:
            active[code] = {'family': family, 'points': points, 'status': 'UNPROVEN'}
        else:
            active[code] = {'family': family, 'points': points, 'status': 'INACTIVE'}

    top3_8 = raw.get('top3_8j'); top3_15 = raw.get('top3_15j'); top3_30 = _num(raw.get('top3_30j'))
    add('SF-01', bool(top3_8) if top3_8 is not None else None)
    add('SF-02', bool(top3_15) and not bool(top3_8) if top3_15 is not None else None)
    add('SF-03', top3_30 >= 2 if top3_30 is not None else None)
    pente = _num(raw.get('pente_score'))
    pente_condition = pente >= .07 if pente is not None else None
    add('SF-04b', pente_condition)
    if pente_condition is True:
        active['SF-04b']['points'] = 5.0 if pente >= .15 else 3.0
        active['SF-04b']['classification'] = 'PENTE_FORTE' if pente >= .15 else 'PENTE_MODEREE'
    taux_top5 = _num(raw.get('taux_top5_carriere'))
    taux_top3 = _num(raw.get('taux_top3_carriere'))
    add('SF-05', taux_top5 > .55 if taux_top5 is not None else None)
    add('SF-06', taux_top3 > .35 if taux_top3 is not None else None)
    terrain = _module_score(partant, 'MODULE_TERRAIN_DYN')
    add('SF-07', terrain >= 8 if terrain is not None else None)
    incidents = _num(raw.get('incidents_10_dernieres'))
    add('SF-08', incidents == 0 if incidents is not None else None)
    if discipline.startswith('TROT'):
        age_ok = 6 <= age <= 9 if age is not None else None
    elif discipline == 'PLAT':
        age_ok = 3 <= age <= 5 if age is not None else None
    else:
        age_ok = 6 <= age <= 10 if age is not None else None
    add('SF-09', age_ok)
    iff = _module_score(partant, 'IFF_v2')
    add('SF-10', iff >= 8 if iff is not None else None)
    add('SF-11', bool(raw.get('changement_equipement_positif')) if raw.get('changement_equipement_positif') is not None else None)
    bsc = _module_score(partant, 'BSC_v3'); bsh = _module_score(partant, 'BSH_v3v4')
    add('SF-12', bsc >= 8 if bsc is not None else None)
    stability = raw.get('pas_changement_equipe')
    add('SF-13', bool(stability) if stability is not None else None)
    add('SF-14', bool(raw.get('distance_habituelle')) if raw.get('distance_habituelle') is not None else None)
    add('SF-15', bsh >= 12 and bsc >= 8 if bsh is not None and bsc is not None else None)
    recul = _module_score(partant, 'MODULE_RECUL')
    add('SF-16', recul >= 8 if recul is not None and course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE) and course.est_handicap else None)
    delta = _num(raw.get('delta_cote_snapshots'))
    add('SF-17', abs(delta) < .05 if delta is not None else None)
    sov = _num(raw.get('sov_v2'))
    add('SF-18', sov >= .07 if sov is not None else None)
    delta_long = _num(raw.get('delta_long'))
    add('SF-19', delta_long > .25 if delta_long is not None else None)
    add('SF-20', bool(raw.get('valeur_pmu_stable_3_courses')) if raw.get('valeur_pmu_stable_3_courses') is not None else None)
    dist = _module_score(partant, 'MODULE_DIST_ADAPT')
    add('SF-21', dist >= 10 and bool(raw.get('specialiste_confirme')) if dist is not None and raw.get('specialiste_confirme') is not None else None)
    add('SF-22', bool(raw.get('b04_actif')) if raw.get('b04_actif') is not None else None)
    add('SF-23', course.nb_partants < 10 if course.nb_partants is not None else None)
    add('SF-24', recul >= 10 if recul is not None else None)
    active_rows = [row for row in active.values() if row['status'] == 'ACTIVE']
    families = {row['family'] for row in active_rows}
    coeff = {1: .50, 2: .65, 3: .80, 4: .85, 5: .92}.get(len(families), .92 if len(families) > 5 else 0.0)
    bonus = min(50.0, sum(row['points'] for row in active_rows) * coeff)
    details = {'status': 'CALCULATED' if active else 'UNPROVEN', 'signals': active, 'sum_sf_pts': sum(row['points'] for row in active_rows), 'families_active': sorted(families), 'synergy_coefficient': coeff, 'bonus_csf': bonus, 'csf_norm': bonus / 50.0}
    return details


def executer_csf(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='CSF', actif=True)
    details = evaluer_csf(partant, course)
    result.score = 0.0
    result.details = details
    result.flags = [code for code, row in details['signals'].items() if row['status'] == 'ACTIVE']
    return result


def evaluer_pdq(partant: Partant, course: Course) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    premiere_course = raw.get('premiere_course') is True or raw.get('cheval_inedit') is True or raw.get('nb_courses_total') == 0
    if premiere_course:
        return {'status': 'CALCULATED', 'pdq': 0.0, 'contribution': 0.0, 'flags': ['RAH136_NOEUF_PDQ_NEUTRALISE'], 'rah136_inedit': True}
    taux = _num(raw.get('taux_top5_carriere'))
    nb = _num(raw.get('nb_courses', raw.get('courses_total')))
    cote = _num(partant.cote)
    kill = bool(raw.get('kill_list')) or any(flag in {'STAB_DQ_SERIE_CRITIQUE', 'KILL_LIST_M25_EQUIVALENT'} for module in getattr(partant, 'modules_results', []) for flag in module.flags)
    flags: List[str] = []
    if None in (taux, nb, cote):
        return {'status': 'UNPROVEN', 'pdq': 0.0, 'contribution': 0.0, 'flags': ['PDQ_DATA_NC']}
    active = taux >= .60 and nb >= 8 and cote >= 12 and not kill
    regularite_sans_victoire = taux >= .60 and _num(raw.get('taux_victoires', raw.get('taux_victoires_carriere'))) is not None and _num(raw.get('taux_victoires', raw.get('taux_victoires_carriere'))) < .15
    contribution = 1.0 if active else 0.0
    rah110 = {'status': 'NOT_APPLICABLE' if not active else 'UNPROVEN', 'factor': None, 'valeur_actuelle': None, 'valeur_meilleure': None}
    m30_extended = _num(raw.get('nb_top3_consecutifs_sans_victoire')) is not None and _num(raw.get('nb_top3_consecutifs_sans_victoire')) >= 5
    pdq_overlap = _num(raw.get('pdq_pente_overlap_pct', raw.get('pdq_sources_overlap_pct')))
    if active and pdq_overlap is not None and pdq_overlap > .60:
        contribution = 1.0 + (contribution - 1.0) * .50
        flags.append('RAH152_PDQ_MULT_CORRIGE')
    if active:
        if regularite_sans_victoire:
            contribution = min(contribution, .50)
            flags.append('PDQ_REGULARITE_SANS_VICTOIRE')
        valeur = _num(raw.get('valeur_actuelle', raw.get('valeur_pmu')))
        meilleure = _num(raw.get('valeur_meilleure'))
        rah110.update({'valeur_actuelle': valeur, 'valeur_meilleure': meilleure})
        if meilleure is None:
            flags.append('VALEUR_MEILLEURE_ABSENTE')
        elif valeur is not None and valeur == meilleure:
            contribution *= 0.0; rah110.update({'status': 'APPLIED', 'factor': 0.0}); flags.append('PDQ_ANNULE')
        elif valeur is not None and valeur > meilleure - 2:
            contribution *= .5; rah110.update({'status': 'APPLIED', 'factor': 0.5}); flags.append('PDQ_MODERE')
        elif valeur is not None:
            rah110.update({'status': 'CALCULATED', 'factor': 1.0})
        if _num(raw.get('nb_courses_quinte')) == 0 and nb < 15 and not bool(raw.get('m25_classe_superieure_exempte')):
            contribution *= .5; flags.append('PDQ_PREMIER_QUINTE')
        pattern = str(raw.get('pattern_incidents', '')).upper()
        stab = _num(raw.get('stab_pch'))
        if pattern in {'CHANGEANTE', 'SERIES'} and stab is not None and stab < -10:
            contribution = 0.0; flags.append('PDQ_ANNULE_INSTABILITE')
        if 8 <= nb <= 11:
            contribution *= .75; flags.append('PDQ_PETIT_ECHANTILLON')
        elif 12 <= nb <= 14:
            contribution *= .90; flags.append('PDQ_PETIT_ECHANTILLON')
    rah137_applicable = bool(raw.get('pdq_garde_1')) and str(getattr(course, 'hippodrome', '') or '').upper() == 'VINCENNES' and (raw.get('vincennes_hiver_elite') is True or raw.get('montee_depuis_reunion_regionale') is True)
    if rah137_applicable and contribution > 0:
        contribution *= .40 / .50
        flags.append('RAH137_PDQ_GARDE1_X040')
    if m30_extended:
        raw['m30_extended_malus'] = -4.0
        flags.append('M30_ETENDU_5_TOP3_SANS_VICTOIRE')
    return {'status': 'CALCULATED', 'pdq': 1.0 if active else 0.0, 'contribution': contribution, 'flags': flags, 'taux_top5_carriere': taux, 'nb_courses': nb, 'cote': cote, 'rah152_overlap_pct': pdq_overlap, 'rah152_overlap_applied': 'RAH152_PDQ_MULT_CORRIGE' in flags, 'rah252_regularite_sans_victoire': regularite_sans_victoire, 'm30_extended_malus': -4.0 if m30_extended else 0.0, 'rah110': rah110, 'rah137': {'status': 'APPLIED' if rah137_applicable else 'NOT_TRIGGERED', 'factor': .40 if rah137_applicable else .50, 'conditions': {'pdq_garde_1': bool(raw.get('pdq_garde_1')), 'vincennes': str(getattr(course, 'hippodrome', '') or '').upper() == 'VINCENNES', 'hiver_elite': raw.get('vincennes_hiver_elite') is True, 'montee_regionale': raw.get('montee_depuis_reunion_regionale') is True}}}


def executer_pdq(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='PDQ', actif=True)
    details = evaluer_pdq(partant, course)
    result.score = 0.0
    result.details = details
    result.flags = details.get('flags', [])
    if details.get('contribution', 0.0) > 0:
        partant.tocard_score = max(partant.tocard_score, min(1.0, details['contribution'] * .18))
    return result
