"""Évaluation traçable du catalogue Ghost D01–D43."""
from __future__ import annotations

from typing import Any, Dict

from engine.models import Course, Partant, ModuleResult, Discipline


GHOST_WEIGHTS = {
    'D01': .12, 'D02': .12, 'D03': .08, 'D04': .08, 'D05': .10, 'D06': .12, 'D07': .12, 'D08': .10, 'D09': .08, 'D09BIS': 3.0,
    'D10': .12, 'D11': .08, 'D12': .10, 'D13': .25, 'D14': .10, 'D15': .10, 'D16': .08, 'D17': .12, 'D18': .08, 'D19': .06,
    'D20': .10, 'D21': .08, 'D22': .30, 'D23': .10, 'D24': .10, 'D25': .10, 'D26': .10, 'D27': 0.0, 'D28': .08, 'D29': .12,
    'D30': .08, 'D31': .08, 'D32': .10, 'D33': .12, 'D34': .12, 'D35': .22, 'D36': .20, 'D37': .10, 'D38': .10, 'D39': .10,
    'D40': .10, 'D41': .08, 'D42': .10, 'D43': .22,
}


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def _status(value, required: bool = False):
    if value is True:
        return 'ACTIVE'
    if value is False:
        return 'INACTIVE'
    return 'NC' if required else 'UNPROVEN'


def _common(p: Partant, course: Course) -> Dict[str, Any]:
    cote = _num(p.cote)
    icp = _num(_raw(p, 'icp_global'))
    terrain_module = next((m.score for m in p.modules_results if m.nom == 'MODULE_TERRAIN_DYN'), None)
    dist_module = next((m.score for m in p.modules_results if m.nom == 'MODULE_DIST_ADAPT'), None)
    recul_module = next((m.score for m in p.modules_results if m.nom == 'MODULE_RECUL'), None)
    poids_module = next((m.score for m in p.modules_results if m.nom == 'MODULE_POIDS'), None)
    h2h = _num(_raw(p, 'h2h_avg'))
    tandem_rate = _num(_raw(p, 'taux_top5_tandem'))
    tandem_courses = _num(_raw(p, 'nb_courses_ensemble'))
    return {
        'cote': cote, 'icp': icp, 'terrain_module': terrain_module, 'dist_module': dist_module,
        'recul_module': recul_module, 'poids_module': poids_module, 'h2h': h2h,
        'tandem_rate': tandem_rate, 'tandem_courses': tandem_courses,
    }


def calculer_ee_score(partant: Partant) -> Dict[str, Any]:
    """RAH-169 : EE_SCORE cumulé sur les trois dernières courses."""
    raw = getattr(partant, 'raw_data', {}) or {}
    categories = raw.get('ee_categories_3', raw.get('ee_categories'))
    weights = {'A': 1.0, 'B': .70, 'C': .50}
    recency = (1.0, .65, .35)
    if isinstance(categories, (list, tuple)):
        details = []
        total = 0.0
        for index, category in enumerate(categories[:3]):
            cat = str(category).upper() if category is not None else ''
            if cat not in weights:
                continue
            contribution = weights[cat] * recency[index]
            total += contribution
            details.append({'course_index': index + 1, 'category': cat, 'weight_excuse': weights[cat], 'weight_recency': recency[index], 'contribution': contribution})
        source_list = raw.get('ee_sources_3', raw.get('ee_sources', []))
        source_count = len([source for source in source_list if source]) if isinstance(source_list, (list, tuple)) else 0
        return {'status': 'CALCULATED' if details else 'UNPROVEN', 'ee_score': total if details else None, 'courses_documented': len(details), 'sources_documented': source_count, 'details': details, 'ift_penalty': -2 if details and source_count < 2 else 0}
    explicit = _num(raw.get('ee_score'))
    if explicit is not None:
        return {'status': 'EXPLICIT_SOURCE', 'ee_score': explicit, 'courses_documented': _num(raw.get('ee_courses_documented'), 0), 'sources_documented': _num(raw.get('ee_sources_documented'), 0), 'details': [], 'ift_penalty': -2 if _num(raw.get('ee_sources_documented'), 0) < 2 else 0}
    return {'status': 'UNPROVEN', 'ee_score': None, 'courses_documented': 0, 'sources_documented': 0, 'details': [], 'ift_penalty': 0}


def evaluer_ghost(partant: Partant, course: Course) -> Dict[str, Any]:
    ee = calculer_ee_score(partant)
    raw = getattr(partant, 'raw_data', {}) or {}
    if ee.get('ee_score') is not None:
        raw['ee_score'] = ee['ee_score']
    raw['ee_details'] = ee
    partant.raw_data = raw
    c = _common(partant, course)
    cote, icp = c['cote'], c['icp']
    rules: Dict[str, Dict[str, Any]] = {}

    def add(code, condition, reason, required=False, value=None):
        rules[code] = {
            'code': code,
            'status': _status(condition, required),
            'value': GHOST_WEIGHTS.get(code, 0.0) if condition is True else 0.0,
            'condition': condition,
            'reason': reason,
        }

    add('D01', cote is not None and cote >= 15 and _num(_raw(partant, 'delta_cote_pct')) is not None and abs(_num(_raw(partant, 'delta_cote_pct'))) < 10 and _num(_raw(partant, 'top5_6_courses')) is not None and _num(_raw(partant, 'top5_6_courses')) >= 2, 'cote stable, forme correcte, jamais en avant', True)
    ee_score = _num(_raw(partant, 'ee_score'))
    d02_active = ee_score is not None and ee_score >= .35 and cote is not None
    add('D02', d02_active and ((ee_score >= 1.00 and cote >= 10) or (ee_score >= .65 and cote >= 8) or (ee_score >= .35)), 'EE_SCORE et cote', True)
    if d02_active and rules['D02']['status'] == 'ACTIVE':
        if ee_score >= 1.00 and cote >= 10:
            rules['D02'].update({'value': .12, 'tier': 'STRICT', 'flag': 'EE_FORT'})
        elif ee_score >= .65 and cote >= 8:
            rules['D02'].update({'value': .08, 'tier': 'DEGRADE', 'flag': 'EE_MODERE'})
        elif cote >= 6:
            rules['D02'].update({'value': .04, 'tier': 'MINIMAL', 'flag': 'EE_LEGER'})
        else:
            rules['D02'].update({'value': .02, 'tier': 'DERNIER_RECOURS', 'flag': 'EE_DERNIER_RECOURS'})
    add('D03', _num(_raw(partant, 'taux_top1_20j')) is not None and _num(_raw(partant, 'taux_top1_20j')) >= .15 and (_num(_raw(partant, 'icp_driver'), 0) or 0) < 1, 'driver efficace peu cité', True)
    add('D04', _num(_raw(partant, 'classement_national_entraineur')) is not None and _num(_raw(partant, 'classement_national_entraineur')) <= 15 and (icp or 0) == 0, 'entraîneur sous-radar', True)
    add('D05', _num(partant.age) is not None and partant.age <= 5 and bool(_raw(partant, 'progression_rang_3')) and cote is not None and cote >= 12, 'jeune en progression silencieuse', True)
    add('D06', c['terrain_module'] is not None and c['terrain_module'] >= 10 and cote is not None and cote >= 15 and (icp or 0) <= 1, 'terrain sous-évalué', True)
    add('D07', _num(_raw(partant, 'top5_hippodrome')) is not None and _num(_raw(partant, 'top5_hippodrome')) >= 3 and cote is not None and cote >= 12 and (icp or 0) <= 2, 'spécialiste hippodrome', True)
    add('D08', bool(_raw(partant, 'retour_blessure_documente')) and bool(_raw(partant, 'retour_precedent_top3')) and cote is not None and cote >= 12, 'retour de blessure', True)
    add('D09', bool(_raw(partant, 'changement_equipement')) and _num(_raw(partant, 'mentions_presse_equipement'), 0) == 0 and cote is not None and cote >= 12, 'équipement peu remarqué', True)
    add('D09BIS', bool(_raw(partant, 'deferrage_ponctuel_nouveau')) and str(getattr(course.discipline, 'value', course.discipline)).upper().startswith('TROT'), 'déferrage ponctuel', True, 3.0)
    add('D10', c['tandem_rate'] is not None and c['tandem_rate'] >= .70 and (c['tandem_courses'] or 0) >= 5 and cote is not None and cote >= 12, 'tandem historique', True)
    add('D11', not bool(_raw(partant, 'historique_distances_perf')) and bool(_raw(partant, 'profil_distance_coherent')) and cote is not None and cote >= 15, 'distance non testée mais profil cohérent', True)
    add('D12', not bool(_raw(partant, 'historique_hippodrome')) and bool(_raw(partant, 'profil_gru_favorable')) and cote is not None and cote >= 15, 'hippodrome neuf et GRU favorable', True)
    add('D13', bool(_raw(partant, 'premieres_oeilleres')) and (bool(_raw(partant, 'historique_entraineur_oeilleres')) or bool(_raw(partant, 'changement_equipement'))), 'premières œillères', True)
    add('D14', bool(_raw(partant, 'performances_etrangeres_non_valorisees')) and cote is not None and cote >= 15, 'performance étrangère', True)
    add('D15', c['h2h'] is not None and c['h2h'] >= 8 and cote is not None and cote >= 12, 'H2H favorable', True)
    add('D16', bool(_raw(partant, 'changement_categorie')) and bool(_raw(partant, 'adaptation_categorie_prouvee')) and cote is not None and cote >= 12, 'changement de catégorie', True)
    add('D17', _num(_raw(partant, 'mpa_champ'), 0) >= 15 and cote is not None and cote >= 15 and (icp or 0) <= 1, 'MPA adapté ignoré', True)
    add('D18', bool(_raw(partant, 'jument_retour_maternite')) and bool(_raw(partant, 'historique_avant_pause_positif')) and cote is not None and cote >= 15, 'jument retour', True)
    add('D19', _num(_raw(partant, 'h2h_bipartite'), 0) >= 5 and cote is not None and cote >= 12, 'H2H bipartite', True)
    add('D20', bool(_raw(partant, 'rang_trompeur')) and cote is not None and cote >= 12, 'classement trompeur', True)
    add('D21', bool(_raw(partant, 'petit_entraineur_surperformant')) and cote is not None and cote >= 15, 'petit entraîneur', True)
    add('D22', (icp or 0) <= 1 and (_num(_raw(partant, 'valeur_pmu_rang_champ')) or 99) <= 3, 'manque de confiance public', True)
    add('D23', _num(_raw(partant, 'top5_consecutifs_sans_victoire'), 0) >= 3 and cote is not None and cote >= 15, 'stagnation proche rupture', True)
    add('D24', _num(_raw(partant, 'top5_meme_depart'), 0) >= 4 and cote is not None and cote >= 15 and (icp or 0) <= 1, 'configuration départ', True)
    add('D25', bool(_raw(partant, 'premiere_association_jockey_entraineur')) and _num(_raw(partant, 'classement_jockey'), 99) <= 10 and _num(_raw(partant, 'classement_entraineur'), 99) <= 10 and cote is not None and cote >= 15, 'première association', True)
    add('D26', bool(_raw(partant, 'top5_parcours_difficile')) and cote is not None and cote >= 15 and (icp or 0) <= 1, 'parcours difficile', True)
    add('D27', False, 'obsolète, jamais utilisé')
    add('D28', bool(_raw(partant, 'workout_favorable')) and (icp or 0) == 0 and cote is not None and cote >= 15, 'workout discret', True)
    add('D29', bool(_raw(partant, 'rk_top2_champ')) and cote is not None and cote >= 12 and str(getattr(course.discipline, 'value', course.discipline)).upper().startswith('TROT'), 'RK top2', True)
    add('D30', bool(_raw(partant, 'progression_position_400m')) and cote is not None and cote >= 12, 'progression secteur final', True)
    add('D31', bool(_raw(partant, 'changement_discipline_reussi')) and cote is not None and cote >= 15, 'changement discipline', True)
    add('D32', bool(_raw(partant, 'profil_anti_rythme_solide')) and cote is not None and cote >= 15, 'profil anti-rythme', True)
    add('D33', c['poids_module'] is not None and c['poids_module'] >= 15 and cote is not None and cote >= 15 and (icp or 0) <= 1, 'petit poids', True)
    add('D34', c['recul_module'] is not None and c['recul_module'] >= 12 and cote is not None and cote >= 15 and (icp or 0) <= 1, 'recul favorable', True)
    add('D35', bool(_raw(partant, 'survalue_fort')) and cote is not None and cote >= 12, 'survalorisation poids', True)
    add('D36', c['recul_module'] is not None and c['recul_module'] >= 10 and cote is not None and cote >= 12, 'recul sous-coté', True)
    add('D37', c['dist_module'] is not None and c['dist_module'] >= 12 and cote is not None and cote >= 15 and (icp or 0) <= 1, 'progression parcours', True)
    add('D38', _num(_raw(partant, 'h2h_04'), 0) >= 8 and cote is not None and cote >= 12, 'tandem H2H', True)
    add('D39', _num(_raw(partant, 'tandem_bonus'), 0) >= 10 and (icp or 0) <= 1 and cote is not None and cote >= 12, 'tandem peu cité', True)
    add('D40', bool(_raw(partant, 'overbet_souscote')) and cote is not None and cote >= 15, 'OVERBET sous-coté', True)
    add('D41', None, 'convergence calculée après activation des autres signaux', True)
    add('D42', bool(_raw(partant, 'deferrage_4_pieds')) and course.distance <= 2200 and bool(_raw(partant, 'autostart')), 'D4 autostart', True)
    add('D43', cote is not None and cote >= 12 and _num(_raw(partant, 'classement_driver_national'), 99) <= 20, 'driver d’exception', True)

    active_values = [float(v['value']) for v in rules.values() if v['status'] == 'ACTIVE' and v['code'] != 'D09BIS']
    active_count = len(active_values)
    if active_count >= 3:
        rules['D41'] = {'code': 'D41', 'status': 'ACTIVE', 'value': .08, 'condition': True, 'reason': '3 signaux Ghost actifs ou plus'}
    elif rules['D41']['status'] == 'UNPROVEN':
        rules['D41']['status'] = 'NC'
    total = min(1.0, sum(active_values) + (rules.get('D41', {}).get('value') or 0))
    return {'rules': rules, 'tocard_score': total, 'active_count': active_count, 'status': 'CALCULATED' if active_count else 'NC'}


def executer_ghost(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='GHOST', actif=True)
    details = evaluer_ghost(partant, course)
    result.score = details['tocard_score']
    result.details = details
    result.flags = [code for code, value in details['rules'].items() if value['status'] == 'ACTIVE']
    partant.ghost_details = details
    partant.tocard_score = max(partant.tocard_score, details['tocard_score'])
    return result
