"""Présentation indicatrice et preuves de sortie RAH-201."""
from __future__ import annotations

from typing import Any, Dict

from engine.models import Course


def _primary_rule(item: Dict[str, Any]) -> str | None:
    flags = item.get('familles_actives') or []
    if item.get('stab_ticket_policy', {}).get('active'):
        return 'STAB'
    if item.get('p5p6_score') is not None:
        return 'RAH-150/P5P6'
    if item.get('ssfo_bonus', 0) >= 5:
        return 'RAH-271/SSFO'
    if item.get('tocard_score', 0) >= .25:
        return 'RAH-95/TOCARD'
    if flags:
        return str(sorted(flags)[0])
    if item.get('ordre_score') is not None:
        return 'ORDRE_SCORE'
    return None


def evaluer_rah201(course: Course, ticket_report: Dict[str, Any], supra_report: Dict[str, Any] | None = None) -> Dict[str, Any]:
    ticket = ticket_report.get('ticket_final', {}) or {}
    entries = {}
    missing_probability = []
    missing_justification = []
    for position, item in ticket.items():
        numero = item.get('numero')
        partant = next((p for p in course.partants if p.numero == numero), None)
        raw = getattr(partant, 'raw_data', {}) if partant else {}
        p_top5 = raw.get('p_top5')
        if p_top5 in (None, '', 'NC', 'UNPROVEN'):
            missing_probability.append(numero)
        details = getattr(partant, 'longshots_details', {}) if partant else {}
        entries[position] = {
            'numero': numero,
            'nom': item.get('nom'),
            'regle_principale': _primary_rule(item),
            'justification_status': 'CALCULATED' if _primary_rule(item) else 'UNPROVEN',
            'confiance_reduite': bool(raw.get('confiance_reduite')),
            'p_top5': p_top5 if p_top5 not in ('', 'NC') else None,
            'longshot_slot': 'F2_ALPHA' if details.get('gouvernance') == 'F2_ALPHA' else 'OBSERVATION' if details.get('LS_FINAL') is not None else 'AUCUN_CANDIDAT_ALPHA',
        }
        if not entries[position]['regle_principale']:
            missing_justification.append(numero)
    coverage = ticket_report.get('coverage_ticket_top5')
    if coverage in (None, '', 'NC', 'UNPROVEN'):
        coverage = None
    return {
        'rule': 'RAH-201',
        'status': 'CALCULATED' if ticket else 'UNPROVEN',
        'ticket_entries': entries,
        'missing_p_top5': missing_probability,
        'missing_justification': missing_justification,
        'coverage_top5_ticket': coverage,
        'coverage_status': 'OBSERVED' if coverage is not None else 'UNPROVEN',
        'supra_detail': (supra_report or {}).get('modifications_appliquees', []),
        'format_pari_suggere': None,
        'format_pari_status': 'INDICATIF_NON_CALCULE',
        'no_invented_probability': True,
    }
