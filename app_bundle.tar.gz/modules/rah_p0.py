"""Règles RAH P0 restantes.

Le module ne fabrique aucune donnée. Chaque décision expose ses entrées, sa formule,
son statut et ses flags afin de pouvoir être auditée dans l'export final.
"""
from __future__ import annotations

import math
from typing import Any, Dict, Iterable, Optional

from engine.models import Course, Partant


def _raw(partant: Partant, key: str, default=None):
    return (getattr(partant, 'raw_data', {}) or {}).get(key, default)


def _num(value, default: Optional[float] = None) -> Optional[float]:
    try:
        if value in (None, '', 'NC', 'UNPROVEN'):
            return default
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def _observed_count(raw: Dict[str, Any], keys: Iterable[str]) -> Optional[int]:
    for key in keys:
        if key in raw and raw[key] not in (None, '', 'NC', 'UNPROVEN'):
            value = _num(raw[key])
            if value is not None:
                return max(0, int(value))
    for key in ('rangs_4_dernieres', 'rangs_dernieres', 'positions_dernieres'):
        value = raw.get(key)
        if isinstance(value, (list, tuple)):
            observed = [x for x in value if _num(x) is not None]
            if observed:
                return len(observed)
    return None


def _trial_days(raw: Dict[str, Any]) -> Optional[float]:
    for key in ('trial_jours_avant_course', 'essai_jours_avant_course', 'prepared_trial_days'):
        value = _num(raw.get(key))
        if value is not None:
            return value
    if raw.get('trial_documented') is True or raw.get('essai_documente') is True:
        # La preuve booléenne sans âge ne permet pas d'établir le seuil <30 jours.
        return None
    return None


def _market_top2(partant: Partant, course: Course) -> Optional[bool]:
    raw_rank = _num(_raw(partant, 'rang_marche'))
    if raw_rank is not None:
        return raw_rank <= 2
    odds = [(p.numero, _num(p.cote)) for p in getattr(course, 'partants', [])]
    valid = sorted((cote, numero) for numero, cote in odds if cote is not None and cote > 0)
    if not valid:
        return None
    return any(numero == partant.numero for _, numero in valid[:2])


def evaluer_rah244(partant: Partant, course: Course) -> Dict[str, Any]:
    """Évalue RAH-244(a)/(b) sans inventer de malus absent du maître.

    RAH-244(a) réduit de moitié le poids d'un PENTE_SCORE établi sur une seule
    performance jusqu'à confirmation par une seconde performance.
    RAH-244(b) distingue une rentrée préparée par un trial documenté de moins de
    30 jours d'une rentrée sans préparation. Le signal de risque ne devient
    actionnable que si la confiance intrinsèque est >=0,65 et que le cheval est
    favori top-2 ou cote <=6/1.
    """
    raw = dict(getattr(partant, 'raw_data', {}) or {})
    pente = _num(raw.get('pente_score'))
    pente_n = _observed_count(raw, ('pente_score_n', 'pente_n_courses', 'pente_observations', 'nb_courses_pente'))
    if pente is None:
        pente_status = 'NC'
        pente_factor = None
        pente_effective = None
        pente_flag = 'PENTE_SCORE_ABSENT'
    elif pente_n is None:
        pente_status = 'UNPROVEN'
        pente_factor = None
        pente_effective = None
        pente_flag = 'PENTE_SCORE_NOMBRE_PERFORMANCES_INCONNU'
    elif pente_n == 1:
        pente_status = 'CALCULATED'
        pente_factor = 0.50
        pente_effective = pente * pente_factor
        pente_flag = 'PENTE_SCORE_NON_CONFIRME'
    else:
        pente_status = 'CALCULATED'
        pente_factor = 1.0
        pente_effective = pente
        pente_flag = 'PENTE_SCORE_CONFIRME'

    absence = _num(raw.get('absence_jours', raw.get('delai_j')))
    trial_days = _trial_days(raw)
    retour = raw.get('retour_absence_2mois') is True or (absence is not None and absence > 60)
    prepared = retour and trial_days is not None and 0 <= trial_days < 30
    unprepared = retour and trial_days is not None and trial_days >= 30
    preparation_status = 'CALCULATED' if not retour or trial_days is not None else 'UNPROVEN'

    confidence = _num(raw.get('confiance_intrinseque', raw.get('risk_signal_confidence')))
    top2 = _market_top2(partant, course)
    cote = _num(partant.cote)
    favori_condition = (cote is not None and cote <= 6) or top2 is True
    risk_candidate = bool(unprepared and confidence is not None and confidence >= .65 and favori_condition)

    # Le maître prévoit une réduction de 30% pour une rentrée préparée.
    # Le malus de base est fourni par les règles appelantes; aucune valeur n'est
    # inventée ici. On expose donc uniquement le multiplicateur normatif.
    preparation_factor = 0.70 if prepared else 1.0 if (not retour or unprepared) else None
    existing_long_absence = bool(raw.get('rah169_active') or raw.get('rah206_active'))
    cumulative_cap = 'APPLIED' if existing_long_absence and risk_candidate else 'NOT_APPLICABLE'

    status = 'CALCULATED' if pente_status == 'CALCULATED' or preparation_status == 'CALCULATED' else 'UNPROVEN'
    flags = [pente_flag]
    if prepared:
        flags.append('RENTREE_PREPAREE_TRIAL_LT_30J')
    elif unprepared:
        flags.append('RENTREE_SANS_PREPARATION')
    elif retour and preparation_status == 'UNPROVEN':
        flags.append('RENTREE_PREPARATION_INCONNUE')
    if risk_candidate:
        flags.append('RAH244_RISK_DEGRADE')
    if existing_long_absence:
        flags.append('RAH244_CUMUL_RAH169_206_INSPECTE')

    result = {
        'status': status,
        'rule': 'RAH-244',
        'subrules': {
            'RAH-244(a)': {
                'status': pente_status,
                'pente_score': pente,
                'observed_performances': pente_n,
                'weight_factor': pente_factor,
                'pente_score_effective': pente_effective,
                'flag': pente_flag,
            },
            'RAH-244(b)': {
                'status': preparation_status,
                'absence_jours': absence,
                'trial_jours_avant_course': trial_days,
                'rentree': retour,
                'prepared': prepared,
                'unprepared': unprepared,
                'preparation_factor': preparation_factor,
                'confidence_intrinseque': confidence,
                'market_top2': top2,
                'cote_le_6': cote is not None and cote <= 6,
                'favori_condition': favori_condition,
                'risk_candidate': risk_candidate,
                'cumulative_cap_rah169_206': cumulative_cap,
            },
        },
        'flags': flags,
        'inputs': {
            'pente_score': pente,
            'pente_observed_count': pente_n,
            'absence_jours': absence,
            'trial_jours_avant_course': trial_days,
            'confiance_intrinseque': confidence,
            'cote': cote,
            'market_top2': top2,
        },
        'formula': 'PENTE effective = PENTE × 0.50 si une seule performance; rentrée préparée = facteur malus 0.70; risque actionnable si rentrée sans préparation + confiance >=0.65 + favori top-2 ou cote<=6/1',
        'evidence_required': ['source_pente', 'source_historique_absence', 'source_trial_si_disponible', 'source_confiance'],
    }
    return result


def executer_rah244(course: Course) -> Dict[str, Any]:
    """Calcule RAH-244 pour tous les partants et prépare les entrées aval."""
    report = {'rule': 'RAH-244', 'status': 'CALCULATED', 'partants': {}, 'risk_candidates': [], 'flags': []}
    for partant in course.partants:
        result = evaluer_rah244(partant, course)
        raw = getattr(partant, 'raw_data', None)
        if raw is None:
            partant.raw_data = {}
            raw = partant.raw_data
        effective = result['subrules']['RAH-244(a)'].get('pente_score_effective')
        if effective is not None:
            raw['rah244_pente_score_effective'] = effective
            raw['rah244_pente_factor'] = result['subrules']['RAH-244(a)'].get('weight_factor')
        raw['rah244_details'] = result
        partant.extended_metrics['rah244'] = result
        for flag in result['flags']:
            if flag not in partant.flags:
                partant.flags.append(flag)
        if result['subrules']['RAH-244(b)'].get('risk_candidate'):
            report['risk_candidates'].append({'numero': partant.numero, 'nom': partant.nom, 'confidence': result['subrules']['RAH-244(b)'].get('confidence_intrinseque'), 'flag': 'RAH244_RISK_DEGRADE'})
        report['partants'][str(partant.numero)] = result
    report['flags'] = sorted({flag for item in report['partants'].values() for flag in item.get('flags', [])})
    report['risk_count'] = len(report['risk_candidates'])
    return report
