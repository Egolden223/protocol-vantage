"""Règles RAH prioritaires ajoutées par les dernières sections du protocole."""
from __future__ import annotations

from typing import Any, Dict
from engine.models import Course, Partant, ModuleResult, Discipline


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def evaluer_rah_priorites(partant: Partant, course: Course) -> Dict[str, Any]:
    raw = getattr(partant, 'raw_data', {}) or {}
    cote = _num(partant.cote)
    tranche = 'T1' if cote is not None and cote < 9 else 'T2' if cote is not None and cote <= 15 else 'T3' if cote is not None and cote <= 50 else 'T4' if cote is not None and cote <= 300 else 'NC'
    scores: Dict[str, float] = {}
    flags = []

    valeur = _num(raw.get('valeur_actuelle', raw.get('valeur_pmu')))
    valeur_meilleure = _num(raw.get('valeur_meilleure'))
    valeur_prev = _num(raw.get('valeur_precedente'))
    b04_signal = next((signal for signal in getattr(partant, 'signaux', []) if str(getattr(signal, 'code', '')).upper() == 'B04' and getattr(signal, 'actif', False)), None)
    b04_base = _num(raw.get('b04_brut', getattr(b04_signal, 'valeur', None)))
    rah109 = {'status': 'UNPROVEN', 'factor': None, 'b04_base': b04_base, 'b04_adjusted': None, 'age': partant.age, 'valeur_actuelle': valeur, 'valeur_meilleure': valeur_meilleure}
    if b04_signal is None:
        rah109 = {'status': 'NOT_APPLICABLE', 'factor': None, 'reason': 'B04 absent'}
    elif valeur_meilleure is not None and valeur is not None and b04_base is not None:
        if valeur == valeur_meilleure:
            rah109 = {'status': 'APPLIED', 'factor': 0.0, 'b04_base': b04_base, 'b04_adjusted': 0.0, 'reason': 'valeur_actuelle=valeur_meilleure'}
        elif partant.age is not None and partant.age >= 8 and valeur > valeur_meilleure - 2:
            rah109 = {'status': 'APPLIED', 'factor': 0.5, 'b04_base': b04_base, 'b04_adjusted': b04_base * .5, 'reason': 'age>=8 et valeur_actuelle>valeur_meilleure-2'}
        else:
            rah109 = {'status': 'CALCULATED', 'factor': 1.0, 'b04_base': b04_base, 'b04_adjusted': b04_base}
    raw['rah109_b04'] = rah109
    if rah109.get('status') == 'APPLIED':
        raw['b04_post_rah109'] = rah109.get('b04_adjusted')
    poids = _num(raw.get('poids_actuel_kg', partant.poids))
    poids_prev = _num(raw.get('poids_precedent_kg'))
    baisse_poids = poids_prev - poids if poids is not None and poids_prev is not None else None
    baisse_valeur = valeur_prev - valeur if valeur is not None and valeur_prev is not None else None
    r304 = False
    if tranche in {'T3', 'T4'} and baisse_valeur is not None and baisse_valeur >= 2:
        r304 = True
    if tranche in {'T1', 'T2'} and baisse_valeur is not None and baisse_valeur >= 3:
        r304 = True
    if baisse_poids is not None and baisse_poids >= 1.5:
        r304 = True
    if r304 and not any(m.nom == 'MODULE_POIDS' and m.actif and m.score > 0 for m in partant.modules_results):
        scores['RAH-304'] = 6.0 if tranche in {'T3', 'T4'} else 3.0
        flags.append('BAISSE_POIDS_VALEUR')

    gains = _num(raw.get('gains_totaux'))
    plafond = _num(raw.get('plafond_elimination'))
    if gains is not None and plafond is not None and plafond > 0 and gains <= .95 * plafond:
        if course.discipline == Discipline.PLAT and course.est_handicap:
            scores['RAH-305'] = -4.0
            flags.append('ENGAGEMENT_PLAFOND')
        elif course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE) and not bool(raw.get('victoire_60j')):
            scores['RAH-305'] = 6.0
            flags.append('ENGAGEMENT_EN_OR_TROT')

    equipment = []
    if bool(raw.get('deferrage_4_pieds_premiere')) and not bool(raw.get('d09bis_capture')):
        equipment.append(('D09BIS', 4.0))
    if bool(raw.get('premieres_oeilleres')) and not bool(raw.get('d13_capture')):
        equipment.append(('D13', 3.0))
    if bool(raw.get('changement_driver_top10')) and not bool(raw.get('b11_capture')):
        equipment.append(('B11', 3.0))
    if bool(raw.get('changement_entraineur_top20')) and not bool(raw.get('b12_capture')):
        equipment.append(('B12', 2.0))
    if equipment:
        pts = sum(p for _, p in equipment)
        scores['RAH-306'] = 2.0 if len(equipment) == 1 else min(10.0, pts * 1.5)
        flags.append('CONFIANCE_EQUIPEMENT_FORTE' if pts >= 4 else 'CONFIANCE_EQUIPEMENT')

    press_top5 = _num(raw.get('press_top5_sources'), 0) or 0
    press_distinct = _num(raw.get('press_distinct_sources'), 0) or 0
    icp = _num(raw.get('icp_global', partant.icp_count), 0) or 0
    value_rank = _num(raw.get('valeur_pmu_rang_champ'))
    outsider = tranche in {'T3', 'T4'} or partant.tocard_score >= .20
    r308 = outsider and (press_top5 >= 1 or press_distinct >= 3 or (icp <= 1 and value_rank is not None and value_rank <= 3))
    if r308:
        scores['RAH-308'] = 5.0
        flags.append('CONFIRMATION_PRESSE_LONGSHOT_CONSENSUS')
        partant.tocard_score = min(1.0, partant.tocard_score + .05)

    # RAH-281 : commentaire négatif explicitement documenté et daté < 7 jours.
    commentaire = str(raw.get('commentaire_entraineur', raw.get('commentaire_entraineur_texte', '')) or '').lower()
    commentaire_negatif = bool(raw.get('commentaire_entraineur_negatif')) or any(term in commentaire for term in ('talon d\'achille', 'souvent fautif', 'fautif', 'délicat', 'délicate', 'peu fiable'))
    age_commentaire = _num(raw.get('commentaire_entraineur_age_jours'))
    source_commentaire = str(raw.get('commentaire_entraineur_source', '') or '')
    documented = commentaire_negatif and age_commentaire is not None and age_commentaire < 7 and bool(source_commentaire)
    if documented and not bool(raw.get('stab_meme_fait_commentaire')):
        scores['RAH-281'] = -2.0
        flags.append('COMMENTAIRE_ENTRAINEUR_NEGATIF')

    # RAH-297 : rating qualitatif Turf.bzh, sans inventer de valeur ELO numérique.
    rating = str(raw.get('turf_bzh_avis_qualitatif', raw.get('turf_bzh_avis', '')) or '').strip().upper()
    sigma = _num(raw.get('turf_bzh_sigma', raw.get('sigma_turf_bzh')))
    ssfo_bonus = _num(getattr(partant, 'ssfo_details', {}).get('bonus_ssfo_final')) or 0.0
    rating_haut = rating in {'✅', 'HAUTE', 'HIGH', 'FAVORABLE', 'BONNE_CONFIANCE'}
    if rating_haut and sigma is not None and sigma >= 50:
        if ssfo_bonus >= 3:
            flags.append('RAH297_NON_CUMUL_SSFO')
        else:
            scores['RAH-297'] = 3.0
            flags.append('TURFBZH_AVIS_QUALITATIF')

    justified_failures = raw.get('justified_failures', raw.get('echecs_justifies'))
    rah307_status = 'CALCULATED' if isinstance(justified_failures, (list, tuple, dict)) else 'UNPROVEN'
    rah307 = {'status': rah307_status, 'evidence': justified_failures, 'count': len(justified_failures) if isinstance(justified_failures, (list, tuple, dict)) else None, 'no_invented_cause': True}
    malus_factor = .5 if tranche in {'T3', 'T4'} else 1.0
    excluded_codes = {'M25', 'M17', 'M18', 'STAB_CRITIQUE'}
    negative_codes = [code for code, value in scores.items() if value < 0 and code not in excluded_codes]
    rah310 = {'status': 'CALCULATED', 'tranche': tranche, 'factor': malus_factor, 'negative_codes_considered': negative_codes, 'excluded_codes': sorted(excluded_codes), 'anti_double_count': True, 'applied_in_caller': True}
    if tranche in {'T3', 'T4'}:
        flags.append('MALUS_OUTSIDER_ATTENUE')
    return {'status': 'CALCULATED' if scores or flags or rah109.get('status') in {'APPLIED', 'CALCULATED'} else 'NC', 'scores': scores, 'flags': flags, 'tranche': tranche, 'malus_catalogue_factor': malus_factor, 'equipment_evidence': equipment, 'rah109_b04': rah109, 'rah307': rah307, 'rah310': rah310}


def executer_rah_priorites(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='RAH_PRIORITES', actif=True)
    details = evaluer_rah_priorites(partant, course)
    result.score = sum(details['scores'].values())
    result.flags = details['flags']
    result.details = details
    partant.rah_details = details
    return result
