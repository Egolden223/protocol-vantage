"""
PROTOCOL VANTAGE — Modules Obligatoires
STAB, H2H_GRAPH, MODULE_TERRAIN_DYN, MODULE_DIST_ADAPT, MPA_CHAMP,
TANDEM_BONUS, OVERBET_DETECTOR
+ Conditionnels: MODULE_POIDS, MODULE_RECUL, TACT
"""
from typing import List, Dict, Any
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.models import (
    Course, Partant, ModuleResult, Discipline, Signal
)
from modules.normative import (
    module_stab_normative, module_h2h_normative, module_terrain_normative,
    module_dist_normative, module_mpa_normative, module_overbet_normative,
    module_poids_normative, module_recul_normative, module_tact_normative,
    module_iff_normative, module_nrc_normative, module_bsh_normative,
    module_bsc_normative, module_cre_normative, module_forme_lineaire_normative,
    module_plat01_normative, module_plat02_normative, module_plat03_normative,
    module_plat04_normative, module_trot01_normative, module_trot02_normative,
    module_trot03_normative, module_trot04_normative, module_obs01_normative,
    module_obs02_normative, module_obs03_normative, module_obs04_normative,
    module_obs05_normative,
)
from modules.advanced_catalogues import executer_ssfo, executer_gamma
from modules.ghost import executer_ghost
from modules.rah_priority import executer_rah_priorites
from modules.critical_normative import executer_sri_v2, executer_csf, executer_pdq
from modules.p5p6 import executer_p5p6
from engine.module_audit_metadata import enrich_module_audit_metadata


def _num235(value):
    try:
        return float(value) if value not in (None, '', 'NC', 'UNPROVEN') else None
    except (TypeError, ValueError):
        return None


def _sum242(value):
    if isinstance(value, dict):
        value = list(value.values())
    if isinstance(value, (list, tuple)):
        numbers = [_num235(item) for item in value]
        return sum(number for number in numbers if number is not None) if all(number is not None for number in numbers) else None
    return _num235(value)


def executer_rah242(partant: Partant, course: Course) -> ModuleResult:
    raw = getattr(partant, 'raw_data', {}) or {}
    primary = _sum242(raw.get('bonus_primaires_positifs'))
    secondary = _sum242(raw.get('bonus_secondaires'))
    result = ModuleResult(nom='RAH-242', actif=True)
    if primary is None or secondary is None:
        result.score = 0.0
        result.details = {'status': 'UNPROVEN', 'bonus_primaires_positifs': primary, 'bonus_secondaires': secondary, 'reason': 'Sommes primaires/secondaires absentes'}
        result.flags.append('RAH242_ENTREES_UNPROVEN')
        return result
    cap = max(0.0, primary)
    allowed_secondary = min(max(0.0, secondary), cap)
    correction = allowed_secondary - max(0.0, secondary)
    result.score = correction
    result.details = {'status': 'CALCULATED', 'bonus_primaires_positifs': primary, 'bonus_secondaires': secondary, 'secondaires_autorises': allowed_secondary, 'correction_pch': correction, 'cap': cap, 'primary_nonpositive_cap_zero': primary <= 0}
    if correction < 0:
        result.flags.append('RAH242_SECONDARY_CAPPED')
    return result


def executer_rah102(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='RAH-102', actif=True)
    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    raw = getattr(partant, 'raw_data', {}) or {}
    distance = _num235(getattr(course, 'distance', None))
    corde = _num235(raw.get('numero_corde', raw.get('corde')))
    stalles = _num235(raw.get('nb_stalles_disponibles', getattr(course, 'nb_partants', None)))
    gru_bonus = raw.get('gru_bonus_corde_specifique')
    applicable_scope = discipline in {'PLAT', 'OBSTACLE'} and distance is not None and distance <= 2400
    required = corde is not None and stalles is not None and stalles > 0 and gru_bonus in (True, False)
    extreme = required and corde > stalles * .75
    applied = applicable_scope and extreme and gru_bonus is False
    details = {'status': 'CALCULATED' if (not applicable_scope or required) else 'UNPROVEN', 'discipline': discipline, 'distance': distance, 'numero_corde': corde, 'nb_stalles_disponibles': stalles, 'dernier_quart': extreme, 'gru_bonus_corde_specifique': gru_bonus, 'applied': applied, 'malus_pch': -4.0 if applied else 0.0, 'cap_factor_total': -15.0, 'flag': 'CORDE_EXTREME_RENFORCE' if applied else None, 'no_trot_autostart': discipline not in {'TROT_ATTELE', 'TROT_MONTE'}}
    result.score = -4.0 if applied else 0.0
    result.details = details
    if applied:
        result.flags.append('CORDE_EXTREME_RENFORCE')
    elif details['status'] == 'UNPROVEN':
        result.flags.append('RAH102_ENTREES_UNPROVEN')
    return result


def executer_rah235(partant: Partant, course: Course) -> ModuleResult:
    raw = getattr(partant, 'raw_data', {}) or {}
    flags = []
    malus = 0.0
    recent = raw.get('derniers_resultats')
    dq3 = raw.get('dq_dans_3_dernieres')
    dq2 = raw.get('dq_dans_2_dernieres')
    if isinstance(recent, list):
        marks = [str(x).upper().strip() for x in recent[:3]]
        if dq3 is None:
            dq3 = any(mark == 'D' for mark in marks)
        if dq2 is None:
            dq2 = any(mark == 'D' for mark in marks[:2])
    stab_pct = _num235(raw.get('stab01_tranche_pct'))
    if dq3 is True and stab_pct is not None and stab_pct <= .10:
        malus -= 6.0
        flags.append('D_RECENT_NON_ABSORBE')
    commentaire = raw.get('commentaire_temperament_risque')
    source = raw.get('commentaire_temperament_source')
    if isinstance(commentaire, str) and commentaire.strip() and isinstance(source, str) and source.strip():
        malus -= 4.0
        flags.append('TEMPERAMENT_RISQUE_DOCUMENTE')
    elif commentaire not in (None, '', 'NC', 'UNPROVEN') and not source:
        flags.append('TEMPERAMENT_RISQUE_SOURCE_UNPROVEN')
    champ_count = sum(1 for other in course.partants if ((getattr(other, 'raw_data', {}) or {}).get('dq_dans_2_dernieres') is True or (isinstance((getattr(other, 'raw_data', {}) or {}).get('derniers_resultats'), list) and any(str(x).upper().strip() == 'D' for x in (getattr(other, 'raw_data', {}) or {}).get('derniers_resultats')[:2]))))
    if champ_count >= 3:
        flags.append('CHAMP_A_RISQUE_DQ_ELEVE')
    evidence = dq3 is not None or dq2 is not None or commentaire not in (None, '', 'NC', 'UNPROVEN') or isinstance(recent, list)
    details = {'status': 'CALCULATED' if evidence else 'UNPROVEN', 'malus_pch': malus, 'flags': flags, 'dq_dans_3_dernieres': dq3, 'dq_dans_2_dernieres': dq2, 'stab01_tranche_pct': stab_pct, 'champ_dq_count': champ_count, 'champ_a_risque_dq_eleve': champ_count >= 3, 'temperament_quote_documented': 'TEMPERAMENT_RISQUE_DOCUMENTE' in flags}
    raw['rah235'] = details
    partant.raw_data = raw
    result = ModuleResult(nom='RAH-235', actif=True)
    result.score = malus
    result.details = details
    result.flags = flags
    return result


def _legacy_module_stab(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE STAB — Stabilité de performance.
    Évalue la régularité des résultats récents.
    """
    result = ModuleResult(nom="STAB", actif=True)

    # Analyse basée sur les signaux de forme
    signaux_forme = [s for s in partant.signaux if s.famille == "F" and s.actif]
    nb_forme = len(signaux_forme)

    if nb_forme >= 3:
        result.score = 8.0
        result.details = {"stabilite": "HAUTE", "nb_signaux_forme": nb_forme}
    elif nb_forme >= 2:
        result.score = 4.0
        result.details = {"stabilite": "MOYENNE", "nb_signaux_forme": nb_forme}
    elif nb_forme == 1:
        result.score = 1.0
        result.details = {"stabilite": "FAIBLE", "nb_signaux_forme": nb_forme}
    else:
        result.score = -3.0
        result.details = {"stabilite": "INSTABLE", "nb_signaux_forme": 0}

    return result


def _legacy_module_h2h_graph(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE H2H_GRAPH — Head-to-Head Graph.
    Analyse des confrontations directes entre partants.
    """
    result = ModuleResult(nom="H2H_GRAPH", actif=True)

    # Score basé sur le nombre de victoires en confrontation directe
    # (simplifié — en production, nécessite historique des courses)
    h2h_signal = next((s for s in partant.signaux if s.code == "B23"), None)
    if h2h_signal and h2h_signal.actif:
        result.score = h2h_signal.valeur * 1.5
        result.details = {"h2h_avantage": True}
    else:
        result.score = 0.0
        result.details = {"h2h_avantage": False}

    return result


def _legacy_module_terrain_dyn(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE_TERRAIN_DYN — Terrain Dynamique.
    Adaptation au terrain du jour.
    """
    result = ModuleResult(nom="MODULE_TERRAIN_DYN", actif=True)

    terrain_signals = [s for s in partant.signaux
                       if s.code in ("B04", "B05", "B42") and s.actif]

    if terrain_signals:
        result.score = sum(s.valeur for s in terrain_signals) * 0.8
        result.details = {
            "terrain_course": course.terrain,
            "adaptation": "BONNE",
            "signaux_terrain": [s.code for s in terrain_signals]
        }
    else:
        result.score = -2.0
        result.details = {
            "terrain_course": course.terrain,
            "adaptation": "INCONNUE",
            "signaux_terrain": []
        }

    return result


def _legacy_module_dist_adapt(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE_DIST_ADAPT — Adaptation à la distance.
    """
    result = ModuleResult(nom="MODULE_DIST_ADAPT", actif=True)

    dist_signals = [s for s in partant.signaux
                    if s.code in ("B15", "B17", "B28", "B33") and s.actif]

    if dist_signals:
        result.score = sum(s.valeur for s in dist_signals) * 0.7
        result.details = {
            "distance_course": course.distance,
            "adaptation": "CONFIRMEE",
            "signaux_distance": [s.code for s in dist_signals]
        }
    else:
        result.score = -1.5
        result.details = {
            "distance_course": course.distance,
            "adaptation": "NON_CONFIRMEE"
        }

    return result


def _legacy_module_mpa_champ(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE MPA_CHAMP — Moyenne des Places d'Arrivée sur le champ.
    """
    result = ModuleResult(nom="MPA_CHAMP", actif=True)

    # Basé sur la forme récente et la cote
    forme_signals = [s for s in partant.signaux if s.famille == "F" and s.actif]
    if forme_signals:
        mpa_score = sum(s.valeur for s in forme_signals) / len(forme_signals)
        result.score = mpa_score * 0.5
        result.details = {"mpa_estimee": mpa_score}
    else:
        result.score = 0.0
        result.details = {"mpa_estimee": "NC"}

    return result


def module_tandem_bonus(partant: Partant, course: Course) -> ModuleResult:
    """TANDEM_BONUS basé sur taux_top5 × coeff_nb × coeff_temps."""
    result = ModuleResult(nom="TANDEM_BONUS", actif=True)
    metric = (partant.extended_metrics or {}).get("tandem_bonus", {})
    if metric.get("status") == "CALCULATED":
        result.score = float(metric.get("value", 0.0))
        result.details = metric
    elif metric.get("status") == "NC":
        result.score = 0.0
        result.flags.append("TANDEM_DATA_NC")
        result.details = metric
    else:
        result.score = 0.0
        result.details = {"status": "UNPROVEN", "reason": "Métrique tandem non calculée"}
    return result


def _legacy_module_overbet_detector(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE OVERBET_DETECTOR — Détection de surcote.
    Identifie les chevaux dont la cote est anormalement basse par rapport aux signaux.
    """
    result = ModuleResult(nom="OVERBET_DETECTOR", actif=True)

    nb_signaux_actifs = len([s for s in partant.signaux if s.actif])

    # Overbet = cote très basse mais peu de signaux
    if partant.cote < 5 and nb_signaux_actifs < 2:
        result.score = -5.0
        result.flags.append("OVERBET_DETECTE")
        result.details = {
            "overbet": True,
            "cote": partant.cote,
            "nb_signaux": nb_signaux_actifs,
            "alerte": "Cote suspecte - peu de signaux justificatifs"
        }
    elif partant.cote < 8 and nb_signaux_actifs < 1:
        result.score = -3.0
        result.flags.append("OVERBET_POSSIBLE")
        result.details = {"overbet": "POSSIBLE"}
    else:
        result.score = 0.0
        result.details = {"overbet": False}

    return result


# =============================================================================
# MODULES CONDITIONNELS
# =============================================================================

def _legacy_module_poids(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE_POIDS — Obligatoire si PLAT + HANDICAP (RAH-46).
    IFT -= 3 si absent.
    """
    result = ModuleResult(nom="MODULE_POIDS", actif=False)

    if course.discipline == Discipline.PLAT and course.est_handicap:
        result.actif = True
        poids_signal = next(
            (s for s in partant.signaux if s.code == "B21" and s.actif),
            None
        )
        if poids_signal:
            # Bonus si poids favorable
            if partant.poids > 0:
                result.score = poids_signal.valeur * 0.8
                result.details = {"poids": partant.poids, "impact": "FAVORABLE"}
            else:
                result.score = 0.0
                result.details = {"poids": "NC", "flag": "MANQUANT"}
        else:
            result.score = -2.0
            result.details = {"impact": "DEFAVORABLE_OU_NC"}

    return result


def _legacy_module_recul(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE_RECUL — Obligatoire si TROT + HANDICAP (RAH-47).
    IFT -= 2 si absent.
    """
    result = ModuleResult(nom="MODULE_RECUL", actif=False)

    if course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE) and course.est_handicap:
        result.actif = True
        # Analyse du recul par rapport à la distance de base
        result.score = 0.0
        result.details = {"recul_metres": 0, "impact": "NEUTRE"}

    return result


def _legacy_module_tact(partant: Partant, course: Course) -> ModuleResult:
    """
    MODULE TACT — TROT uniquement.
    Inclut TACT-05 Vincennes.
    """
    result = ModuleResult(nom="TACT", actif=False)

    if course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE):
        result.actif = True

        # Score basé sur la RK et le type de départ
        if partant.rk_brute is not None:
            base_tact = partant.rk_brute * 0.3
            # Bonus Vincennes
            if course.hippodrome.upper() == "VINCENNES":
                base_tact *= 1.15  # TACT-05
            result.score = base_tact
            result.details = {
                "rk_brute": partant.rk_brute,
                "vincennes_bonus": course.hippodrome.upper() == "VINCENNES"
            }
        else:
            result.score = 0.0
            result.flags.append("RK_MANQUANTE")
            result.details = {"rk_brute": "NC"}

    return result


# =============================================================================
# VERSIONS NORMATIVES RELIÉES AU REGISTRE
# =============================================================================

module_stab = module_stab_normative
module_h2h_graph = module_h2h_normative
module_terrain_dyn = module_terrain_normative
module_dist_adapt = module_dist_normative
module_mpa_champ = module_mpa_normative
module_overbet_detector = module_overbet_normative
module_poids = module_poids_normative
module_recul = module_recul_normative
module_tact = module_tact_normative
module_iff = module_iff_normative
module_nrc = module_nrc_normative
module_bsh = module_bsh_normative
module_bsc = module_bsc_normative
module_cre = module_cre_normative
module_forme_lineaire = module_forme_lineaire_normative


# =============================================================================
# EXÉCUTION DE TOUS LES MODULES
# =============================================================================

def executer_modules(course: Course) -> Course:
    """
    Exécute tous les modules obligatoires et conditionnels pour chaque partant.
    """
    for partant in course.partants:
        modules = []

        # Modules obligatoires (toujours actifs)
        modules.append(module_stab(partant, course))
        modules.append(module_h2h_graph(partant, course))
        modules.append(module_terrain_dyn(partant, course))
        modules.append(module_dist_adapt(partant, course))
        modules.append(module_mpa_champ(partant, course))
        modules.append(module_tandem_bonus(partant, course))
        modules.append(module_overbet_detector(partant, course))
        modules.append(module_iff(partant, course))
        modules.append(module_nrc(partant, course))
        modules.append(module_bsh(partant, course))
        modules.append(module_bsc(partant, course))
        modules.append(module_cre(partant, course))
        modules.append(module_forme_lineaire(partant, course))
        modules.append(executer_sri_v2(partant, course))
        modules.append(executer_csf(partant, course))
        modules.append(executer_pdq(partant, course))
        modules.append(executer_p5p6(partant, course))
        modules.append(executer_rah235(partant, course))
        modules.append(executer_rah102(partant, course))
        modules.append(executer_rah242(partant, course))
        modules.append(executer_ssfo(partant, course))
        modules.append(executer_gamma(partant, course))
        modules.append(executer_ghost(partant, course))
        modules.append(executer_rah_priorites(partant, course))

        # Modules conditionnels
        modules.append(module_poids(partant, course))
        modules.append(module_recul(partant, course))
        modules.append(module_tact(partant, course))

        # Modules disciplinaires autonomes : score nul et statut NC si l’historique requis est absent.
        # Ils ne sont actifs que pour leur discipline; les effets délégués évitent tout double comptage.
        if course.discipline == Discipline.PLAT:
            modules.extend([
                module_plat01_normative(partant, course), module_plat02_normative(partant, course),
                module_plat03_normative(partant, course), module_plat04_normative(partant, course),
            ])
        elif course.discipline in (Discipline.TROT_ATTELE, Discipline.TROT_MONTE):
            modules.extend([
                module_trot01_normative(partant, course), module_trot02_normative(partant, course),
                module_trot03_normative(partant, course), module_trot04_normative(partant, course),
            ])
        elif course.discipline in (Discipline.OBSTACLE, Discipline.HAIES):
            modules.extend([
                module_obs01_normative(partant, course), module_obs02_normative(partant, course),
                module_obs03_normative(partant, course), module_obs04_normative(partant, course),
                module_obs05_normative(partant, course),
            ])

        modules = [enrich_module_audit_metadata(module, partant, course) for module in modules]
        partant.modules_results = modules

    return course
