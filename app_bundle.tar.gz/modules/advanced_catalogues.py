"""Catalogues avancés SSFO et GAMMA, calculés avec plafonds et preuves."""
from __future__ import annotations

from typing import Any, Dict
from engine.models import Course, Partant, ModuleResult

VALIDATED_SSFO = {'f1': 1.0, 'f7': 1.0, 'f10': 1.0, 'f11': 1.0, 'f16': 1.0, 'f17': 1.0, 'f21': 1.0, 'f24': 1.0, 'f30': 1.0, 'f31': 1.0, 'f32': 1.0}
WEAK_SSFO = {'f2': .35, 'f3': .35, 'f4': .35, 'f5': .35, 'f6': .35, 'f8': .35, 'f9': .35, 'f12': .35, 'f13': .35, 'f14': .35, 'f15': .35, 'f18': .35, 'f19': .35, 'f20': .35, 'f22': .35, 'f23': .35, 'f25': .35, 'f26': .35, 'f27': .35, 'f28': .35, 'f29': .35}


def _raw(p: Partant, key: str, default=None):
    return (getattr(p, 'raw_data', {}) or {}).get(key, default)


def _num(value, default=None):
    try:
        return float(value) if value not in (None, '', 'NC') else default
    except (TypeError, ValueError):
        return default


def evaluer_ssfo(partant: Partant, course: Course) -> Dict[str, Any]:
    raw = dict(getattr(partant, 'raw_data', {}) or {})
    explicit = raw.get('ssfo_signals', {}) or {}
    rules: Dict[str, Dict[str, Any]] = {}
    calculated: Dict[str, Any] = {}

    rangs = raw.get('rangs_dernieres', raw.get('rangs_6_dernieres'))
    if isinstance(rangs, list) and len(rangs) >= 4:
        last = _num(rangs[-1])
        previous = [_num(x) for x in rangs[-4:-1] if _num(x) is not None]
        calculated['f1'] = (last is not None and len(previous) == 3 and last <= sum(previous) / 3 - 2, 'CALCULATED')
    else:
        calculated['f1'] = (False, 'UNPROVEN')

    current_distance = _num(getattr(course, 'distance', None))
    hist_dist = raw.get('historique_distances_perf', []) or []
    top3_distances = [(_num(row[0]), _num(row[1])) for row in hist_dist if isinstance(row, (list, tuple)) and len(row) >= 2]
    calculated['f7'] = (current_distance is not None and any(distance is not None and rank is not None and abs(distance - current_distance) <= 50 and rank <= 3 for distance, rank in top3_distances), 'CALCULATED') if hist_dist else (False, 'UNPROVEN')

    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    deferrage = str(raw.get('deferrage', raw.get('ferrure', '')) or '').upper()
    d4 = deferrage in {'D4', 'DÉFERRÉ_4', 'DEFERRÉ_4', 'DEFERRAGE_4'} or bool(raw.get('deferrage_4_pieds')) or bool(raw.get('deferrage_4_pieds_premiere'))
    calculated['f10'] = (discipline in {'TROT_ATTELE', 'TROT_MONTE'} and current_distance is not None and current_distance <= 2200 and d4, 'CALCULATED') if current_distance is not None else (False, 'UNPROVEN')

    nb_hippo = _num(raw.get('nb_courses_hippodrome'))
    profil_similaire = raw.get('profil_hippodrome_similaire')
    calculated['f11'] = (nb_hippo >= 2 or profil_similaire is True, 'CALCULATED') if nb_hippo is not None or profil_similaire is not None else (False, 'UNPROVEN')

    cote = _num(partant.cote)
    calculated['f16'] = (12 <= cote <= 22, 'CALCULATED') if cote is not None else (False, 'UNPROVEN')
    driver_rank = _num(raw.get('driver_classement_national'))
    calculated['f17'] = (driver_rank <= 5, 'CALCULATED') if driver_rank is not None else (False, 'UNPROVEN')
    rk_gain = _num(raw.get('rk_amelioration'))
    calculated['f21'] = (.10 <= rk_gain <= .30, 'CALCULATED') if rk_gain is not None else (False, 'UNPROVEN')
    mi_course = _num(raw.get('position_mi_course'))
    rang_final = _num(raw.get('rang_final'))
    calculated['f24'] = (discipline in {'PLAT', 'OBSTACLE', 'HAIES'} and current_distance is not None and current_distance >= 2000 and mi_course is not None and mi_course > 8 and rang_final is not None and rang_final <= 5, 'CALCULATED') if discipline in {'PLAT', 'OBSTACLE', 'HAIES'} else (False, 'UNPROVEN')
    driver_new = raw.get('driver_nouveau_top10')
    old_perf = _num(raw.get('ancien_driver_performance'))
    new_perf = _num(raw.get('nouveau_driver_performance'))
    calculated['f30'] = (driver_new is True and old_perf is not None and new_perf is not None and new_perf > old_perf, 'CALCULATED') if driver_new is not None or old_perf is not None or new_perf is not None else (False, 'UNPROVEN')
    pente = _num(raw.get('rah244_pente_score_effective', raw.get('pente_score')))
    calculated['f31'] = (pente >= .07, 'CALCULATED') if pente is not None else (False, 'UNPROVEN')
    module_flags = {flag for module in getattr(partant, 'modules_results', []) for flag in getattr(module, 'flags', [])}
    calculated['f32'] = (not bool(raw.get('kill_list')) and 'STAB_DQ_SERIE_CRITIQUE' not in module_flags and 'KILL_LIST_M25_EQUIVALENT' not in module_flags, 'CALCULATED')

    for code, weight in {**VALIDATED_SSFO, **WEAK_SSFO}.items():
        if code in explicit:
            value = explicit.get(code)
            status = 'ACTIVE' if value is True else 'INACTIVE' if value is False else 'UNPROVEN'
            provenance = 'EXPLICIT_SOURCE'
        elif code in calculated:
            value, calc_status = calculated[code]
            status = 'ACTIVE' if value is True and calc_status == 'CALCULATED' else 'INACTIVE' if calc_status == 'CALCULATED' else 'UNPROVEN'
            provenance = calc_status
        else:
            value = raw.get(code)
            status = 'ACTIVE' if value is True else 'INACTIVE' if value is False else 'UNPROVEN'
            provenance = 'RAW_FIELD' if value is not None else 'UNPROVEN'
        rules[code] = {'code': code, 'weight': weight, 'status': status, 'evidence': value, 'provenance': provenance}
    cote = partant.cote
    active = [r for r in rules.values() if r['status'] == 'ACTIVE']
    eligible = cote is not None and cote >= 8 and bool(active)
    raw_score = sum(r['weight'] for r in active) if eligible else 0.0
    bonus = min(10.0, raw_score * 2.0)
    convergence_multiplier = 1.5 if len(active) >= 3 else 1.0
    multiplier = 1.3 if cote is not None and cote >= 25 else 1.0
    bonus_final = min(10.0, bonus * convergence_multiplier * multiplier)
    if _raw(partant, 'pch_final') is not None and float(_raw(partant, 'pch_final')) >= 160:
        bonus_final = 0.0
    rah208_zone = cote is not None and 12 <= cote <= 22
    details = {
        'rah208': {'status': 'CALCULATED' if cote is not None else 'UNPROVEN', 'value_zone_12_22': rah208_zone, 'bonus_pch_separate': 0.0, 'merged_into': 'SSFO_f16'},
        'rules': rules,
        'eligible': eligible,
        'raw_ssfo': raw_score,
        'bonus_ssfo': bonus,
        'convergence_multiplier': convergence_multiplier,
        'multiplier_cote': multiplier,
        'bonus_ssfo_final': bonus_final,
        'pool_eligible': bonus_final >= 5,
        'status': 'CALCULATED' if active else 'UNPROVEN',
    }
    partant.ssfo_details = details
    return details


def executer_ssfo(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='SSFO', actif=True)
    details = evaluer_ssfo(partant, course)
    result.score = details['bonus_ssfo_final']
    result.details = details
    result.flags = [code for code, item in details['rules'].items() if item['status'] == 'ACTIVE']
    return result


def evaluer_gamma(partant: Partant, course: Course) -> Dict[str, Any]:
    raw = dict(getattr(partant, 'raw_data', {}) or {})
    source = raw.get('gamma_signals', {}) or {}
    cote = _num(partant.cote)
    discipline = str(getattr(course.discipline, 'value', course.discipline) or '').upper()
    def explicit_or_calculated(code, calculated):
        if code in source:
            value = source.get(code)
            return value is True or (isinstance(value, (int, float)) and value > 0), 'EXPLICIT_SOURCE'
        return calculated

    rules: Dict[str, Dict[str, Any]] = {}
    effects = {'RAH-195': 0.0, 'RAH-196': 0.0, 'RAH-197': 0.0, 'RAH-202': 0.0, 'RAH-198': 0.0, 'RAH-199': 0.0, 'RAH-200': 3.0, 'RAH-203': 4.0, 'RAH-204': 2.0, 'RAH-205': 3.0, 'RAH-206': 0.0, 'RAH-209': 2.0,
               'RAH-179': 2.0, 'RAH-180': 2.0, 'RAH-181': 2.0, 'RAH-182': 3.0, 'RAH-183': 3.0, 'RAH-184': 2.0, 'RAH-186': 2.0}

    rangs3 = raw.get('rangs_3_dernieres')
    champ_avg = _num(raw.get('moyenne_rangs_champ'))
    calc = {}
    if isinstance(rangs3, list) and len(rangs3) >= 3 and champ_avg is not None and cote is not None:
        calc['RAH-179'] = (sum(float(x) for x in rangs3[-3:]) / 3.0 < champ_avg and cote > 15), 'CALCULATED'
    else:
        calc['RAH-179'] = False, 'UNPROVEN'
    calc['RAH-180'] = (bool(raw.get('top3_turf_bzh')) and cote is not None and cote > 12, 'CALCULATED') if raw.get('top3_turf_bzh') is not None and cote is not None else (False, 'UNPROVEN')
    duo_courses, duo_win = _num(raw.get('duo_courses_12m')), _num(raw.get('duo_taux_victoires_12m'))
    calc['RAH-181'] = (duo_courses >= 3 and duo_win > .30 and cote > 10, 'CALCULATED') if None not in (duo_courses, duo_win, cote) else (False, 'UNPROVEN')
    exact_top5, exact_courses, last_elsewhere = _num(raw.get('top5_parcours_exact_100pct')), _num(raw.get('courses_parcours_exact')), _num(raw.get('dernier_rang_ailleurs'))
    calc['RAH-182'] = (exact_top5 == 1 and exact_courses >= 2 and last_elsewhere > 8 and cote > 15, 'CALCULATED') if None not in (exact_top5, exact_courses, last_elsewhere, cote) else (False, 'UNPROVEN')
    position = _num(raw.get('numero_corde', raw.get('numero_autostart')))
    nb = _num(getattr(course, 'nb_partants', None))
    calc['RAH-183'] = (discipline in {'PLAT', 'OBSTACLE'} and str(course.hippodrome).upper() == 'AUTEUIL' and nb is not None and nb >= 17 and position is not None and position >= 13 and cote is not None, 'CALCULATED') if str(course.hippodrome).upper() == 'AUTEUIL' else (False, 'UNPROVEN')
    stable_count, stable_max = _num(raw.get('ecurie_nb_engages')), raw.get('cote_plus_elevee_ecurie')
    calc['RAH-184'] = (discipline in {'PLAT', 'OBSTACLE'} and str(course.hippodrome).upper() == 'AUTEUIL' and stable_count is not None and stable_count >= 3 and bool(stable_max), 'CALCULATED') if str(course.hippodrome).upper() == 'AUTEUIL' else (False, 'UNPROVEN')
    rythme = str(raw.get('rythme_effectif', '')).upper()
    rapide = _num(raw.get('top5_rapide_5'))
    lent = _num(raw.get('top5_lent_5'))
    style = str(raw.get('style_mpa', '')).upper()
    if rythme in {'RAPIDE', 'TRES_RAPIDE'} and rapide is not None and lent is not None:
        calc['RAH-186'] = (rapide >= 2 and lent == 0 and cote is not None and cote > 15), 'CALCULATED'
    elif rythme == 'LENT' and style == 'ATTENTISTE' and lent is not None and rapide is not None:
        calc['RAH-186'] = (lent >= 2 and rapide == 0 and cote is not None and cote > 15), 'CALCULATED'
    else:
        calc['RAH-186'] = False, 'UNPROVEN'

    gap_relative = _num(raw.get('ecart_relatif_score', raw.get('chaos_index_ecart')))
    calc['RAH-198'] = (gap_relative >= 2.0, 'CALCULATED') if gap_relative is not None else (False, 'UNPROVEN')
    steam_move = _num(raw.get('steam_move_pct'))
    steam_regular = raw.get('steam_move_regulier')
    calc['RAH-199'] = (steam_regular is True and steam_move is not None and abs(steam_move) >= .10, 'CALCULATED') if steam_regular is not None or steam_move is not None else (False, 'UNPROVEN')
    families = set(getattr(partant, 'familles_actives', []) or raw.get('familles_convergentes', []) or [])
    intention = bool(set(raw.get('familles_intention', []) or []) & families) or bool(raw.get('intention_signal'))
    calc['RAH-200'] = (len(families) >= 4, 'CALCULATED') if families else (False, 'UNPROVEN')
    driver_weekly = _num(raw.get('driver_classement_hebdomadaire', raw.get('driver_classement_national')))
    calc['RAH-203'] = (driver_weekly <= 10 and cote is not None and cote > 40, 'CALCULATED') if driver_weekly is not None and cote is not None else (False, 'UNPROVEN')
    calc['RAH-204'] = (raw.get('bio_rythme_saisonnier') is True, 'CALCULATED') if raw.get('bio_rythme_saisonnier') is not None else (False, 'UNPROVEN')
    post_dai = raw.get('rebond_post_dai') is True or raw.get('post_dai_recent') is True
    calc['RAH-205'] = (post_dai and cote is not None and cote < 15, 'CALCULATED') if post_dai or cote is not None else (False, 'UNPROVEN')
    absence = _num(raw.get('absence_jours'))
    gains = _num(raw.get('gains_totaux'))
    plafond = _num(raw.get('plafond_elimination'))
    calc['RAH-206'] = (absence is not None and absence > 90 and driver_weekly is not None and driver_weekly <= 10 and gains is not None and plafond is not None and plafond > 0 and gains >= .85 * plafond, 'CALCULATED') if any(x is not None for x in (absence, driver_weekly, gains, plafond)) else (False, 'UNPROVEN')
    strict_count = _num(raw.get('strict_bonus_count'))
    if strict_count is None:
        strict_count = len(raw.get('strict_bonus_flags', []) or [])
    calc['RAH-209'] = (strict_count >= 3, 'CALCULATED') if strict_count is not None else (False, 'UNPROVEN')

    gamma_age = _num(raw.get('gamma_age_jours'))
    decay = 1.0 if gamma_age is None or gamma_age <= 180 else .75 if gamma_age <= 365 else .50 if gamma_age <= 730 else .25
    supplemente = raw.get('supplemente', raw.get('supplemente_detecte'))
    t4_second_outsider = raw.get('t4_second_outsider', raw.get('deuxieme_outsider_t4'))
    parameters_observed = any(key in raw for key in ('gamma_cap', 'gamma_age_jours', 'gamma_effects', 'gamma_parameters'))
    parameter_values = {'cap': _num(raw.get('gamma_cap', 8.0)), 'decay_coefficient': decay, 'effects_bounded': raw.get('gamma_effects_bounded', True)}
    calc['RAH-195'] = (parameter_values['cap'] is not None and 0 <= parameter_values['cap'] <= 8 and .25 <= decay <= 1 and parameter_values['effects_bounded'] is True, 'CALCULATED' if parameters_observed or parameter_values['cap'] == 8.0 else 'UNPROVEN')
    calc['RAH-196'] = (supplemente is True, 'CALCULATED' if supplemente is not None else 'UNPROVEN')
    calc['RAH-197'] = (t4_second_outsider is True, 'CALCULATED' if t4_second_outsider is not None else 'UNPROVEN')
    gamma202 = raw.get('gt_insider_move', raw.get('RAH-202'))
    calc['RAH-202'] = (gamma202 is True, 'CALCULATED' if gamma202 is not None else 'UNPROVEN')
    total = 0.0
    for code, effect in effects.items():
        if code in calc:
            calculated_value, calculated_status = calc[code]
        else:
            calculated_value, calculated_status = False, 'UNPROVEN'
        active, provenance = explicit_or_calculated(code, (calculated_value, calculated_status))
        status = 'ACTIVE' if active else 'INACTIVE' if (code in source and source.get(code) is False) else provenance
        value = effect if active else 0.0
        if code == 'RAH-183' and active:
            value = 3.0 if cote is not None and cote > 15 else 1.0
        if code == 'RAH-200' and active and intention:
            value = 4.0
        if code == 'RAH-209' and active:
            value = 2.0
        rules[code] = {'code': code, 'status': status, 'raw': source.get(code), 'calculated': calculated_value, 'value': value, 'provenance': provenance}
        total += value
    total = min(8.0, total)
    if decay < 1.0:
        total *= decay
        for row in rules.values():
            if row['status'] == 'ACTIVE':
                row['decay_coefficient'] = decay
                row['flags'] = ['GAMMA_DECOTE_TEMPORELLE']
    details = {'rules': rules, 'gamma_score': total, 'cap': 8.0, 'decay_coefficient': decay, 'parameters_guard': {'status': 'CALCULATED' if calc['RAH-195'][1] == 'CALCULATED' else 'UNPROVEN', 'valid': calc['RAH-195'][0], 'values': parameter_values}, 'supplemente_observation': {'status': 'CALCULATED' if calc['RAH-196'][1] == 'CALCULATED' else 'UNPROVEN', 'detected': supplemente, 'weight': 0}, 'second_outsider_t4_observation': {'status': 'CALCULATED' if calc['RAH-197'][1] == 'CALCULATED' else 'UNPROVEN', 'detected': t4_second_outsider, 'weight': 0}, 'rah202_fusion': {'status': 'CALCULATED' if calc['RAH-202'][1] == 'CALCULATED' else 'UNPROVEN', 'detected': gamma202, 'merged_into': ['RAH-251', 'RAH-261'], 'weight': 0, 'no_double_count': True}, 'intention_convergence': intention, 'status': 'CALCULATED' if any(r['status'] == 'ACTIVE' for r in rules.values()) else 'UNPROVEN'}
    partant.gamma_details = details
    return details


def executer_gamma(partant: Partant, course: Course) -> ModuleResult:
    result = ModuleResult(nom='GAMMA', actif=True)
    details = evaluer_gamma(partant, course)
    result.score = details['gamma_score']
    result.details = details
    result.flags = [code for code, item in details['rules'].items() if item['status'] == 'ACTIVE']
    return result
